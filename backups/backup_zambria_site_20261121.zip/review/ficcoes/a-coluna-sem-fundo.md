---
titulo: "A Coluna Sem Fundo"
resumo: "Um espeleomergulhador desce além dos 220 metros na Lagoa Misteriosa, em Jardim (MS), em busca de um fundo que ninguém chegou a tocar. O que encontra na coluna d'água transforma o mistério natural em condenação pessoal."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "a-coluna-sem-fundo"
tipo: "ficcao"
fonte_pesquisa: "G1, visitbonito.com.br, Gazeta de SP"
---

# A Coluna Sem Fundo

O deque de madeira fica suspenso sobre a dolina como uma prancha de mergulho sobre um buraco de tinta. De onde estou, a Lagoa Misteriosa, em Jardim, no sudoeste do Mato Grosso do Sul, não revela nada além de azul. Água tão transparente que, a quarenta metros de profundidade, ainda se distingue a copa das árvores que contornam a fenda calcária. Um azul que não tem fim visível. Ninguém jamais viu o fundo.

Em 1998, o espeleomergulhador Gilberto Menezes de Oliveira desceu até 220 metros, valendo-se de oito misturas respiratórias diferentes ao longo de oito horas de imersão. Não tocou a rocha. A coluna d'água continuou abaixo dele, fria e sem medida, e ele subiu com os pulmões queimando e a certeza de que a lagoa guarda um segredo que não pretende dividir. Desde então, a marca dos 220 metros permanece como o ponto mais profundo alcançado por um ser humano ali — e também como o limite onde a razão, na maioria das vezes, desiste.

Eu não vim para desistir.

Chamo-me Elias. Fui guia de turismo na Serra da Bodoquena por mais de uma década, vi dezenas de pessoas flutuarem na superfície da lagoa, boquiabertas, tirando fotos do abismo transparente com celulares à prova d'água. Nenhuma delas desceu além dos primeiros metros. O passeio turístico é controlado, raso, seguro: flutuação assistida, instrutor ao lado, respiração pela superfície. Eu queria o oposto. Queria ir até onde o azul deixa de ser cenário e se torna palco.

O guia que me acompanha até a borda chama-se Paulo. Não tenta me dissuadir, apenas avisa: "A partir de seis metros, isto deixa de ser lagoa e passa a ser caverna de gênese freática. A partir daí, a água circula do lençol subterrâneo. Não há corrente visível, mas há pressão. E não há fim conhecido." Paulo é um homem de poucas palavras e muitos mergulhos. Sabe que não vai me impedir. Sabe também que, se eu não voltar, ninguém vai procurar meu corpo a não ser ele, e mesmo assim só porque eu lhe pedi.

Visto o equipamento. Rebreather, dois tanques de mergulho, linhas de guia, computador de pulso, luzes. A máscara sela o rosto. O primeiro metro de água é morno; o segundo, já frio. Desço lentamente, de pé sobre a linha, olhando para baixo. A transparência é quase ofensiva: consigo ver o fundo aparente da dolina, uma camada de lodo e rochas calcárias a uns dez metros, e abaixo dela o azul continua, mais denso, mais escuro. Não há limite. A água não repousa sobre nada que eu possa ver.

Aos quarenta metros, as copas das árvores ainda flutuam ao meu redor, submersas, fantasmagóricas, como se a floresta tivesse sido engolida inteira e continuasse crescendo de cabeça para baixo. A luz do dia ainda chega, filtrada, verde-azulada. Aqui o silêncio não é ausência de som: é a presença ativa de algo que não emite ruído. Meu próprio respirar pelo rebreather soa alto demais, um sopro mecânico que ecoa dentro do crânio.

Aos cem metros, a narcose começa a bater. Não é o êxtase dos mergulhadores recreativos; é uma clareza doentia, como se meus pensamentos tivessem ganhado peso e caísse junto comigo, mais rápido que o corpo. A luz agora é só a minha. Dois feixes, um de cada lado, cortando a água. As paredes da caverna se mostram esporadicamente: rocha calcária úmida, estalactites submersas, fendas que parecem olhar de volta. Não toco nelas. Há uma regra não escrita em espeleomergulho: o que você não vê, não toque.

Aos duzentos e vinte metros, chego ao limite de Gilberto Menezes de Oliveira. Pauso. Olho para baixo. A linha de guia continua, mais fina agora, quase invisível contra a escuridão. Não há rocha. Não há lodo. Não há fim. A coluna d'água simplesmente se estende, mais abaixo, mais abaixo, até onde a luz da minha lanterna se rende e vira um ponto fraco, então nada.

É nesse ponto que algo muda.

Não é um barulho. Não é um movimento. É a sensação de que a pressão, que até então me empurrava de todos os lados de forma uniforme, passou a puxar de um lado só — de baixo. O computador de pulso marca profundidade crescente, mas o relógio de superfície, se alguém ainda estivesse me observando, diria que estou parado. A água ao redor fica mais densa, mais escura, quase viscosa. E, a uns poucos metros abaixo de mim, algo brilha.

Não é reflexo da minha lanterna. É um brilho próprio, azul e fraco, como uma chama submersa, vindo do ponto onde a coluna deveria terminar e não termina. Desço mais. Dez metros. Vinte. A pressão agora dói nos ouvidos, nos seios da face, nos dentes. O brilho não se aproxima nem se afasta. Ele está à minha frente, sempre à mesma distância, independente de quanto eu desça. Como um horizonte que se move junto com quem caminha.

Desligo uma das luzes. Depois a outra. Fico no escuro total, com apenas o brilho à frente. E então percebo que não é um objeto. É uma abertura. Uma boca na rocha, ou no que parece ser rocha, que emite essa luz fraca e pulsante. Não é luz do sol. Não é luz de superfície. É luz que nasce debaixo da água, debaixo da terra, debaixo de tudo o que conheço.

Estendo a mão. A luva de neoprene arrasta na água. Meus dedos quase tocam a borda da abertura. É então que sinto o toque.

Não é na mão. É na mente. Uma voz que não usa palavras, apenas uma impressão: você não é o primeiro. Você não será o último. A coluna não tem fundo porque o fundo não é um lugar. É uma garganta. E estamos todos, acima dela, suspensos como iscas.

Subo.

Não sinto o tempo passar. A narcose, agora, é minha aliada: me torna lento, distante, quase indiferente à própria sobrevivência. Pelo caminho, olho para cima e vejo a superfície muito distante, um círculo de luz cada vez menor, e vejo — ou imagino ver — algo subindo comigo, não na água, mas dentro dela, algo que desliza pela coluna sem fazer bolhas, sem movimento visível, apenas presença. Algo que respira na mesma frequência que meus pulmões.

Chego aos dez metros. A luz do dia retorna. Paulo está na superfície, olhando para baixo, segurando a linha. Ele me vê subir. Sinto suas mãos me ajudando a tirar o equipamento, a tirar a máscara. Respirei ar de verdade depois de horas. O sol da Serra da Bodoquena está alto, cruel, comum.

Paulo me pergunta o que encontrei. Não respondo. Não consigo responder. O que encontrei não cabe em palavras, e se cabesse, ele não acreditaria. Ninguém acreditaria. A lagoa continua ali, transparente, azul, convidativa. Turistas vão tirar fotos do abismo. Guia de turismo vai explicar que a profundidade é desconhecida, que já chegaram a 220 metros e não acharam o fundo. Eles vão sorrir. Eles vão voltar para casa.

E eu vou voltar também, de alguma forma. O corpo volta. A mente, não. Fica ali, suspensa na coluna d'água, a ouvirem a garganta de baixo. Porque o fundo não é um lugar que se chega. É um lugar que chega até você, no silêncio, quando a luz acaba e a água deixa de ser elemento para se tornar dente.

A Lagoa Misteriosa segue sem fundo. E agora, eu também.

## Fontes de inspiração

- G1 (Mato Grosso do Sul): "Lagoa Misteriosa: o que explica a água azul e cristalina?" — caverna inundada de profundidade desconhecida, explorada até 220 metros, localizada em dolina na Serra da Bodoquena, Jardim (MS), visibilidade superior a 40 metros.
- visitbonito.com.br: Lagoa Misteriosa, Jardim (MS), apontada como sétima caverna inundada mais profunda do Brasil; marca de Gilberto Menezes de Oliveira (1998) de mais de 220 metros sem alcançar o fundo; caverna de gênese freática a partir de seis metros.
- Gazeta de SP: coluna d'água acima de 220 metros com fundo inalcançável; águas cristalinas e abismo transparente sobre a dolina.

Todas as fontes acima serviram apenas como inspiração de campo. A narrativa, os personagens e os eventos são ficcionalizados; não há cópia de trechos externos.
