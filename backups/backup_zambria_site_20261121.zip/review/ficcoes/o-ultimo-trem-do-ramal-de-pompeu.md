---
titulo: "O Último Trem do Ramal de Pompéu"
resumo: "Um ex-fiscal de via investiga um apito que soa às três e dezessete da manhã num ramal desativado da Estrada de Ferro Oeste de Minas e descobre que o horário não admite passageiros vivos."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "o-ultimo-trem-do-ramal-de-pompeu"
tipo: "ficcao"
fonte_pesquisa: "Wikipedia - Estrada de Ferro Oeste de Minas; Olhares por Minas
---

O apito soa às três e dezessete da manhã. Não consta de nenhum horário oficial, nunca constou. O ramal Pompéu–Paraopeba da Estrada de Ferro Oeste de Minas foi desativado no início dos anos 1970; os trilhos foram entregues à ferrugem e ao capim, as estações — São Gonçalo do Pará, Velho da Taipa, Martinho Campos, Pompéu, Paraopeba — foram trancadas e esquecidas. Eu sei disso porque carimbei, com as minhas próprias mãos, os horários que depois cancelaram. Fui fiscal de via da Rede Ferroviária Federal até a encampação da malha, e guardo na gaveta da escrivaninha um caderno amarelecido onde anoto, dia após dia, a hora exata em que o apito soa e nada, absolutamente nada, passa nos trilhos.

Na primeira vez, atribuí o som a insetos noturnos ou ao vento nos fios de alta tensão. Na segunda, deixei de rir. Na terceira, atravessei a cerca de arame farpado nos arredores de Pompéu com uma lanterna de pilha fraca e um revólver que não sei usar, e esperei no cruzamento onde a estrada de barro corta a bitola estreita — setecentos e sessenta e dois milímetros de largura, trilhos feitos para máquinas pequenas, para um Brasil que ainda acreditava em progresso medido em quilômetros de aço.

Era uma quarta-feira de outubro, ou novembro; os meses se misturam quando se dorme pouco. Às três e dezessete, o apito soou. Não um apito de locomotiva a diesel, rouco e mecânico, mas um apito longo, modulado, de máquina a vapor — o tipo de som que a Oeste de Minas abandonara décadas atrás. Vi a luz primeiro: um único farol branco, imóvel na curva antes de Velho da Taipa, como se o trem não se aproximasse, mas simplesmente aparecesse. Não houve estalidos de dormentes de madeira sob o peso, não houve rangido de aço sobre a bitola, não houve o cheiro de óleo queimado e carvão. Havia apenas o farol e o apito, e o silêncio dos grilos que parara exatamente no momento em que o som começou.

O trem parou. Ou melhor: o trem já estava parado quando eu percebi sua presença. Vagões escuros, janelas pretas, sem luz interna. Não li numeração nas laterais. Subi no degrau — a porta estava aberta, embora nada a segurasse — e o interior cheirava a mofo e a cobertor de lã guardado por anos em baú úmido. Nos bancos de madeira estavam eles: passageiros em trajes de outra época, paletós escuros, vestidos longos, chapéus abaixados sobre o rosto. Nenhum se mexeu. Nenhum respirou audivelmente. Olhei para as mãos deles. Eram mãos de quem está acostumado a segurar ferramentas de via, ou lápis de carimbo de estação, ou nada.

Desci antes que o farol se apagasse. Corri de volta ao cruzamento. Quando olhei para trás, não havia trilho, nem trem, nem farol: apenas a curva do matagal e a poeira levantada pelos meus próprios passos.

Comecei a anotar no caderno. Descobri que o apito soa sempre na mesma data: treze de outubro. Em 1963, um descarrilamento no trecho entre Velho da Taipa e Martinho Campos matou dezenas de pessoas — funcionários da via, passageiros de terceira classe, um chefe de estação de Pompéu que voltava de licença médica. Em 1968, um incêndio num vagão de carga de Paraopeba deixou corpos irreconhecíveis, e a ferrovia enterrou o que restou junto aos trilhos, sem inquérito, sem jornal. Os nomes desses mortos estão em relatórios que li nos arquivos da RFFSA antes de serem trancados a chave. E esses mesmos nomes — li depois, com o coração batendo nos ouvidos — estavam nos bilhetes que encontrei nos bancos de madeira do trem que não existe: bilhetes amarelos, rasgados à pressa, carimbados com estações que não aparecem mais em mapa algum.

Na segunda aparição, fui preparado. Levei uma câmera e um gravador de fita. Esperei no velho prédio da estação de Pompéu, telhado caído, piso de azulejo quebrado. O apito soou às três e dezessete em ponto. O trem passou devagar, sem parar, e pelas janelas vi os passageiros olhando na minha direção — não para mim, exatamente, mas por cima do meu ombro, como se esperassem alguém que ainda não tinha chegado. A câmera não registrou nada: o filme saiu em branco, exceto por uma mancha escura no lugar onde a locomotiva deveria estar. O gravador capturou o apito, e atrás dele uma voz, fraca, dizendo meu nome completo. Eu nunca disse meu nome para ninguém naquela linha. Eu nunca disse meu nome para os mortos.

Na terceira vez, o trem parou para mim.

A porta abriu sozinha no cruzamento de Pompéu. O condutor apareceu na plataforma do vagão da frente: farda escura, boné abaçado, luvas brancas sujas de graxa. Ele não tinha rosto. Não no sentido de estar desfigurado — tinha a pele lisa, contínua, como uma máscara de cera esquecida ao sol, onde os olhos e a boca deveriam estar. Estendeu a mão, fez um gesto de convite. Eu subi. Sentei no banco de madeira ao lado de uma mulher de vestido escuro que segurava, no colo, um bilhete com o meu nome escrito à tinta vermelha.

"Sua passagem está paga desde 1963", disse o condutor. A voz saiu de onde a boca não existia, direto dentro do meu crânio.

Foi então que me lembrei. Eu estava no descarrilamento de 1963. Fui eu quem carimbou os bilhetes daqueles passageiros, eu quem assinou o relatório de via que declarava o trecho seguro, eu quem estava na cabine da locomotiva quando a bitola cedeu sob o peso do trem — ou, pelo menos, é isso que os relatórios dizem que aconteceu com um homem do meu nome, minha idade, minhas impressões digitais nos formulários. Eu não sobrevivi ao acidente. Sobrevivi ao enterro, ao seguro, à vida de aposentado que levei desde então, mas não ao acidente. A diferença é que demorei sessenta anos para perceber.

O trem partiu sem barulho de rodas. As estações fantasma passaram nas janelas: São Gonçalo do Pará, Velho da Taipa, Martinho Campos, Pompéu, Paraopeba — luzes acesas nas plataformas, funcionários saudando com a lanterna, passageiros descendo com malas de couro, subindo com bilhetes novos. Eu olhava para as minhas mãos e via que estavam transparentes, que o escuro do vagão entrava pelos meus dedos como ar por uma tela.

No fim da linha, não há Paraopeba. Há apenas o horizonte de terra vermelha e o apito, soando de novo às três e dezessete, para quem ainda estiver acordado nos arredores dos trilhos abandonados. Se você ouvir, não saia de casa. Não atravesse a cerca. E, sobretudo, não responda quando alguém chamar o seu nome na plataforma escura. O horário ainda é válido. A bitola ainda mede setecentos e sessenta e dois milímetros. E o último trem do ramal de Pompéu continua esperando passageiros — ou, talvez, continuando a entregar os que já estão mortos ao lugar onde nunca chegaram.

## Fontes de inspiração

- Estrada de Ferro Oeste de Minas (Wikipedia): histórica ferroviária mineira de bitola estreita (762 mm), inaugurada em 1881, com ramais desativados entre as décadas de 1960 e 1980, incluindo trechos na região de Pompéu e Paraopeba.
- Olhares por Minas: trajetória da Maria Fumaça entre São João del-Rei e Tiradentes, tombada pelo Iphan, com fim da atividade comercial em 1982.

Os fatos ferroviários servem apenas de cenário. Os trens, os passageiros e o apito das três e dezessete são ficção.
