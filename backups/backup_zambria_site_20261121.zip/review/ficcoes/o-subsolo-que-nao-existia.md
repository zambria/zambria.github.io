---
titulo: "O Subsolo que Não Existia"
resumo: "Um inquilino de um prédio antigo de São Paulo encontra uma escada que leva a um subsolo que não consta dos projetos. Descobre andares que espelham o seu — e uma porta com o seu próprio número, entreaberta."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "o-subsolo-que-nao-existia"
tipo: "ficcao"
fonte_pesquisa: "nulo"
---

Elias Cardoso morava sozinho no sexto andar de um prédio de 1923, no centro velho de São Paulo, e nunca suspeitara que o edifício guardasse algo abaixo do solo. O laudo técnico do síndico, assinado por um engenheiro em 1987, garantia que não havia subsolo: a partir da cota da garagem, o terreno era rocha maciça, e o prédio repousava sobre ela como sobre uma laje. Seis andares acima do nada. Abaixo, somente pedra. Os síndicos, como é de se saber, confiam cegamente em papéis assinados.

Foi por acidente que encontrou a porta. O síndico pedira ajuda para empilhar pastas de prestações de contas antigas no arquivo do térreo, um salão estreito atrás da portaria. Entre estantes de ferro e caixas moídas pela umidade, Elias moveu uma estante para alcançar um ficheiro de 1964 e descobriu, atrás dela, uma porta de madeira pintada de cinza, quase da cor da parede, maçaneta de latão opaco, sem número. Acima, um letreiro enferrujado: ÁREA TÉCNICA — PROIBIDO O ACESSO. Abriu. Havia escadas. Desciam.

Desligou a luz do salão e acendeu a lanterna do celular. As paredes eram de concreto branco, manchadas de umidade, e o cheiro era de cimento velho e cera de piso esquecida. Contou os degraus: trinta e sete até o primeiro descanso. O corredor que encontrou era espelhado ao do seu andar: portas numeradas, nomes em latão nas maçanetas. 602, 604, 606 — a mesma sequência do sexto andar, só que abaixo da terra, onde, segundo o laudo, não existia nada.

Parou diante de uma porta cuja placa de latão trazia um nome que não deveria estar ali: o de um inquilino que morrera no sexto andar dois anos antes, segundo a portaria. A campainha abaixo da placa estava gasta, como se alguém tivesse apertado o botão muitas vezes nos últimos dias. Elias tirou o dedo do lugar e continuou, mas agora ouvia atrás de si um passo que não era o seu.

Nas portas, os nomes eram os mesmos do prédio acima. Silva, Costa, Oliveira. Até que chegou à 614. A sua. A porta estava entreaberta, um vão de dedos. Empurrou. Entrou no próprio apartamento, mas coberto de poeira: uma camada grossa sobre o sofá, a mesa de jantar, o rádio. Os móveis estavam nos mesmos lugares. O calendário na cozinha estava parado na data de ontem — de um ano em que ele ainda não morava ali, e talvez ainda não existisse. A geladeira tinha leite, fresco. O armário tinha suas roupas, mas cheias do mofo de casa fechada por anos.

Ouviu, então, a chave girar na fechadura de cima. Alguém entrava no apartamento de verdade, o de cima, o seu, agora. Passos no assoalho do sexto andar. O que estava lá embaixo não era um porão abandonado; era um espelho, e o espelho estava sendo ocupado.

Elias saiu correndo. A escada ainda estava lá. Subiu trinta e sete degraus, abriu a porta e saiu no salão de arquivo, no térreo. Pegou o elevador até o sexto, passou pelo corredor, abriu 614 com sua chave. Tudo estava como deixara: sofá limpo, calendário de hoje, leite velho na geladeira. Respirou.

Na noite seguinte, às três e vinte da manhã, ouviu passos na escada atrás das estantes do arquivo. Subiam. Andar por andar. Três e vinte era a hora em que saíra para procurar o ficheiro de 1964.

Na manhã seguinte encontrou o número 614 pintado em vermelho no teto do quarto, sobre a cama. Não sabia quem pintara. Sabia apenas que o número não estava lá quando dormiu, e que, de algum jeito, o que morava abaixo já havia escolhido o quarto que iria ocupar.

Não desceu mais. Mas às vezes, quando o prédio fica em silêncio e o elevador demora demais, Elias pressiona o ouvido contra o chão e ouve, vindo de onde não deveria haver nada, o som de alguém subindo, degrau a degrau, direção ao sexto andar.

---

## Fontes de inspiração

Nenhuma. O prédio, o subsolo e o inquilino são ficção.
