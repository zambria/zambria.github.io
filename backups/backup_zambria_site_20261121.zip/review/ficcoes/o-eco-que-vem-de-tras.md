---
titulo: "O Eco que Vem de Trás"
resumo: "Um guia experiente da Chapada Diamantina entra sozinho na Gruta do Lapão para checar um desabamento reportado por turistas. No interior de quartzo escuro e úmido, o eco deixa de ser um efeito acústico e começa a responder — com voz própria."
categoria: "criptozoologia"
data: "2026-11-21"
slug: "o-eco-que-vem-de-tras"
tipo: "ficcao"
fonte_pesquisa: "bahia.ws e showcaves.com (Gruta do Lapão, Lençóis, BA)"
---

# O Eco que Vem de Trás

A Chapada Diamantina guarda pedras que não pedem permissão para existir. Em sua maioria, as grutas da região nascem do calcário, moldadas pela água ao longo de milhões de anos, cheias de estalactites que pingam como dentes de um monstro adormecido. A Gruta do Lapão é diferente. É de quartzito — uma rocha tão dura que quase não se dobra, nem se dissolve. Sua boca tem cinquenta metros de altura, um pórtico de pedra que parece recortado no céu, e seu interior estende-se por cerca de mil metros, sem luz, sem corrimão, sem qualquer conforto para quem não sabe onde pisa.

Eu conhecia aquele lugar como quem conhece a própria pele. Durante anos, guiei grupos pela travessia: a descida íngreme, os blocos soltos deixados por garimpeiros desativados, o rio que corre pelo interior e sobe rápido quando chove, o silêncio que engole a voz antes que ela consiga voltar. Sabia que o Lapão não é um lugar para ficar. É um lugar para atravessar e sair.

Até a noite em que entrei sozinho.

Foi depois do pôr do sol, na estação seca, quando o rio está baixo e os turistas já haviam ido embora. Um grupo relatara um barulho de desabamento perto da boca maior, um gemido de pedra que não batia com nada conhecido. Fui verificar. Levei apenas uma lanterna, uma garrafa d'água e a confiança tola de quem acredita que conhece todos os riscos de um mapa.

A entrada do Lapão impõe respeito. Cinquenta metros de altura de quartzito férreo, uma abertura que parece engolir a luz do dia. Passei pelo pórtico e, alguns metros adiante, desliguei a lanterna por um instante para ouvir o escuro. Não havia som. Nem o rio, nem o vento, nem o próprio coração — só a pressão do silêncio contra os tímpanos.

Acessei o feixe de luz novamente e comecei a caminhar. O chão de pedra era irregular, coberto de areia fina e lascas de quartzo que brilhavam como dentes quebrados sob a luz. Cada passo ecoava, mas de um jeito estranho: o eco voltava não exatamente como fora dito, mas com um pequeno atraso, como se a pedra precisasse de um instante para decidir como devolver o som.

Eu testei. Gritei um nome qualquer — "Marcelo!", o nome de um colega guia que não estava ali. O eco devolveu "Marcelo", mas arrastado, mais grave, como se fosse dito por uma garganta cheia de água. Esperei. Repeti. Dessa vez, o eco respondeu antes de eu terminar a palavra.

Parei. Respirei fundo. O som da minha respiração ecoou — e voltou acompanhado de uma segunda respiração, mais lenta, que vinha de algum lugar à frente, além do alcance da lanterna.

A partir daí, o escuro deixou de ser ausência de luz e passou a ser presença de algo. Caminhei mais fundo, mais longe do que qualquer turista chegava, além do ponto onde o teto sobe e se abre em salões de pedra crua. O rio apareceu à minha esquerda, estreito, gelado, correndo sobre pedras afiadas. Não havia peixes. Não havia insetos. Apenas a água e o eco.

Comecei a notar que o eco não apenas repetia. Ele antecipava. Se eu dizia "estou sozinho", o eco respondia "não", antes que eu tivesse terminado a frase. Se eu perguntava "quem está aí?", voltava um sussurro que não era resposta, mas repetição da minha própria pergunta, distorcida, como se fosse dita por uma boca que não conhecia as palavras, apenas as formas.

Algo estava comigo na gruta. Algo que não saía do escuro porque o escuro era seu corpo.

Continuei andando, contra todo o meu treinamento de guia, contra todo instinto de sobrevivência. O eco agora imitava meus passos, minha respiração, o rangido da minha mochila. E então, em um salão onde o teto desaparecia na escuridão total, ele imitou a minha voz dizendo o meu próprio nome.

Não era uma repetição. Era uma declaração.

Fiquei imóvel. A lanterna tremia na minha mão. O eco voltou a falar, dessa vez com palavras que nunca havia dito: "Saia daqui. Não volte. Estamos fechados."

Não sei por quanto tempo fiquei ali. O tempo se dilui no quartzo. Quando finalmente me virei para sair, o caminho de volta parecia mais longo do que o de ida. As pedras haviam se movido, ou a minha memória as havia movido. Cada curva que reconhecia levava a outra curva desconhecida. O eco ria agora, baixo, de todos os lados ao mesmo tempo.

Saí da Gruta do Lapão quando o céu ainda estava escuro. Não sei como encontrei a saída. Sei apenas que, nos últimos dez metros antes da boca, o eco parou de imitar minha voz e começou a falar com a dela — com a minha voz, saindo da frente de mim, como se algo já estivesse lá fora me esperando.

Hoje não guio mais ninguém no Lapão. Recuso qualquer grupo que queira atravessar a gruta. Não porque acredite em monstros — não acredito em nada que não possa ser medido — mas porque aprendi uma coisa que o quartzo não costuma revelar: o eco não é apenas um efeito acústico. É uma memória da pedra, e algumas memórias têm apetite.

Se você for ao Lapão, fique perto da saída. Não grite nomes que não pertencem ao lugar. E, se ouvir sua própria voz vindo de algum lugar à frente, não responda. Porque a pergunta que fica, fria, depois de uma noite no interior de uma rocha dura, não é o que habita o fundo da gruta.

É o que já saiu dela e anda por aí com a sua cara.

## Fontes de inspiração

- Bahia.ws — "Gruta do Lapão: Aventura na Chapada Diamantina" (localização, geologia de quartzito, dimensões da boca e extensão da caverna).
- Showcaves.com — "Gruta do Lapão" (dimensões do portal, ausência de iluminação, perigos do terreno e do rio interno).
