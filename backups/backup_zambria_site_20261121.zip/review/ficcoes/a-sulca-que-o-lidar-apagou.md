---
titulo: "A Sulca Que o Lidar Apagou"
resumo: "Uma arqueóloga encontra um geoglifo que os dados rejeitaram. Na floresta de Acre, algo antigo espera para ser pisado."
categoria: "arqueologia"
data: "2026-11-21"
slug: "a-sulca-que-o-lidar-apagou"
tipo: "ficcao"
fonte_pesquisa: "Correio Braziliense, Live Science, Estadão (geoglifos da Amazônia / civilização Aquiry)"
---

A copa da Amazônia não esconde árvores. Esconde desenhos.

Por séculos, as valas e os aterros dos geoglifos do sudoeste amazônico ficaram invisíveis a qualquer olho que olhasse do chão. Só quando o desmatamento abriu clareiras, e depois quando o lidar — a varredura a laser de aeronaves — passou a mirar o solo através da folhagem, é que o mundo soube: ali, debaixo das árvores, há quadrados, círculos e linhas retas com até 350 metros de extensão, erguidos entre 600 a.C. e 850 d.C. por uma sociedade que hoje chamamos de Aquiry. Cerca de 432 obras foram catalogadas recentemente. Os pesquisadores acreditam que restem mais de vinte mil, aguardando que alguém olhe na direção certa.

Elena não era do time que publicava os números. Ela era a estagiária encarregada de limpar o ruído dos dados brutos. O trabalho dela era descartar o que o algoritmo não reconhecia como geoglifo: qualquer marca muito irregular, muito orgânica, muito assimétrica para ter sido traçada por mãos humanas. Era, em essência, apagar o que não cabia na teoria.

Foi assim que encontrou a sulca 433.

Ela não apareceu nos mapas finais. Não constava do artigo da Nature. Nenhum comunicado de imprensa mencionava sua existência. Mas nos dados brutos, sobrepostos à floresta perto da fronteira com a Bolívia, havia algo que o filtro rejeitara por não ser geométrico o suficiente. Não um círculo, não um quadrado. Uma linha que se enrolava sobre si mesma em espiral, com braços de comprimentos desiguais, como se quem a tivesse desenhado tivesse tropeçado, mudado de ideia, ou não tivesse tido uma mão humana para guiá-la.

Elena imprimiu a imagem. Colou na parede do quarto de hotel em Rio Branco. Passou três noites olhando para ela até que, certa manhã, decidiu ir até o local.

Os Apurinã que moram no centro da área de terraplenagens evitam os geoglifos. Não usam o solo sagrado para moradia, nem para plantio. Quando Elena perguntou sobre a sulca que não aparecia nos relatórios, o ancião que a atendeu não respondeu com palavras. Apenas apontou para o chão e disse, em português pesado: "O desenho não está no mapa. Mas o mapa está no desenho."

Ela foi mesmo assim.

A floresta não recebeu bem a visita. O ar era úmido e pesado, cheirando a terra podre e a algo que não tinha nome — não exatamente enxofre, não exatamente musgo, mas algo entre os dois, como se a vegetação estivesse apodrecendo de dentro para fora. A sulca não era difícil de encontrar. Estava ali, na clareira que o desmatamento recente havia feito, mas não tinha a nítida precisão geométrica dos outros geoglifos. Era uma espiral grossa, erodida pelas chuvas, com as bordas borradas como se a terra tivesse se recusado a manter a forma.

Elena calçou as botas, tirou o fone de ouvido, e entrou na sulca.

Não caminhou até o centro. Caminhou sobre o desenho, seguindo o braço da espiral com os pés, como quem traça uma linha com o dedo sobre uma página. A cada passo, o chão cedia um pouco mais do que deveria. A cada curva, a floresta ao redor parecia recuar, deixando um círculo de silêncio em volta dela. Os pássaros pararam. O vento parou. Até sua própria respiração soou abafada, como se o ar estivesse sendo sugado para dentro da terra.

Quando chegou ao centro da espiral, não havia nada ali. Apenas solo úmido e uma depressão rasa, do tamanho de um corpo humano deitado.

Ela se virou para voltar. Foi então que notou.

A espiral não era estática.

Do ângulo em que estava, do centro mirando para fora, os braços da sulca não formavam mais uma espiral. Formavam um rosto. Ou parte de um — uma órbita profunda, uma cavidade onde deveria haver um nariz, uma linha que podia ser uma boca aberta num grito ou num sorriso. Não era nítido. Exigia que ela não olhasse diretamente, que visse de canto, como se a imagem só existisse na periferia da visão.

Ela deu um passo para trás, para enxergar melhor. O rosto desapareceu. Voltou a ser apenas sulco na terra.

Elena riu, nervosa. Ilusão de ótica. Pareidolia. A mente humana encontra rostos nas nuvens, nas torradeiras, nas paredes úmidas. Nada de sobrenatural.

Mas quando saiu da clareira e olhou para trás, a sulca havia se movido.

Não muito. Apenas o suficiente. Um dos braços da espiral, que antes apontava para o leste, agora parecia apontar diretamente para onde ela estava.

Ela ignorou. Voltar para a cidade, escrever o relatório, mostrar para o orientador. Isso era o que uma arqueóloga sensata faria.

Naquela noite, no hotel, Elena olhou para a própria pele. Sob a luz amarela do abajur, notou algo que não conseguira nomear de imediato: nas costas, entre as omoplatas, havia uma marca fina, escura, como se a pele tivesse sido riscada por algo muito delicado. Não doía. Não sangrava. Tinha o mesmo traçado do braço da espiral que ela pisara.

Ela esfregou. A marca não saiu.

Nos dias que se seguiram, o padrão começou a aparecer em outros lugares. Na disposição das folhas no chão do quarto. No rachamento do azulejo do banheiro. No vazio entre as estrelas, quando ela abria a janela à noite e olhava para o céu. A espiral estava em toda parte, esperando ser notada. E quanto mais ela notava, mais nítida ficava, como se o desenho estivesse se aprofundando dentro dela, traço por traço.

O orientador dela perguntou, numa chamada de vídeo, por que ela estava demorando tanto para entregar o relatório de campo. Elena abriu a boca para responder, e o que saiu não foi exatamente palavras. Foi um suspiro longo, arrastado, que soou como o vento passando por uma vala. O orientador ficou em silêncio. Na tela, Elena viu sua própria imagem piscar — mas não quando ela piscou. Um atraso de meio segundo. Um espaço entre o movimento e a imagem.

Ela desligou a chamada.

Na última noite em Rio Branco, antes do voo de volta, Elena voltou sozinha à clareira. Não levou câmera. Não levou ninguém. Queria ver, com os próprios olhos, se a sulca ainda estava ali, e se o rosto ainda se mostrava para quem soubesse olhar de canto.

Estava. E o rosto estava mais claro agora.

Não era um rosto humano. Não exatamente. Era algo que a espiral havia guardado por dois mil anos, algo que o lidar não conseguiu captar porque o laser mede distâncias, não intenções. A sulca não era um desenho feito por pessoas. Era uma armadilha. Ou uma escrita. Ou uma porta.

Elena deu o passo final.

Não pisou no centro desta vez. Ela se deitou na depressão rasa, do tamanho de um corpo, e deixou que a espiral a preenchesse.

Quando a equipe de busca chegou três dias depois — acionada pelo hotel, que havia se esquecido de existir, por assim dizer — a clareira estava vazia. A sulca continuava ali, grossa e borrada pela chuva. Nenhuma pegada levava até ela. Nenhuma pegada saía dela. O ancião Apurinã que os acompanhava olhou para o solo, fez um gesto com a mão e disse apenas:

"Agora o desenho está completo."

O lidar, se sobrevoasse a área novamente, não encontraria nada de novo. A 433ª sulca nunca entraria nos mapas. Não porque não existisse, mas porque havia deixado de ser uma marca na terra para se tornar algo que anda, olha e espera — e que, de vez em quando, pisca com um atraso de meio segundo.

A Amazônia guarda mais de vinte mil geoglifos esperando para serem encontrados. Elena, agora, é um deles.

## Fontes de inspiração

- Correio Braziliense: reportagem sobre os mais de 400 geoglifos da Amazônia, ocultos sob a floresta por séculos, com estruturas de até 350 metros, originados por povos indígenas do Acre tratados como sagrados pelos grupos locais.
- Live Science / Estadão: cobertura da varredura a laser (lidar) que revelou centenas de geoglifos atribuídos à civilização Aquiry, construídos entre 600 a.C. e 850 d.C., com propósito cerimonial ainda em aberto.
