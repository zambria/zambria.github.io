---
titulo: "A Sulca do Oeste"
resumo: "Um geólogo é enviado para verificar marcas estranhas em um afloramento de arenito no interior do Mato Grosso. O que começa como uma vistoria de rotina vira uma constatação fria: algumas inscrições não foram feitas para serem lidas, e sim para serem ouvidas — e quem as escuta, não volta igual."
categoria: "arqueologia"
data: "2026-11-21"
slug: "sulca-do-oeste"
tipo: "ficcao"
fonte_pesquisa: "Pedra da Gávea (debate inscrição fenícia vs erosão); caso Percy Fawcett / Cidade Z (desaparecimento no Mato Grosso)"
---

A chegada

O interior do Mato Grosso não perdoa quem chega com pressa. Elias Marins desceu do caminhão às cinco e meia da manhã, com o ar ainda úmido e pesado, carregando no nariz o cheiro forte de terra molhada misturado a um odor de cinzeiro velho que vinha de uma usina abandonada a três quilômetros dali. Não era arqueólogo. Era geólogo de formação, contratado por uma consultoria ambiental para verificar um laudo de campo: um afloramento de arenito às margens de um igarapé sem nome apresentava sulcos que um técnico de campo insistia não serem produto da erosão natural.

O técnico chamava aquilo de inscrição. Elias chamou de trabalho rotineiro.

Levou lupa, fita métrica, câmera e caderno de campo. Levou também a cautela de quem já vira demais parecer mistério e ser, no fim, apenas pedra e tempo. Mas o afloramento o recebeu de um jeito que nenhum relatório havia previsto.

A rocha emergia do solo como um dente quebrado, cinza-rosado, com uma face quase plana voltada para o norte. Nela, gravados com uma precisão que incomodava, corriam dois sulcos paralelos, largos uns dez centímetros e profundos o suficiente para reter água da chuva da noite. Uniam-se num ponto, a um metro do solo, formando um ângulo aberto que lembrava, se estivesse disposto a acreditar em fantasmas, um V. Ou uma seta. Ou uma boca aberta.

Elias passou os dedos pelo sulco. A aresta era nítida, não arredondada pelo vento nem pela chuva. A areia dentro dos sulcos era mais escura, mais úmida, como se a rocha suasse exatamente ali. Tirei fotos, anotou medidas, raspou uma amostra com a espátula. Nada de anormal na composição mineral. Areia cimentada por sílica, grãos bem selecionados, camadas cruzadas típicas de um ambiente eólico antigo. A pedra tinha trezentos, talvez quatrocentos milhões de anos. Não tinha por que guardar marcas de ninguém.

Só que as marcas estavam ali.

Desenvolvimento

De volta ao alojamento da consultoria, um prédio baixo de telhas de amianto que cheirava a mofo e óleo diesel, Elias abriu o prontuário do técnico. O nome dele era Roberto Carneiro, e o laudo tinha três páginas. Carneiro afirmara que os sulcos não seguiam nenhuma linha de fraturamento natural da rocha, que a orientação era intencional — apontava, segundo ele, para um azimute de duzentos e dez graus, quase sul-sudoeste — e que a largura constante dos sulcos sugeria uma ferramenta de corte com lâmina rígida, não o desgaste de água e areia.

Elias sublinhou a última frase com a caneta, seca. Carneiro havia visitado o afloramento sozinho, em julho. Em setembro, pediu demissão por telefone, sem dar motivos. Em outubro, não atendeu mais as ligações. A consultoria nunca encontrou o corpo, porque nunca procurou: Carneiro simplesmente deixara de existir nos registros da empresa.

Isso não era motivo suficiente para Elias parar. Ele voltou ao afloramento no dia seguinte, desta vez com um tripé e um teodolito barato. Mediu o azimute dos sulcos: duzentos e nove graus, quarenta minutos. Perto do que Carneiro dissera, mas não igual. A diferença era pequena, mas existia. E existia mais: ao pôr do sol, quando a luz incidia rente à face da rocha, os sulcos projetavam uma sombra que, por cerca de quatro minutos, se alinhava perfeitamente com uma fenda no horizonte, entre dois morros baixos cobertos de capim seco. Era o tipo de coincidência que faz um geólogo duvidar da própria profissão.

Elias passou a noite no alojamento revendo anotações. Pesquisou no telefone, sinal fraco, o nome do técnico e o do afloramento. Encontrou apenas um boletim de ocorrência genérico, um sumiço não esclarecido, e uma menção em um fórum de curiosidades locais sobre "a pedra que aponta para baixo". Não clicou no link. Não queria alimentar a cabeça com histórias.

No terceiro dia, levou uma escova de cerdas macias e limpou os sulcos com cuidado. Abaixo da camada de poeira e de umidade, a gravura mostrava marcas de ferramenta — linhas retas, cortes limpos, nada do aspecto aleatório que a erosão deixa. Não eram letras de nenhum alfabeto que Elias reconhecesse. Não tinham começo nem fim óbvio. Eram simplesmente sulcos, duplos, convergentes, como se alguém tivesse tentado gravar uma instrução e desistido no meio. Ou como se a instrução não fosse para ser lida com os olhos, mas seguida com o corpo: ande nessa direção, até aqui, pare.

À tarde, foi ao mercado da cidadezinha mais próxima, União do Oeste — um nome inventado por alguém com senso de humor duvidoso, já que não havia nada de união nem de oeste ali, apenas lojas fechadas e um posto de saúde com a porta trancada. Perguntou ao dono do mercado, um homem magro de dentes amarelados, se alguém já falara da pedra.

O homem secou as mãos no avental sujo e olhou para Elias como quem avalia se vale a pena perder saliva.

— Essa pedra não é para ser tocada, senhor. Três homens já foram lá olhar de perto. Dois não voltaram. O terceiro voltou, mas não falou mais nada. Morreu uma semana depois, de um infarto. Tinha trinta e quatro anos.

Elias não disse nada. Pagou a cerveja e saiu.

Na volta ao afloramento, levou uma lanterna forte. O sol já se punha, pintando o céu de um laranja sujo que parecia uma ferida aberta sobre a floresta. Quando iluminou os sulcos com a lanterna, notou algo que não vira antes: dentro do V formado pelos sulcos, mais abaixo do ponto de convergência, havia um terceiro traço, curto, quase imperceptível, atravessando o arenito como uma linha de risco. Não estava nos esboços de Carneiro. Não aparecia nas fotos do primeiro dia.

Elias aproximou o rosto da rocha. O cheiro de umidade era mais forte ali. Ele passou o polegar pelo traço curto e, nesse instante, ouviu um som.

Não foi um som de fora. Foi dentro do crânio, um zumbido baixo, como o ruído de uma linha elétrica próxima em dia de chuva, ou o eco de uma voz falando atrás de uma parede grossa. Ele se afastou, ofegante, o coração batendo forte contra as costelas. O zumbido parou. A noite estava silenciosa, só o cigarrinho e o vento nas folhas secas.

Ele voltou ao alojamento, trancou a porta com a cadeira encostada no puxador e não dormiu. Pela manhã, os sulcos estavam preenchidos com uma areia fina e escura que não estava lá na véspera. Areia que não vinha da chuva — não chovera. Areia que não vinha do vento, porque não havia vento forte o suficiente. Elias coletou uma amostra, levou para o laboratório improvisado da consultoria, examinou ao microscópio. Os grãos eram de arenito, idênticos aos do afloramento. Mas estavam úmidos, e dentro de cada grão, sob a ampliação de cem vezes, havia uma estrutura que não parecia mineral. Parecia, se é que Elias conseguia descrever sem soar como um louco, uma impressão digital de algo que nunca tinha pele.

Conclusão

Elias Marins não voltou para São Paulo no dia marcado. Deixou o aluguel do carro pago, o caderno de campo aberto em cima da mesa, a câmera com o cartão de memória ainda dentro. O relatório final da consultoria nunca foi escrito. Alguém, semanas depois, encontrou o alojamento vazio, a porta destrancada, e o cheiro forte de umidade e cinzeiro velho impregnado nas paredes.

O afloramento continua lá, às margens do igarapé sem nome, com seus sulcos paralelos apontando para um azimute que ninguém consegue explicar. A areia escura volta a aparecer nos sulcos depois de cada limpeza, como se a rocha estivesse preenchendo os espaços que alguém, um dia, tentou esvaziar.

O que Elias viu naquela noite — se viu alguma coisa — ele não contou a ninguém. Não porque fosse impossível de acreditar, mas porque era pior: fazia sentido. Fazia sentido que uma rocha de trezentos milhões de anos guardasse uma instrução. Fazia sentido que a instrução ainda estivesse funcionando. E fazia sentido, agora que Elias havia tocado o traço curto, que ele estivesse, a cada dia que passa, um pouco mais próximo da direção que os sulcos apontam.

Algumas inscrições não foram feitas para serem lidas. Foram feitas para serem seguidas. E quem as segue, não costuma voltar para contar.

## Fontes de inspiração

- Pedra da Gávea, Rio de Janeiro: debate entre geólogos e estudiosos sobre se as marcas na rocha são inscrições antigas (hipótese fenícia) ou resultado da erosão natural. Fonte: Wikipedia e reportagens sobre o interesse arqueológico no local.
- Caso Percy Fawcett e a Cidade Z: desaparecimento do explorador e seus acompanhantes no Mato Grosso em 1925, enquanto buscavam uma civilização perdida no interior do Brasil. Fonte: Folha de S.Paulo, Correio Braziliense, SciELO e reportagens sobre o centenário do sumiço.

Todas as fontes serviram apenas como inspiração geográfica e temática. Os personagens, os fatos narrados e o desfecho são inteiramente fictícios.
