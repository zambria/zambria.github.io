---
titulo: "A Luz Que Caminhava Atrás de Mim"
resumo: "Um técnico ambiental vai a um brejo do interior documentar fogos-fátuo e descobre que a luz não se limita a dançar sobre a água: ela o segue, e o medo não vem do sobrenatural, mas da constatação de que a ciência explica a chama — e não explica por que ela escolheu um alvo."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "a-luz-que-caminhava-atras-de-mim"
tipo: "ficcao"
fonte_pesquisa: "Agro em Campo (iG), Super Interessante (Abril), O Antagonista"
---

Na terceira noite, a luz parou de ficar no brejo e passou a ficar comigo.

Eu não acredito em presságio. Fui contratado por uma consultoria ambiental de São Paulo para documentar, com câmera e notas de campo, os fogos que aparecem sobre um brejo no interior da Bahia, naquela região onde a terra fica encharcada mesmo na seca e a vegetação apodrece debaixo d'água sem que ninguém se dê ao trabalho de retirar. O serviço era simples: chegar ao anoitecer, gravar as chamas azuladas que surgem sobre a superfície, medir a temperatura ambiente, anotar a direção do vento, voltar pela manhã. Três noites. Três laudas. Um cheque.

Na primeira noite, vi uma luz. Pequena, azulada, flutuando a menos de um metro sobre a água parada. Apareceu, durou alguns segundos, apagou sem deixar vestígio. A explicação nos manuais: decomposição anaeróbica da matéria orgânica, microrganismos liberando metano e fosfina, os gases vazando por fendas do solo e entrando em combustão espontânea ao contato com o oxigênio. Chama fria, azulada, inofensiva à distância. Eu anotei tudo, fechei o equipamento e voltei para a pousada. O brejo cheirava a umidade e a terra molhada, cheiro de matéria que não termina de descansar.

Na segunda noite, apareceram duas. Uma ficou no mesmo lugar de sempre, próxima à borda dos juncos. A outra se moveu. Não muito — uns dez metros — mas na direção contrária ao vento, o que não deveria ser possível para uma combustão de gás. Eu caminhei em sua direção. Ela recuou na mesma medida, mantendo a distância. Quando voltei para o carro, a luz estava parada no acostamento da estrada de terra, esperando. Liguei o farol. Ela apagou. No dia seguinte, não escrevi nada disso no relatório.

Na terceira noite, decidi ficar até o fim. Levei uma lanterna, o detector de gases e a câmera em modo de gravação contínua. O brejo estava mais silencioso que o normal — nem sapos, nem insetos, só o barulho da própria respiração dentro do capuz do casaco. Por volta das duas da manhã, a luz surgiu no ponto de sempre e, em vez de flutuar sobre a água, começou a caminhar na lama na minha direção. Não corria. Deslizava, devagar, como se medisse o terreno. Eu retrocedi. Ela avançou. Quando cheguei à cerca de arame que separa o brejo da fazenda, a luz parou a uns cinco metros de distância e ficou ali, imóvel, enquanto eu desligava a câmera e guardava as coisas no carro. Só então ela se apagou.

É nesse ponto que a ciência começa a falhar como explicação completa.

Tudo o que li antes de viajar aponta para o mesmo: o fogo-fátuo — batatão, batata d'água, boitatá, consoante a região — é fenômeno natural, químico, sem intenção. Fosfina e difosfano são pirofóricos: entram em combustão espontânea ao tocar o ar, acendem o metano, produzem a chama azulada que dura segundos e some. Um estudo publicado em 2025 sugeriu até uma possível fonte de ignição natural: microbolhas de metano desenvolvendo diferenças de carga, pequenas descargas elétricas, microrrelâmpagos no lodo. Tudo muito razoável. Tudo muito frio. Nenhuma das fontes, porém, explica por que uma chama de gás deveria manter uma distância constante de um homem caminhando, nem por que ela deveria esperar no acostamento de uma estrada de terra, nem por que ela deveria apagar no exato momento em que a câmera é desligada.

Comecei a não dormir bem. Não por medo de fantasma — não acredito em fantasma — mas pelo vazio que fica quando a explicação esgota-se e o fenômeno continua. Acordava no escuro com a sensação de que algo azulado pairava no pé da cama, e acendia a luz do quarto para encontrar apenas a poeira sobre o abajur. O detector de gases, nos dias seguintes, não registrou nada acima do normal no quarto da pousada. O ar estava limpo. A luz, não.

Na quarta noite — eu havia pedido mais um dia, contra o bom senso — voltei ao brejo com a lanterna e uma corda amarrada ao pulso, presa a uma estaca na beira da água, para não me perder no lodo. A luz apareceu antes da meia-noite. Dessa vez não ficou na borda dos juncos. Veio direto até a estaca, parou a meio metro de mim, e eu senti o calor — não o calor de uma chama, mas um calor úmido, de fôlego, como se a luz estivesse respirando. Segui-a. Caminhei pelo brejo por quase uma hora, afundando os tornozelos na lama negra, a luz sempre à frente, sempre a mesma distância, nunca mais perto, nunca mais longe. Ela me levou a uma depressão no terreno, um buraco onde a terra parecia afundar sozinha, coberto de vegetação podre e água parada. O chão estava quente. Eu abaixei a lanterna e vi, no fundo da depressão, ossos. Não de animal: eram demasiado alinhados, demasiado inteiros, para serem de um boi ou de um cavalo mortos ali por acaso. Não toquei. Subi de volta, a luz me acompanhando até a beira do brejo, onde apagou definitivamente quando pisuei na estrada de terra.

Voltei para São Paulo no dia seguinte. Cancelei o restante do contrato. Não entreguei as gravações. Não sei o que são os ossos, nem quem os colocou ali, nem se a luz os guardava ou os atraía. A ciência explica a chama: gás, oxigênio, faísca. Não explica por que a chama escolheu me seguir, nem por que escolheu me levar até ali.

Às vezes, antes de dormir, apago todas as luzes do apartamento e olho para a janela. No escuro, há sempre um ponto azulado lá fora, muito distante, parado. Não se move. Não apaga. Não precisa: ele sabe que, mais cedo ou mais tarde, eu terei que respirar, e o ar que exalo traz oxigênio o suficiente para manter uma chama acesa por alguns segundos a mais.

## Fontes de inspiração

- Agro em Campo (iG): "Fogo-fátuo: a ciência por trás do mistério luminoso dos campos" — decomposição anaeróbica, metano, fosfina, difosfano; no sertão nordestino, o fenômeno recebe o nome de batatão ou batata d'água.
- Super Interessante (Abril): "O que é o fogo-fátuo e como ele se forma?" — chamas azuladas em cemitérios e pântanos, duração de segundos, combustão espontânea de gases de decomposição.
- O Antagonista: reportagem sobre o fenômeno dos pântanos e o estudo de 2025 (PNAS) sobre microrrelâmpagos em bolhas de metano como possível fonte natural de ignição.
