---
titulo: "Os Geoglifos do Silêncio"
resumo: "Uma arqueóloga documenta um geoglifo recém-revelado no leste do Acre e descobre que o desenho geométrico no solo não é um espaço ritual, mas uma espécie de convite — e que cada medição que faz aproxima algo do centro da estrutura."
categoria: "arqueologia"
data: "2026-11-21"
slug: "os-geoglifos-do-silencio"
tipo: "ficcao"
fonte_pesquisa: "Correio Braziliense e FAPESP Revista Pesquisa (mais de 400 geoglifos com mais de 2.500 anos no leste do Acre, estruturas de ate 350 metros revelados pelo desmatamento, sem ossadas humanas nem terra preta, povos indigenas tratam os locais como sagrados; Alceu Ranzi avistou as estruturas em 1999 de um voo comercial; Denise Pahl Schaan pioneira nas pesquisas)"
---

# Os Geoglifos do Silêncio

O leste do Acre, perto de Rio Branco, guarda uma mentira conveniente: a de que a floresta esconde tudo o que não queremos ver. Por séculos, a mata cobriu centenas de desenhos escavados no solo — círculos, quadrados, elipses, octógonos de até trezentos e cinquenta metros de extensão, feitos há mais de dois mil anos por mãos que não deixaram ossos, nem terra preta, nem registro escrito. Eles só apareceram porque o desmatamento do fim do século XX abriu o chão, como se a floresta os tivesse devolvido apenas no momento em que deixamos de tê-los para proteger.

Chamam-nos de geoglifos. A explicação aceita é que foram espaços rituais, locais de encontro, algo que serve para acalmar a curiosidade. Nenhuma ossada humana foi encontrada dentro deles. Nenhuma mancha de solo negro que ateste ocupação prolongada. Os povos indígenas da região ainda os tratam como sagrados e evitam ali moradia ou plantio. O suficiente para que eu, arqueóloga de formação e cética por ofício, tenha sentido o primeiro arrepio não ao ver o desenho, mas ao perceber que ninguém queria falar dele.

Fui designada para documentar o sítio recém-revelado na linha de divisão entre dois igarapés, terra firme, interflúvio dos rios Acre e Iquiri. Cheguei com drone, fita métrica, GPS e a presunção de quem acredita que o passado se mede em centímetros e se escreve em relatórios. O geoglifo que me coube — sem nome oficial, só um código alfanumérico no banco do Iphan — era um quadrado quase perfeito de cento e vinte metros de lado, com uma mureta baixa de terra delimitando o contorno e uma valeta rasa do lado de fora. Do solo, não passava de um estranho desnível na grama rasurada. Do alto, via as imagens do drone, era um quadrado exato, imposto sobre a floresta como uma ferida fechada.

Nos primeiros dias, tudo foi metódico. Marquei os vértices, fotografei cada trecho da valeta, coletei amostras de solo em profundidades variadas. O solo não guardava surpresas: argila, raízes, nenhum fragmento de cerâmica, nenhum osso queimado. O silêncio, porém, era incomum. Mesmo para a Amazônia, onde o barulho nunca para, aquele trecho de floresta parecia ofegar baixo, como se segurasse o ar.

Foi então que as medidas começaram a não bater.

No segundo dia, o lado norte do quadrado media cento e vinte e um metros. No terceiro, cento e dezoito. No quarto, voltei ao mesmo ponto com a mesma fita métrica e marquei cento e vinte e três. Não era erro de medição: a fita não se esticara, o GPS não falhara, e eu não estava me enganando. O desenho no solo estava crescendo. Ou encolhendo. Ou se movendo, devagar, enquanto eu não olhava.

Comecei a dormir mal. À noite, na lona da barraca, fechava os olhos e via linhas retas — quadrados, círculos, elipses — se sobrepondo às pálpebras, girando lentamente no escuro. Sonhava que estava de pé no centro do geoglifo, deitada na terra, e que algo abaixo de mim respirava no mesmo ritmo. Acordava com a sensação de que o chão se afastara de meus pés durante a noite, como se a terra tivesse se recolhido uns centímetros para não me tocar.

Um dos guias locais, um homem mais velho que se recusava a entrar no perímetro do desenho, disse uma coisa que não esqueci: Não se olha para isso de cima por muito tempo. O desenho olha de volta. Não soube se era superstição ou aviso. Anotei no caderno de campo como folclore, sem dar importância.

Na quinta noite, revisei as imagens do drone. No voo de chegada, o geoglifo era um quadrado limpo. No voo de ontem, uma linha extra havia aparecido no interior do contorno — um traço reto, sutil, que cruzava o vértice sudoeste em direção ao centro. Não estava lá antes. Ou estava, e eu não vira. O drone não mentia; a câmera registra o que há, não o que esperamos.

Fui ao local ao amanhecer. A valeta ainda estava lá, a mureta de terra intacta, mas agora, ajoelhada no centro do quadrado, vi o que o drone havia capturado: uma linha fina, quase uma risca no solo, partindo da borda e convergindo exatamente onde eu me ajoelhara. Como se o desenho estivesse sendo traçado a partir de mim. Como se eu fosse o ponto que faltava para fechá-lo.

A partir daí, deixei de medir o geoglifo e passei a medir a mim mesma. Minha sombra, ao meio-dia, não caía mais onde deveria. Minhas pegadas, no chão úmido, se alinhavam sozinhas com os vértices do quadrado, mesmo quando eu caminhava em linha reta. Sentia os olhos de algo — não sei dizer se debaixo da terra, se acima da floresta, se dentro do próprio silêncio — seguindo cada passo.

No sétimo dia, decidi encerrar a documentação. Empacotei o drone, guardei as fitas, escrevi o relatório final com a conclusão mais chata possível: sítio ritual, sem vestígios materiais, sem datação precisa, recomendação de monitoramento. Entreguei ao Iphan. Assinei. Achei que estava livre.

Naquela noite, antes de dormir, apaguei a luz do quarto e olhei para o teto. No escuro, vi novamente as linhas retas, os quadrados, os círculos — mas desta vez não estavam só nas minhas pálpebras. Estavam projetados no teto, finos, cinzentos, traçando um contorno que começava no canto do quarto e terminava exatamente onde minha cabeça repousava no travesseiro. Um quadrado de cento e vinte metros não cabe em um quarto de pousada em Rio Branco. Mas as linhas não se importam com escala. Elas só precisam de um ponto de partida.

E eu, ao terminar este relatório, acabo de fornecer o ponto final.

## Fontes de inspiração

- Correio Braziliense — reportagem sobre os mais de 400 geoglifos da Amazônia, com mais de 2.500 anos, estruturas de até 350 metros revelados pelo desmatamento no leste do Acre, origem e função ainda desafiando a ciência.
- FAPESP Revista Pesquisa — A cultura dos geoglifos (construção há pelo menos 2 mil anos por cultura pré-colombiana indeterminada, sem ossadas humanas, sem terra preta, povos indígenas tratam os locais como sagrados; Alceu Ranzi avistou as estruturas em 1999 de um voo comercial; Denise Pahl Schaan pioneira nas pesquisas).
