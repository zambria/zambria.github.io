---
titulo: "O Turno das 3h17"
resumo: "Um vigia noturno contratado para medir o ruído de uma serraria desligada descobre que as máquinas ligam sozinhas na mesma hora todas as noites — e que o medidor registra um som que nenhum ouvido escuta."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-turno-das-3h17"
tipo: "ficcao"
fonte_pesquisa: "NR-15 / gov.br; Serraria das Três Vendas / Rádio Fandango"
status: "pendente de curadoria"
---

Marcos desceu do ônibus às 22h12 de uma terça de outubro e caminhou os últimos oitocentos metros até o pavilhão da Serraria das Três Vendas, em Cachoeira do Sul. O local estava desligado havia dezoito meses, sem licença ambiental, com o chão batido, a lâmina de corte exposta e as máquinas cobertas de pó de serragem — exatamente como relatava o laudo do técnico de segurança do trabalho que recomendara a interrupção imediata das atividades. Ele não estava ali para operar nada. Estava ali para ouvir. E para medir. Levava um decibelímetro emprestado da faculdade, um caderno de campo e a instrução de preencher um laudo de exposição ao ruído de um turno noturno em ambiente que, em tese, não emitia som algum. A serraria estava morta. Era precisamente isso que o deixava inquieto.

As primeiras duas horas passaram sem incidentes. O medidor oscilava entre 28 e 32 dB(A) — o ruído de fundo do pavilhão, o vento nas frestas do telhado de zinco, o tique-taque de algum relógio parado. Marcos anotava, passava a fita métrica nas frisas de madeira, fotografava com o celular o painel desarmado da serra circular. Às 23h47, bebeu água morna da garrafa e ouviu apenas a própria respiração ecoando entre as toras empilhadas.

Então, às 3h17, o medidor pulou.

Não foi um ruído alto. Foi um salto abrupto de trinta e dois para noventa e quatro decibéis, registrado no circuito de compensação "A", resposta lenta, exatamente como exigia o anexo da NR-15. Marcos olhou para a tela do aparelho, depois para as máquinas. Tudo permanecia imóvel. A serra circular não girava. O desbastador não vibrava. Nenhuma correia se movia. E, no entanto, o instrumento afirmava que ali havia som — um som constante, estável, de noventa e quatro decibéis, suficiente para exigir proteção auditiva e limitar a exposição a duas horas por dia.

Ele tentou desligar o aparelho e ligar novamente. O número permaneceu. Andou em direção à fonte da leitura: o pavilhão central, onde ficava a serra de fita antiga. O chão de concreto estava úmido em um ponto, próximo ao eixo de transmissão, como se algo tivesse passado recentemente por ali. Marcos encostou a mão na carcaça da máquina. Estava fria. Sem vibração. Sem calor de motor. Ele aproximou o decibelímetro da lâmina de corte. Noventa e quatro decibéis. Retirou o aparelho. Vinte e oito.

Repetiu o teste três vezes. Sempre o mesmo resultado: noventa e quatro decibéis exatamente a um metro da lâmina, zero decibéis audíveis para os ouvidos dele.

Às 3h17 da noite seguinte, voltou. Levou um gravador de fita, fones de ouvido profissionais e uma lanterna de pilha. A serraria continuava desligada, sem energia desde a desabilitação da prefeitura — os disjuntores estavam removidos, os cabos cortados no poste. Não havia como qualquer máquina funcionar. Às 3h17 em ponto, o medidor disparou novamente. Noventa e quatro decibéis. O gravador, no entanto, capturou apenas o silêncio do pavilhão: o chiado da fita, a respiração de Marcos, o distante latido de um cachorro na cidade. Os fones não transmitiam nada além de um estalo ocasional.

Na terceira noite, Marcos levou um colega do curso, Renato, para testemunhar. Renato não viu nada de anormal. Também não ouviu. O decibelímetro de Marcos, no entanto, marcou noventa e quatro decibéis às 3h17, enquanto o aparelho de Renato, medindo o mesmo ponto, registrava trinta e um.

Foi então que Marcos notou o detalhe que mudou tudo. No painel de controle enferrujado da serra circular, uma chave de segurança mantida na posição "desligado" desde a interdição estava, naquela noite, na posição "ligado". Não havia energia. Não havia como. Mas a chave estava ligada. E no chão, próximo ao eixo, a serragem fina e úmida havia sido varrida para um canto, formando um pequeno monte com a textura de algo recém-serrado — madeira que, segundo o laudo municipal, não existia mais ali desde que as máquinas foram encaminhadas ao leilão.

Marcos nunca terminou o laudo. Devolveu o decibelímetro à faculdade, trancou o caderno de campo em uma gaveta e saiu da serraria antes das 3h da quarta noite. Nunca voltou. O que o assusta não é a possibilidade de as máquinas ligarem sozinhas em um pavilhão sem energia. É a certeza de que algo, ali dentro, mediu o ruído de volta. E que, quando ele estiver sozinho novamente em um ambiente silencioso, às 3h17 da madrugada, o medidor — ou algo que imita um medidor — vai piscar noventa e quatro decibéis bem ao lado do ouvido dele, onde nenhum aparelho deveria conseguir chegar.

## Fontes de inspiração

- NR-15 — Atividades e Operações Insalubres (gov.br): limites de exposição diária ao ruído em dB(A) e procedimentos de medição com nível de pressão sonora, circuito de compensação "A" e resposta lenta.
- "Prefeitura fecha antiga Serraria das Três Vendas" (Rádio Fandango, Cachoeira do Sul): desabilitação de serraria inoperante, com laudo de técnico de segurança do trabalho apontando riscos estruturais e máquinas sem condições de operação.
