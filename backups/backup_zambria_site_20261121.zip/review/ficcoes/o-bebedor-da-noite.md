---
titulo: "O Bebedor da Noite"
resumo: "Em 1977, durante a Operação Prato, a Força Aérea enviou militares a Colares, no Pará, para observar luzes que, segundo ribeirinhos, sugavam sangue e deixavam pessoas inertes. O sargento Ronaldo Silva foi um dos que observou — e aprendeu que observar pode ser um convite."
categoria: "ufos"
data: "2026-11-20"
slug: "o-bebedor-da-noite"
tipo: "ficcao"
fonte_pesquisa: "Folha de S.Paulo (levantamento de avistamentos junto à Aeronáutica, dez/2024; reportagem de 1996 sobre a onda na Paraíba) e pt.wikipedia.org/wiki/Ufologia"
---

# O Bebedor da Noite

O céu sobre o estuário do rio Moju não era cenário. Era palco, e a plateia, em 1977, era composta por ribeirinhos assustados, militares da Força Aérea e um sargento de rádio que aprendeu cedo demais que alguns fenômenos não gostam de ser observados.

Colares, Pará. Maio de 1977. A Operação Prato chegara à cidade com a discrição que a Aeronáutica consegue fingir ter: um destacamento do 1º Comando Aéreo Regional, câmeras, telex e a ordem oficial de observar, registrar e não interceptar. Os objetos — luzes, discos, charutos, lâmpadas fluorescentes do tamanho de uma casa — apareciam todas as noites, desciam sobre o rio e a vila, e, segundo quem vivia ali, deixavam vítimas inertes, trêmulas, com a voz presa e marcas no corpo. O bicho, chamavam os moradores. Não vampiros, não demônios: algo que vinha do céu e se alimentava em silêncio.

Eu era o sargento Ronaldo Silva, operador de rádio da equipe designada a Colares. Minha função era anotar horários, coordenadas, cores, formas. Transmitir os boletins para Belém. Arquivar o que os pilotos viam e o que eles se recusavam a colocar por escrito. Não fui escolhido por coragem. Fui escolhido porque estava disponível e porque, naquela época, a Aeronáutica tratava o assunto com a mesma seriedade de quem arregimenta gente para varrer um porão que não quer admitir estar assombrado.

As primeiras semanas foram de rotina burocrática. Luz verde às vinte e oito, movimento de sudeste para noroeste, desaparecimento sobre a baía. Relatório enviado. Arquivado. Os moradores paravam nossos carros de patrulha na estrada de terra para contar que um vizinho fora encontrado deitado na lama do igarapé, sem sinais de violência, sem conseguir falar, com dois pontos escuros no peito que ninguém sabia nomear. O médico do posto chamou de colapso nervoso. O prontuário sumiu. Eu passava esses relatos para os relatórios como anedotas folclóricas, com o descuido de quem ainda acredita que o oficial e o inexplicável habitam mundos diferentes.

A verdade começou a entrar pelo rádio, na frequência que ninguém monitorava.

Na noite de 12 de maio — ou de 13, os horários se embaralham quando o relógio deixa de fazer sentido —, uma luz laranja, maior que a lua naquele ponto do horizonte, desceu sobre o rio a menos de quinhentos metros do posto de observação. Não houve barulho de motor. Não houve vento. Houve apenas um zumbido baixo, na frequência dos dentes, e a sensação súbita de que o ar tinha ficado mais pesado, como se a atmosfera estivesse sendo sugada para cima. Dois dos nossos saíram com lanterna e crachá — protocolos para intrusão desconhecida — e voltaram cinco minutos depois sem conseguir explicar por que estavam com as mãos trêmulas e o relógio parado. Um deles, o cabo Mendez, não conseguiu dormir naquela noite. Disse que, quando fechava os olhos, via uma luz baixa pairando sobre a cama, e sentia, com clareza absurda, algo sendo retirado dele. Não sangue. Algo mais leve. Algo que, uma vez ido, não volta mais.

Comecei a manter um registro paralelo. Não telex. Caderno. Anotei que as luzes não apareciam ao acaso: seguiam um corredor, entravam pelo noroeste, circulavam sobre o rio e saíam em direção ao Atlântico, sempre entre meia-noite e as três da manhã. Anotei que as vítimas relatadas pelos ribeirinhos apareciam nos dias seguintes às aparições mais intensas. Anotei que, quando os holofotes do destacamento se acendiam em direção aos objetos, as luzes respondiam diminuindo a intensidade, como se estivessem sendo estudadas de volta.

Na semana seguinte, a luz veio para o posto.

Eu estava de plantão sozinho na cabina de rádio, transcrevendo o boletim do dia, quando a claridade invadiu a sala sem bater nas paredes primeiro. Era azul, quase branca, e não projetava sombras — sinal de que vinha de todos os lados ao mesmo tempo. O rádio começou a emitir um chiado que não era estática: era voz, ou algo tentando ser voz, em uma língua que meus ouvidos não conseguiam montar. Meu peito ficou apertado, como se alguém estivesse tirando o ar dos pulmões com uma seringa invisível. Olhei pela janela. A luz pairava a dez metros do solo, silenciosa, maior que o caminhão de transporte, com um halo que tornava a floresta ao redor apenas contorno. Não havia feixe. Não havia raio. Havia apenas presença, e a certeza fria de que algo ali estava olhando para dentro da cabina, e que minha tarefa — observar, registrar — tinha acabado de me colocar no cardápio.

Tentei ligar o gerador. Tentei o rádio de emergência. Nada respondeu. A porta da cabina, que eu havia trancado por dentro, abriu sozinha com um rangido que parecia vindo de muito longe. Saí. A luz subiu. Enquanto subia, senti o zumbido nos dentes, o frio no estômago, e aquela sensação que os ribeirinhos descreviam: a de ter algo retirado, um vazio onde deveria haver peso. Quando a luz sumiu sobre a baía, o rádio voltou a funcionar. O relógio marcava três horas e doze minutos. Tinha passado menos de um minuto, ou tantas horas quanto a noite comporta. Nunca saberei.

No dia seguinte, a Operação Prato foi encerrada. O relatório oficial registrou avistamentos de luzes, não chegou a conclusões sobre sua natureza, e recomendou que o assunto fosse arquivado. Os militares deixaram Colares. Os ribeirinhos continuaram a ver as luzes, e a Aeronáutica continuou a não vê-las. Eu voltei para Belém, depois para o sul, e guardei o caderno paralelo numa gaveta que não abro mais.

Anos depois, li um levantamento da Folha de S.Paulo: a Aeronáutica reuniu 934 relatos de OVNIs em sete décadas, e o Pará lidera o ranking com 140 casos. 1977 foi o ano com mais notificações — 85 no Brasil, 82 deles no Pará. Li isso sentado numa cozinha de Porto Alegre, com a luz da geladeira como única companhia, e pensei que os números são apenas a versão burocrática do mesmo medo. O que o levantamento não conta é que as luzes não pararam de vir. Pararam de ser registradas. Há diferença.

Não durmo bem com as janelas abertas. Não porque acredite em alienígenas — essa palavra é pequena demais, e otimista demais — mas porque sei o que acontece quando o céu deixa de ser cenário e se torna palco, e você está na plateia com a tarefa de observar. O observador, no final, é apenas o próximo item da lista. Algo vem do escuro, algo se alimenta em silêncio, e o relatório oficial nunca menciona o preço pago por quem esteve olhando.

## Fontes de inspiração

- Folha de S.Paulo, "Pará lidera relatos de aparição de óvnis à Aeronáutica, mostra levantamento" (dez/2024): dados de 934 relatos reunidos por militares desde 1952; Pará com 140 casos (16%); 1977 como ano com mais notificações (85 no país, 82 no Pará); referências à Operação Prato e a Colares (PA), com relatos de corpos luminosos, raios e vítimas inertes. Utilizado como referência de contexto histórico; todos os eventos, personagens e diálogos são ficcionais.
- Folha de S.Paulo, "Assembléia discute os 'Ovnis' da PB" (30/4/1996): sessão especial da Assembleia Legislativa da Paraíba sobre avistamentos em dez municípios; descrição de objetos cilíndricos, esféricos, em forma de charuto e lâmpadas fluorescentes, com luzes verde, amarela, azul e alaranjada. Utilizado apenas como inspiração atmosférica; não há reprodução de trechos.
- pt.wikipedia.org/wiki/Ufologia: menção à Operação Prato, ao Caso Varginha e à Noite Oficial dos OVNIs como ícones da ufologia brasileira. Referência geral, sem citação de texto.
