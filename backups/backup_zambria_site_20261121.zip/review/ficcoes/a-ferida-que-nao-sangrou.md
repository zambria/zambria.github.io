---
titulo: "A Ferida que Não Sangrou"
resumo: "Um veterinário é chamado para examinar gado mutilado em uma fazenda do interior e descobre que o predador não deixa sangue, nem pegadas, nem explicação — apenas um silêncio que aprende."
categoria: "criptozoologia"
data: "2026-11-21"
slug: "a-ferida-que-nao-sangrou"
tipo: "ficcao"
fonte_pesquisa: "G1 (onda do chupa-cabra no interior de SP, 1999); Revista UFO (mutilações de gado, 1997-1998)
---

O veterinário chegou ao fim da tarde, quando o sol já não aquecia mais o curral e as sombras das árvores se alongavam sobre o pasto como manchas de óleo. Não havia sido chamado para tratar de doença. Havia sido chamado porque algo, na fazenda de Santana da Vargem, estava tirando a vida do gado sem tirar o sangue — e isso, para um homem que passa a vida entre agulhas, seringas e hemácias, era mais inquietante do que qualquer epidemia conhecida.

O primeiro animal fora encontrado de manhã cedo: uma vaca adulta, deitada de lado na grama, olhos abertos, língua ausente. Um corte preciso no pescoço, quase cirúrgico, e não uma gota de sangue no solo. Nem nos flancos. Nem nos dentes do dono da fazenda, que estivera ali parado, de chapéu na mão, repetindo que os cachorros não latiram e que não se ouvira nada durante a noite. Foram treze animais em vinte dias, todos do sexo feminino, todos com o mesmo ferimento no pescoço, e nenhum com uma única mancha de sangue ao redor.

Foi essa ausência que prendeu a atenção do veterinário. Predadores deixam rastros. Sangue, luta, arranhões na terra, pegadas na lama, vísceras espalhadas. Nada. A grama ao redor dos corpos estava inteira. Não havia arrasto. Não havia luta. Só o animal morto, aberto com precisão, e o silêncio.

Na casa da fazenda, o dono lhe mostrou um arquivo de fotos impressas, amassadas pelo bolso da camisa. Cada imagem trazia o mesmo detalhe: o corte começava abaixo da mandíbula e terminava no pescoço, limpo, sem lascar osso, sem romper músculos desnecessários. Como se quem tivesse feito soubesse exatamente onde parar. O veterinário passou os dedos por uma das fotografias e sentiu o frio da tinta, não o calor de uma explicação.

Passou a noite no curral, sozinho, com uma lanterna e um revólver que o dono lhe emprestara e que ele não sabia usar. O silêncio do interior não é o silêncio da cidade. É um silêncio cheio: de grilos, de vento na palha, de respiração de bois sonolentos. Por volta das duas da manhã, o veterinário ouviu algo que não era nenhum dos três. Um arrasto leve, na grama úmida, vindo da linha de árvores ao fundo do pasto. Acendeu a lanterna. Não viu nada. Apagou. Ouviu novamente, mais perto, como se algo estivesse testando se ele estava acordado. Quando amanheceu, não havia pegadas ao redor do curral. Só a grama pisada, e um único fio de cabelo escuro, grosso, preso num galho baixo — que não parecia de nenhum animal da região.

Nos dias que se seguiram, começou a notar algo pior do que as mortes. Os bois restantes mudaram de comportamento. Pararam de se aproximar da cerca na hora da ração. Ficavam parados, voltados para a mesma direção, a linha de árvores, com os ouvidos eriçados, como se ouvissem algo que ele não ouvia. Uma noite, no escuro do quarto que lhe deram na casa, o veterinário ouviu seu próprio nome dito do lado de fora da janela. Com a voz do dono da fazenda. Saiu com o revólver na mão. Não havia ninguém. Só o vento, e o gado, parado, imóvel, olhando para ele.

Examinou os corpos novamente, desta vez com lupa e coletor de amostras. Os cortes não apresentavam sinais de dentes. Não havia saliva. Não havia bactérias bucais de canídeo ou felino. As bordas estavam seladas, como cauterizadas em temperatura baixa, algo que nenhum bicho conhecido consegue fazer. Enviou uma amostra de tecido para um laboratório privado na capital. O laudo voltou uma semana depois, escasso: "Material biológico não identificado. Não corresponde a nenhuma espécie registrada no banco de genomas."

Na décima quarta manhã, encontrou a décima quarta vítima. Desta vez, o animal não estava morto. Estava de pé, olhos abertos, sem língua, sem a metade do pescoço, e respirava. O veterinário aproximou-se lentamente. A vaca o olhou. Não mugiu. Não se moveu. Seus olhos não tinham mais foco, mas pareciam enxergar algo atrás do veterinário, algo que estava mais perto do que as árvores, mais perto do que a cerca, mais perto do que a própria pele. O veterinário voltou para casa, pegou o revólver e, em vez de matar o animal, fechou a porta do curral por fora e trancou com cadeado. Deixou a chave no bolso. Nunca voltou para abrir.

O que resta é uma questão que o dono da fazenda não quer fazer e o veterinário não consegue parar de fazer: se não era um cão, nem um felino, nem um morcego hematófago, e se não havia sangue porque o sangue havia sido retirado com precisão cirúrgica, então o que está nas árvores de Santana da Vargem não é um predador. É algo que aprende. Algo que observa. Algo que, aos poucos, descobre como somos feitos por dentro — e, mais importante ainda, como soamos quando chamamos uns pelos outros pelo nome.

As luzes da fazenda ainda se acendem à noite. Os cães ainda não latem. E quem passa pela estrada de terra depois do escuro jura ter visto, entre as árvores, uma figura alta demais para ser humana, parada entre os bois, ouvindo.

## Fontes de inspiração

- G1, "Chupa-cabra: há 20 anos, lenda sobre bicho que mutilava animais assustou moradores no interior de SP" — relatos de ataques noturnos a rebanhos em cidades do interior de São Paulo, animais encontrados sem sangue e com ferimentos precisos, entre 1997 e 1999.
- Revista UFO, "Um mistério ainda sem resposta" — documentação de mutilações de animais de criação no Brasil (1997-1998), com ênfase na ausência de sangue, cortes cirúrgicos e órgãos removidos sem rastros externos.

Toda menção a fazenda, personagens e eventos é ficcional. Qualquer semelhança com pessoas, locais ou casos reais é coincidência.
