---
titulo: "As Esferas que Desceram no Sertão"
resumo: "No sertão de Pernambuco, entre 19h e 21h, esferas douradas e prateadas pairam sobre o pasto. Um homem decide filmá-las, e descobre que algumas luzes não vêm do céu — e que já estavam aqui antes de qualquer um."
categoria: "ufos"
data: "2026-11-20"
slug: "as-esferas-que-desceram-no-sertao"
tipo: "ficcao"
fonte_pesquisa: "g1.globo.com; agroemcampo.ig.com.br"
---

# As Esferas que Desceram no Sertão

No sertão de Pernambuco, o crepúsculo não desce: ele invade. Entre dezenove e vinte e uma horas, quando o sol já se foi mas o calor ainda está grudado na pele, o céu de Arcoverde e dos distritos vizinhos deixa de ser cenário e se torna palco. Moradores registraram, nas últimas semanas, esferas douradas e prateadas pairando baixo sobre o pasto, mudando de direção sem ruído, deslocando-se em velocidade que nenhum telescópio convencional consegue acompanhar. Não é satélite, não é avião, não é balão meteorológico. Quando o especialista não sabe o que é, chama de OVNI — objeto voador não identificado — e fecha o assunto como se fecha um arquivo: não reconhecido, portanto inexistente.

Eu chamo Edmundo. Tenho cinquenta e quatro anos, passei a vida consertando motores de caminhão na oficina do irmão, que morreu de cirrose, e vivo sozinho numa fazenda às margens de um rio que já teve nome e agora só guarda água parada. Dois cachorros, uma espingarda nunca disparada, o hábito de assistir o fim do dia da varanda. Foi ali, numa segunda-feira de julho, que vi a primeira esfera: dourada, do tamanho de uma bola de vôlei, suspensa a poucos metros do solo, silenciosa, quente. Quando me aproximei, os cachorros não latiram. Simplesmente se calaram, como se a voz lhes tivesse sido roubada.

No começo, pensei em reflexo de luz de poste, em balão solto de alguma festa junina adiada, em qualquer coisa que não exigisse mudar minha rotina. Mas as esferas voltaram. Todas as noites, entre dezenove e vinte e uma horas, elas apareciam sobre o pasto, pairavam, subiam, sumiam atrás da crista. Comecei a filmar com o celular, exposto de trinta segundos, como sugerem os manuais de astrofotografia. Nas imagens, as luzes não são pontos fracos: são rastros bruscos, velocidades impossíveis, mudanças de direção que desafiam a inércia. E, em algumas das filmagens, algo mais: quando a esfera passa direto sobre a cerca, a grama fica achatada em círculos perfeitos, como se algo pesado e invisível tivesse pousado ali por uns segundos.

Passei a anotar datas, horários, intensidade. Tentei conversar com o vizinho mais próximo, um homem de setenta anos que planta feijão e não sai de casa à noite. Ele não olhou nos meus olhos. Disse apenas que as luzes vêm desde 1997, que seu pai já as vira, que quem assiste demais acaba sendo visto de volta. Não deu nome ao que via. Não precisou.

Uma quinta-feira, elas desceram mais do que nunca. Estava na varanda com a câmera na mão, filmando uma esfera prateada que pairava a uns três metros do solo, acima do curral. Ela desceu ainda mais, até ficar a cerca de um metro do chão, e então parou. Senti um calor intenso no rosto, como abrir o forno de uma padaria no auge do verão. Os cachorros uivaram uma vez — um uivo curto, cortado — e mudos. Minhas pernas não respondiam. Não era medo; era como se o peso da gravidade tivesse dobrado só para mim. A esfera emitia um zumbido baixo que eu sentia mais nos dentes do que nos ouvidos. E, dentro da luz, algo se movia. Não uma forma clara, não algo que eu pudesse descrever sem mentir, mas uma presença. Algo observando de volta, como o vizinho dissera.

Na manhã seguinte, encontrei a vaca mais velha do rebanho morta ao lado do curral. Não havia sangue, não havia ferimento, não havia pegadas ao redor. Apenas o corpo, seco, como se a umidade tivesse sido sugada para fora da pele em questão de horas. O veterinário de Buíque, chamado às pressas, não soube dizer a causa. Sugeriu raio, embora não houvesse tempestade. Sugeriu doença, embora não houvesse sintoma. Saiu da fazenda sem assinar o laudo.

Comecei a não dormir direito. O sono vinha em pedaços, e sempre acordava entre dezenove e vinte e uma horas, com a nuca arrepiada, certa de que algo estava lá fora, parado na cerca, me esperando. Parei de filmar. Parei de anotar. Não adiantou. As luzes continuam a aparecer, todas as noites, no mesmo horário, e cada vez parecem mais próximas. Ontem, deitado no escuro, vi pela janela um brilho prateado cruzando o quintal — baixo, silencioso, sem pressa.

Passei semanas procurando uma explicação racional. Linhas de transmissão, balões, satélites, alucinação coletiva, estresse do campo. Nada se encaixa. Nenhum aparelho registra. Nenhuma autoridade assume. Nenhum vizinho confirma. Apenas eu, as esferas, e um silêncio que não é silêncio, mas espera.

A verdade, a que recuso dizer em voz alta, é simples: elas não estão de passagem. Não vêm de outro planeta para nos visitar e partir. Elas já estavam aqui, debaixo do solo, antes de qualquer estrada, antes de qualquer fazenda, antes de mim. O que sobe no céu entre dezenove e vinte e uma horas não é nave. É varredura. E ontem, quando o brilho parou na varanda e algo, dentro da luz, olhou diretamente para mim, entendi que a varredura terminou. Agora começa a coleta.

Não apaguei os vídeos. Estão no celular, na gaveta, ao lado da espingarda. Às vezes, à noite, abro a gaveta só para ter certeza de que eles ainda estão lá. E oro — embora não reze — para que, quando a esfera voltar, ela não encontre ninguém em casa.

## Fontes de inspiração

- g1.globo.com — "Luzes são vistas no céu no interior de Pernambuco" (relato de objetos não identificados vistos entre 19h e 21h no Sertão pernambucano, deslocamento em alta velocidade, ausência de identificação por satélites, aviões ou balões meteorológicos).
- agroemcampo.ig.com.br — "Fogo-fátuo: a ciência por trás do mistério luminoso dos campos" (fenômeno luminoso natural em regiões pantanosas e sertanejas, conhecido no Nordeste como "batatão", aparecendo em noites calmas diretamente do solo).
