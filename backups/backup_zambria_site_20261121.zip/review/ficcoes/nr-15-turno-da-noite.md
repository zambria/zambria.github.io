---
titulo: "NR-15, Turno da Noite"
resumo: "Um perito de ruído ocupacional é contratado para medir os decibéis de uma marcenaria abandonada antes da demolição. No turno da noite, o dosímetro aponta sons que não existem — e frequências que o ouvido não capta, mas o corpo sente."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "nr-15-turno-da-noite"
tipo: "ficcao"
fonte_pesquisa: "PubMed (infrassom e resposta aversiva/cortisol); NR-15 / limites de exposição ao ruído ocupacional (SciELO/NCBI)"
---

Laércio Moraes estacionou o Gol às 22h12, em frente a um portão de ferro enferrujado que nem se fechava mais. À frente, a Serra e Marcenaria Monte Verde ocupava quinhentos metros quadrados de telhado de zinco, paredes de tijolo aparente e um silêncio que não parecia vazio. A planta estava desativada havia vinte anos, desde que o dono morreu e os herdeiros decidiram não herdar o negócio, apenas o terreno. Laércio não havia vindo por nostalgia. Havia vindo por um laudo de ruído ocupacional, NR-15, turno da noite: medição dos decibéis que uma máquina desligada já não deveria produzir, assinatura de um perito, liberação para a demolição.

No porta-malas, o dosímetro Quest calibrado, protetor auricular, lanterna e um caderno de campo. A primeira leitura, ainda do lado de fora: 32 dBA, o vento chacoalhando as lâminas soltas do telhado. Dentro, o número desabou para 28 dBA. Um silêncio de porão. Laércio tirou o protetor do bolso. Não precisaria dele, pensou. Não havia máquina ligada, não havia motor, não havia ninguém.

Ele começou pelo setor de corte. Uma serra fita antiga, guarda-corpo de ferro, lâmina enferrujada pendendo do eixo como uma língua seca. O dosímetro, apoiado na mesa de trabalho, marcava 28 dBA. Laércio passou para a eletroserra de bancada: 29 dBA. A desbastadeira: 30. Nada acima do limite de 85 dBA da NR-15 para uma jornada de oito horas. Tudo conforme. Tudo morto.

Até que chegou à estação de acabamento, no fundo da planta, onde ficava a lixadeira de fita larga. O dosímetro saltou para 86 dBA.

Laércio parou. Olhou para a máquina. Estava desligada, coberta de poeira, a correia rachada. Não havia energia no quadro — os disjuntores estavam abaixados desde 2005, segundo o laudo de vistoria anterior. Ele tocou a carcaça da lixadeira. Fria. Imóvel. O dosímetro, no entanto, continuava a subir: 87, 88, 89 dBA.

Ele conferiu a calibração do aparelho. Conferiu de novo. Trocou de modo: ponderação C, resposta lenta. O número não baixou. Abaixou para a escala de baixa frequência, abaixo de 20 Hz, o território do infrassom — som que o ouvido humano não captura, mas que o corpo aceita como pressão no peito, como enjoo, como o pressentimento errado de que algo está prestes a acontecer.

Na lixadeira, a leitura era de 17 Hz.

Laércio andou pela planta com o aparelho na mão, mapeando a fonte. O som não vinha de um motor. Vinha do chão. Da viga mestra de madeira, do tijolo, da laje de concreto que sustentava a caldeira velha, desmontada na década de noventa. No subsolo — um poço de elevador de cargas nunca usado, preenchido com entulho e uma escada de ferro — a leitura chegou a 91 dBA em frequência infrassônica. A estrutura inteira parecia vibrar em uma nota que não tinha nome.

Ele desceu com a lanterna. O ar cheirava a serragem velha, umidade e óleo queimado, embora não houvesse fogo lá há duas décadas. Nas paredes, marcas de água formando mapas sem sentido. No fundo do poço, ele encontrou algo que não estava nos projetos da marcenaria: uma câmara pequena, revestida de tijolos escuros, com um piso de laje que ressoava sob seus pés como uma membrana esticada. O dosímetro, apoiado no chão, marcava 18 Hz constante, sem variação.

Laércio tirou do bolso um gravador de campo. Ligou. Deixou rodar por três minutos. Desligou. Colocou os fones de ouvido.

Não havia som. Não havia nada que se pudesse chamar de som. Havia, sim, um ritmo. Uma cadência grave, quase imperceptível, que subia pelo crânio e se instalava atrás dos olhos. Soava como respiração. Ou como alguém contando, devagar, em uma língua que Laércio não conhecia.

Ele subiu as escadas de volta ao térreo. O dosímetro no bolso ainda marcava 85 dBA, embora a marcenaria estivesse em silêncio absoluto. A lixadeira, desligada. A serra fita, parada. O prédio, vazio. Ele olhou para o relógio: 00h47. Faltavam mais de seis horas para o turno acabar, embora não houvesse turno, não houvesse operários, não houvesse nada a medir.

Na sala do escritório abandonado, sobre uma mesa coberta de excremento de pássaro, Laércio encontrou o livro de ponto antigo. Abriu. Havia anotações à caneta, datadas de 1998: operários pedindo transferência, reclamando de náuseas, insônia, dores de cabeça que começavam às dez da manhã e não paravam à noite. Uma frase, escrita à lápis e riscada duas vezes: o zumbido não sai da cabeça depois que a gente sai daqui. Abaixo, a última entrada, do próprio dono, Assis Monte Verde: Desligamos a chave geral às dezessete horas. O barulho não parou. Fechamos tudo e ninguém mais entra à noite.

Laércio fechou o livro. O dosímetro, agora sobre a mesa, subiu para 92 dBA.

Ele saiu da marcenaria às 02h10, travou o portão com um cadeado novo e dirigiu para casa, em Três Corações. O carro estava silencioso. O GPS, desligado. O rádio, mudo. Mas o peito de Laércio continuava a vibrar em 18 Hz, uma pressão sorda atrás do esterno que a música do rádio não abafava e o travesseiro não escondia.

Na mesa de cabeceira, ele deixou o dosímetro ligado, em modo de registro contínuo. Às seis da manhã, antes de sair para o trabalho, ele olhou para a tela. O aparelho marcava 85 dBA em um quarto vazio, com a janela fechada, o mundo lá fora em silêncio. Nenhum motor, nenhuma serra, nenhuma lixadeira. Apenas ele, a cama e um som que não tinha fonte, não tinha desligador e não respeitava o limite de oito horas da NR-15.

Alguns ruídos não param quando a máquina para. Eles apenas mudam de endereço.

## Fontes de inspiração

- Pesquisa sobre infrassom (frequências abaixo de 20 Hz, tipicamente imperceptíveis ao ouvido) associada a respostas aversivas, irritabilidade e elevação de cortisol em ouvintes que não conseguiam detectar sua presença — estudo indexado no PubMed.
- Limites de exposição ao ruído ocupacional da NR-15 (Brasil): 85 dBA como limite máximo para uma jornada de oito horas, com redução do tempo permitido à medida que o nível sobe — revisão da literatura sobre perda auditiva induzida por ruído (SciELO / NCBI).
