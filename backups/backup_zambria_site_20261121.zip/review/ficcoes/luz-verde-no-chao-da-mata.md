---
titulo: "Luz Verde no Chão da Mata"
resumo: "Na Amazônia, cogumelos bioluminescentes acendem pontos verdes no chão da floresta à noite. Um pesquisador passa a notar que a luz não aparece ao acaso — e que fica mais forte perto de onde as pessoas desaparecem."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "luz-verde-no-chao-da-mata"
tipo: "ficcao"
fonte_pesquisa: "revistaamazonia.com.br — fungos bioluminescentes na Amazônia
---

A fronteira da mata, Amazonas. Noite. O pesquisador acende a lanterna e a apaga quase na hora — a floresta já emite a própria luz. Pontos verdes, pequenos, constantes, pululam no solo entre as raízes expostas e as folhas em decomposição. Não são vaga-lumes. Não piscam, não procuram parceiro, não traçam trajetórias no ar. Apenas estão ali, brilhando com uma luz fria e sem calor, como estrelas que desceram e decidiram ficar coladas ao chão.

É bioluminescência. O leitor mais apressado vai dizer que já ouviu falar: fungos, uma enzima, uma molécula, oxigênio, luz verde sem chama. É verdade, até certo ponto. O que ninguém prepara quem vai para o campo é a textura do escuro amazônico quando ele volta, depois que você desliga a lanterna e deixa os olhos se acostumarem. O escuro não é ausência. É uma presença que respira, que cheira a umidade e terra podre, e que, de quando em quando, acende um ponto verde a menos de um metro da sua bota.

O pesquisador se chama apenas ele mesmo no caderno de campo — não importa o nome. Veio para catalogar espécies de cogumelos luminosos, mais especificamente os que emitem luz constante, visíveis em noites sem lua. Nos primeiros dias anotava tudo com o zelo de quem acredita que o mundo se deixa explicar por reações químicas. Anotava a espécie, o substrato, a umidade do ar, a intensidade da luminescência em uma escala arbitrária de um a dez. Não anotava o calafrio que sentia ao perceber que alguns pontos apareciam exatamente onde, na semana anterior, um cão da aldeia mais próxima tinha desaparecido. Não anotava que a luz parecia mais branda sobre a folhagem intacta e mais intensa, quase pulsante, sobre o solo movido recentemente.

Então veio a primeira noite em que os pontos não estavam onde ele os deixara.

Ele retornara a um transecto marcado na véspera, fitas de plástico amarelo amarradas a galhos baixos, coordenadas GPS gravadas no aparelho. Na noite anterior, ali brilhavam quatro cogumelos em torno de uma touceira de samambaia. Na noite seguinte, a samambaia continuava ali, as fitas continuavam ali, mas os cogumelos tinham se movido — ou tinham aparecido outros, formando um semicírculo quase perfeito em volta de um buraco pequeno na terra, do tamanho de uma cabeça humana. O pesquisador se ajoelhou. Não tocou em nada. Observou. A luz era verde, constante, e não projetava sombra porque não tinha fonte única: parecia emanar do próprio solo, como se a terra estivesse doente de claridade.

Trouxe isso ao coordenador da expedição no dia seguinte. O coordenador riu — um riso curto, de quem passa meses na floresta e aprendeu a duvidar de tudo, inclusive de si mesmo. Disse que cogumelos não se movem, que o pesquisador provavelmente tinha confundido o ponto de referência na escuridão, que a mata engana a percepção. Acrescentou, com um cinismo que o pesquisador reconheceu como defesa, que se os cogumelos comessem gente eles já teriam acabado com os ribeirinhos há séculos. O pesquisador não contestou. Guardou a observação no caderno, desta vez com a hora, a coordenada exata e o nome do coordenador, para constar.

A semana seguinte trouxe o segundo incidente. Um dos guias locais, um homem que conhecia cada igarapé da região, saiu para checar uma armadilha de caça pequena e não voltou ao acampamento ao anoitecer. O pesquisador participou da busca com lanternas e cães. Não encontraram o guia. Encontraram, sim, aos pés de uma castanheira, um círculo de pontos verdes no solo, mais numerosos que o normal, mais brilhantes, como se alguém tivesse espalhado tinta fosforescente sobre a terra e, em seguida, pisado no centro. Os cães não queriam se aproximar. Latiram de longe, com o rabo entre as pernas, e nenhum deles queria cheirar o chão ali dentro do círculo.

O pesquisador fez o que qualquer pessoa razoável faria: registrou tudo. Tirou fotografias — saíram escuras, quase inutilizáveis, com pequenos borrões verdes que o flash não conseguiu capturar direito. Anotou a data, a hora, o nome do guia desaparecido, a descrição do círculo. Devolveu o caderno ao coordenador, que desta vez não riu. Fechou o caderno com uma pancada seca na mesa de lona e disse que a expedição estava encerrada, que voltariam à cidade no dia seguinte, que o pesquisador poderia levar seus cogumelos e suas teorias para outro lugar.

O pesquisador não voltou à cidade. Ou, melhor dizendo, voltou, mas não ficou.

Ficou porque, na última noite na cabana de lona, antes de desmontar o acampamento, apagou todas as luzes e se sentou na soleira da porta para esperar. Esperou o que não sabia dizer. A mata, no escuro, não fez barulho de bicho. Não houve grilo, não houve sapo, não houve o estalo de um galho sob o peso de um jacaré. Houve apenas a luz. Os pontos verdes começaram a aparecer na clareira em frente à cabana, um a um, como acendidos à distância, e não paravam mais. Cobriam o solo, subiam um pouco nos troncos baixos, formavam linhas que não eram linhas, círculos que não se fechavam, padrões que o pesquisador, com todo seu ceticismo de laboratório, começou a ler como escrita. Não escrita de letras, claro. Escrita de presença. Escrita de convite.

Ele entendeu, então, com a clareza fria que só o pânico tardio concede, que os cogumelos não brilham para atrair parceiros nem para espantar predadores. Não brilham por reação química inofensiva. Brilham porque algo se alimenta ali, debaixo da terra, e a luz verde é o rastro que o alimento deixa ao ser levado. Ou é a isca. Ou é a marca de quem já foi escolhido e ainda não sabe.

No dia seguinte, a equipe encontrou a cabana vazia. O caderno de campo estava aberto sobre a mesa de lona, a última página preenchida com a mesma letra de sempre, mas as coordenadas não faziam sentido para nenhum lugar da mata. Ao redor da cabana, no solo, não havia pegadas. Havia, sim, um círculo de pontos verdes, pequenos, constantes, que não piscavam nem procuravam parceiro. Apenas estavam ali. Brilhando. Esperando.

Quem voltar àquele ponto em uma noite sem lua, e desligar a lanterna, e deixar os olhos se acostumarem ao escuro, vai ver a luz verde subir aos poucos pelo tronco da árvore mais próxima. Vai ver o padrão se formar no chão. Vai sentir o cheiro de umidade e terra podre. E, se estiver atento o suficiente, vai ouvir o próprio nome chamado com a voz da floresta — uma voz que não precisa de pulmões, e que já sabe onde você pisa.

## Fontes de inspiração

- Revista Amazônia, "Fungos que brilham: o espetáculo oculto da Amazônia" — sobre fungos bioluminescentes que emitem luz verde no solo da floresta tropical, mediante reação entre luciferase, luciferina e oxigênio.
- Matérias sobre o Fenômeno Hessdalen e a Operação Prato (Colares/PA, 1977) — luzes não explicadas que aparecem sem causa aparente e mobilizam investigadores sem produzir uma resposta definitiva.

Ambas as fontes serviram apenas como inspiração atmosférica; a história, os personagens e os eventos são fictícios.
