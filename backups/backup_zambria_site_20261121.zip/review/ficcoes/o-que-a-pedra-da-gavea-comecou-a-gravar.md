---
titulo: "O Que a Pedra da Gávea Começou a Gravar de Volta"
resumo: "Um restaurador contratado para documentar as supostas inscrições fenícias na Pedra da Gávea descobre que as marcas na rocha mudam entre visitas — e que a pedra não registra o passado. Registra quem a olha."
categoria: "arqueologia"
data: "2026-11-21"
slug: "o-que-a-pedra-da-gavea-comecou-a-gravar"
tipo: "ficcao"
fonte_pesquisa: "Super Abril, O Globo, iMirante, R7"
---

O céu do Rio de Janeiro não serve de cenário para a Pedra da Gávea. Serve de cortina. Com oitocentos e dois metros de granito e gneisse, a montanha ergue-se sobre o bairro de São Conrado como um espetáculo que a cidade aprendeu a ignorar. De longe, tem cara de gente: testa, nariz, boca fechada em um largo sossego de pedra. Pareidolia, dizem os cientistas — o cérebro humano insiste em ver rostos onde não há nada. De perto, no entanto, a Pedra da Gávea deixa de ser rostinho de montanha e passa a ser algo mais incômodo: uma superfície de sulcos, cortes e reentrâncias que alguém, no começo do século passado, teve a ideia de chamar de escrita.

Fui contratado por uma consultoria de patrimônio para fazer o registro fotográfico e em nuvem de pontos das supostas inscrições fenícias. O pretexto era uma nova trilha de acesso que a prefeitura queria desenhar no flanco leste; meu trabalho, em tese, nada mais era do que deixar em arquivo a condição atual da rocha antes que o tráfego de turistas a desgastasse ainda mais. Eu não acreditava em fenícios no Brasil, nem em conspirações, nem em montanhas que falam. Acreditava em pixels, em tripés e em relatórios técnicos. Era justamente esse tipo de homem que a pedra mais precisava para começar seu trabalho.

A primeira subida aconteceu em um sábado de julho, com céu cinza e umidade grudando na nuca. Levei um scanner de luz estruturada, uma câmera de sensor grande e uma cabeça de tripé nivelada por bússola. Subi pela trilha do Pico da Tijuca, atravessei a mata fechada até o sopé da rocha, e montei o equipamento na lateral oeste, onde os sulcos são mais visíveis — aquelas linhas que Bernardo de Azevedo da Silva Ramos, arqueólogo e entusiasta dos anos 1930, leu como fenícias e traduziu, segundo ele, como algo que ligava a pedra a Tiro, à Fenícia e a um tal de Badezir, primogênito de Jethbaal. O Ministério da Educação e Saúde negou qualquer escritura ali, em 1950. Geólogos dizem que é intemperismo: chuva, vento, insolação, a ação lenta do tempo sobre granito. Nenhum túnel, nenhuma tumba, nenhuma frota antiga ancorada na Guanabara antes de Cabral. Tudo coerente. Tudo chato.

Fiz os scans. Voltei para casa. O relatório foi entregue. O trabalho estava encerrado.

Sete dias depois, retornei à mesma posição GPS para uma segunda passagem, desta vez apenas fotográfica, para controlar a iluminação entre as sessões. Abri as duas nuvens de pontos no software de comparação e fiquei parado diante do monitor por um tempo que não soube medir. Alguns sulcos haviam se aprofundado. Não muito — décimos de milímetro, talvez menos. Mas em sete dias. A erosão não trabalha nesse ritmo. O granito não cede a chuva de uma semana. Revisei os alinhamentos das câmeras, recalculei a escala, verifiquei se tinha trocado de lente. Não havia erro de equipamento. Havia diferença real entre a pedra de sábado passado e a pedra de hoje.

Comecei a voltar. A cada visita, marcava coordenadas exatas e fotografava a mesma moldura: a tal "inscrição" fenícia e, logo acima, o rosto da montanha. Na terceira semana, a boca de pedra — sempre fechada nas primeiras imagens — parecia um pouco mais aberta, como se estivesse prestes a soltar um ar que segurara por milênios. Nas semanas seguintes, um sulco vertical que Ramos havia interpretado como a letra Taw se ramificou em dois, formando um ângulo que não existia antes. Não eram marcas novas aparecendo do nada. As marcas existentes estavam se movendo. Reescrevendo-se.

Isso foi o suficiente para eu parar de dormir direito.

Comecei a ouvir a montanha no apartamento de Tijuca, onde moro sozinho. Não era som de fora. Era um som dentro do crânio, uma vibração baixa, como de granito se arranhando contra granito, que só aparecia quando eu estava prestes a desligar a luz e fechar os olhos. Eu me levantava, ia à janela, e a Pedra da Gávea ficava ali, do outro lado da cidade, imóvel e silenciosa como sempre. Mas eu já sabia que imóvel e silencioso são apenas as roupas que a pedra veste para nos enganar.

Pesquisei — não como acadêmico, apenas o suficiente para não soar totalmente ignorante no relatório que nunca entreguei. Li que Ramos foi acusado de método errado, de pareidolia, de ver o que queria ver. Li que especialistas modernoss usaram fotos e mostraram que os sulcos não têm alinhamento, não mantêm espaçamento regular, não formam sequência linguística coerente. São apenas riscos parecidos com letras. Coincidências morfológicas. Nada mais. Consenso científico: não houve fenícios aqui. Não há mistério. A montanha é apenas uma montanha.

Não acreditei no consenso. O scanner não mentia. Meus olhos não mentiam.

Na quarta semana, subi sozinho, fora de horário, sem autorização da prefeitura e sem a consultoria sabendo. Levei o tripé e uma lanterna de cabeça. Esperei o sol terminar de varrer a lateral oeste e me sentei na rocha, de frente para os sulcos, a uns três metros de distância. Fiquei imóvel por quase duas horas. Não esperei ver letras se formando — eu já sabia que não funcionava assim. Esperei ver se a pedra me olhava de volta.

Por volta das duas e meia da manhã, vi um grão de areia subir.

Não rolou. Não caiu. Subiu. Um pequeno grão de quartzo, preso dentro de um dos sulcos, mudou de posição contra a gravidade, movendo-se para cima como se algo, dentro da rocha, o tivesse empurrado. Respirei fundo e não me movi. Meu coração batia contra as costelas como um pássaro preso em caixa de papelão. Liguei a câmera e comecei a fotografar em sequência, exposições longas, intervalos de trinta segundos. No fone de ouvido, gravava áudio ambiente — não ouvia nada audível, mas o aparelho capturava frequências abaixo do limiar humano, um zumbido grave que crescia e diminuía com a respiração, embora eu estivesse parado e não estivesse respirando pesado.

Quando voltei para casa, passei a noite revisando as fotos no computador. As imagens em si não mostravam nada de anormal: apenas a rocha, as sombras, o escuro. Mas, ao sobrepor os quadros da sequência, percebi que as sombras não batiam com a posição da lua. Elas se deslocavam como se algo estivesse em pé à frente da pedra, entre a pedra e a fonte de luz, projetando sua própria sombra sobre a superfície. Algo alto. Algo com contornos de cabeça e ombros. Algo que, na última foto da sequência, tirada às três horas e dezessete minutos da manhã, tinha meu rosto.

Não era uma sombra parecida comigo. Era eu. Estatura, cortes de cabelo, a queda do ombro esquerdo — tudo ali, gravado na escuridão da lateral oeste da Pedra da Gávea, como se eu já tivesse sido esculpido nela muito antes de nascer.

Na sexta-feira seguinte, acordei com areia nos olhos. Não areia de praia. Grãos ásperos, translúcidos, que saíam dos cantos dos olhos quando esfregava o rosto. Levei ao espelho e vi, pela primeira vez, que minha própria expressão parecia um pouco diferente: a boca ligeiramente entreaberta, o olhar fixo em um ponto distante que ninguém mais enxerga. Não me assustei. Senti apenas um reconhecimento frio, do tipo que não dá mais volta.

Entendi o que a pedra faz.

A Pedra da Gávea não guarda uma mensagem antiga de navegadores fenícios. Não há inscrição para decifrar, não há idioma perdido para traduzir, não há tesouro enterrado no interior do granito — os geólogos estão certos quanto a isso, pelo menos. O que a pedra faz é registrar. Ela grava quem a observa com atenção suficiente, quem passa horas a fio tentando ler os sulcos como se fossem letras, quem passa a noite ouvindo o som que só existe dentro do crânio. Ela grava o observador e, com o tempo, devolve a gravação. A pareidolia funciona nos dois sentidos: nós vemos rostos na pedra, e a pedra aprende a nos ver de volta.

Não subi mais lá. Não entreguei o relatório final. A consultoria já mandou dois e-mails perguntando sobre o prazo. Eu não respondo. Hoje, quando fecho os olhos para dormir, sinto os próprios traços se assentando na rocha, grão a grão, sulco a sulco, esperando o próximo visitante levantar os olhos e notar que a montanha do lado de fora da janela não é mais apenas uma montanha. É um espelho que ainda não terminou de nos esculpir.

## Fontes de inspiração

- Super Abril — "Antiga teoria achava que a Pedra da Gávea era uma criação dos fenícios" (história da hipótese de Bernardo da Silva Ramos e o consenso científico de intemperismo natural).
- O Globo — coluna sobre as supostas inscrições fenícias na Pedra da Gávea (debate entre erosão e presença antiga; dimensão de mais de 800 metros).
- iMirante — "Pedra da Gávea: entre a geologia e a hipótese fenícia" (análise morfológica dos sulcos e ausência de sequência linguística coerente).
- R7 — reportagem sobre estudos antigos que viram escrituras fenícias na Pedra da Gávea (negação do Ministério da Educação e Saúde em 1950; acusação de pareidolia a Ramos).

Todas as fontes acima serviram apenas como inspiração de fundo. A narrativa, os personagens e os eventos descritos são ficção.
