---
titulo: "O Clarão do Tabuleiro"
resumo: "Um guarda-parque passa noites vigiando uma luz inexplicável sobre o planalto de Minas Gerais, até perceber que ela não está apenas no céu — e que já escolheu quem observar de perto."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-clarao-do-tabuleiro"
tipo: "ficcao"
fonte_pesquisa: "G1 / Globo Repórter — luzes inexplicáveis no céu de Minas Gerais (Parque do Tabuleiro)"
---

# O Clarão do Tabuleiro

No Parque Nacional Municipal do Tabuleiro, no centro de Minas Gerais, o céu noturno não é apenas um teto escuro sobre a cabeça de quem passa. É um palco. E, de vez em quando, algo sobe para dançar nele.

Há mais de sessenta anos, o velho Antônio — morador de uma casa de pedra que serve de ponto de apoio para viajantes que cruzam o parque — conta que, de tempos em tempos, aparece uma luz no espaço. Ele não sabe o que é, e diz não acreditar que alguém saiba. Guardas-parque já ouviram visitantes relatarem discos voadores, clarões intensos, luzes que descem do alto e parecem correr atrás de quem caminha pelo mato, forçando as pessoas a se esconder entre as árvores até que o clarão suma. A Guarda Municipal não emite nota oficial. A ciência não apresentou explicação. O que sobra é o silêncio, e a certeza de que, quando a noite cai sobre aquele planalto, o escuro não é vazio.

Eu cheguei ao Tabuleiro como guarda temporário, contratado para cobrir o turno da noite por três meses. Não procurava mistério. Precisava de dinheiro e de um lugar onde ninguém me conhecesse. A cabana de observação fica numa clareira elevada, com janelas de vidro grosso que dão para o vale e para a serra ao redor. Nos primeiros dias, o que mais me incomodava era o silêncio — um silêncio denso, que parece ter peso, como se o ar estivesse segurando a respiração.

A luz apareceu na quarta noite.

Eu estava de pé na janela, com um café morno na xícara, quando vi um ponto branco no alto da serra, parado, como uma estrela que tivesse se enganado de lugar. Olhei de novo. O ponto tinha se movido, sem deixar rastro, e agora ficava mais perto da copa das árvores. Não fazia barulho. Não tinha cauda, não deixava faísca. Não parecia avião, não parecia drone, não parecia balão. Era simplesmente uma luz, branca e fria, pairando acima do mato como se estivesse esperando algo.

A partir daí, passou a aparecer todas as noites. Às vezes surgia logo após o anoitecer; outras, só perto da meia-noite. Nunca seguia trajetória reta. Subia, descia, parava de repente, girava em si mesma e sumia — para reaparecer do outro lado do vale, como se o espaço entre um ponto e outro não existisse. Eu anotava cada aparição num caderno: horário, cor, duração, direção. Uma obsessão discreta, que comecei a proteger como quem guarda um segredo perigoso.

O velho Antônio veio à cabana uma noite, trouxe um pote de doce de leite e sentou-se na cadeira de pau ao lado da janela.

— Você está vendo ela, não é? — disse ele, sem olhar para mim, os olhos fixos no céu.

— A luz — respondi.

— Ela não brinca. Já vi gente correr para o mato porque ela desceu perto demais. Já vi gente que não quis mais sair de casa depois do anoitecer. A gente não sabe o que é. Só sabe que ela observa. E que, quando escolhe alguém, não deixa mais esse alguém em paz.

Sai da cabana naquela noite com a nuca arrepiada. Não foi medo comum. Foi a sensação de que algo, lá fora, estava me estudando com a mesma atenção com que eu a estudava.

Nas semanas seguintes, a luz mudou. Não parou mais apenas no alto da serra. Começou a descer pelo vale, a ficar baixa, próxima do chão, como se estivesse cheirando o ar. Uma noite, vi-la pousar — ou algo parecido com pousar — numa clareira a menos de duzentos metros da cabana. Uma bola de luz branca, silenciosa, que não iluminava o mato ao redor, mas parecia absorver a claridade do lugar. Fiquei parado na janela, sem ousar acender a lanterna. A luz ficou ali por longos minutos, imóvel, e então subiu de volta, rápido, sumindo entre as nuvens.

Foi depois disso que o tempo começou a falhar.

Eu acordava na cabana e o relógio marcava quatro da manhã, mas o céu ainda estava escuro de um jeito que não fazia sentido. Perdi duas horas inteiras de um turno sem lembrar de nada. Encontrei a lanterna ligada no chão, a bateria gasta, embora eu me lembrasse de tê-la deixado sobre a mesa. Comecei a sonhar com a luz — não como algo que vejo, mas como algo que me vê de volta, de dentro do próprio sono. Acordava com a sensação de que algo tinha estado ao lado da minha cama enquanto eu dormia, e que tinha saído justo no momento em que abria os olhos.

Pedi transferência. A resposta veio por escrito, num papel seco: o turno da noite no Tabuleiro estava com falta de efetivo, eu deveria permanecer até o fim do contrato. Não houve argumento que adiasse.

Na última noite, a luz não ficou no alto da serra. Ela desceu.

Sentei-me na cadeira de pau, a mesma do velho Antônio, e esperei. O ponto branco apareceu no horizonte, desceu pelo vale, parou acima da cabana. Não havia nuvens. Não havia lua. Havia apenas aquela claridade fria pairando sobre o telhado, e o silêncio pesado do parque segurando a respiração.

Apaguei a luz da cabana. Fiquei no escuro, parado na janela, e deixei que o clarão entrasse pelo vidro. Não senti medo. Senti reconhecimento, como quem finalmente entende uma peça de um quebra-cabeça que vinha tentando montar a vida toda.

A luz não se moveu. Também não saiu. Ela ficou ali, acima da cabana, enquanto o relógio marcava três horas e vinte minutos — e, pela primeira vez desde que cheguei, eu consegui enxergar o que ela não era.

Não era um fenômeno natural. Não era um avião, não era um satélite, não era reflexo atmosférico. Era uma presença. E o pior não era saber que ela estava lá, acima do meu telhado, observando cada movimento meu. O pior foi perceber, no fim daquela noite, que ela não ia embora.

Quando saí do parque na manhã seguinte, o clarão ainda estava lá. Não acima da cabana — acima de mim. Um ponto branco no céu da estrada, seguindo o ônibus, subindo a serra, descendo para a cidade. Nas semanas que vieram depois, continuei vendo. Não importa onde durmo, em qual cidade, em qual quarto, em qual cama. Quando apago a luz e olho para a janela, há sempre um ponto branco no escuro, parado, esperando.

Não sei o que ela quer. Sei apenas que não está mais no céu do Tabuleiro.

Ela está comigo. E não vai embora enquanto eu estiver acordado para vê-la.

## Fontes de inspiração

- G1 / Globo Repórter, "Mistério no céu de Minas: luzes inexplicáveis intrigam moradores e viajantes", 30/07/2025. Relatos de luzes não explicadas no Parque Nacional Municipal do Tabuleiro (MG), incluindo aparições que mudam de trajeto e, segundo moradores e servidores do parque, parecem seguir ou se aproximar de pessoas; a origem dos fenômenos não foi esclarecida.

Esse texto é uma obra de ficção. Locais, nomes e fatos são inspirados por relatos públicos, mas a narrativa, os personagens e os eventos são criados pelo autor e não pretendem representar eventos reais.
