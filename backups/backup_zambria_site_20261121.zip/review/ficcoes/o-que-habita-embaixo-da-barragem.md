---
titulo: "O Que Habita Embaixo da Barragem"
resumo: "Um investigador volta à cidade natal para apurar desaparecimentos em um reservatório e descobre que algumas lendas não existem para assustar, mas para avisar."
categoria: "criptozoologia"
data: "2026-11-21"
slug: "o-que-habita-embaixo-da-barragem"
tipo: "ficcao"
fonte_pesquisa: "lenda do Minhocão e lagoa sem fundo de Goiás (folclore brasileiro)"
---

## O peso do silêncio

Há coisas que a gente aprende a não mencionar antes dos dez anos. Em Água Branca, no sertão goiano, essa coisa era a Barragem Velha. Não era grande — uns poucos quilômetros de água parada entre dois morros de pedra serrada —, mas tinha fama de engolir. Não barcos. Não objetos. Pessoas. Pescadores que saíam ao amanhecer e não voltavam. Crianças que se aproximavam demais da borda e eram vistas, uma última vez, olhando para a superfície como se algo lá embaixo as olhasse de volta. Oitos nomes nos últimos vinte anos. Oito lápides sem corpo.

Eu saí de Água Branca aos dezoito, prometi nunca mais pisar lá, e voltei aos trinta e dois porque o irmão de uma das vítimas me pagou adiantado para descobrir o que havia acontecido. Chama-se Válter. Não é parente de ninguém importante. É só um homem que enterrou uma filha de catorze anos com caixão fechado e a promessa, feita pela prefeitura, de que tinha sido "afogamento acidental". Eu acreditei na primeira vez. Não acredito mais.

Cheguei na sexta-feira. O céu estava daquele cinza úmido que antecede tempestade, e a barragem repousava no vale como um dente podre. A água não tinha cor definida — um esverdeado opaco que mudava conforme a nuvem passava, e que em certos horários da tarde parecia mais escuro do que deveria, como se a profundidade não fosse medida em metros, mas em algo que não tivéssemos nome. Fui até lá ao entardecer. Não havia ninguém. Apenas o eco dos meus próprios passos no cascalho, o vento nos juncos secos e aquele cheiro antigo de matéria orgânica apodrecendo debaixo do barro.

Sentei na pedra de borda, a mesma onde, segundo contam, um menino chamado Tiago sentou antes de simplesmente não estar mais ali. Esperei. Nada aconteceu. Até que, por volta das dezessete horas e vinte, vi a superfície se mover.

Não foi onda. Não foi peixe. Foi como se algo enorme, abaixo da linha d'água, tivesse virado de lado lentamente. Um deslocamento de massa que arrastou a superfície comigo, um puxão sutil, quase sensual, como se a barragem estivesse respirando. Fiquei imóvel. O silêncio voltou, mas agora carregado — não o silêncio de ausência, mas o de presença contida. Algo estava observando daquela profundidade esverdeada, e eu, pela primeira vez em anos, entendi por que minha mãe me batia quando me pegava perto da água.

## O que o barro guarda

No dia seguinte, procurei Válter. Morava em uma casa de taipa na beira da estrada poeirenta, com um cão que não latia e um olhar que parecia já ter visto o fundo do poço. Ele não ofereceu café. Sentou à minha frente, com as mãos sobre a mesa, e contou o que o laudo oficial omitiu.

— Minha filha não sabia nadar, disse ele, mas não era disso que ela morria. O corpo dela nunca apareceu. Buscaram com rede, com vara, com mergulhador do Corpo de Bombeiros de Goiânia. Nada. Dois dias depois, um cão de pastoreio apareceu a três quilômetros da barragem, morto, com o corpo aberto como se algo grande o tivesse esmagado por dentro. Não havia sangue. Havia apenas… pressão.

Deixei ele falar. Válter não era homem de exageros. Falava baixo, com a precisão de quem repete uma sentença que já ouviu muitas vezes.

— Os antigos dizem que aquilo não é peixe, nem cobra, nem jacaré. Dizem que é uma coisa antiga, que viveu aqui antes da barragem, antes da cidade, antes de termos nome para o medo. Chamam de minhocão, caboclo d'água, bicho-do-fundo. O nome não importa. O que importa é que aquilo fica debaixo do barro, espera, e quando a fome aperta, sobe.

Perguntei se alguém já tinha visto. Válter desviou os olhos.

— Uma pessoa viu. O senhor Seu Pedro, que trabalhava na dragagem na época da construção, nos anos setenta. Eles estavam alargando o leito, retirando lodo, quando o cabo de aço arrebentou. Não se rompeu. Foi cortado. Limpo. Como se algo do tamanho de uma perna de boi, com dentes, tivesse mordido o aço debaixo da água. Depois disso, os operários se recusaram a entrar. A obra parou. A barragem ficou inacabada, e o povoado passou a chamá-la de Barragem Velha, como se a idade pudesse esconder o perigo.

Sai da casa de Válter com o estômago apertado. Voltei à barragem naquela noite. Levei uma lanterna, um gravador e a teimosia de quem acha que o mistério se resolve com luz e equipamento. Fiquei sentado na mesma pedra até a meia-noite. A água permaneceu calma. Só que, por volta da uma da madrugada, ouvi algo.

Não foi respingo. Foi arrasto. Um som pesado, úmido, como de algo grande se deslocando sobre lama — vindo de dentro da água, não da borda. Liguei a lanterna. A luz não atravessou a superfície. Refletiu. E, por um segundo que durou o tempo de um coração parado, vi dois pontos escuros sob a lâmina verde, imóveis, do tamanho de pratos de jantar, olhando para cima.

Desliguei a lanterna e saí correndo.

## A verdade que ninguém quer nomear

No domingo, fui ao arquivo da prefeitura. A funcionária, uma mulher de óculos grossos e pés descalços sobre o chão frio, me deixou revirar pastas amareladas sob a condição de que não levasse nada. Encontrei relatórios de 1984, 1991, 2003 e 2015. Todos concluíam a mesma coisa: afogamento, desaparecimento, causa indeterminada. Nenhum mencionava testemunhas. Nenhum mencionava o som de arrasto. Nenhum mencionava os pontos no fundo.

O padrão era nítido para quem estivesse disposto a vê-lo. Os desaparecimentos aconteciam sempre no mesmo período do ano — entre setembro e novembro, quando as chuvas ainda não tinham enchido o reservatório completamente e a água ficava mais rasa, mais exposta. As vítimas eram sempre sozinhas, sempre perto da borda, sempre em silêncio. Nenhum grito. Nenhum pedido de socorro. Como se fossem puxados antes que o medo tivesse tempo de se tornar som.

A conclusão era simples, e por isso assustadora: algo vive na Barragem Velha. Algo que não é de nossa espécie, que não respeita nossas leis, e que se alimenta do que chega à sua beira. A prefeitura sabe. Os pescadores sabem. Os moradores antigos sabem. Eles não falam porque falar não tira ninguém de dentro da água, e porque admitir que há um predador no reservatório é admitir que o governo não protege, que a ciência não explica e que a noite tem dentes.

Voltei para Válter na segunda-feira. Ele estava na porta, esperando.

— Já sabe o suficiente, disse ele.

— Não. Quero ver.

Ele balançou a cabeça.

— Quem vê, não volta para contar. Minha filha não voltou. O Seu Pedro não voltou para trabalhar. O Tiago não voltou para a escola. Você quer o quê? Uma prova? Uma fotografia? Um corpo? Não há corpo. Só há o que fica embaixo.

Saí da casa dele com o mesmo peso de quando entrei. Dirigi até a barragem uma última vez. Não sentei na pedra. Fiquei na estrada de cascalho, a uns cinquenta metros da água, e olhei para aquele espelho verde que não refletia nada além do céu. Pensei nos oito nomes. Pensei no corpo do cão esmagado por dentro. Pensei nos pontos do tamanho de pratos de jantar, olhando para cima do fundo da lama.

E pensei na maior mentira que contamos a nós mesmos: a de que o desconhecido só existe enquanto não olhamos para ele.

Às cinco da tarde, voltei ao carro e deixei Água Branca para trás. Não terminei a investigação. Não entreguei relatório a Válter. Não cobrei o adiantamento. Algumas respostas não servem para encerrar casos. Servem apenas para fazer você olhar, daí em diante, com desconfiança, para qualquer corpo d'água parado.

Porque agora eu sei. E quem sabe, não pode mais fingir que não sabe.

Quando você passar por uma represa, um lago, um rio escuro, não jogue pedra. Não se incline sobre a borda. Não chame ninguém que esteja sozinho perto da água. A superfície é só a pele. Abaixo dela, algo ainda tem fome. E lembre-se: as lendas não nasceram para entreter. Nasceram para que sobrevivêssemos o suficiente para contá-las.

---

## Fontes de inspiração

Esta é uma obra de ficção. Os elementos reais consultados serviram apenas como referência atmosférica:

- Lenda do Minhocão, criatura do folclore brasileiro associada a rios, lagos e desaparecimentos ribeirinhos (canallendas.blogspot.com).
- Reportagem sobre a "lagoa sem fundo" de Goiás e as lendas de criaturas e desaparecimentos em suas águas (correiobraziliense.com.br).
- Entrada sobre o Caboclo-d'Água na Wikipédia (pt.wikipedia.org).

Nenhum trecho foi copiado integralmente. Todos os fatos, nomes e eventos narrados são fictícios.