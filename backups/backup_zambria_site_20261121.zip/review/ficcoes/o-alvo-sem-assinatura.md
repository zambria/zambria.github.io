---
titulo: "O Alvo Sem Assinatura"
resumo: "Um técnico de radar de vigilância na Amazônia detecta algo que a câmera térmica vê e o radar ignora — e descobre que o silêncio dos registros pode ser o aviso mais alto."
categoria: "ufos"
data: "2026-11-21"
slug: "o-alvo-sem-assinatura"
tipo: "ficcao"
fonte_pesquisa: "SIVAM — Sistema de Vigilância da Amazônia (FAB)"
status: "pendente de curadoria"
---

A sala de controle não tem janelas. Só as telas, a luz vermelha dos indicadores e o zumbido constante dos equipamentos de refrigeração. Sou o técnico de plantão da terceira vigia, numa estação de vigilância aérea do alto rio Negro. Fora dali, a floresta está escura e imensa; dentro, minha função é simples: garantir que tudo o que cruza o espaço aéreo esteja registrado. Toda noite, mesma rotina. A FAB mantém esses radares vinte e quatro horas por dia, trezentos e sessenta e cinco dias por ano, porque o espaço aéreo da Amazônia não dorme. Eu deveria dormir, mas a vigia da noite aprendeu a acordar com os ouvidos.

Foi na terceira terça de outubro que apareceu algo que não tinha assinatura.

Às 02:17, a câmera térmica de apoio apontada para a copa da floresta capturou uma assinatura de calor em baixa altitude, movendo-se paralelamente ao curso do rio. Olhei para o radar principal: nada. Nenhum eco, nenhum retorno de sinal, nenhum transponder, nenhum plano de voo. O alvo não existia para o radar, mas existia para o olho térmico. Uma massa do tamanho de um utilitário pequeno, deslizando a trinta metros acima das copas, sem luzes, sem som que os microfones direcionais captassem.

Registrei o horário, a posição, a ausência de retorno radar. Anotei que o alvo seguia o rio abaixo, mantendo velocidade constante, e desapareceu às 02:23, minutos exatos depois de cruzar a linha da copa. No dia seguinte, entreguei o relatório ao oficial de operações. Ele leu, não comentou, arquivou.

Na semana seguinte, aconteceu de novo. Mesmo horário, mesma trajetória, mesma ausência no radar. Desta vez, verifiquei o arquivo da noite anterior. O registro do primeiro evento havia sido sobrescrito — o sistema de gravação dos radares roda em loop de trinta dias, me disseram, e a fita do meu primeiro avistamento já tinha sido reutilizada. Não havia backup. Não havia prova. Só minha anotação de caneta em um caderno que ninguém pede para ver.

Procurei o técnico da vigia anterior, o Soares, que havia pedido transferência dois meses antes. Atendi ele pelo telefone, numa linha ruim. Perguntei se ele já tinha visto algo que a térmica mostrasse e o radar ignorasse. Soares demorou a responder. Disse que sim, duas vezes, no mesmo período do ano passado. Disse que, depois da segunda vez, parou de anotar. Perguntei por quê. Ele respondeu: porque o que não tem assinatura não tem dono, e quem começa a procurar dono para coisa sem assinatura acaba passando a ter um.

Voltei ao arquivo. A partir daí, revisei trinta dias de gravações — não todas, impossível, mas o suficiente. Encontrei a mesma assinatura em outras três noites, sempre entre 02:17 e 02:23, sempre seguindo o rio, sempre invisível ao radar. Em duas dessas noites, o arquivo seguinte ao avistamento estava corrompido, com blocos de zeros onde deveriam estar os ecos. Não é erro de equipamento. Ou é, mas é um erro que só acontece exatamente ali.

Na quarta-feira passada, decidi não ficar na sala. Subi à torre de observação com binóculos de visão noturna e um gravador de campo. O céu estava limpo, cheio de estrelas, sem luzes incomuns. O rio, embaixo, era uma fita escura entre a mata. Esperei até as 02:15. O silêncio da floresta naquela hora não é ausência de som; é uma espécie de contenção, como se os bichos estivessem segurando a respiração.

Às 02:17, a térmica do posto — deixei ligada, com o feed enviado para um tablet na torre — mostrou a assinatura novamente. Olhei para cima, para o ponto exato sobre o rio. Não vi nada. Só céu. Só escuridão. Mas o som mudou. O zumbido dos insetos parou. O barulho da água no rio diminuiu, como se a corrente tivesse engrossado e parado de fazer barulho contra as pedras. Algo estava ali. Algo que o radar não registra, que a vista não alcança, que o ouvido não nomeia. Algo que desliza pelo espaço aéreo da Amazônia sem pedir permissão, sem transponder, sem plano de voo, sem assinatura.

Desliguei o tablet. Desci a torre. Não anotei nada dessa vez. Não vou anotar. O que não tem assinatura não entra nos relatórios, e o que não entra nos relatórios não existe para ninguém.

Só que agora eu sei que existe. E o pior não é saber que algo voa sobre a floresta sem ser visto. O pior é a suspeita fria, que não me deixa dormir, de que, ao olhar na direção certa na hora certa, eu deixei de ser apenas quem registra o alvo. Passei a ser o alvo.

## Fontes de inspiração

- Sistema de Vigilância da Amazônia (SIVAM), descrito pela FAB e por fontes públicas como uma rede de radares que monitora o espaço aéreo da Amazônia 24 horas por dia, com estações em cidades como São Gabriel da Cachoeira, Tabatinga e Tefé.
- Wikipedia (pt), "Sistema de Vigilância da Amazônia": estrutura de sensores, radares bidimensionais e tridimensionais, integração com satélites de sensoriamento remoto.

Todos os nomes, personagens, eventos e reviravoltas são fictícios. A pesquisa serve apenas de cenário para a narrativa.
