---
titulo: "Os 21 Pinos no Radar"
resumo: "Na noite oficial dos OVNIs, 19 de maio de 1986, um controlador do Cindacta I acompanha vinte e um plotes não identificados cruzarem o céu brasileiro enquanto caças são lançados no vazio e o silêncio oficial fecha o arquivo atrás de tudo."
categoria: "ufos"
data: "2026-11-21"
slug: "os-21-pinos-no-radar"
tipo: "ficcao"
fonte_pesquisa: "BBC News Brasil, CNN Brasil e Wikipédia (pt) — Noite dos Discos Voadores / Noite Oficial dos OVNIs"
---

# Os 21 Pinos no Radar

A noite de dezenove de maio de mil novecentos e oitenta e seis não começou como anúncio. Começou como ruído. No Cindacta I, o Primeiro Centro Integrado de Defesa Aérea e Controle de Tráfego Aéreo, em Brasília, a tela do radar varria o céu do Sudeste com a mesma metódica preguiça de sempre: aviões de linha em rotas traçadas, caças da Força Aérea em exercícios programados, o trânsito previsível de quem acredita que o espaço aéreo pertence a quem o mapeia. Até que um ponto se recusou a seguir o roteiro.

Não era um avião. Não tinha plano de voo, não respondia à frequência, não assinava o plano de pressão nem a curva de inércia que todo controlador aprende no primeiro dia de aula. Era um plote. Um ponto sólido no radar, portanto real para a máquina, mas impossível para o horizonte. Depois vieram mais. Vinte e um, ao fim da noite, espalhados entre São Paulo, Rio de Janeiro, Minas Gerais e Goiás, movendo-se a velocidades que não constavam nas tabelas, parando no ar, invertendo curso, desaparecendo e reaparecendo como se o céu brasileiro fosse um brinquedo desmontado e remontado por mãos que não pedem licença a ninguém.

Não há como descrever a sensação de ver vinte e um intrusos aparecerem simultaneamente na sua tela sem saber o que são, de onde saem ou se estão vendo você de volta. O coração não acelera da forma romântica dos filmes. O coração simplesmente para de bater com confiança. Você passa a duvidar da própria cadeira, do próprio colete, do próprio ar que respira na sala de controle. Cada varredura do radar confirma que algo está ali, sólido, silencioso, e que nenhuma das regras escritas no manual serve para conversar com aquilo.

Os primeiros relatos chegaram da Torre de Controle do Aeroporto de São José dos Campos, no Vale do Paraíba. Luzes que mudavam de cor — branco, vermelho, verde —, pontos que dançavam no escuro, pilotos civis perguntando ao controlador se ele estava vendo a mesma coisa. A confirmação veio do Cindacta I: não eram ilusão de ótica. Eram objetos sólidos, detectados por radares de defesa aérea, o que significa, em outras palavras, que ocupavam espaço físico, refletiam ondas eletromagnéticas, deixavam rastros que a máquina podia medir. O que a máquina não podia medir era a intenção.

O Centro de Operações de Defesa Aérea, o CODA, decidiu então que o céu precisava de uma resposta. Cinco caças foram lançados no escuro: dois F-5 Tiger II decolaram da Base Aérea de Santa Cruz, no Rio de Janeiro; três Mirage III partiram da Base Aérea de Anápolis, em Goiás. Caças supersônicos contra alvos que não queriam ser alcançados. Durante horas, pilotos da Força Aérea Brasileira perseguiram pinos de luz no vazio, tentaram fechá-los, tentaram encurralá-los contra o horizonte. Cada aproximação terminou da mesma forma: os objetos simplesmente não estavam mais lá. Ou estavam em outro lugar. Ou nunca estiveram. Nenhum dos cinco caças chegou perto o suficiente para afirmar alguma coisa. A operação foi uma brincadeira de gato e rato em que o rato não existia, apenas os dentes do gato mordendo o ar.

Enquanto isso, no solo, um avião bimotor Xingu voltava de Brasília para São José dos Campos. O piloto ouviu a voz do controlador pela frequência, perguntando algo que nenhum passageiro jamais quer ouvir: se ele tinha avistado "algo de esquisito no ar". No radar do controlador, três objetos pairavam sobre São José dos Campos exatamente na mesma altitude. Três. Não um. Três espectadores silenciosos sobre um avião civil, sobre uma cidade, sobre um país que havia acabado de descobrir que seus céus não eram mais inteiramente seus.

No dia seguinte, o então Ministro da Aeronáutica, o tenente-brigadeiro do ar Octávio Júlio Moreira Lima, enfrentou os jornalistas ao lado dos pilotos dos caças. Confirmou os acontecimentos. Nomeou a noite. Foi a primeira e, possivelmente, a última vez que o Estado brasileiro admitiu, oficialmente, que algo desconhecido cruzou seu espaço aéreo em formação, desafiou seus caças e sumiu sem deixar recibo. Por isso o episódio ficou conhecido como a Noite Oficial dos OVNIs — oficial não porque alguém explicou o que aconteceu, mas porque alguém admitiu que aconteceu, e depois fechou a porta.

E aqui mora o verdadeiro arrepio desta história, o que eu levo comigo depois de tantas varreduras de tela e tantos relatórios arquivados: não foram os objetos o assustador. Foi o silêncio que veio depois. Os caças voltaram às bases. Os plotes sumiram dos radares. Os jornais estamparam a manchete por um dia, talvez dois. A vida voltou ao normal, ou pelo menos ao que o normal finge ser depois de um susto coletivo. Nenhum inquérito público revelou a natureza dos vinte e um pinos. Nenhum general apareceu na televisão para dizer que estão vigilantes, que estão preparados, que o espaço aéreo está seguro. Apenas o arquivo fechado, o ministro que nunca mais falou do assunto, e os pilotos que, segundo consta, nunca mais voaram naquela região noturna sem olhar para trás.

Fico pensando nisso toda vez que o céu se abre em noite clara. O que quer que tenha passado por cima do Brasil naquele dezenove de maio não veio nos visitar, nem nos entregar mensagens, nem nos raptar para mostrar o interior de um disco. Veio nos mostrar que o céu nunca foi cenário. O céu é palco. E nós, embaixo, somos apenas plateia que aprendeu a fingir que não ouviu os aplausos virem do lugar errado.

## Fontes de inspiração

- BBC News Brasil — "Óvnis: a noite em que 21 objetos voadores invadiram o espaço aéreo brasileiro e foram perseguidos por caças da FAB" (https://www.bbc.com/portuguese/articles/c5ye4gz9mezo.lite)
- CNN Brasil — "Noite dos OVNIs: Brasil já teve caças da FAB perseguindo objetos voadores" (https://www.cnnbrasil.com.br/nacional/noite-dos-ovnis-brasil-ja-teve-cacas-da-fab-perseguindo-objetos-voadores/)
- Wikipédia (pt) — "Noite dos discos voadores" (https://pt.wikipedia.org/wiki/Noite_dos_discos_voadores)
- SP Rio Mais — "Noite Oficial dos OVNIs completa 40 anos de mistério" (https://spriomais.com.br/2026/05/19/noite-oficial-dos-ovnis-completa-40-anos-de-misterio/)

Os fatos históricos acima serviram apenas como inspiração para esta obra de ficção. Personagens, diálogos e percepções internas são criações próprias; não há reprodução de texto das fontes consultadas.
