---
titulo: "O Fogo de Yaripo"
resumo: "No sopé do ponto mais alto do Brasil, um técnico de rádio vê luzes descerem do Pico da Neblina e descobre que voltar da montanha não é o mesmo que nunca ter saído dela."
categoria: "ufos"
data: "2026-11-21"
slug: "o-fogo-de-yaripo"
tipo: "ficcao"
fonte_pesquisa: "Portal 6, NSC Total e O Povo Amazonense (Pico da Neblina e relatos de luzes no Alto Rio Negro); O Antagonista (Operação Prato, Pará, 1977)"
---

# O Fogo de Yaripo

Há vinte e três dias acordo às 5h30 para confirmar que a montanha ainda está onde deveria estar. O posto de rádio fica a quarenta quilômetros do sopé do Pico da Neblina, Yaripo para os Yanomami, 2.995 metros de pedra e nuvem sobre a Serra do Imeri, no ponto em que o Brasil termina e a Venezuela começa. Área restrita. Parque Nacional desde 1979. Acesso proibido a turistas desde 2003, com reabertura condicionada apenas a partir de 2019, sob acordo entre ICMBio, Funai e associações indígenas, guia Yanomami obrigatório e grupos de no máximo dez pessoas. Eu não sou turista. Sou técnico de telemetria de uma comissão de controle de frequências, e minha autorização assinada permite apenas que eu permaneça aqui ouvindo o silêncio.

O silêncio, no entanto, não é a única coisa que se recusa a ser medida.

Durante décadas, os mapas oficiais apontaram 3.014 metros de altitude. Depois o IBGE, com GPS e imagens de satélite, revisou o número para 2.995,30 metros, e o Exército Brasileiro atualizou as cartas. Ninguém, porém, mediu o que costuma descer da montanha quando o sol se retira atrás da Serra do Imeri. Nas primeiras duas semanas no Alto Rio Negro, atribui as luzes ao cansaço: clarões na periferia da visão, reflexos de aeronaves em rotas comerciais sobre Manaus, estrelas que parecem se mover porque a mente humana odeia o imóvel. Na décima nona noite, deixei de atribuir a qualquer coisa.

Foi um ponto laranja, do tamanho de uma moeda estendida, que emergiu da floresta abaixo da linha de nuvens, subiu devagar, sem som, e parou ao nível do mastro de antena do posto. Ficou ali por cerca de quarenta segundos — contei no relógio de pulso, cuja bateria parou exatamente no instante em que a luz se apagou. Não houve ruído de motor, não houve trilha de combustão, não houve declaração de plano de voo. Apenas o ponto, a parada e o escuro que voltou mais denso do que antes.

Achei que tivesse sonhado com os olhos abertos, se não fosse pelo gravador de fita. Revisava a fita na manhã seguinte e ouvi minha própria voz dizendo, em tom calmo demais para ser meu: "Está descendo. Está aqui embaixo agora." O registro tem quarenta e seis segundos de áudio seguido por sete minutos de estática, e depois nada. Nada até as 6h02 do dia seguinte, quando a gravação retoma com o som da minha respiração e a porta do posto abrindo. Entre as 22h14 e as 6h02, nove horas do meu turno não existem em nenhum aparelho que possuo, nem na memória. Dormi? Não sei. Se dormi, não sonhei — ou sonhei demais para conseguir contar.

Naquele mesmo instante, tentei contactar o comando em São Gabriel da Cachoeira. Rádio em frequência morta. O oficial de ligação do Exército chegou no dia seguinte num helicóptero que não constava em nenhum plano de voo, recolheu o gravador, conferiu as baterias dos equipamentos e disse para eu não escrever nada no relatório de campo. "Constam apenas o que o IBGE mede", afirmou, como se a altura de uma montanha explicasse tudo o que acontece ao redor dela. É esse o tipo de sarcasmo oficial que sustenta a fronteira: medem a pedra com precisão de centímetros, catalogam o parque, exigem autorizações e guias indígenas, e ignoram sistematicamente o que a pedra devolve quando ninguém está autorizado a olhar.

K., o auxiliar Yanomami do posto, recusou-se a subir naquela noite. Não deu explicações. Disse apenas que Yaripo não chama quem não é chamado, e que quem sobe sem ser convidado volta com o olhar ocupado por outra coisa que não é ele. Depois de meu episódio, K. parou de falar comigo por completo. Não por rancor — por reconhecimento, acredito. Ele viu o mesmo ponto laranja da floresta, de onde quer que estivesse, e soube que eu tinha sido notado.

Tentei retomar a rotina. Verifico antenas, anoto frequências, confirmo que a montanha está no lugar. Mas perdi a capacidade de dormir com a janela fechada. Sinto que algo assiste do telhado, ou do cume, ou do espaço entre as nuvens que o Exército se esforça em mapear. Não tenho prova física. Não tenho marca na pele, não tenho implante, não tenho memória de ter sido levado a lugar algum. Tenho apenas a ausência: nove horas que o mundo registrou sem mim, e a constatação fria de que o fogo de Yaripo não veio para ser visto. Veio para verificar se havia alguém assistindo. Agora há alguém. E o pior não é ter sido visto. O pior é que, toda noite, antes de apagar a lanterna, ainda olho para o cume esperando que a luz desça de novo — e desta vez eu esteja pronto para subir.

## Fontes de inspiração

- Portal 6, NSC Total e Revista Amazônia — dados sobre o Pico da Neblina: altitude oficial de 2.995 metros (revisada pelo IBGE a partir dos 3.014 metros anteriores), localização na Serra do Imeri, fronteira com a Venezuela, Parque Nacional criado em 1979, controle de acesso por ICMBio e Funai, reabertura condicionada com guia Yanomami obrigatório.
- O Povo Amazonense — relatos de luzes inexplicáveis no céu do Amazonas, citando São Gabriel da Cachoeira, o Pico da Neblina e o Monte Roraima como pontos frequentes de avistamentos, com registros desde os anos 1950 e ocorrências recentes entre 2024 e 2026.
- O Antagonista — reportagem sobre a Operação Prato, missão da Aeronáutica na região de Colares (Pará), em 1977, que documentou centenas de ocorrências de corpos luminosos sobre comunidades costeiras, encerrada sem explicação pública conclusiva.

Todas as referências servem apenas como inspiração geográfica e documental; os personagens, os eventos e o diálogo são ficção.
