---
titulo: "O Espectro do Caparaó"
resumo: "Um pesquisador sobe ao Pico da Bandeira para registrar o espectro de Brocken, o fenômeno óptico que projeta a sombra do observador na névoa com um halo de luz ao redor da cabeça. O que retorna da névoa, no entanto, não obedece à ótica — e não é apenas a sua sombra que sobe com ele."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-espectro-do-caparao"
tipo: "ficcao"
fonte_pesquisa: "Super Abril, tempo.com, G1, MeteoSwiss, Wikipedia (Pico da Bandeira)"
---

# O Espectro do Caparaó

Elias chegou ao cume do Pico da Bandeira pouco antes das seis da manhã, com o vento do Caparaó já cortando a jaqueta e o sol ainda abaixo da linha do horizonte. A 2.892 metros de altitude, o ar é fino o suficiente para transformar cada respiração em um esforço consciente. Ele não viera para provar nada. Viera para ver, com os próprios olhos, uma ilusão que montanhistas relatam há séculos: o espectro de Brocken.

Era o terceiro dia na montanha. Acampado no Terreirão, do lado mineiro, Elias passara as noites ouvindo o crepitar do geada na lona e o sussurro da serra abaixo. De dia, caminhava pelas trilhas com uma câmera e um caderno de campo, não como um turista, mas como alguém que coleta fenômenos atmosféricos como quem coleta provas de um crime sem corpo. O Caparaó, em novembro, é um lugar de névoas baixas e de sol feroz quando decide aparecer — a combinação exata que o espectro exige.

Por volta das seis e vinte, o céu clareou a leste. Elias posicione-se de costas para o sol, exatamente como a física do fenômeno manda, e olhou para a camada de névoa que se estendia como um tapete branco abaixo do cume. E então apareceu.

À frente de si, suspensa sobre o mar de nuvens, estava sua própria sombra — mas ampliada a proporções que desafiavam a crença. Uma silhueta negra, de braços abertos, de cabeça erguida, gigantesca, pintada na névoa como se a nuvem fosse uma tela e ele, o artista invisível. Ao redor da cabeça da sombra, um halo de anéis concêntricos, branco no centro e com toques de azul e violeta nas bordas: a gloria, o companheiro inevitável do espectro. Era belo. Era também, Elias percebeu com um arrepio que não veio do frio, profundamente errado.

A ótica explica tudo, é claro. A sombra é projetada sobre as gotículas de água da névoa porque o observador está entre o sol e a camada de nuvens. A ampliação é ilusão: o cérebro julga a distância da névoa como se fosse o solo distante, e enxerga a silhueta maior do que ela é. Os anéis coloridos são difração da luz sobre gotículas pequenas. Há equações, há física, há um nome alemão para a montanha onde o fenômeno foi descrito pela primeira vez. Nada disso, no entanto, prepara quem está ali de pé, sozinho, vendo a si mesmo transformado num deus de névoa e luz.

Elias levantou a câmera. O espectro levantou a câmera ao mesmo tempo. Ele fechou o punho direito; o gigante de névoa fechou o punho direito. Era o espelho perfeito, como devia ser. Ele sorriu, e a sombra sorriu de volta com uma curva de boca que, nesse tamanho, parecia uma ameaça.

Abaixou a câmera. Abaixou a mão. E o espectro não baixou a mão.

Ficou ali, suspensa na névoa, a mão direita ainda erguida, os dedos longos e pretos entrelaçados com a brisa que não existia. Elias piscou. Esfregou os olhos. Atribuiu ao cansaço, à altitude, à fadiga de três dias sem sono adequado. A sombra voltou a imitar seus movimentos nos minutos seguintes — ou pareceu imitar. A dúvida, uma vez plantada, é mais difícil de extirpar do que o geada da lona.

Decidiu descer. A névoa, porém, começou a subir com ele.

Pelo caminho de volta ao Terreirão, Elias parou três vezes para olhar para trás. Cada vez, a silhueta gigante ainda estava lá, pintada nas nuvens abaixo do cume, embora o sol já estivesse alto demais para projetar qualquer coisa naquela direção. Cada vez, a sombra estava em uma posição ligeiramente diferente da anterior. Não era a sombra de Elias. Era algo que usava a forma de sua sombra como disfarce.

Naquela noite, deitado na tenda com a lanterna pendurada no mastro central, Elias observou sua própria sombra projetada na lona. Movimentou a mão direita. A sombra na lona movimentou a mão direita. Movimentou a esquerda. A sombra acompanhou. Então parou de se mexer — e a sombra de Elias na lona continuou o gesto, devagar, como se estivesse testando até onde o corpo real ainda podia chegar.

Elias apagou a lanterna. No escuro da tenda, ouviu algo do lado de fora: um passo que não ecoou contra o solo, apenas contra a névoa. Um passo que não tinha peso.

Desceu no dia seguinte. Fez o caminho de volta por entre as trilhas do Parque Nacional do Caparaó, passando por Tronqueira, sem olhar para trás até alcançar a portaria de Alto Caparaó. Quando olhou, o cume ainda estava envolto em névoa, e por um instante — apenas um instante, jura — viu a silhueta gigante se levantar das nuvens, sem sol, sem câmera, sem testemunha.

O espectro de Brocken não é uma projeção da luz. É um convite. E algo, nas névoas do Caparaó, aprendeu a sair dela.

## Fontes de inspiração

- Super Abril — "O espectro de Brocken": fenômeno óptico em que a sombra do observador é projetada nas camadas densas de nevoeiro no cimo de uma montanha, com sol próximo ao horizonte, acompanhada de halos coloridos ao redor da cabeça; a ampliação da sombra decorre de refração e da ilusão de distância.
- tempo.com — "O incrível e raro fenômeno ótico do espectro de Brocken": ocorre quando o sol está baixo, atrás do observador, e este está acima de uma camada de nuvens; a sombra ampliada aparece contra o "tapete branco de nuvens", com áureola semelhante a um arco-íris; raro e dependente de condições específicas de umidade e iluminação.
- G1 — fenômeno óptico registrado durante acampamento no Rio Grande do Sul: a sombra de uma pessoa projetada sobre nuvens ou neblina com o sol atrás; neblina próxima gera ilusão de ótica que amplia o tamanho da sombra.
- MeteoSwiss — "Glory and Brocken Spectre": anéis coloridos ao redor da sombra projetada na camada de neblina; fenômeno frequente em topos de montanha expostos à neblina; pode ser bastante desconcertante pelo movimento e pela vastidão da própria sombra.
- Wikipedia — "Pico da Bandeira": terceiro ponto mais alto do Brasil (2.892 m), divisa entre Minas Gerais e Espírito Santo, Parque Nacional do Caparaó, acesso pela portaria de Alto Caparaó (MG) com áreas de acampamento como o Terreirão; clima frio, com geadas comuns e temperaturas abaixo de zero nos meses mais frios.

Todas as referências servem apenas de inspiração para a ficção; os personagens, os eventos e o desfecho são invenções do autor.
