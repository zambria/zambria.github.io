---
titulo: "O Furo Que Chamou de Volta"
resumo: "Uma perfuração privada no interior mineiro alcançou profundidades que não constavam em nenhum projeto oficial. O que subiu do furo não deixou registros — exceto na memória de quem esteve lá."
categoria: "conspiracos"
data: "2026-11-21"
slug: "o-furo-que-chamou-de-volta"
tipo: "ficcao"
fonte_pesquisa: "Wikipedia — Kola Superdeep Borehole; BMC News; Aventuras na História"
---

# O Furo Que Chamou de Volta

A tampa de aço ainda está lá. Não a vejo há anos, mas sei que está. Uma chapa circular, soldados ao redor, cravada no solo de uma fazenda abandonada no interior de Minas Gerais, a uns sessenta quilômetros de qualquer município com nome em mapa. Abaixo dela, a boca de um furo de nove mil e oitocentos metros. Ninguém mais se lembra da empresa que o cavou. Os documentos somaram-se, os responsáveis morreram de causas naturais ou simplesmente sumiram, e o poço foi selado com a pressa de quem não quer mais olhar para baixo.

Eu estive lá. Não como operário, mas como geólogo de campo. Fui contratado para registrar estratigrafia, não para acreditar em fantasmas. O que aconteceu abaixo dos dois quilômetros deixou de ser geologia e passou a ser outra coisa — algo que a empresa decidiu não nomear, e que eu decidi não esquecer.

## I

A perfuração começou em julho de 1998, sob o pretexto de pesquisa hídrica. A Sondagem Profunda Ltda. trouxe uma plataforma Uralmash comprada de sucata na Europa Oriental, montou o acampamento na beira da serra e começou a girar a broca. O objetivo oficial era localizar aquíferos profundos para abastecer uma região atingida por seca. O objetivo real, só soube depois, era testar até onde a crosta continental brasileira podia ser perfurada antes de se tornar algo diferente de pedra.

Nos primeiros seis meses, tudo correu como nos manuais. Passados os mil metros, a rocha era gnaisse, como esperado nos Escudos Precâmbricos. Nos três mil, ainda gnaisse, mais metamorfizado. Por volta dos cinco mil, a temperatura começou a subir mais rápido do que o gradiente geotérmico previu. Não era um erro de medição: a rocha, àquela profundidade, comportava-se quase como material plástico, fechando-se ao redor da broca, prendendo o fio de sondagem. O calor chegava aos cento e cinquenta graus centígrados antes dos sete mil metros, quando os modelos mais otimistas prometiam noventa.

Lá estava a primeira anomalia. A segunda veio nas fraturas. Aos seis mil e duzentos metros, o núcleo de retorno trouxe água — não água de perfuração, não resíduo de lama bentonítica, mas água fria, presa em fendas da rocha, algo que não deveria existir ali. A empresa mandou analisar. O laudo, que eu li, falava em "contaminação de superfície" e arquivou o amostra. Eu guardei uma cópia não oficial.

A terceira anomalia não apareceu em nenhum laudo. Apareceu no som.

## II

Aos oito mil e trezentos metros, a broca voltou à superfície quente demais para ser tocada com luva de aluminizado. Aderia à ponta uma película escura, fina, que cheirava a ozônio e a pedra molhada. O laboratório de campo não conseguiu identificar a composição. Dissolveram um fragmento em ácido nítrico e o líquido ficou preto, espesso, como se recusasse a ser reduzido a elementos.

Naquela noite, desceram um hidrofone com cabo blindado até os sete mil e novecentos metros. O aparelho foi construído para captar sismos, não vozes. O que gravou não foi sismo. Foi um impacto rítmico, lento, espaçado por cerca de doze segundos entre cada golpe, como se algo do outro lado da crosta estivesse batendo na parede do furo com uma massa pesada e macia. O som não viajava pela rocha — viajava pelo ar dentro do tubo de aço, como se o furo fosse um órgão e o ar, seu fôlego.

Desligamos o equipamento. Na manhã seguinte, o gravador estava vazio. Não havia fita, não havia arquivo digital, não havia nada. O hidrofone voltou quebrado, o cinto de aço entortado para dentro, como se algo tivesse puxado o aparelho para o fundo e não deixado sair.

A empresa parou a perfuração no dia seguinte. Oficialmente: falta de verba, falha técnica, instabilidade do poço. Oficialmente nada, porque o projeto nunca existiu nos registros públicos. Três técnicos da equipe foram dispensados. Um deles, o sondaísta que operava o guincho, morreu duas semanas depois em um acidente de moto — ou então não morreu; não há certidão, não há enterro, não há corpo. O outro, o eletricista que instalou o hidrofone, pediu demissão e saiu da cidade sem deixar endereço. Eu pedi demissão na mesma semana.

Levei comigo um caderno de campo. Nele, anotei a profundidade exata, a temperatura, a descrição da película escura, a data da gravação. E anotei uma coisa que não devia estar lá: quando o hidrofone estava a sete mil e novecentos metros, e antes do impacto rítmico começar, ouvi pelo fone de ouvido uma palavra. Não era português. Não era qualquer língua que reconhecesse. Era o meu próprio sobrenome, dito com uma voz que soava como se estivesse vindo de muito abaixo, e muito perto, ao mesmo tempo.

## III

O furo foi selado em março de 1999. Uma tampa de aço de meia polegada, soldados por todo o perímetro, cimento ao redor, placa de identificação com um número de série que não consta em nenhum banco de dados que eu consiga acessar. A fazenda foi vendida. O proprietário disse que nunca ouviu falar de nenhuma perfuração. O terreno agora é pasto. Gado sopra nascente a poucos metros da tampa.

Não voltei ao local. Não preciso. Levo o furo comigo.

Às vezes, à noite, quando a casa fica quieta e o ar parado, sinto uma pressão nos ouvidos, como se estivesse a mil metros de profundidade. Outros ouvem zumbido. Eu não ouço zumbido. Eu ouço o silêncio abaixo da tampa, esperando que alguém lembre de abrir.

A ciência já perfurou mais fundo que isso. O poço soviético de Kola chegou aos doze mil duzentos e sessenta e dois metros, encontrou água onde não deveria haver, microfósseis de dois bilhões de anos, rocha que se comportava como plástico, e parou porque o calor tornou a broca inútil. Selou o poço com uma tampa metálica em dois mil e oito. Não publicou o que ouviu lá embaixo, se ouviu algo. Não publicou porque algumas descobertas não servem para artigos. Servem para manter as pessoas longe da broca.

O que me assusta não é a possibilidade de haver algo vivo, ou algo inteligente, a nove mil e oitocentos metros abaixo de um pasto de gado em Minas Gerais. O que me assusta é saber que, quando o hidrofone captou aquele som, eu não tive medo. Tive reconhecimento. Como se já conhecesse aquela voz. Como se ela estivesse esperando, e como se, algum dia, ela consiga subir.

Não abram a tampa. Não desçam nada pelo furo. E, se uma noite vocês sentirem pressão nos ouvidos em um quarto silencioso, lembrem-se: não é o ouvido que está errado. É o mundo, fininho como casca de ovo, e do outro lado algo está batendo, contando doze segundos entre cada golpe, esperando que a gente desista de selar o que nunca deveria ter sido aberto.

## Fontes de inspiração

As informações geológicas que embasam a atmosfera desta ficção (profundidade máxima, temperaturas encontradas, presença de água em fraturas profundas, ausência da descontinuidade de Conrad, selamento do poço) são referências gerais sobre o Poço Superprofundo de Kola, consultadas em fontes públicas: Wikipedia (Kola Superdeep Borehole), BMC News e Aventuras na História. Nenhum trecho foi copiado; todos os fatos foram parafraseados e inseridos em um contexto de ficção original.

---

Fim.
