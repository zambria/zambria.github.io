---
titulo: "O Que Rasteja nas Fendas do Roraima"
resumo: "Uma expedição ao tepui mais isolado da América do Sul descobre que as lendas sobre os sunkies — pequenos seres que habitam o interior da montanha — não são apenas folclore. Algo observa das fendas, e não está disposto a ser visto."
categoria: "criptozoologia"
data: "2026-11-21"
slug: "o-que-rasteja-nas-fendas-do-roraima"
tipo: "ficcao"
fonte_pesquisa: "Correio Braziliense, Portal Amazônia, Venezuela Verde, Ancient Pedia, ACA Brasil (lendas do Monte Roraima)"
---

O Monte Roraima não é um monte. É um pedaço de terra que decidiu parar de subir e ficar flutuando entre o céu e a selva, como um prato de jantar de gigante deixado cair sobre a fronteira entre Brasil, Venezuela e Guiana. Do chão, ele parece um paredão vertical de 400 metros que não convida ninguém. Para os Pemon, os Ingarikó, os Macuxi, é a Casa de Makunaima. Para os guias de turismo que levam aventureiros até o cume, é apenas mais um destino instagramável com pedras que parecem bustos de presidente. Nenhuma das duas versões está inteiramente certa.

A neblina no Roraima não se comporta como neblina comum. Não entra, não sai. Ela fica. Assenta-se sobre o platô como um tecido úmido que se recusa a ser sacudido pelo vento, e dentro dela as distâncias perdem o sentido. Você caminha em linha reta e, quando olha para trás, o ponto de partida não está mais onde deveria. É nesse território de incerteza que as pessoas começam a notar as fendas.

Não são fendas comuns. Não são aquelas rachaduras que a erosão faz em qualquer pedra velha, produto da chuva e do tempo. As fendas do Roraima parecem ter sido cortadas com precisão cirúrgica, como se alguém tivesse passado uma lâmina invisível sobre a rocha arenítica e aberto espaços onde não deveria haver espaço. Elas são estreitas demais para um homem, largas demais para um rato, e suficientemente profundas para engolir o som de uma voz humana sem devolver nenhum eco.

Foi aí que os sunkies entraram na história.

De acordo com a tradição oral dos povos indígenas da região, os sunkies — também chamados de amaikok — são seres pequenos, de aproximadamente um metro de altura, cabeça larga, olhos grandes e escuros, pele cinzenta. Moram dentro da montanha, em túneis e câmaras que a ciência ainda não catalogou. Não são malignos, segundo os Pemon. Ajudam índios e exploradores perdidos, dizem as lendas. Não representam ameaça. Apenas observam.

Eu não fui ao Roraima para procurar sunkies. Fui por algo muito mais banal: um contrato de reportagem, uma pauta sobre ecoturismo na fronteira, a promessa de um texto bonito sobre a natureza intocada. Cheguei com o equipamento padrão — mochila, botas, casaco impermeável, câmera, gravador — e a arrogância de quem acredita que o mistério é algo que se resolve com mapa e bússola. O guia, um homem de Paraitepuy de quem nunca soube o nome verdadeiro, me olhou com aquela expressão de quem já viu turistas desaparecerem e nunca mais serem encontrados, mas não disse nada. Apenas balançou a cabeça e começou a subir.

O primeiro dia foi exaustivo. A rampa de subida é íngreme, a rocha escorregadia, o ar fica mais rarefeito a cada passo. No acampamento base, antes de alcançar o topo, a frente do tepui é dominada por uma formação que os guias chamam de "portal de energia" — uma abertura na parede que, segundo dizem, permite o contato com seres de outros mundos. Não vi nada de extraordinário ali. Apenas rocha, neblina e o silêncio pesado de quem não quer ser ouvido.

O problema começou no segundo dia, quando acampamos no Vale dos Guardiões, aquela área do cume repleta de pedras com formatos de animais que a erosão esculpiu ao longo de milhões de anos. Ou, se preferir a versão menos romântica, pedras que parecem animais porque a nossa mente é programada para ver padrões onde não há nenhum. É uma questão de perspectiva. Até a noite cair.

Por volta da meia-noite, acordei com a sensação de que algo estava me observando. Não era um barulho. Não era um movimento na tenda. Era apenas — peso. O peso de um olhar vindo de fora, vindo de perto, vindo de algum lugar que minha visão não alcançava. Zinpei a linterna para fora do saco de dormir e iluminei a entrada da tenda. Nada. Apenas a neblina cinzenta, as pedras escuras, o silêncio. Voltei a deitar. Não dormi mais.

Na manhã seguinte, o guia encontrou as primeiras pegadas.

Não eram pegadas de animal conhecido. Não tinham marcas de garras, não mostravam dedos, não deixavam sulcos na areia úmida do vale. Eram simplesmente impressões de algo pequeno, leve, que havia caminhado ao redor da nossa tenda e depois entrado — ou saído — por uma fenda na rocha que não tinha mais do que quinze centímetros de largura. Uma fenda que, no dia anterior, não existia. Ou, pelo menos, ninguém havia notado.

— Essas não são de sapinho — disse o guia, em português carregado de sotaque. Oreophrynella quelchii, o sapinho-preto do Roraima, não deixa pegadas assim. Não caminha em linha reta. Não contorna tendas.

Não respondi. Olhei para a fenda. Ela era escura demais para ser apenas uma rachadura na pedra. Parecia uma boca fechada, esperando ser aberta.

Durante os dois dias seguintes, as coisas se tornaram estranhas de forma cumulativa, não espetacular. Não houve gritos, não houve monstros correndo pela nossa frente, não houve luzes no céu. Apenas pequenos deslocamentos da realidade. Um equipamento eletrônico que parava de funcionar e voltava ao ser movido para dez metros de distância. Uma bússola que girava em círculos quando parada sobre certas formações rochosas. O som de passos leves na areia à noite, sempre vindo de trás, sempre parando quando nos virávamos para olhar.

E as fendas. Cada vez mais fendas.

Elas apareciam onde não deveriam. Em pedras lisas. Em superfícies que, no dia anterior, eram sólidas. Eram finas, precisas, e pareciam pulsar com uma respiração própria quando olhadas diretamente por tempo demais. Eu comecei a evitar olhar para elas. O guia também. Nunca falamos sobre isso, mas ambos sabíamos que algo havia mudado no platô.

Na terceira noite, decidi gravar o que quer que estivesse acontecendo. Liguei o gravador, deixei do lado de fora da tenda, apontei na direção das fendas mais próximas e voltei para dentro. Esperei. Ouvi. Nada. Desliguei o aparelho e fui dormir.

Na manhã seguinte, ouvi a gravação.

Não havia vento. Não havia chuva. Não havia o som de pássaros ou insetos — de qualquer forma, não há muitos no cume do Roraima. Havia apenas, primeiro, um silêncio absoluto que durava quase um minuto. Depois, um ruído de arrasto, como se algo pequeno estivesse sendo puxado sobre a pedra arenítica. Então, uma voz. Não era humana. Não era exatamente inumana também. Era algo entre um sussurro e um chiado, como se alguém estivesse tentando formar palavras com uma boca que não tinha lábios. A voz falava em um idioma que eu não conhecia, ou talvez em português distorcido por algo que não era uma garganta humana. Não consegui entender as palavras. Mas consegui entender a intenção. A voz estava nos convidando. Não para sair da tenda. Para entrar nas fendas.

Desliguei o gravador. O guia entrou na tenda pouco depois, com o rosto pálido. Não precisou dizer nada. Ele também havia ouvido. Ou algo parecido. Não falamos sobre isso durante o dia seguinte. Apenas empacotamos nossas coisas e começamos a descida, mais rápido do que o planejado.

Foi na descida que vi a primeira sunkie.

Não foi uma visão clara. Não houve encontro face a face. Eu estava alguns metros atrás do guia, descendo uma seção íngreme da rampa, quando olhei para baixo e vi algo se movendo entre as pedras. Algo pequeno, de pele cinzenta, cabeça desproporcionalmente grande em relação ao corpo, que se movia não como um animal, mas como alguém que conhece exatamente o lugar onde pisa. Ele parou, olhou para cima na minha direção — eu juro que sentiu meu olhar — e então desapareceu em uma fenda na rocha que, pela geometria do local, não deveria ter espaço para conter nem um gato.

Não gritei. Não chamei o guia. Apenas continuei descendo, com o coração batendo forte demais contra as costelas, sentindo que cada pedra ao redor podia ser uma porta aberta para algo que não queria ser encontrado.

Chegamos ao chão antes do anoitecer. O guia se despediu com um aceno, sem olhar nos meus olhos. Subi no veículo que nos esperava e deixei o Roraima para trás.

Desde então, não consigo mais dormir com a porta do quarto fechada.

Não porque tenha medo de alguém entrar. Tenho medo de algo sair.

Todas as noites, antes de apagar a luz, olho para a fresta embaixo da porta. E todas as noites, por mais que a razão me diga que é impossível, juro que vejo um par de olhos grandes e escuros piscando de volta, vindo de algum lugar que não deveria existir, vindo de uma fenda que a minha casa não tem, vindo do interior de uma montanha a três mil quilômetros de distância que decidiu me seguir para casa.

Os sunkies não são malignos, dizem as lendas. Apenas observam. Não representam ameaça, segundo os Pemon. Ajudam os perdidos, contam as histórias.

O problema é que eu não estava perdido quando eles começaram a me observar. Eu estava exatamente onde queria estar.

E agora, toda vez que vejo uma rachadura na parede, um espaço entre o assoalho e o rodapé, uma fresta na porta do armário, me pergunto a mesma coisa: o que está rastejando nas fendas, e por que resolveu me convidar para entrar?

---

## Fontes de inspiração

As informações sobre o Monte Roraima, seus tepuys, as tradições dos povos Pemon, Ingarikó e Macuxi, o sapinho-preto Oreophrynella quelchii e as lendas sobre os sunkies/amaikok foram pesquisadas em fontes públicas da internet, incluindo reportagens do Correio Braziliense, artigos do Portal Amazônia e da Venezuela Verde, além de textos sobre mitos do Roraima publicados pela ACA Brasil e Ancient Pedia. Esta é uma obra de ficção; nenhum fato foi apresentado como real, e os nomes, personagens e eventos são produto da imaginação do autor.