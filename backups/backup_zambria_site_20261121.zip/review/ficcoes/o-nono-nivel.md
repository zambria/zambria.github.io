---
titulo: "O Nono Nível"
resumo: "Um engenheiro é contratado para assinar o laudo de estabilidade de uma mina abandonada em Mariana, Minas Gerais. No nível mais profundo, selado após uma inundação que matou dezessete homens em 1936, encontra galerias que não estão em nenhum mapa — e algo que ainda observa do fundo do poço."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-nono-nivel"
tipo: "ficcao"
fonte_pesquisa: "Wikipedia — Mina da Passagem; G1 — Caminhos subterrâneos de Ouro Preto; Super Interessante — Lugares assombrados do Brasil: Mina da Passagem"
---

O nono nível da Mina da Passagem não consta de nenhum mapa oficial. Aparece apenas em um relatório de inspeção de 1937, datilografado a máquina, com o carimbo da companhia rasurado e uma assinatura ilegível no canto inferior direito. O documento diz uma coisa apenas: "Nível inseguro. Selar definitivamente. Não há sobreviventes para resgatar."

Li esse relatório três vezes antes de descer. Fui contratado para assinar o laudo de estabilidade de uma mina que a prefeitura de Mariana quer reabrir como atração turística — mais uma galeria iluminada com spots de LED, mais um guia repetindo a lenda do Capitão Jack, o chefe inglês vestido de branco que, dizem, cavalga pelos túneis disparando faíscas prateadas. História bonita para visitante de fim de semana. A verdade é mais chata e mais pesada: em 1936, uma inundação subita matou dezessete homens, nivelou sete galerias e enterrou o nono nível sob dezenas de metros de rocha e lama. Os corpos nunca subiram. Não por impossibilidade técnica, mas por decisão. Custava menos deixar os mortos onde estavam do que tentar trazê-los de volta.

Eu, no entanto, tinha ordem para descer.

A gaiola do poço principal é do tempo em que a mina ainda pertencia aos ingleses. Cadeira de ferro, cabos de aço, uma luz pendurada no teto da cuba. O ar já cheira diferente a cinquenta metros: umidade, ferro velho, madeira apodrecendo, um adocicado que não consegui nomear. Passei pelos nichos — os "buchos" onde os mineiros deixavam lamparinas, e os nichos maiores, dos escravos, buracos na rocha onde cada um tinha que preencher o espaço com ouro sob punição. Na parede do sétimo nível, a imagem de Santa Bárbara, protetora dos mineiros, guarda o lugar com a mão estendida sobre os mortos. Turistas dizem ouvir sinos e correntes nos corredores vazios. Eu não ouvi sinos. Ouvi o próprio silêncio, que é diferente: o silêncio de quem está esperando.

O oitavo nível é o último constado nos mapas. Ali terminei o laudo técnico — paredes estáveis, drenagem funcionando, ventilação aceitável. Assinei cada item. Depois, peguei a fita de amarração e a lanterna, e fui para onde o mapa acaba.

A parede de contenção do nono nível não é de alvenaria. É rocha viva, quebrada a martelo e dinamite depois de 1937. Alguém reabriu o que a companhia selara. As marcas de broca são recentes, o pó ainda não assentou nos trilhos que levam para dentro. Dei o nó da fita na viga de sustentação, acendi a lanterna e entrei.

A galeria não aparece em nenhum levantamento do SIGEP. Desce em espiral estreita, o teto tão baixo que tive que andar curvado, as paredes sujas de um pó escuro que não é minério — parece fuligem, mas cheira a sangue seco. A cada cem passos, encontrei um objeto: um capacete de lona com o nome A. RIBEIRO riscado à tinta preta; uma marmita de metal amassada, ainda com o cheiro de feijão frio; um relógio de pulso parado às três e dezessete. Nenhum osso. Só objetos, como se os donos tivessem saído a pé e nunca mais fossem procurados.

A galeria se abriu numa câmara. Não era câmara de mina. Bancos de pedra entalhados em círculo, dispostos como em um tribunal ou em um ritual, e no centro um poço sem fundo visível — água negra e parada, ou talvez não fosse água. As paredes estavam cobertas de riscos, centenas deles, feitos com algo pontiagudo, nomes e datas empilhados umas sobre as outras, até que os nomes deixaram de ser nomes e se tornaram apenas linhas. No centro do círculo, um osso. Grande. Não humano. Não de nenhum animal que eu conhecesse.

Foi aí que a água se moveu.

Não foi corrente. Foi algo saindo de dentro dela, devagar, com o peso de algo que não pertence ao ar. O ouvido esquerdo zumbiu, como acontece antes de um desabamento, e eu entendi que o som não vinha da minha cabeça. Vinha da câmara. Algo respirava ali embaixo, algo que a inundação de 1936 não matara — apenas atrasara. Os dezessete homens não morreram na enchente. Foram deixados para trás. Custava menos selá-los com o que quer que estivesse lá embaixo do que arriscar trazê-los para cima.

Apaguei a lanterna. No escuro, a câmara inteira passou a brilhar com uma luz que não vem de fonte alguma — um cinza azulado que nasce da própria rocha, como se a mina estivesse viva e quente por dentro. Ouvi passos. Não os meus. Algo subia pela espiral, um passo de cada vez, pesado, arrastando algo — correntes? Ou o próprio corpo?

Escrevi o laudo no dia seguinte. Nível nove: estável. Seguro para visitação pública. Recomendo a abertura guiada. Na segunda-feira, turistas vão descer com capacetes de plástico e fones de ouvido, ouvindo guias contar a história do Capitão Jack como se fosse folclore. Eles não saberão que o nono nível não é um espaço vazio esperando ser preenchido por luz elétrica. É uma garganta fechada que alguém acabou de abrir.

Na noite anterior à reabertura, voltei sozinho ao poço principal. Não pela gaiola — pela escada de serviço, os cento e vinte metros até o oitavo nível, e dali pela brecha. Não carregava lanterna. Não precisava. A mina agora emite sua própria luz, um cinza azulado que sobe pelos troncos, e nas paredes da galeria não mapeada havia um risco novo, feito com unha ou com lâmina, letra que reconheci como a minha própria: um nome, uma data. Meu nome. A data de amanhã.

Algo está subindo. Ou algo já saiu comigo — porque quando acendi a lanterna antes de deixar a câmara, vi minha sombra na parede, e a sombra não estava me imitando. Ela estava me esperando.

## Fontes de inspiração

- Wikipedia — Mina da Passagem (Mariana, MG): história da mina, profundidade, enchente, encerramento em 1954 e reabertura para turismo.
- G1 — Caminhos subterrâneos de Ouro Preto (MG): redes de galerias coloniais, condições de trabalho, nichos e buchos das minas.
- Super Interessante — Lugares assombrados do Brasil, parte 5: Mina da Passagem: inundação de 1936 com dezessete mortos, imagem de Santa Bárbara e relatos de sinos e correntes nos corredores.

Todas as fontes serviram apenas de inspiração para a ficção; personagens, eventos e diálogos são criações originais.
