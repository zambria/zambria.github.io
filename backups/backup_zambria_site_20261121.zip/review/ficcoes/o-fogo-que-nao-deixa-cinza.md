---
titulo: "O Fogo que Não Deixa Cinza"
resumo: "Um homem volta ao brejo onde o irmão sumiu, perseguido por luzes que não queimam, apenas assinam a carne. Entre o fogo-fátuo e o Boitatá, resta saber o que ainda arde debaixo da lama."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-fogo-que-nao-deixa-cinza"
tipo: "ficcao"
fonte_pesquisa: "oantagonista.com.br, atarde.com.br"
---

O brejo não costuma pedir permissão. Ele apenas acende.

Na volta para casa, depois de dez anos ausente, o primeiro sinal foi uma luz azulada sobre a água parada, parando e arrancando como se tivesse pulso próprio. Não vinha de lanterna, nem de farol de carro, nem de qualquer instalação elétrica — o povoado de Várzea dos Pisos não tem rede que mereça esse nome. Era um ponto frio, esverdeado, parado sobre o brejo como um inseto demasiado grande para ser natural. Desliguei o motor. A luz se apagou. Liguei de novo. Acendeu de novo, um pouco mais perto.

Voltei porque o irmão não voltou. Dez anos antes, Marcos saiu de casa à noite dizendo que ia buscar lenha no limite do brejo. Levou um machado, uma garrafa de cachaça e nunca mais entrou pela porta. A polícia fez o que a polícia faz nesses lugares: interrogou um parente, anotou sumiço, arquivou com a palavra "voluntário" riscada à caneta. Ninguém procura vivo quem o brejo decide manter. Eu, no entanto, voltei para procurar.

Antes de mais nada, vale dizer o que a ciência conta sobre essas luzes. Elas têm nome: fogo-fátuo. Em pântanos, brejos e terrenos alagados, a matéria orgânica se decompõe sem oxigênio suficiente, e microrganismos liberam gases — metano, fosfina, difosfano — que sobem pelo sedimento em bolhas. Quando atingem o ar, podem se incendiar sozinhos, produzindo labaredas azuis que duram segundos e desaparecem sem vestígios. Pesquisadores chegaram, em 2025, a demonstrar em laboratório que microbolhas de metano desenvolvem diferenças de carga e geram minúsculas descargas elétricas, batizadas de microrrelâmpagos, capazes de iniciar a oxidação do metano em condições ambiente. Explicação bonita, limpa, de laboratório. Também é mentira por omissão: explica a chama, não explica por que a chama parece te observar.

No Brasil, o fogo-fátuo deu origem ao Boitatá, a serpente de fogo que protege as matas e queima os olhos de quem tenta prejudicar a floresta. Mito bonito, também incompleto. O Boitatá da lenda é um guardião com intenção. O que vi sobre o brejo não guardava nada. Apenas assinava.

Na primeira noite, acampei na beira do brejo com uma lona fina e a faca que era de Marcos. Não acendi fogueira. Não por medo do fogo-fátuo, mas porque não queria convidar nada que enxergasse clarão. Por volta das duas da manhã, a luz voltou. Desta vez não parou na superfície. Desceu da água e flutuou a um metro do solo, a uns quatro metros de onde eu estava deitado. Azul, tremeluzente, sem calor aparente. Não fazia barulho. O brejo, no entanto, ficou silencioso — nem sapo, nem grilo, nem o estralo da própria água. Apenas a luz e minha respiração.

Ela pairou por tempo suficiente para eu notar que não se movia com o vento. Ela se movia com intenção. Quando levantei a mão, ela se aproximou. Quando recuei, recuou também, mantendo a distância. Não era um gás queimando ao acaso. Era um ponto de atenção.

No segundo dia, caminhei até o ponto onde Marcos foi visto pela última vez, segundo o único vizinho que ainda se lembrou de mencionar o nome dele. O chão lá é uma mistura de lama preta, palha apodrecida e água que não reflete o céu. Encontrei a garrafa de cachaça, vazia, a uns vinte metros da trilha. O machado não apareceu. Em compensação, apareceu a marca: uma queimadura fina, quase um risco, no tronco de um inseto seco que emergia da lama. Não havia cinza ao redor. Não havia fumaça. Apenas o risco, como se algo tivesse tocado a madeira com a ponta de um fósforo apagado e, ainda assim, marcado.

O vizinho, um homem de dentes escuros e olhar que não focava direito, me disse que as luzes "escolhem quem querem". Não levaram, segundo ele. Escolhem. "O brejo não devolve", disse, cuspindo na palma da mão. "Ele assina. Quem é assinado, volta diferente — ou não volta."

Passei a terceira noite sentado na margem, com a faca no colo e os olhos na água. A luz apareceu por volta da meia-noite, dessa vez em pares: dois pontos, um verde e um azul, dançando um ao redor do outro sem nunca se tocar. Eu segurava a respiração. Um dos pontos se deslocou em minha direção, parou à frente do meu rosto, a menos de um metro. Por um instante, dentro daquela chama azul que não aquecia, vi algo que não era chama: um reflexo de olhos, muitos olhos, profundos demais para caber em um ponto de luz tão pequeno.

Desviei o olhar. Quando olhei de volta, havia desaparecido.

Foi então que percebi o cheiro. Não o cheiro de enxofre ou de pântano queimado, mas um cheiro de pele úmida, de algo que esteve debaixo d'água por tempo demais e ainda assim respira. O cheiro vinha de mim. Olhei para as mãos. No dorso da mão esquerda, uma linha fina, quase invisível, brilhava com um azul pálido sob a luz da lua. Não doía. Não ferveu. Apenas estava ali, como um risco de fósforo apagado na pele.

A ciência explica o fogo-fátuo com gases e descargas elétricas. O folclore explica com serpentes de fogo e guardiões da mata. Nenhuma das duas explica por que a marca não desaparece, por que eu agora consigo ver as luzes mesmo de dia, como manchas escuras no ar parado sobre o brejo, e por que, quando fecho os olhos à noite, sinto a água fria subindo pelos meus pulmões e algo, muito abaixo da lama, chamando meu nome com a voz de Marcos.

Voltei para casa. A luz apagou quando liguei o carro. Acendeu de novo no retrovisor, a uns cem metros de distância, parado sobre a estrada como se estivesse esperando eu decidir voltar. Não voltei. Sigo dirigindo. A marca na minha mão continua azul, fria, viva.

O fogo-fátuo não queima. Não deixa cinza. Só deixa marca. E quem é marcado, cedo ou tarde, aprende a andar com o brejo dentro de si — a água nos pulmões, o silêncio na garganta, e a certeza fria de que o fogo não estava lá para nos assustar. Estava lá para nos reconhecer.

## Fontes de inspiração

- Reportagem sobre o fenômeno do fogo-fátuo em pântanos e cemitérios, com explicação sobre a decomposição de matéria orgânica, emissão de metano e fosfina, e combustão espontânea ao contato com o oxigênio (atarde.com.br).
- Matéria sobre luzes misteriosas nos pântanos e a pesquisa de 2025 publicada na Proceedings of the National Academy of Sciences sobre microrrelâmpagos em microbolhas de metano (oantagonista.com.br).
- Contexto sobre o mito brasileiro do Boitatá, serpente de fogo ligada ao fogo-fátuo e à proteção das matas.
