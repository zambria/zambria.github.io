---
titulo: "A grade do mar"
resumo: "Duas tempestades distantes cruzaram suas ondas ao largo de um litoral brasileiro, e o mar virou tabuleiro. Quem entra na grade não aprende a nadar — aprende a desaparecer."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "a-grade-do-mar"
tipo: "ficcao"
fonte_pesquisa: "Cross sea / ondas quadradas — fenômeno de sistemas de ondas que se cruzam em ângulo reto, perigoso para embarcações e banhistas (Wikipedia, Superinteressante, O Globo)"
---

# A grade do mar

O mar não costuma olhar de volta. Naqueles dias de inverno, no entanto, ele aprendeu a contar. Não digo isto como quem repete lenda de pescador — digo como quem viu, de um morro acima, a superfície do oceano se dobrar em um padrão de quadradinhos, perfeito e inquieto, como um tabuleiro de xadrez molhado. Duas tempestades que nunca se encontraram enviaram suas ondulações por rotas separadas, e elas se chocaram ao largo de Vila do Cabo Oco, naquele recanto quieto do sul do Brasil. O resultado não foi uma tempestade. Foi algo mais silencioso, e por isso mais perigoso: o mar cruzado.

A ciência chama o fenômeno de cross sea, ou ondas quadradas. Dois sistemas de maré, nascidos de tempestades distantes, viajam em ângulos opostos e se encontram em algum ponto do oceano. Quando suas cristas se cruzam em ângulo reto, a superfície se organiza numa grade. Parece inofensiva vista da areia — até mesmo bonita, uma estranha calma geométrica. Por baixo, porém, as correntes disputam o mesmo espaço em direções contrárias, e um barco que aprendeu a enfrentar as ondas de frente não tem para onde virar: encarar uma série significa navegar paralela à outra. A Agência Espacial Europeia já anotou que uma parcela grande dos acidentes marítimos acontece exatamente nessas águas. O resto é silêncio oficial.

Eu tinha quatorze anos na primeira vez que vi a grade. Meu irmão caçula, Pedro, tinha dez. Morávamos com o pai em uma casa de alvenaria baixa, a menos de quinhentos metros da praia, e nossa vida girava em torno da maré: quando saía, íamos colher marisco entre as pedras; quando subia, ajudávamos a arrumar as redes dos vizinhos. O povoado era pequeno demais para segredos, mas grande o suficiente para abrigar os que ninguém ousava nomear.

Naquele dia, o céu estava limpo. Não havia nuvem escura, nenhum sinal de mau tempo. Só o mar, ao longe, dividido em quadrados, como se alguém tivesse riscado a água com uma régua gigante. Os pescadores mais velhos saíram à pressa das barracas, olharam para o horizonte e recuaram. Nenhum deles entrou na água. O senhor Antenor disse que aquilo era "mar a duas bandas" e que quem entrasse na grade não voltaria para contar. Rimos — eu e Pedro — achando que era mais uma daquelas histórias para manter criança longe do oceano.

A tarde passou, e a grade não sumiu. Pelo contrário: cresceu. Quando a maré subiu, os quadrados se aproximaram da costa, e a água começou a mexer de um jeito estranho — subia e descia ao mesmo tempo em direções opostas, como se o fundo do mar estivesse respirando em dois tempos diferentes. Eu fiquei na beirada do morro observando. Pedro não. Pedro era teimoso e achava que nada podia machucá-lo na água rasa.

Por volta das quatro e meia, ele desceu com a prancha de madeira velha que usávamos para deslizar nas ondas pequenas. Eu gritei, ele acenou sem parar, e entrou na água bem onde os quadrados começavam. No primeiro momento, nada aconteceu. A prancha flutuava. Então uma série chegou de um lado, outra de outro, e a prancha girou sozinha, como se algo abaixo dela tivesse dado uma torção na corrente. Pedro perdeu o equilíbrio. A água o engoliu entre dois quadrados.

Eu corri descendo o morro, chamando o nome dele, e cheguei à praia sem fôlego. A grade continuava ali, imóvel e perfeita, e de Pedro não havia sinal. Não gritos, não braços se agitando, não prancha boiando. Apenas o mar, em quadrados, como se nada tivesse acontecido. Chamei os moradores. Vieram com lanterna e cães, mas a busca terminou antes do anoitecer: nenhum corpo, nenhum vestígio, apenas um par de chinelos de borracha abandonado na areia molhada.

O senhor Antenor não se surpreendeu. Disse que o mar cruzado não devolve o que pega, e que não adiantava procurar corpo onde a corrente puxa para quatro lados ao mesmo tempo. O padre fez uma missa, o prefeito nada disse, e a vida em Vila do Cabo Oco voltou ao normal. O normal, ali, significa aprender a conviver com ausências que não têm enterro.

Anos depois, ainda moro na mesma casa. Ainda olho para o mar antes de sair de casa. Quando o vento muda de direção repentina e a superfície ao longe começa a ganhar linhas retas, eu fecho a janela e não saio. Não sou supersticioso — sou apenas alguém que aprendeu que o oceano não precisa de monstros para ser perigoso. Basta duas tempestades distantes, um ângulo errado, e a paciência de algo que espera debaixo da água.

Às vezes, à noite, sonho que Pedro está lá embaixo, em pé entre os quadrados, com os olhos abertos e a boca cheia de sal, me acenando de volta para a grade. E o pior não é o sonho em si. O pior é perceber que, se a grade aparecesse novamente agora, eu provavelmente desceria a escada para olhar mais de perto. É assim que o mar venceria: não com uma onda gigante, mas com a nossa própria curiosidade.

## Fontes de inspiração

- "Cross sea" (Wikipedia) — fenômeno de sistemas de ondas não paralelas que formam uma grade perigosa para embarcações e banhistas.
- "O que são 'ondas quadradas'?" (Superinteressante) — explicação do cross-sea no litoral e o risco para embarcações que só podem enfrentar as ondas de frente.
- "Ondas 'quadradas' podem ser perigosas" (O Globo) — padrão de mar cruzado, correntes perigosas e a associação do fenômeno a acidentes marítimos.
