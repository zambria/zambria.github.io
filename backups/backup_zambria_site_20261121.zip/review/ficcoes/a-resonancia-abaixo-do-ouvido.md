---
titulo: "A Ressonância Abaixo do Ouvido"
resumo: "Um arqueólogo mapeia geoglifos no Acre e encontra um círculo não catalogado que emite som abaixo do limite da audição humana — e descobre que a frequência não só altera o humor: grava vozes, incluindo as que ainda não foram ditas."
categoria: "arqueologia"
data: "2026-11-21"
slug: "a-resonancia-abaixo-do-ouvido"
tipo: "ficcao"
fonte_pesquisa: "PubMed/PMC (estudo de infrassom: cortisol, irritabilidade e tristeza sem detecção consciente); IPHAN, Wikipedia e FAPESP Pesquisa (geoglifos do Acre, entre os rios Acre e Iquiri)"
---

Ricardo Varella havia passado dez anos dizendo que a Amazônia não guarda segredos, apenas coisas que ninguém se deu ao trabalho de procurar com atenção. Era outubro, o fim da seca, e ele acampava a três quilômetros de um círculo de terra que os sensores lidar teimavam em classificar como erro de medição. No papel, ali não havia nada: vegetação densa, solo de terra firme, a mesma umidade de sempre. No chão, sob o dossel, uma vala rasa desenhava um círculo de quase cinquenta metros — invisível a pé, óbvio do ar.

Ele não foi o primeiro a notar os geoglifos do Acre. Desde a década de 1970, pesquisadores catalogaram mais de quatrocentos desses terraplenagens entre os rios Acre e Iquiri, círculos e quadrados escavados há dois milênios por sociedades que deixaram pouca cerâmica e nenhum monumento. O Instituto do Patrimônio chegou a tombar um deles. Os arqueólogos debatem se foram espaços cerimoniais, locais de reunião ou algo que a gente ainda não tem nome para chamar. Ricardo nunca levou o debate a sério. Para ele, um geoglifo era terra movida. Até encontrar o que não estava no mapa.

O novo círculo ficava numa clareira de bambu, a um dia de caminhada da base mais próxima. Não constava nos registros do IPHAN, nem nos levantamentos da Universidade de Helsinque, nem nas bases de lidar que ele levava no laptop. Quando chegou ao centro, Ricardo sentiu a primeira coisa: não era medo, exatamente. Era uma irritabilidade fina, como se o ar estivesse carregado de eletricidade estática, e uma tristeza que não tinha origem — não vinha de lembrança, não vinha de perda, simplesmente estava ali, como um ruído de fundo na cabeça.

À noite, a equipe toda sentiu o mesmo. Marcos, o topógrafo, acordou gritando que alguém estava batendo na lona da tenda. Não havia ninguém. Lúcia, a assistente de campo, passou três horas sentada na cadeira de campanha olhando para o círculo, sem piscar, sem falar. Quando Ricardo perguntou o que via, ela respondeu que não via nada, apenas ouvia algo "abaixo do ouvido". Não conseguiu explicar melhor.

Ricardo levou gravadores para o centro do círculo no dia seguinte. Deixou dois aparelhos ligados durante vinte e quatro horas, a um metro de profundidade da vala, outro suspenso num galho. Quando baixou os arquivos no computador, o espectro mostrou um pico limpo a dezoito hertz. Infrasom. Frequência abaixo do limiar da audição humana — o ouvido não capta, mas o corpo sente. Estudos recentes associam essa exposição a níveis mais altos de cortisol, irritabilidade, tristeza e a sensação vaga de que algo não está certo. Ricardo leu esses estudos. Não precisava deles para saber o que sentia.

O problema não era o som em si. O problema era o que estava gravado junto com ele.

Na terceira noite, Ricardo remexeu nos arquivos com fones de ouvido. Abaixo do limiar audível, dezoito hertz constantes — e, por cima, vozes. Não gravações da equipe. Vozes que ele não reconhecia, falando em português com um sotaque que não conseguia localizar, dizendo frases soltas: "não desça", "já aconteceu", "está ouvindo de volta". Ele aumentou o ganho, limpou o filtro, isolou o canal. As vozes não vinham da floresta. Vinham do círculo.

No quarto dia, Marcos desapareceu. Encontraram a mochila dele na borda da vala, a garrafa d'água meio cheia, os cadernos de campo abertos na página em branco. Não havia pegadas saindo do círculo. Apenas pegadas entrando, parando no centro. Ricardo desceu até lá sozinho, com o gravador na mão. Ficou parado no ponto exato onde as pegadas paravam. Não ouviu nada com os ouvidos. Sentiu no estômago, uma náusea baixa, o tipo de enjoo que vem de um movimento que o corpo não faz. Ao voltar para a tenda, baixou o áudio daquela hora. No arquivo, a própria voz de Ricardo falava com ele.

Não era uma imitação. Era a voz dele, o ritmo dele, as pausas dele, dizendo: "Você ainda não saiu do círculo, Ricardo. Só não sabe que já está aqui." O arquivo era datado de ontem. Ricardo não tinha gravado nada ontem à noite. Ele estava acordado, escrevendo o relatório, sozinho na tenda.

As coisas se deterioraram rápido depois disso. Lúcia parou de dormir. Dizia que, quando fechava os olhos, ouvia a si mesma conversando com alguém que não estava na tenda, e que a voz dela usava palavras que ela nunca aprendera. Ela passou uma noite inteira gravando o próprio sono. De manhã, o arquivo tinha trinta minutos de silêncio — e, no último segundo, um sussurro: "já aconteceu". Ela largou o gravador no chão e andou para dentro do bambu. Não voltou. Ricardo não foi atrás. Não houve como voltar: o círculo parecia maior à noite, e a vala, mais profunda do que cinquenta centímetros deveria permitir.

Ricardo entendeu, tarde demais, o que os geoglifos eram. Não espaços cerimoniais. Não moradias. Aparelhos de ressonância. A terra movida em círculos precisos, as valas com profundidade calculada, a geometria alinhada a algo que não era o sol — tudo isso fazia o solo vibrar numa frequência que o ouvido não captura, mas o cérebro registra. Infrasom não assusta sozinho. O que assusta é que frequências abaixo de vinte hertz mexem com a memória, com o senso de tempo, com a fronteira entre o que aconteceu e o que ainda vai acontecer. O corpo responde com cortisol. A mente responde criando histórias para explicar o calafrio. E o círculo, aparentemente, responde gravando tudo — inclusive momentos que ainda não ocorreram.

Na última noite, Ricardo deixou o gravador ligado no centro do círculo, a pilha nova, o microfone apontado para o centro da vala. Ele próprio ficou fora, deitado na grama, ouvindo pelo fone o ruído abaixo do ouvido. Dezoito hertz. Um tom constante, inaudível, que fazia a visão tremer nas bordas. Quando amanheceu, ele foi buscar o aparelho. O arquivo tinha quase sete horas. Nas primeiras seis, só o zumbido. No sétimo minuto da última hora, sua própria voz — a voz de Ricardo, calma, sem medo — dizia para o gravador: "Está funcionando. Eles vão ouvir. E quando ouvirem, vão descer."

Ricardo fechou o laptop. Não apagou o arquivo. Não contou para ninguém, porque não havia mais ninguém para contar. Deixou o gravador onde estava, fechou a tenda, e caminhou de volta para a estrada, para a cidade, para qualquer lugar que não fosse aquele círculo. O som não parou. No ônibus, no quarto de hotel, no silêncio da noite, ele ainda ouvia dezoito hertz abaixo do ouvido. E, de vez em quando, quando o cansaço chegava, uma voz — a própria — sussurrava algo que ele ainda não havia dito, mas que o círculo já tinha gravado.

Os geoglifos do Acre continuam ali, invisíveis do chão, perfeitos do ar. Ninguém sabe para que foram construídos. Talvez nunca saibamos. O que Ricardo levou do círculo não foi uma resposta, mas uma certeza fria: alguns sinais não são mensagens. São convites. E quem responde, passa a fazer parte da gravação.

## Fontes de inspiração

- Estudo sobre exposição a infrassom (frequências abaixo de 20 Hz) associada a aumento de cortisol, irritabilidade e tristeza em humanos, sem que o som seja conscientemente detectado (PubMed Central / PMC).
- Pesquisa sobre os geoglifos do Acre: terraplenagens geométricas na Amazônia ocidental, entre os rios Acre e Iquiri, com cerca de dois milênios, usadas provavelmente para encontros e cerimônias, e tombadas pelo IPHAN (Wikipedia, IPHAN, FAPESP Pesquisa).
