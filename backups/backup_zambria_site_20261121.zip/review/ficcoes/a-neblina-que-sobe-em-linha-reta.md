---
titulo: "A Neblina que Sobe em Linha Reta"
resumo: "No vale de um rio seco no interior, uma neblina sobe em colunas verticais e retas, ignorando o vento, e devolve as palavras de quem entra nela — com atraso."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "a-neblina-que-sobe-em-linha-reta"
tipo: "ficcao"
fonte_pesquisa: "tupi.fm; oantagonista.com.br
---

A neblina não se comporta como neblina.

Essa foi a primeira coisa que aprendi ao voltar para o Vale do Rio Seco, e foi também a última que quis aprender. No interior, a gente está acostumado com a névoa da manhã que rasteja pelo chão, grudada nos pés, cheirando a terra úmida e capim batido. Ela se espalha, difusa, sem pressa. A neblina do vale não. Ela sobe.

Sobe em colunas retas, verticais, como pilares de cinza claro erguidos do nada contra o céu azul. Não há vento que as dobre, não há calor que as dissipe. Elas aparecem ao amanhecer e ao entardecer, algumas com dois metros de diâmetro, outras com cinco, e permanecem ali, imóveis, enquanto o mundo ao redor segue sua rotina seca e poeirenta. Os moradores têm uma regra, transmitida de pai para filho sem jamais ser escrita: não entre na coluna. Não grite perto dela. E, acima de tudo, não responda se ouvir o seu próprio nome saindo de dentro dela.

Eu sou Marcos Varela. Fui técnico de som de uma emissora de rádio na capital, o que significa que passei anos treinando o ouvido para distinguir ruído de sinal, eco de voz direta, fala humana de interferência. Voltei para o vale porque meu irmão desapareceu dentro de uma dessas colunas seis anos atrás. Levou uma cabra que havia se afastado do rebanho, entrou na névoa para buscá-la, e nunca mais saiu. Não houve grita, não houve luta, não houve corpo. O bicho também sumiu. Só ficou a cabra do lado de fora, mirando a coluna com os olhos vidrados, como se visse algo que nós não víamos.

Nas primeiras noites de volta, acampava na borda do vale com um gravador de fita e um microfone direcional. Registrava o silêncio. É um silêncio estranho: não absoluto, mas seletivo. O canto dos pássaros morre a uns dez metros da coluna. O latido dos cães é engolido antes de chegar lá. O motor da minha moto, parado a vinte passos de distância, soa como se estivesse do outro lado de uma montanha. O som não viaja até a neblina; ele é parado por ela, como se a névoa fosse uma parede invisível feita de ar parado.

Foi então que comecei a ouvir as respostas.

Não imediatamente. Demorou semanas. Uma noite, deixei o gravador ligado apontado para uma coluna média, perto do lugar onde meu irmão entrou, e voltei para a barraca. Na manhã seguinte, reembobinei a fita. Ouvi o vento fraco, o rangido de uma arvoredo distante, e então — aos quatorze minutos — uma voz. Era a voz do meu irmão, ou algo que soava exatamente como ela, falando palavras que ele nunca tinha dito a ninguém. Ele dizia o nome da vizinha de porta, Dona Lalau, e perguntava se ela ainda deixava a porta da cozinha aberta à noite. Meu irmão não sabia o nome dela. Nunca tivera razão para saber.

A regra do vale é clara: não responda. Eu respondi, na fita, em voz alta, perguntando quem estava falando. A resposta veio na gravação seguinte, três dias depois: a mesma voz, meu irmão, dizendo meu nome. Marcos. Marcos. Com um atraso de exatamente sete segundos entre cada sílaba, como se alguém estivesse aprendendo a pronunciar.

Comecei a documentar os desaparecimentos. O cartório do povoado tem registros esparsos — o valem é pequeno, e as pessoas aqui morrem de velhice, de cobra, de bebida ruim. Mas há um padrão nos últimos trinta anos: a cada dois ou três anos, alguém entra na neblina e não volta. Um menino de doze anos perseguindo uma pipa. Uma mulher idosa procurando uma galinha. Um caminhoneiro que parou para consertar o pneu e desviou para dentro de uma coluna para aliviar a bexiga. Todos sumidos sem vestígios. Todos, segundo os mais antigos, ouvidos novamente algum tempo depois, falando de dentro da névoa com as vozes deles mesmos, dizendo coisas que ninguém entendia.

A ciência, quando se importa com essas coisas, chama isso de fenômenos acústicos incomuns. Fala em camadas de ar com temperaturas diferentes que conduzem o som por rotas estranhas, em estrondos que aparecem sem causa visível e desaparecem sem deixar vestígios, em silêncios repentinos que funcionam como sinal de alerta entre os animais. É uma explicação confortável porque termina em ponto final. O problema é que o vale não termina em ponto final. A neblina continua subindo.

No sétimo mês de volta, resolvi entrar.

Não numa coluna grande. Uma pequena, perto da borda do vale, com menos de um metro de largura. Levei o gravador, o microfone, uma lanterna e uma corda amarrada ao tornozelo, com a outra extremidade presa a um cajazeiro. O plano era simples: atravessar a coluna, gravar o que houvesse dentro, voltar antes que algo notasse minha presença.

O interior da névoa não é branco nem cinza. É um branco descolorido, como sonho esquecido ao acordar. Não há som. Não há som de nada — nem de minha respiração, nem do batimento do coração, nem do atrito do tecido da roupa contra a pele. Andei uns vinte passos e a corda ficou frouxa; o cajazeiro estava do lado de fora, mas eu não sentia puxão. A corda simplesmente havia deixado de existir para mim, ou eu para ela.

Falei. Minha voz não ecoou. Ela foi absorvida antes de sair da boca, ou talvez nunca tenha saído. Liguei o gravador e deixei rodar. Fiquei ali, parado, por tempo que não consegui medir — sem relógio, sem som, sem referência, o tempo se desfaz. Então ouvi algo. Não com os ouvidos. Dentro do crânio. Uma voz dizendo meu nome, não com a voz do meu irmão, mas com a minha própria. Marcos. Você demorou.

Saí correndo. Não sei em que direção. Saí quando a névoa ainda estava lá, ou quando ela me deixou sair. A corda ainda estava amarrada ao tornozelo, do lado de fora, presa ao cajazeiro. O gravador continuou ligado.

Ouvi a fita no dia seguinte, sozinho na barraca, com fones de ouvido e o volume no máximo. O vento fraco. O rangido da árvore. E então, no minuto treze, minha voz. Não a voz que eu ouvi dentro da névoa, mas a voz que saíra da minha boca antes de entrar, gravada pelo microfone: Marcos. Você demorou. Seguido de um silêncio de sete segundos. E então, pela primeira vez, algo que não era a minha voz, nem a do meu irmão, nem de ninguém que eu conhecesse: já podemos sair.

Não digo que acredite em fantasmas. Não digo que acredite em aliens, ou em dimensões paralelas, ou em qualquer uma das explicações baratas que a internet costuma vender para quem não quer dormir à noite. Digo apenas o que é factível: a neblina do vale sobe em colunas retas, não obedece ao vento, e devolve as palavras de quem entra com atraso e com acréscimos. Algo ali está ouvindo. Algo ali está aprendendo a falar como nós. E as colunas, há anos, não param de aparecer.

Deixei o gravador ligado dentro de uma coluna na semana passada. Não entrei. Deixei apenas o aparelho, ligado, na borda da névoa, com o microfone apontado para dentro. Hoje de manhã fui buscá-lo. O gravador estava no mesmo lugar, a fita até o fim, e não havia nada registrado nos últimos cinquenta minutos — exceto, nos últimos dez segundos, a minha voz dizendo adeus, em um tom que não foi o meu, seguida de um ruído que soa muito parecido com alguém, do lado de dentro, tentando aprender a respirar.

A neblina está mais baixa hoje. Chegou perto da estrada. Logo não haverá mais colunas. Haverá apenas neblina, em todo lugar, e ninguém vai saber onde ela começa e onde termina.

## Fontes de inspiração

- "O silêncio repentino em alguns lugares chama atenção e causa estranheza", Tupi FM — sobre a queda brusca de ruídos familiares e o silêncio como sinal de alerta na natureza.
- "Os estrondos misteriosos que sacodem janelas há séculos sem deixar qualquer sinal de explosão", O Antagonista — sobre sons que aparecem sem causa visível e desaparecem sem vestígios.

Nenhum trecho foi copiado desses textos; eles serviram apenas como referência atmosférica para esta ficção.
