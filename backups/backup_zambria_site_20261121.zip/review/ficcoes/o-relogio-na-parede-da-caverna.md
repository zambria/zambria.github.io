---
titulo: "O Relógio na Parede da Caverna"
resumo: "Em um abrigo da Serra da Capivara, uma equipe de arqueólogos documenta uma pintura rupestre de um relógio de pulso — impossível em arte com mais de nove mil anos. Os ponteiros marcam 3h17. A partir daí, os relógios da equipe começam a parar no mesmo horário, e um fotógrafo desaparece para reaparecer usando no próprio pulso o relógio que não podia estar pintado na pedra."
categoria: "arqueologia"
data: "2026-11-21"
slug: "o-relogio-na-parede-da-caverna"
tipo: "ficcao"
fonte_pesquisa: "Revista Pesquisa FAPESP; G1; UNESCO/ICOMOS"
---

O abrigo não tem nome oficial. Fica a quatro quilômetros de São Raimundo Nonato, dentro do Parque Nacional da Serra da Capivara, e a equipe do projeto chamou-o, por falta de imaginação, de Abrigo 37. Eduardo Marins passou três tardes esfregando poeira de arenito do painel P-417 antes de notar que uma das figuras não era um cervo.

Entre auroques de ocre vermelho, homens com braços estendidos e cenas de caça que o tempo desbotara até o cinza, havia um pulso. Um pulso humano, estendido para a frente, e naquele pulso um relógio: mostrador circular, pulseira de elos, coroa de ajuste às três horas, ponteiros parados nas três e dezessete. Pintado com o mesmo carvão e óxido de ferro das figuras ao redor, mergulhado na mesma pátina de milênios, impossível de descolar da pedra com a unha ou com bisturi.

O primeiro a falar foi Tiago, o fotógrafo, com aquele tom seco de quem tenta transformar pavor em piada: "Então o Holoceno já tinha smartwatch, é isso?" Lúcia riu, nervosa. Ramos, o coordenador, apenas franziu a testa e anotou no caderno de campo: "Figura antropomorfa com objeto de pulso, possível interpretação equivocada, não conclusivo."

Não era equívoco. Qualquer pessoa que tivesse visto um relógio de pulso na vida reconheceria aquele desenho. O problema é que nenhuma pessoa que tivesse visto um relógio de pulso existia há nove mil anos no sertão do Piauí.

A datação da arte rupestre nunca é absoluta. Todos no projeto sabiam disso: não se data a pintura, data-se o sedimento aos pés da parede, onde lascas de pigmento caíram e se enterraram. O carbono-14 das lascas encontradas ao redor do Abrigo 37 apontava para algo entre oito mil e dez mil anos AP. O pulso com o relógio estava sobreposto a uma mancha de ocre mais antiga, o que o tornava, no mínimo, contemporâneo das demais figuras — ou seja, impossível.

Marins não durmiu bem na primeira noite. Acordou às 3h17, sem despertador, com a boca seca e a nuca formigando. Lúcia contou, no café da manhã seguinte, que também acordara às 3h17, todas as noites desde que limparam o painel P-417. O relógio de pulso dela, um Casio comprado em 2014, parou exatamente às 3h17 daquela manhã. Não caiu, não tomou chuva, simplesmente parou. Tiago fez uma piada sobre campos magnéticos da caatinga. Ninguém riu.

Na terceira noite, Marins sonhou com o mostrador circular. Nos ponteiros, parados em 3h17. Sonhou que alguém usava aquele relógio no pulso esquerdo e que o braço, deitado sobre a pedra arenita, não era um braço de hoje: era um braço de amanhã. Acordou suando, olhou para o próprio pulso — o relógio dele marcava 3h16. Um minuto de diferença. Ele olhou para a parede do quarto de hotel, escura, e pensou que 3h17 era apenas uma hora. Que horas não perseguem ninguém.

Na quarta noite, Tiago não saiu do abrigo.

Eles o encontraram ao amanhecer, sentado de frente para o painel P-417, de costas para a caatinga, usando no pulso esquerdo o próprio relógio de prata que levara ao trabalho durante toda a semana. O mesmo que Marins vira no pulso dele ao chegar na segunda-feira. O mesmo que aparecia na fotografia da terça-feira, em que Tiago ajustava o tripé ao lado do painel. Os ponteiros estavam parados em 3h17.

Tiago estava catatônico. Pupilas simétricas, pulso presente, respiração regular. Não respondia a perguntas. Quando Marins virou o relógio dele para ver a tampa traseira, encontrou a gravação: "T.M. 1987". Tiago nasceu em 1989. A pulseira tinha um arranhão próximo à fivela, idêntico ao desenho em preto que cobria o mostrador da figura pintada — um traço fino, irregular, como uma trinca no vidro do relógio. Um relógio de 1987, no pulso de um homem de 1989, reproduzido com precisão de detalhe em uma pintura de pelo menos oito mil anos.

Ramos não fez piadas. Ramos fez o que os arqueólogos fazem quando a evidência quebra a cronologia: fechou o caderno, disse que iam notificar o IPHAN, e sugeriu que ninguém tocasse em nada até a chegada de um perito. Marins olhou para a foto que Tiago tirara do painel. A figura do pulso estava lá, nítida, o relógio marcando 3h17. Ele ampliou a imagem no laptop. O arranhão no vidro. A coroa às três horas. Os ponteiros. Não havia dúvida: o artista que pintara aquilo havia visto, com clareza, um objeto que só existiria milênios depois. Ou havia visto um homem que ainda não existira.

Lúcia perguntou, em voz baixa, se alguém havia contado a Tiago, antes de desaparecer, o que estava pintado na parede. Ninguém tinha contado. Ninguém tinha mencionado relógios. Ninguém tinha dito 3h17.

Eles levaram Tiago embora de maca. Ele não abriu os olhos durante todo o trajeto de volta a São Raimundo Nonato. O relógio dele continuou parado em 3h17. Marins guardou o próprio relógio na mochila, não porque estivesse com medo do horário, mas porque não suportava mais olhar para o ponteiro dos minutos se aproximando do dezessete.

A arqueologia lida com o que ficou para trás. Com ossos, lascas, cinzas de fogueira, impressões digitais na argila seca. O Abrigo 37, no entanto, não parecia guardar o passado. Parecia, cada vez mais, estar anotando o futuro — e usando a equipe como rascunho. A figura no painel P-417 não era um aviso. Era um registro. Um registro de chegada. De alguém que, usando um relógio de pulso, sentar-se-ia exatamente ali, de costas para a caatinga, com os ponteiros marcando 3h17, e nunca mais se moveria.

Marins fechou o notebook na noite seguinte, no quarto do hotel, e olhou para o pulso nu. O relógio estava na mochila, parado. Fora da janela, o sertão escuro respirava o cheiro de poeira e cacto. Ele fechou os olhos e tentou não pensar na hora. Não conseguiu. Na cabeça dele, o mostrador girava sozinho, os ponteiros avançavam lentamente, e às 3h17 alguma coisa, na pedra arenita do Abrigo 37, parou de esperar e passou a olhar de volta.

Ele deixou o relógio na mochila. Não voltou a usá-lo. Não porque acredite em maldição — Marins é arqueólogo, não acredita em maldição, acredita em estratigrafia e datações contraditórias —, mas porque, desde aquela noite, sempre que olha para o próprio pulso, mesmo sem nada amarrado ali, ele jura que sente o peso de um mostrador circular, de uma pulseira de elos, e o som muito baixo, muito próximo, de um ponteiro batendo o dezessete. Três e dezessete. A hora em que a pedra termina de escrever sobre você e começa a escrever com você.

## Fontes de inspiração

As referências abaixo serviram apenas de base factual para o cenário da ficção. A história, os personagens, o Abrigo 37 e o painel P-417 são inventados; não há transcrição de textos externos.

- Revista Pesquisa FAPESP, "Pré-história ilustrada": Parque Nacional da Serra da Capivara, mais de 700 sítios pré-históricos, arte rupestre de São Raimundo Nonato (Piauí), Patrimônio Mundial da UNESCO desde 1991, datações controversas por carbono-14 e termoluminescência, pesquisas de Niède Guidon.
- G1, reportagem sobre a pintura da Serra da Capivara tida como a cena de beijo mais antiga do mundo: estimativa de 12 mil anos, pigmentos de óxidos de ferro e carvão, preservação pela rocha arenítica e clima seco, e o arqueólogo Igor Linhares explicando que a arte rupestre se data por datação relativa, nunca absoluta.
- UNESCO/ICOMOS, documento da Lista do Patrimônio Mundial n.º 605 (Serra da Capivara National Park): datações do abrigo Pedra Furada e ensembles rupestres dos períodos 10000-4000 a.C., com ressalvas sobre a controvérsia das datações do sítio.
