---
titulo: "O Poço Nove"
resumo: "Uma técnica acústica escuta fitas de um poço científico selado e descobre que algo, doze quilômetros abaixo do solo, está batendo de volta — e aprendendo a contagem dela."
categoria: "conspiracos"
data: "2026-11-21"
slug: "o-poco-nove"
tipo: "ficcao"
fonte_pesquisa: "Poço Superprofundo de Kola — relatos públicos (BBC News Brasil, Wikipedia) sobre a perfuração de 12.262 metros, selada em 2008; lendas urbanas sobre gritos no fundo do poço tratadas como folclore, sem citação textual"
---

O Poço Nove

A tampa de aço de doze toneladas fica sobre o concreto como uma tampa de caixão mal selada. Do lado de fora, a tundra da Península de Kola cobre de ferrugem os contêineres da estação soviética, o gerador mudo há décadas, a torre de perfuração desmoronada. Não resta nada visível do furo: apenas um diâmetro de vinte e três centímetros, agora selado por uma placa chumbada ao chão e um anel de ferrolhos grossos. O mundo decidiu que o assunto estava encerrado em 1992, quando a broca parou a doze mil duzentos e sessenta e dois metros de profundidade, e novamente em 2008, quando o complexo foi liquidado e abandonado.

Eu não fazia parte do mundo que decidiu isso. Meu trabalho era ouvir o que sobe.

Durante três turnos de noite, transcrevi fitas de áudio gravadas por sensores sísmicos e hidrofones deixados no interior do poço SG-3 antes de ele ser selado. O material oficial fala de rochas de 2,7 bilhões de anos, de água salgada em bolsões onde não deveria haver água, de hidrogênio borbulhando da rocha e de cem oitenta graus Celsius no fundo — calor suficiente para amolecer o aço das ferramentas e transformar a rocha em algo próximo de plástico. Não fala de cavidades. Não fala de batidas.

Aos dez quilômetros de profundidade, o som do poço muda. Para de ser o estalo da rocha se ajustando ao peso de si mesma e passa a ser algo regular, com intervalo de aproximadamente um segundo. Um martelo contra aço grosso, às vezes descrito nos rascunhos dos engenheiros como "expansão térmica do revestimento". Eu abri os arquivos brutos, sem filtros, nos alto-falantes do escritório. O som não vinha de cima. Vinha de baixo. Algo, do lado de dentro da rocha, batia na parede do furo. E respondia.

Quando eu emitia um tom de teste pelo alto-falante de superfície, a batida vinha de volta com um atraso de dezoito segundos. Exatamente dezoito. Não dezessete, não dezenove. Dezoito. Como se algo estivesse medindo o tempo entre o eco e a resposta, como se estivesse aprendendo a minha frequência.

Na décima quarta noite de gravação, perguntei em voz alta, perto do microfone de referência: "Quem está aí?" A resposta está na fita do dia seguinte, gravada às três e dezessete da madrugada, quando eu dormia. Uma voz. Não consigo identificar o idioma com certeza — soa como eslavo distorcido, como se as vogais tivessem sido moldadas por uma garganta que não conhece o ar. Ela diz o meu nome. Eu nunca havia dito meu nome em voz alta perto dos microfones do poço.

Pedi acesso ao local. Negado. A estação estava sob controle militar desde o início dos anos noventa, diziam os documentos; o poço, selado; o assunto, encerrado. Roubei então a fita de dezessete de outubro de mil novecentos e oitenta e oito, a última antes da perfuração parar. Ouvi-a nos alto-falantes do escritório, volume alto. Abaixo do chiado da fita, abaixo do zumbido residual dos equipamentos, há palavras. Não em russo. Em português. Uma mulher contando de um a dez. A voz é a minha. Nunca contei de um a dez em gravação alguma.

Os relatórios internos, nos trechos que não foram riscados a caneta antes do arquivo ser transferido para o setor privado, mencionam uma seção entre dez mil e onze mil metros onde a sonda de temperatura encontrou um vazio de cerca de meio metro. Uma caverna natural, ou algo com a geometria de uma caverna. Nos registros, alguém escreveu à mão, e depois rabiscou: "objeto nove". Não há objeto nove nos catálogos oficiais. Não há caverna a doze quilômetros de profundidade na crosta continental. Não há nada que possa bater de volta.

Fui até o local uma última vez. A tampa de aço está soldada ao concreto, com cadeados de segurança e um selo do governo que ninguém se importa em verificar. Encostei o ouvido na placa fria. De dentro vem um som baixo e contínuo, como a respiração de algo enorme deitado sob o frio do Círculo Polar Ártico. E então, acima do silêncio da tundra, as batidas: um, dois, três. Três batidas. A resposta à contagem da fita roubada.

Saí dali sem dizer nada a ninguém. Dois dias depois, meu nome foi removido da lista de pessoal. A fita desapareceu. O poço permanece selado. Desde mil novecentos e noventa e dois, ninguém perfurou mais fundo na Terra do que aquele ponto.

Às vezes, quando o silêncio é absoluto, eu ouço três batidas. Não vêm de fora. Vêm de dentro do crânio, como se algo, doze quilômetros abaixo da superfície, tivesse aprendido a bater no mesmo ritmo do meu coração. E como se, da próxima vez que eu abrir a boca para contar, algo do outro lado do poço estivesse pronto para continuar a sequência.

## Fontes de inspiração

O relato é ficção. A base factual é o Poço Superprofundo de Kola (SG-3), perfurado na Península de Kola, na Rússia, entre 1970 e 1992, com profundidade máxima de 12.262 metros, interrompido pelo calor de aproximadamente 180 graus Celsius e selado com uma tampa de aço em 2008, conforme relatos públicos da BBC News Brasil e da Wikipedia. A lenda urbana de que seriam ouvidos gritos de almas torturadas no fundo do poço é um folclore sem comprovação e não é citada textualmente; todos os nomes, áudios, vozes e eventos da narrativa são inventados.
