---
titulo: "A Segunda Imagem"
resumo: "Um técnico de laboratório revela negativos encontrados em uma casa abandonada e descobre uma figura que aparece mais próxima a cada foto — algo que nunca esteve visível a olho nu, mas que estava latente no filme."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "a-segunda-imagem"
tipo: "ficcao"
fonte_pesquisa: "Spirit photography (Wikipedia) e Latent image (Wikipedia/Britannica)
---

O quarto escuro cheira a fixador e a vinagre — esse ácido doce e agressivo que gruda nas paredes e na roupa de quem não sai de lá antes do amanhecer. Não há janelas. Há apenas a luz vermelha do safelight, baixa o suficiente para não estragar o papel, mas forte o bastante para projetar sombras longas sobre as bancadas de aço. Eu trabalho sozinho à noite, no laboratório de revelação do subsolo de um edifício velho na periferia de uma cidade que ninguém menciona nos mapas turísticos. Cheguei aqui por acaso, ou assim me disse o dono quando me contratou. Agora eu sei que não foi acaso. Foi necessidade. Algo precisava de alguém que não fugisse do escuro.

Na semana passada, entregaram-me uma caixa de negativos encontrados numa casa abandonada no distrito vizinho. O imóvel fora arrombado, revirado, deixado para apodrecer. Entre papéis moídos por cupins e roupas apodrecidas nos armários, alguém achou uma maleta de couro com dezenove rolos de filme, todos eles já expostos, nenhum revelado. O dono da casa, um certo senhor que já não morre desde 1983, segundo o registro do cartório, deixara para trás apenas isso: imagens congeladas em prata haleto, esperando que alguém as tirasse do limbo.

Revelei o primeiro rolo na segunda-feira.

As primeiras negativas pareciam inofensivas. Interiores de cômodos vazios, corpos de móveis cobertos por lona, uma cadeira de balanço no meio de um quarto sem janelas, um espelho quebrado encostado na parede. Nada fora do comum. Nada que justificasse o medo que senti ao pendurar as tiras no varal do laboratório. Foi só quando comecei a passar os dedos pelas emulsões, procurando riscos ou manchas de fábrica, que notei o detalhe.

Na terceira foto do rolo, no canto esquerdo, abaixo da janela, havia uma forma. Não um objeto. Uma figura. Humanoide, mas sem rosto definido, como se a própria escuridão do cômodo tivesse ganhado contornos e decidido se sentar ali, no limite do enquadramento. Eu não me lembrava de ter visto nada ali quando a foto foi tirada — obviamente, eu não estava lá. Mas algo naquela figura me pareceu errado, como se ela não pertencesse à arquitetura do espaço, mas tivesse sido sobreposta depois, ou antes, ou fora do tempo.

Revelei o segundo rolo na terça-feira.

Desta vez, a figura estava mais perto.

Na mesma sequência de interiores, a sombra humanoide aparecia novamente, mas agora ocupava o centro do cômodo, de pé, de costas para a câmera, olhando para a parede como se esperasse algo do outro lado. Nas fotos seguintes, ela se aproximava do quadro. Na sexta imagem, estava a menos de um metro da cadeira de balanço. Na oitava, parecia tocar o espelho quebrado com uma mão que não tinha dedos distintos, apenas um emaranhado de prata escura.

Comecei a duvidar da minha própria memória. Voltei aos negativos do primeiro rolo e confirmei: a figura não estava na primeira foto. Aparecia só a partir da terceira. Como se estivesse chegando. Como se estivesse aprendendo a ser vista.

Revelei o terceiro rolo na quarta-feira.

Agora a figura não estava só nos interiores. Aparecia nas paisagens também — à beira de um campo, no fundo de uma floresta, à sombra de uma árvore morta. E, pela primeira vez, olhava diretamente para a lente. Não para o assunto da foto. Para a câmera. Para quem estivesse do outro lado, revelando o filme.

Foi aí que percebi o problema.

A fotografia não captura apenas o que está diante da objetiva. Ela captura o que é exposto à luz, sim, mas também o que é latente — aquilo que está escondido, invisível a olho nu, mas presente, aguardando o momento certo de se revelar. O químico do revelador não cria a imagem; ele apenas revela o que já está lá, encolhido nos cristais de prata do filme, esperando a transformação. Aquela figura nunca esteve visível para quem tirou a foto. Ela estava latente. Invisível. Mas estava lá.

E agora, por eu tê-la revelado, ela sabia que eu existia.

Comecei a tirar minhas próprias fotos na quinta-feira. Selfies no espelho do banheiro, retratos da minha própria mão segurando a câmera, fotos do quarto escuro vazio. Revelei tudo imediatamente. Nas primeiras imagens, nada. Só eu, sozinho, como sempre. Mas na sétima foto — um autorretrato frente ao espelho, iluminação lateral, expressão neutra — algo apareceu no reflexo do vidro, atrás de mim, um passo além do ombro esquerdo. A mesma forma. A mesma escuridão com contornos. Agora não estava mais só nos negativos de um estranho morto desde 1983. Estava comigo. Estava no meu laboratório. Estava no meu reflexo.

Não consegui dormir naquela noite. Ou talvez tenha conseguido, e só não me lembre. O vazio de memória é um sintoma conhecido entre quem lida com o insólito, embora ninguém goste de nomeá-lo. Acordei com a câmera na mão, o filme carregado, e um novo negativo na bandeja de revelação que eu não recorda ter exposto. A imagem mostrava o quarto escuro. As bancadas de aço. O varal com as fotos penduradas. E, no centro do quadro, de pé entre as imagens já reveladas, estava eu — ou algo com minha roupa, meu corpo, minha postura — segurando a bandeja de revelação, olhando diretamente para a lente. Não era um reflexo. Era uma segunda imagem. Uma imagem de quem observa o observador.

Na sexta-feira, o dono do laboratório veio me buscar. Não encontrou meu corpo. Encontrou apenas o quarto escuro, as luzes acesas, o cheiro de fixador no ar, e uma bandeja de revelação sobre a mesa, com um único negativo úmido ainda em desenvolvimento. Na foto, eu estava ali, de pé no centro do quarto, olhando para a câmera. Mas ao meu lado, preenchendo quase todo o enquadramento, havia uma figura de prata escura, sem rosto, com a mão repousada no meu ombro. Eu não estava sozinho quando a foto foi tirada. Nunca estive.

O dono fechou o laboratório naquele mesmo dia. Dizem que vendeu os equipamentos, que demoliu a sala, que nunca mais quis saber de negativos. Eu não sei se ele conta a verdade. Não importa. O que importa é isto: quando você olha para uma fotografia e sente que algo do outro lado está olhando de volta, não é imaginação. É o revelador fazendo o seu trabalho. É a imagem latente, finalmente, deixando de ser invisível.

E agora que você leu até aqui, ela também sabe que você existe.
