---
titulo: "A Torre de São Francisco"
resumo: "Um mergulhador desce à torre da igreja submersa no lago de uma cidade mineira inundada e descobre que o sino, debaixo d'agua, ainda toca — e que algo responde ao som."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "a-torre-de-sao-francisco"
tipo: "ficcao"
fonte_pesquisa: "Reportagens sobre as cidades submersas do Lago de Furnas e de Nova Ponte (MG); relatos de desaparecimentos em mergulhos em reservatórios"
---

# A Torre de São Francisco

Quando o nível do lago baixou naquele verão de 2024, a torre de São Francisco voltou a aparecer. Não por inteiro — apenas os últimos dez metros de alvenaria, cinza e úmidos, como um dedo apontando do fundo do Reservatório da Pedra Branca para um céu que não lhe devia mais nada. A cidade inteira, Vila Nova do Campo Alegre, fora inundada em 1971 para dar lugar à barragem, e desde então a torre era o único monumento da velha praça matriz que ousava romper a superfície, sempre que a seca se estabelecia com insistência.

Marcelo não era um homem supersticioso. Trabalhara quinze anos como mergulhador comercial em usinas, inspeções de cabos submersos e resgate de corpos em rios de Minas Gerais. Sabia o que a água fazia com os corpos, com as madeiras, com as lembranças. Mas algo naquela torre o puxara desde a primeira vez que a vira, ainda criança, no banco do carro do pai, quando o nível do reservatório desaba e a alvenaria emergiu como um osso de um animal enterrado a pressa. Agora, aos quarenta e dois anos, decidido a descer até ela sozinho, Marcelo alugou um barco pequeno, um cilindro de alumínio duplo e uma lanterna de 4.000 lúmens. Não avisou a ninguém onde ia. Avisar exigiria explicações, e explicações exigiriam respostas que ele não possuía.

Desceu ao anoitecer.

A superfície do lago estava ótima, oleosa, refletindo as últimas cores do crepúsculo sem ondas. Marcelo fez a verificação do equipamento, entrou de ré na água escura e começou a descer pela linha de amarração que prendeu à base visível da torre. A visibilidade não era boa — o lago de Furnas, ou Pedra Branca, ou como quer que chamassem aquele corpo de água artificial, nunca foi transparente. Aos quinze metros, a luz solar já era uma lembrança fraca. Aos vinte e cinco, mergulhou na noite permanente da profundidade.

A torre surgiu do nada, como um paredão de concreto velho, coberto de lama verde e de algo mais escuro que a lama, algo que parecia grudado na pedra com intenção. A lanterna cortou a escuridão e revelou o portal da igreja, ainda de pé, ainda escuro, com as portas ausentes — arrancadas pela corrente ou levadas pelo tempo. Marcelo passou por baixo do arco e entrou.

O interior era maior do que deveria. Ou parecia maior porque a água distorce, porque o medo distorce, porque a lanterna só alcançava alguns metros à frente. Pisadas de mergulhador levantaram nuvens de lodo que flutuaram devagar, como cinzas de um incêndio sem fim. Pela feixe de luz, Marcelo viu os bancos de madeira, intactos, alinhados, cobertos de uma camada fina de algo branco e brilhante que não era areia. As paredes estavam forradas de musgo escuro, e em algumas delas o concreto estava lascado, como se algo tivesse arranhado a pedra de dentro para fora.

No altar, a imagem de São Francisco permanecia. Estátua de concreto ou gesso, de um metro e meio, de mãos estendidas, rosto voltado para o lado esquerdo da nave, como se olhasse para algo que não estava ali. Marcelo aproximou-se, iluminou o rosto do santo. Os olhos da estátua estavam pretos — não pintados de preto, mas vazios, como buracos perfurados no gesso, profundos demais para o tamanho da cabeça. E a boca estava aberta, ligeiramente, como se estivesse prestes a falar ou a engolir.

Ele passou a mão na testa, embaçou a máscara, limpou com o dedo. Quando tirou o dedo, a máscara estava suja de um resíduo branco, fino, que cheirava a cal e a algo úmido, como terra removida de um túmulo há muito tempo.

Foi então que o sino tocou.

Não foi um som de metal batendo no metal. Foi mais grave, mais úmido, um ressoar que veio do próprio corpo da água, do alto da torre, do campanário que ficava vários metros acima do nível atual do lago. O som viajou pela coluna de água, vibrou no peito de Marcelo, nos tímpanos, nos ossos da face. Tocou uma vez. Tocou duas vezes. Cada toque mais longo que o anterior, cada toque mais próximo, como se o sino estivesse descendo em sua direção.

Marcelo acionou o regulador, respirou fundo, subiu em espiral lenta em direção ao campanário. A escada de caracol de ferro ainda existia, enferrujada, parcialmente desmoronada, mas subível. Subiu degrau a degrau, a lanterna tremendo na mão, as bolhas de exalação subindo como prateados peixes cegos. No topo, o sino estava lá — de bronze, verde de ferrugem, imenso, pendurado em uma estrutura de madeira que a água não conseguira apodrecer completamente. O sino estava imóvel. Não havia correnteza forte ali, não havia peixe grande o bastante para movê-lo, não havia motivo para tocar.

Marcelo aproximou a lanterna do bronze. O metal estava úmido, e na superfície molhada havia marcas. Pegadas. Pequenas. Não de animal — de dedo humano, ou algo que se lembrasse de dedo, pressionado contra o sino molhado, como se alguém tivesse tentado segurá-lo do lado de dentro, ou do lado de fora, para impedir que tocasse.

Ele voltou a descer. Apressadamente, desta vez. O som do sino tinha parado, mas o silêncio que lhe sucedera era diferente do silêncio de antes: era um silêncio ouvinte, um silêncio que esperava algo.

Ao voltar ao portal da nave, Marcelo viu o que não estivera lá na descida. Ou talvez estivesse, e ele não tivesse notado. No centro da nave, onde antes havia apenas lodo e bancos, havia agora uma figura. De pé. Envolta em algo branco e pesado, como um sudário ensopado de argila, com a cabeça baixa, os braços pendentes, as mãos — se eram mãos — longas demais, dedos demasiados, descansando sobre o próprio quadril. A cabeça não tinha rosto. Tinha, em vez disso, a mesma cavidade preta que Marcelo vira na estátua de São Francisco. Dois buracos. Vazios. Profundos.

Marcelo não se moveu. Não respirou — ou tentou não respirar, o barulho do regulador soando alto demais no capacete, como o vento de uma tempestade dentro de um tubo. A figura não se moveu. Não flutuava. Não nadava. Estava simplesmente ali, em pé no chão da igreja submersa, como se o peso da água acima não lhe dissesse respeito.

Depois de um tempo que Marcelo não conseguiu medir — um minuto? cinco? — a figura inclinou a cabeça, lentamente, em direção a ele. Não houve som. Não houve bolhas. Não houve movimento da água ao redor. A figura apenas esperou, imóvel, e Marcelo entendeu, com a clareza fria do medo que não grita, que aquela coisa estava há muito tempo debaixo d'água, muito antes da barragem, muito antes da cidade, muito antes da torre ser erguida. Que a igreja fora construída sobre ela. Que a cidade fora inundada para cobri-la, para esquecê-la, para mantê-la quieta. E que o sino tocar fora um convite, não um acidente.

Marcelo deu um passo para trás. O calcanhar bateu num banco de madeira. O som ecoou, nítido, violento no silêncio da nave. A figura não reagiu. Não se afastou. Não avançou. Esperou.

Ele virou e nadou para fora, de volta ao portal, de volta à linha de amarração, subiu a coluna de água o mais rápido que sua tabela de descompressão permitiu, ignorando o risco, ignorando as bolhas que saíam rápido demais, ignorando o zumbido nos ouvidos. Rompeu a superfície às dez e vinte e três da noite, ofegante, tirando a máscara, tossindo água e ar, agarrado à borda do barco. O lago estava calmo. A torre emergia a poucos metros, um dedo cinza apontando para o céu. O sino, de cima, não tocou mais.

Marcelo subiu a bordo, tirou o equipamento com mãos trêmulas, ligou a lanterna de mão do barco e apontou para a torre. Nada. Só a alvenaria molhada, o céu, a escuridão. Ele respirou fundo, duas, três vezes. Tinha exagerado. Tinha deixado a imaginação voar. A figura no lodo era um banco de madeira, uma luz refletida, um truque da profundidade. Nada mais.

Foi então que notou a caixa préta presa ao cinto do colete — a pequena câmera de ação que levara para registrar a descida. Ligue-a. Revisar as imagens seria prudente. Prudentemente, apertou play.

A tela pequena mostrou a descida, a torre, o portal, o interior da nave, os bancos, o altar, a estátua de São Francisco com os olhos pretos. Mostrou a subida ao campanário, o sino imóvel, as marcas de dedo no bronze. E mostrou, na descida de volta, a figura branca em pé no centro da nave, a cabeça baixa, os dedos longos, os buracos onde deveria haver um rosto. Até aí, tudo coerente com o que vira.

Mas no último minuto da gravação, quando a câmera aponta para a linha de amarração e a superfície se aproxima, algo aparece na borda inferior do quadro. Uma mão — não humana, pálida, dedos demasiados — repousa no conves do barco, do lado de fora, segurando a borda de alumínio com uma força que deixa marcas no metal. A mão não está na água. Está no barco. Está ali agora. Marcelo olhou para o conves. Não havia nada. Só o alumínio escuro, a chuva começando a cair, o cheiro de lama e de cal branca.

Ele desligou a câmera. O sino, no topo da torre submersa, tocou uma vez. Apenas uma. O som atravessou a água, atravessou o casco do barco, atravessou o peito de Marcelo, e parou. Na água ao redor do barco, algo se moveu. Não um peixe. Não uma corrente. Algo grande, algo lento, algo que subia.

Marcelo ligou o motor. Não olhou para trás. Afastou-se da torre, do lago, da cidade submersa, sem saber se o que havia visto ainda estava no fundo, ou se havia decidido, finalmente, acompanhá-lo para fora da água.

## Fontes de inspiração

- Reportagens sobre as cidades submersas pelo Lago de Furnas e pelo Reservatório de Nova Ponte, em Minas Gerais, incluindo o reaparecimento de torres de igrejas durante períodos de estiagem.
- Relatos jornalísticos sobre desaparecimentos e mortes em mergulhos recreativos e comerciais em reservatórios e lagos artificiais.
- Lendas regionais sobre entidades que habitam águas profundas e chamam pessoas para o fundo de rios e lagos.

---

Nota editorial: esta é uma obra de ficção. Personagens, locais e eventos são produtos da imaginação do autor, ainda que inspirados em fenômenos reais de forma parcial e não exaustiva. Nenhum fato apresentado como real.