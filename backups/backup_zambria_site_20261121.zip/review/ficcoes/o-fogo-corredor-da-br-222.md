---
titulo: "O Fogo-Corredor da BR-222"
resumo: "Um caminhoneiro do sertão piauiense é acompanhado, noite após noite, por uma luz que não foge dos faróis. Quando decide segui-la fora do asfalto, descobre que o perigo nunca foi perder o caminho — era ser lembrado por algo que ainda caminha no escuro."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-fogo-corredor-da-br-222"
tipo: "ficcao"
fonte_pesquisa: "Luzerna (lenda) — Wikipedia; Boitatá — folclore brasileiro"
---

Na BR-222, entre Teresina e a fronteira do Maranhão, a noite não é ausência de luz. É presença de outra coisa. Raimundo dirigia há dezoito horas sem parar, com a carga de azulejos trincando na caçamba a cada buraco, e o painel do caminhão pintava o rosto dele de vermelho morto quando, no quilometro trezentos e doze, uma luz se acendeu ao lado direito da pista.

Não era farol. Estava muito baixa, flutuando a pouco mais de um metro do solo, como uma lanterna segurada por alguém que caminha no matagal. Branca, quase azul, do tamanho de uma cabeça humana. Raimundo piscou os faróis baixos. A luz se moveu, devagar, acompanhando o ritmo do caminhão.

Ele não acelerou. Não freiou. Não chamou ninguém no rádio. Essa foi a primeira coisa estranha: a ausência de surpresa. Durante duas noites seguidas, a luz esteve lá, no mesmo ponto, na mesma altura, como um passageiro que não ocupa assento. Raimundo passou a anotar no bloco de recibos: "KM 312. Luz branca. Não some." Não fez sentido, mas também não fez falta. No sertão, o que não explica nada costuma ficar quieto.

O problema começou na terceira noite.

A luz não só apareceu no KM 312. Ela apareceu no KM 308, depois no 305, depois no 300. Estava à frente dele, sempre à frente, nunca mais que uns cinquenta metros, como se esperasse que ele alcançasse. Raimundo parou no acostamento, desligou o motor, desceu. O cheiro do sertão à noite é de terra seca, capim queimado e umidade que sobe do subsolo quando o ar esfria. Ele olhou para o escuro. Não viu nada. Voltou para a cabine, ligou o caminhão, e a luz estava do outro lado do para-brisa, parada, observando.

Lenda local, pensou. Luzerna. Fogo-corredor. Alma de compadre que morreu sem se falar, condenada a guerrear pelas estradas até encontrar paz — ou explodir, soltando cheiro de enxofre. Raimundo não acreditava em compadres, nem em almas. Acreditava em pneus carecas, freio de motor e entregas atrasadas. Mas acreditava também no que via pelos espelhos: a luz não se afastava quando ele acelerava, e não se aproximava quando ele freava. Ela simplesmente estava lá, como se a estrada tivesse crescido um olho.

Na quarta noite, ele decidiu seguir.

Saiu do asfalto no trecho onde a pista curva para o leste, na altura de um poste caído que ninguém conserta. O caminhão embuchou na areia, faróis iluminando galhos retorcidos de umburana e cactos que se erguem como dedos. Raimundo dirigiu até os pneus afundarem. Parou. Desligou os faróis.

O silêncio foi imediato, completo. O tipo de silêncio que não é ausência de barulho, mas presença de atenção. E então ele viu: a luz, agora a uns vinte metros, parada no meio do mato baixo, piscando devagar — uma vez, duas vezes — como quem sinaliza.

Raimundo desceu novamente. Levou a lanterna, não usou. Caminhou na direção da luz. O solo era de argila vermelha, úmida, pegando nos tornozelos. A cada passo, a luz recuava o mesmo tanto, mantendo a distância. Ele parou. A luz parou. Ele deu um passo à frente. A luz recuou.

Foi então que notou o cheiro. Enxofre, mas também algo mais velho: osso velho, fio de cobre queimado, a carne de algo que morreu há muito tempo e ainda não terminou de apodrecer.

A luz piscou mais rápido. Raimundo sentiu algo descer pela nuca dele, não frio, mas reconhecimento — como se a luz o conhecesse, como se estivesse esperando que ele chegasse até ali, naquela noite, naquele passo exato. Ele estendeu a mão.

A luz se aproximou, devagar, parou a uns dez centímetros da palma da mão dele. Dentro dela, não havia chama, nem lâmpada, nem reflexo. Havia um escuro mais denso que o da noite, um núcleo de escuridão que piscava no ritmo de um coração.

Raimundo ouviu algo. Não com os ouvidos. Foi dentro do crânio, uma voz que não tinha sotaque nem sexo, dizendo apenas uma palavra: "Volte."

Ele voltou.

Quando chegou ao caminhão, o sol já clareava o horizonte. O motor pegou na primeira tentativa. Os azulejos estavam no lugar, intactos. Ele seguiu até o posto de combustível mais próximo, bebeu café, fumou um cigarro. Um outro caminhoneiro, velho, de boné sujo, sentou na mesa dele e disse: "Está vendo luz na BR-222, rapaz?"

Raimundo negou com a cabeça. Mentiu.

"Cuidado", disse o velho. "A luzerna não leva ninguém para lugar nenhum. Ela apenas escolhe um motorista, viaja com ele até o amanhecer, e depois segue em frente. O que resta para quem ficou é dirigir para sempre com a luz dentro do espelho, esperando que, numa noite qualquer, ela decida sair do vidro e ocupar o banco do passageiro de verdade."

Raimundo pagou a conta e voltou para a estrada. Naquela noite, no KM 312, ele não viu a luz branca. Viu, no espelho retrovisor, o próprio rosto — e, ao lado dele, uma pontinha branca, piscando, do tamanho de uma cabeça, esperando que ele fechasse os olhos para poder entrar.

Na manhã seguinte, Raimundo não parou no posto. Ele continuou dirigindo. E se você passar pela BR-222 depois da meia-noite, verá um caminhão sem nome na placa, faróis apagados, e uma luz branca caminhando ao lado dele — não atrás, não adiante. Ao lado. Como um passageiro que finalmente conseguiu entrar.

## Fontes de inspiração

- "Luzerna (lenda)" — Wikipédia: luzes globulares que flutuam lentamente por estradas e caminhos à noite, no interior do Nordeste brasileiro; na tradição oral, seriam almas de dois compadres que morreram sem se falar; explicação científica aponta para fenômenos elétricos como o raio globular.
- "Boitatá" — folclore brasileiro: o "fogo corredor" do sertão nordestino, também chamado fogo-fátuo ou santelmo, luz errante associada a campos, cemitérios e regiões com restos orgânicos em decomposição; a ciência relaciona o fenômeno à combustão de gases como metano e fosfina.