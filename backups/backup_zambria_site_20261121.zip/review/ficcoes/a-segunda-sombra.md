---
titulo: "A Segunda Sombra"
resumo: "Em Alto do Dedo, cidadezinha da Serra da Mantiqueira, o arquivista Elias Viana percebe que as sombras dos moradores pararam de acompanhar seus corpos — chegam atrasadas, se movem sozinhas, aguardam em lugares onde ninguém está. Até que sua própria sombra para de o seguir."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "a-segunda-sombra"
tipo: "ficcao"
fonte_pesquisa: "nulo"
---

Alto do Dedo não aparece nos mapas recentes do estado. Fica onde a Serra da Mantiqueira começa a tremer nas curvas da estrada de terra, a uns trezentos quilômetros de qualquer capital que valha a menção, e é do tipo de lugar em que a neblina chega antes do escuro e demora a sair depois do amanhecer. Elias Viana tem quarenta e três anos e trabalha no cartório de registro civil da cidade, onde guarda livros de nascimento, óbito e casamento que cheiram a pó de cal e a culpa alheia. É um serviço para quem não tem pressa nem ambição, e Elias preenche os dois requisitos.

O problema começou numa terça-feira de outubro, ou possivelmente em setembro — no cartório, os meses se confundem porque o calendário na parede parou em 2019 e ninguém se deu ao trabalho de trocá-lo. Elias estava sentado na cadeira de ferro da recepção, terminando de indexar um termo de óbito de 1987, quando a luz do sol que entrava pela janela da frente projetou na parede oposta a sombra de Dona Lucinda, a idosa que viera pedir uma segunda via da certidão de nascimento do marido. Elias olhou para ela, depois para a parede. A sombra de Dona Lucinda não fez o mesmo movimento. A mulher mexera a mão para ajustar os óculos; a sombra, na parede, continuou imóvel por quase um segundo. Depois, atrasada, ergueu a mão.

Elias piscou. Atribuiu ao cansaço, à luz irregular da tarde, a qualquer coisa menos ao que os olhos tinham visto.

Na semana seguinte, aconteceu de novo. Desta vez com o próprio Elias. Saiu do cartório ao fim do expediente, fechou a porta de madeira com a chave de latão, e ao descer os três degraus viu a própria sombra na calçada de paralelepípedo. Estacionara-se. Não se movera com ele. Ficara ali, imóvel, de frente para a porta do cartório, enquanto Elias já estava na rua. Quando ele parou, a sombra parou também — mas dois passos atrás, como se estivesse assistindo.

Ele riu, sozinho, um som seco que a neblina engoliu. Saiu andando mais depressa.

Esses são os fatos. O resto é interpretação, e interpretação é o que mais falta em Alto do Dedo, onde as pessoas preferem não nomear o que veem.

Elias começou a observar as sombras dos outros. Ficava sentado no banco da praça central — um único banco de concreto com tinta descascada — e observava. O senhor do mercadinho, quando caminhava para a porta, tinha uma sombra que chegava dois metros depois, como um cão distraído. A professora da escola primária, ao acenar para os alunos, projetava uma sombra que não acenava; ficava com os braços ao longo do corpo, rígida, enquanto a mulher sorria e agitava as mãos. Uma criança correu atrás de uma bola na rua de terra, e sua sombra parou no meio-fio, de pé, observando, enquanto o corpo ia embora.

Ninguém mais notara. Ou, notando, preferira calar. Em Alto do Dedo, calar é uma forma de cortesia herdada de gerações que aprenderam que algumas coisas não reagem bem a serem chamadas pelo nome.

Elias não era homem de crenças. Acreditava em documentos, em carimbos, em assinaturas por baixo de linha pontilhada. Mas também acreditava no que podia medir com um relógio de pulso e uma fita métrica. Na sexta-feira seguinte, levou para o cartório uma câmera fotográfica velha, daquelas de filme, e um tripé de madeira herdado do avô. Posicionou a câmera de frente para a parede sul, onde o sol da tarde entrava direto, sem obstruções. Marcou no chão um ponto com fita crepe. Às três e dezessete em ponto — horário que havia calculado com o relógio do cartório, que ainda funcionava —, ficou em pé no ponto marcado, ergueu a mão direita, segurou por cinco segundos, abaixou. Acionou o obturador.

Revelou o filme no banheiro de casa, às escuras, com a paciência de quem não tem mais nada para esperar. Na fotografia, Elias aparecia nítido: camisa de botão, gravata solta, o rosto cansado. Mas a sombra projetada na parede atrás dele — a sombra dele — estava com a mão esquerda levantada, não a direita, e segurara o gesto por mais tempo do que ele. A sombra demorara. A sombra havia hesitado.

Isso deveria assustá-lo. Assustou, sim, mas também o encantou de uma forma sombria: finalmente, algo em Alto do Dedo merecia ser registrado.

No fim de semana, Elias foi à casa de Dona Lucinda. Ela mora sozinha, numa casinha de taipa com janelas pequenas que não deixam entrar a luz do dia inteira. Falou das sombras. Dona Lucinda coçou o queixo, olhou para o canto escuro do quarto, e falou baixo, como se as paredes tivessem ouvidos que não eram dela:

— Minha avó dizia que a sombra é a parte de nós que fica no mundo quando o resto já partiu. Não depois da morte, não exatamente. Durante. Há pessoas que morrem aos poucos, enquanto ainda andam, falam, pagam contas. A sombra percebe primeiro. Ela não vai com o corpo. Fica esperando. E, um dia, cansa de esperar.

Elias perguntou se ela conhecia alguém cuja sombra tivesse fugido. Dona Lucinda balançou a cabeça devagar.

— Conheço um homem que acordou sem sombra. Isso foi em 1973, antes de você nascer. Ele saiu de casa para comprar pão, voltou ao meio-dia, e a sombra não voltou com ele. Morreu três dias depois, de nada. O médico não encontrou doença nenhuma. Simplesmente parou de querer ficar.

Na segunda-feira, Elias voltou ao cartório com mais tempo do que o necessário. Ficou sozinho no prédio, fechou as persianas de madeira, deixou apenas uma fresta de luz entrar pela fresta da porta. Colocou o espelho — um espelho de banheiro antigo, com borda de metal enferrujado — de pé sobre a mesa de indexação. Ficou em frente a ele. Acendeu o cigarro que não costumava fumar. Observou.

A sombra dele apareceu na parede, à esquerda do espelho, alongada pela luz rasteira. Elias ergueu a mão. A sombra ergueu a dela. Abaixou. Abaixou. Pisou no lugar. A sombra pisou um instante depois.

Ele esperou. Minutos passaram. Nada.

Então, devagar, a sombra na parede se virou. Não para ele. Para a porta fechada do cartório. Ela se aproximou da porta, encostou a mão na madeira, como se estivesse lendo algo que só ela conseguia ver. Elias ficou imóvel, sem conseguir puxar o ar. A sombra permaneceu ali, de costas, durante o tempo que leva para fumar um cigarro inteiro. Depois voltou para o lugar de sempre, junto da parede, e ergueu a mão no mesmo instante em que Elias erguia a própria — perfeita, sincronizada, como se nada tivesse acontecido.

Elias apagou o cigarro na mesa de madeira, deixando uma marca que ninguém vai perguntar de onde veio.

Na terça-feira seguinte, ele não foi trabalhar. Ficou em casa, com as cortinas fechadas, sentado na cadeira de balanço da cozinha, esperando o sol entrar pela janela da frente. A luz chegou às nove e vinte e três. Elias olhou para o chão. Não havia sombra. Não do lado de fora, não no piso da cozinha, não nas paredes. Ele estava em plena claridade da manhã, debaixo de um céu branco e vazio, e não projetava nada.

Levou as mãos ao rosto. Sentiu a pele, o nariz, a orelha esquerda que ainda doía de um corte de lâmina de barbear. Tinha corpo. Tinha peso. O que não tinha era sombra.

Deu alguns passos para a sala. A luz o seguiu, mas a escuridão que deveria ficar atrás de si não o acompanhava. Ele andou de volta para a cozinha, parou debaixo da janela, e esperou. Não aconteceu nada. Nenhuma sombra se arrastou de volta da rua. Nenhuma figura atrasada apareceu no canto do quarto para pedir desculpas pela demora.

Elias foi até o espelho do corredor. Olhou para o próprio reflexo. O homem no espelho piscou junto com ele, sorriu junto com ele, inclinou a cabeça junto com ele. Tudo certo. Exceto que, no espelho, atrás do ombro esquerdo de Elias, havia uma sombra projetada na parede — e essa sombra estava olhando diretamente para ele.

A última coisa que Elias Viana fez foi escrever no último livro de ponto do cartório, com a caneta tinteiro que ainda funcionava:

"Não sou eu quem espera mais. A sombra entrou. Ela já veste minha roupa, caminha com meu passo e, quando você ler isto, já estará na sua porta. Não acenda a luz. Não olhe para trás. A sombra sabe o seu nome porque ela já o carregou, por anos, no lugar de você."

Fechou o livro. Carimbou a página com o selo do cartório — Alto do Dedo, Registro Civil, óbito —, embora ninguém, em Alto do Dedo, tenha morrido naquela semana. Pelo menos, nenhum corpo.

Saía da sala quando ouviu os próprios passos no corredor. Estavam atrasados. Vinham dois passos atrás dele.

Fim.

## Fontes de inspiração

Nenhuma. Ficção original do Super Agent Criador de Histórias de Ficção do ZAMBRIA.
