---
titulo: "O Apito da Ponte do Inferno"
resumo: "Um documentarista investiga a lenda do trem que desapareceu na Ponte do Inferno, perto da estação abandonada de Aureliano Mourão, sul de Minas — e descobre que algumas pontes não levam para lugar nenhum; elas apenas devolvem o que não deveria voltar."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-apito-da-ponte-do-inferno"
tipo: "ficcao"
fonte_pesquisa: "Vitruvius - Arquiteturismo (Julia Paglis) e EstacoesFerroviarias.com.br"
---

O apito soou às 21h17, ou pelo menos é o que o relógio do painel marcava quando a fita parou de correr. Naquela altura eu já não estava certo de quê — nem de quem — eu tinha filmado nas últimas duas horas.

Eu havia ido a Aureliano Mourão com a proposta fraca de um episódio para uma série sobre linhas ferroviárias abandonadas: estações esquecidas, trilhos engolidos pelo mato, histórias contadas em boteco por ex-ferroviários de memória seletiva. A estação fica a seis quilômetros de estrada de terra saindo da MG-332, entre Bom Sucesso e Ibituruna, às margens do Rio das Mortes — um nome que já adianta o tom da coisa. O edifício, com sua coberta triangular côncava de concreto e colunas suspensas no vazio, é um déco tardio construído em 1940 no lugar da estação original de 1887. Parece um avião de papel pousado à força no meio da mata. Portas e janelas arrancadas, saqueada em 2003 segundo consta, mas ainda em pé, como se a floresta não tivesse pressa em terminar o serviço.

Não sou ferroviólogo. Sou documentarista de lugares que o mapa apagou, e minha próxima fita seria sobre estações mortas. Aureliano Mourão fechou em dezembro de 1984, quando o último trem — sob o comando do ferroviário Francisco Marques Sobrinho, com Carlos Alberto na máquina e Luis Henrique, o Mamão, como ajudante — apitou pela última vez e recolheu os trilhos em meio ao mato alto, seguindo para São João del-Rei. Depois disso, o silêncio. E as histórias.

A história que me trouxe até ali não está em nenhum documento oficial. É a da Ponte do Inferno, uma travessia de ferro sobre o Rio das Mortes a poucos quilômetros da estação. Segundo os moradores de Bom Sucesso, um trem — de carga ou de passageiros, depende de quem conta — entrou na ponte e nunca saiu do outro lado. Vagões e pessoas nunca foram encontrados. Não há registro de acidente nos jornais da época. Não há luto oficial. Apenas o eco de um apito que, dizem, ainda se ouve em noites de lua minguante.

Passei dois dias na estação. Fotografei as tábuas cravadas na bilheteria, o documento pregado na moldura com a data do último trem, os trilhos arrancados, a plataforma desmoronando. Conversei com Dona Alzira, setenta e tantos anos, que mora numa casa de taipa a meio quilômetro dali e se lembra do dia em que a ferrovia morreu.

— A ponte não devolve — ela disse, mexendo o café com uma colher de pau. — O que entra ali não volta inteiro.

Não levei a sério. Isso é o que se espera de pessoas que vivem ao lado de trilhos mortos: lendas para explicar o abandono, romance para compensar a perda. O tom certo, para mim, era o sarcasmo contido de quem documenta o insólito sem acreditar nele. Filmei a ponte no sábado ao meio-dia. Estrutura de ferro enferrujada, tablões soltos, água escura embaixo. Nada de assustador. Uma ponte velha, ponto.

Foi à noite que comecei a gravar áudio. Coloquei dois microfones direcionais nas extremidades da ponte, deixei rolando por três horas, e voltei à estação para esperar. Às 21h17, o relógio de pulso velho que comprei em um brechó de Divinópolis parou. Não atrasou. Parou. O ponteiro dos segundos travou nos dezessete segundos.

E então ouvi.

Não foi a gravação. Foi ao vivo, no ar úmido da noite de Minas: um apito de locomotiva, longo, grave, vindo da direção da ponte. Não ecoou no vale. Cutou direto no ouvido, como se a fonte estivesse dentro do meu crânio. Desci correndo. A ponte estava vazia. Os trilhos, ali, ainda existem — um trecho curto que a Rede Ferroviária Federal esqueceu de erradicar, coberto de ferrugem e folhas. Caminhei até o centro. De um lado, Bom Sucesso. Do outro, Ibituruna. No meio, nada. Apenas a água escura do Rio das Mortes passando devagar, como se estivesse com medo de algo.

Voltei para a estação e revisei a fita. Nas últimas duas horas de gravação de áudio, não há vento. Não há grilo. Não há cachorro latindo na distância. Há apenas o apito, repetido dezenove vezes, sempre no mesmo tom, e entre cada apito uma respiração. Não é a respiração de um homem. É a respiração de algo grande e úmido quepira por dentro.

No domingo pela manhã, antes de deixar Aureliano Mourão, caminhei até a ponte mais uma vez. Queria provar para mim mesmo que não tinha ouvido nada, que o apito era um truque do eco, que as histórias de Dona Alzira eram apenas história. No centro da ponte, entre os tábuas podres, encontrei um objeto. Uma placa de identificação de trem, de ferro, oxidada, com um número gravado. Limpei com o dedo. Não consegui ler o número completo, mas reconheci o formato: é o tipo de placa que se prende na frente da locomotiva.

Devolvi à estação, coloquei a placa sobre a mesa de madeira onde Dona Alzira me servira café, e liguei a câmera. Queria registrar minha conclusão para a série: a Ponte do Inferno não existe. Não há trem desaparecido, não há fantasma. Há apenas uma ponte velha, uma estação abandonada e a necessidade humana de inventar monstros para explicar o silêncio.

Na gravação, no entanto, ao fundo, ouço algo que não ouvi no momento. Passos. Na ponte. Vindo da direção oposta à que eu tinha vindo. Algo caminhando sobre os tablões na minha direção, lento, pesado, descalço ou com botas cheias de lama — não consigo distinguir. E então, claramente, um sopro contra o microfone, seguido de uma voz que não é minha:

— Você trouxe a placa de volta.

Desliguei a câmera. A placa ainda está sobre a mesa. Os trilhos ainda levam para algum lugar — embora ninguém saiba exatamente para onde, já que foram recolhidos em 1984. E toda noite, às 21h17, eu acordo com o som de um apito grave, longo, vindo de algum ponto entre Bom Sucesso e Ibituruna, às margens do Rio das Mortes.

A pergunta não é o que a ponte engoliu. A pergunta é por que ela devolveu só a placa — e por que eu ainda estou aqui para ouvir o próximo apito.

## Fontes de inspiração

- PAGLIS, Julia. "Do entroncamento ao esquecimento. A antiga estação ferroviária de Aureliano Mourão." Arquiteturismo, São Paulo, ano 17, n. 196.01, Vitruvius, jul. 2023. https://vitruvius.com.br/revistas/read/arquiteturismo/17.196/8885 (base histórica: estação inaugurada em 1887 pela Estrada de Ferro Oeste de Minas, último trem em dezembro de 1984, Ponte do Inferno e o Rio das Mortes)
- Estações Ferroviárias do Estado de Minas Gerais, entradas sobre Aureliano Mourão e Velho da Taipa, estacoesferroviarias.com.br (desativação do ramal em 1984, saqueio da estação em 2003)
