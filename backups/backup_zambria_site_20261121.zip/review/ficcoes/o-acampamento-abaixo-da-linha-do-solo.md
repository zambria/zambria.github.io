---
titulo: "O Acampamento Abaixo da Linha do Solo"
resumo: "Em uma operação de arqueologia preventiva às margens de uma estrada histórica de Minas Gerais, um técnico encontra sepultamentos que não pertencem a nenhum povo registrado — e a pressa do empreiteiro em tapar o buraco sugere que alguém já sabe o que está ali."
categoria: "arqueologia"
data: "2026-11-21"
slug: "o-acampamento-abaixo-da-linha-do-solo"
tipo: "ficcao"
fonte_pesquisa: "web"
---

A retroescavadeira não para. O motor ronca desde as seis e meia da manhã e a poeira da laterita cobre o caderno de campo, as lentes da câmera e o rosto de quem ainda não aprendeu a não engolir o ar de Minas Gerais. Eu sou só o técnico de campo da consultoria contratada para o resgate preventivo — não sou arqueólogo, não sou o responsável técnico, apenas quem anota camadas, saca fragmentos e coloca etiqueta em sacos plásticos. A estrada que duplicam leva a um povoado do ciclo do ouro, fundado no século XVIII, e o licenciamento ambiental exigiu que olhássemos para baixo antes que o asfalto subisse. Ninguém espera encontrar nada. O esperado, neste tipo de serviço, é não encontrar nada, ou encontrar tão pouco que um laudo curto resolva o problema.

A primeira camada é a de sempre: terra preta do lote colonial, cacos de louça inglesa, prego enferrujado, garrafa de bebida dos anos 1950. Depois vem a cinza, e abaixo dela, ossos.

Não ossos de animal. Crânios. Longos ossos dispostos em anéis. Dentes.

A estratégia da empreiteira é conhecida: quanto menos se documenta, mais rápido se libera a área. O engenheiro de segurança veio duas vezes, olhou a vala e disse que o prazo da pavimentação não espera laudo do Iphan. O responsável técnico da consultoria assinou o termo de ocorrência, fotografou o necessário e recomendou o encerramento da sondagem. "É um sepultamento colonial comum," disse ele, varrendo a poeira das calças. "Enterro de escravo ou de algum operário da mina. Coisa de arquivo."

Eu não assinei nada sobre a camada abaixo.

Abaixo dos ossos há outra coisa. Uma cava mais profunda, revestida de lascas de quartzito dispostas em círculo — não é obra colonial, não tem nada de bandeirista, não combina com os padrões conhecidos do sítio. Os crânios da camada superior estão virados para baixo, face contra a terra, como se tivessem sido colocados de cabeça para guardar algo. Alguns dentes apresentam limagens simétricas que não correspondem a nenhum grupo indígena registrado na região e muito menos a padrões europeus. E entre as costelas de um dos indivíduos, encontrei um fragmento de metal oxidado, formato regular, que não deveria estar ali: parece uma peça usinada, algo que não existiria naquele solo antes de máquinas modernas.

Não fotografei a peça. Coloquei no bolso e esqueci de entregar.

Na noite anterior ao aterro, voltei sozinho. A vala já estava parcialmente coberta pela retroescavadeira; apenas uma fenda ainda expunha a cava de pedra. Desci com uma lanterna e uma espátula. O ar dentro da fenda não cheira a umidade velha; cheira a ozônio e a pedra quente, como se o subsolo estivesse aquecido de baixo para cima. Raspei a terra com as mãos até encontrar a borda do círculo de quartzito. A pedra não é fria. Emite um zumbido baixo, quase abaixo do ouvido, que senti mais nos dentes do que nos ouvidos.

Não registrei nada disso no caderno.

Na manhã seguinte, a empresa cobriu a vala com terra compactada e asfalto. O laudo foi arquivado. O povoado agora tem uma pista dupla e uma placa histórica com o nome errado do fundador.

Às vezes, à noite, motoristas que passam pelo trecho relatam ver luzes entre as árvores, ou ouvir batidas na parede do asfalto quando o trânsito pára. Ninguém leva a sério. Não deveria levar. O que fica abaixo da linha do solo não precisa ser fantasma, demônio ou visitante de outro mundo para ser perigoso. Basta ser algo que não foi feito para ser desenterrado, e que agora tem uma estrada inteira sobre a cabeça — peso suficiente para não sair, mas não suficiente para ficar quieto.

A pergunta não é o que está enterrado ali. A pergunta é por que ninguém ousa desenterrar — e se, um dia, o peso do asfalto não será mais suficiente.

## Fontes de inspiração

- Artigo sobre os sepultamentos secundários da Lapa do Caboclo, Diamantina (MG), na Serra do Espinhaço (revista Sabnet / Seer PUC Goiás): descrição de enterramentos secundários em estojos de casca de árvore, ossos rearranjados, pigmentos e couro. Usado apenas como referência atmosférica de práticas funerárias antigas da região.
- Notícia sobre o resgate de mais de 40 sítios arqueológicos pela Anglo American em Conceição do Mato Dentro (MG), no âmbito do programa Minas-Rio, seguindo parâmetros do IPHAN e do IEPHA: base para a rotina de arqueologia preventiva e a tensão entre cronogramas de obra e patrimônio.
- Reportagem do G1 sobre a obra de duplicação em Congonhas (MG) paralisada após a descoberta de túneis coloniais, cobertos pela empresa antes da interdição do IPHAN: referência para a pressa em tapar valas e para o descaso institucional com o que fica abaixo da linha do solo.
- Notícia da Terra sobre o sítio arqueológico encontrado pela Vale em Itabirito (MG) durante obras de reparação da barragem de Brumadinho: exemplo de achados interrompidos por cronogramas de empreiteira.

Tudo acima é consulta pública na internet; a história é ficção, os personagens e o sítio descrito são inventados, e nenhum texto foi copiado integralmente das fontes.