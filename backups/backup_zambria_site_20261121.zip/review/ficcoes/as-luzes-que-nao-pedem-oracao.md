---
titulo: "As Luzes que Não Pedem Oração"
resumo: "Um homem retorna ao interior de Minas Gerais para liquidar a herança do pai e decide passar uma noite no brejo onde, segundo o folclore, as luzes-fátuas marcam ouro enterrado guardado por almas dos mortos. O que grava em sua câmera não é gás inflamável."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "as-luzes-que-nao-pedem-oracao"
tipo: "ficcao"
fonte_pesquisa: "agroemcampo.ig.com.br; oantagonista.com.br"
---

# As Luzes que Não Pedem Oração

Há uma regra, no interior de Minas Gerais, que ninguém se dá ao trabalho de escrever: quando uma luz azulada pairar sobre o brejo à noite, você não corre.

Não porque a luz vá queimá-lo. O fogo-fátuo, se é isso que aquelas chamas são, não queima mais que um fósforo molhado — pequena labareda nascida da decomposição da matéria orgânica, que vive segundos e some sem deixar vestígios. Você não corre porque correr avisa à luz que você tem medo. E coisas que observam no escuro costumam gostar de ver o que acontece depois do medo.

Eu conheci essa regra tarde demais.

Voltei a Cachoeira do Brejo — nome que serve tão bem quanto qualquer outro para um lugar que o mundo prefere esquecer — para enterrar o pai. Herdei uma casa de alvenaria descascando, um terreno que não vale o papel do documento, e um caderno de capa dura cheio de anotações sobre as luzes do pântano. Segundo o pai, e segundo metade dos moradores da cidadezinha, as chamas miúdas que dançam sobre a água parada entre novembro e março são almas penadas. Guardam ouro. Escravos enterrados à pressa, garimpeiros esquecidos, dinheiro de ninguém que ninguém ousa desenterrar. No Sul do país dizem que as luzes buscam orações para alcançar o descanso eterno; em Minas Gerais e Goiás, dizem que guardam riquezas. O pai acreditava na segunda versão.

Gastou os últimos três anos mapeando cada ponto de aparição. Anotava data, horário, direção do vento, fase da lua, temperatura da água. Morreu de infarto aos sessenta e dois anos, duas semanas depois de afirmar, ao telefone, que "finalmente encontrara o ponto certo".

Ri disso. Ri até chegar lá, abrir o caderno e decidir passar uma noite no brejo.

A noite era úmida e sem estrelas. Vesti botas de borracha, levei uma lanterna fraca, uma câmera de filme e um gravador de fita. O pai anotara que as luzes apareciam sempre entre a uma e as três da madrugada, sobre um trecho do brejo onde a água não passa de meio braço e o fundo é de argila negra. Caminhei até lá sob o barulho dos sapos e o cheiro de podre que não apodrece totalmente — matéria orgânica em decomposição lenta, gás acumulado sob o sedimento, a ciência explicaria depois. Eu só queria ver.

As luzes surgiram por volta da uma e meia. Pequenas fagulhas azuladas, do tamanho de uma bola de tênis, pairando a poucos centímetros da superfície. Não faziam barulho. Não projetavam sombras. Flutuavam, subiam e desciam como se respirassem. De acordo com o folclore, deveriam fugir quando eu me aproximasse. Não fugiram. Observaram.

Desci até a água. O barro cedeu sob as botas. As luzes se aproximaram, silenciosas, cercando-me a um metro de distância. Olhei para o visor da câmera: não havia nada além de clarões indefinidos. Olhei para os meus pés: a água estava preta e imóvel. Uma das luzes parou à minha frente, estável, não maior que um punho fechado. Não irradiava calor. Não cheirava a enxofre. Não queimava nada. Era apenas uma presença, azul e quieta, olhando para cima — ou para mim.

Apanhei o gravador. Apertei o botão. O silêncio do brejo voltou, denso, e então algo mudou no tom da noite. As luzes se aproximaram ainda mais. Não houve vento, mas a chama — se era chama — inclinou-se levemente, como um pescoço. Fiquei imóvel. A regra, agora eu entendia, não era para me proteger da luz. Era para proteger a luz de mim. Ou para proteger o que quer que estivesse atrás dela.

Começou a chover miudamente. As luzes não se apagaram. Elas subiram um pouco, subiram mais, formando um círculo ao redor de onde eu estava, e nesse momento apertei o botão da câmera. Doze quadros. Talvez vinte. Não sei. O medo paralisa o tempo.

Saí do brejo antes das três. Não corri. Correr seria admitir medo, e medo era exatamente o que aquelas coisas pareciam buscar. Voltei para a casa, tratei de não olhar para a janela do quarto, e fui dormir com o gravador ligado sobre a mesa de cabeceira.

Ouvi a fita na manhã seguinte.

No começo há apenas o barulho dos sapos e a minha respiração. Depois, por volta do minuto sete, as luzes aparecem na fita de áudio como um chiado irregular — algo que não existe no mundo físico, porque luz não faz som. Então vem a minha voz. Não é uma gravação do que eu disse naquela noite; eu não falei quase nada. É a minha voz, com o meu timbre, chamando pelo meu próprio nome, vindo de dentro da água, com um eco que o gravador não deveria conseguir captar. E por trás dela, outra coisa: uma respiração que não é humana, lenta, úmida, como se alguém estivesse falando debaixo d'água, com os pulmões cheios de argila negra.

Desliguei o gravador. Deixei-o sobre a mesa. Voltei ao brejo no fim da tarde, desta vez apenas para olhar, com a câmera na mão e a mente preparada — não, não estava preparado, ninguém está.

A água estava vazia. Não havia luzes. Não havia fagulhas azuladas. Apenas o brejo, o silêncio e o cheiro de podre. Exceto que, quando olhei para o visor da câmera antes de guardar o equipamento, vi algo que não estava lá ao vivo: minha própria figura, imóvel, de pé na água preta, de costas para mim, enquanto na realidade eu caminhava de volta para a estrada. Na gravação, a figura levanta lentamente uma mão — a minha mão — e aponta para algo atrás de mim, para algo que a câmera, por sorte ou desgraça, não conseguiu captar.

O pai encontrou o ponto certo. Duas semanas depois, morreu de infarto. Eu passei uma noite no brejo, voltei para casa, e hoje, às três da madrugada, ouço algo pairar lá fora, sob a janela. Não é vento. Não é gás decomposto. Não é ciência. É uma luz azulada que não queima nada, não deixa cinza, não pede oração, e olha.

As luzes do brejo não perseguem ninguém. Elas esperam. Esperam que você pare de correr. Esperam que você se dobre sobre si mesmo, entre na água preta e descubra, de perto, o que guarda o ouro — ou o que o ouro guarda.

O caderno do pai está aberto na escrivaninha. Na última página, escrita de próprio punho: "elas não são luzes. são olhos." Abaixo, ele riscou a frase com tanta força que rasgou o papel. E embaixo do risco, de caligrafia que não é a dele, nem a minha, há uma linha única: "agora sabe onde ele mora".

Não vou dormir hoje. E não vou correr.

## Fontes de inspiração

- "Fogo-fátuo: a ciência por trás do mistério luminoso dos campos" (Agro em Campo / iG): explicação sobre o fenômeno — chamas azuladas oriundas da decomposição anaeróbica de matéria orgânica, liberação de metano, fosfina e difosfano, combustão espontânea ao contato com o oxigênio, ocorrência em brejos, pântanos e cemitérios úmidos, e o folclore de Minas Gerais e Goiás que associa as luzes a tesouros guardados por almas dos mortos.
- "O fenômeno misterioso dos pântanos onde luzes fantasmas flutuam à noite" (O Antagonista): relatos históricos de luzes sobre brejos, a dificuldade científica de explicar a ignição do metano sem fonte externa e a pesquisa de 2025 (Proceedings of the National Academy of Sciences) sobre "microlightning" — minúsculas descargas entre microbolhas de metano que poderiam iniciar a oxidação luminosa.
- "Nem fantasma, nem feitiço: entenda a luz misteriosa dos cemitérios" (A Tarde): descrição do fogo-fátuo em cemitérios, a impressão de perseguição gerada pelo deslocamento de ar ao redor da chama leve, e a conexão com o mito do Boitatá.

Todas as referências servem apenas como inspiração para a ficção; personagens, lugares e eventos são criações próprias.
