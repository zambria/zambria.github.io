---
titulo: "Os Observadores da Serra de Maracaju"
resumo: "Na serra que dá nome a uma região inteira de Mato Grosso do Sul, luzes pairam no céu há décadas sem registro oficial. Um homem voltou para casa para documentá-las e descobriu que o fenômeno não está no céu — ele está assistindo de volta."
categoria: "ufos"
data: "2026-11-21"
slug: "os-observadores-da-serra-de-maracaju"
tipo: "ficcao"
fonte_pesquisa: "G1 (maior avistamento coletivo de OVNIs do Brasil, Morenão, Campo Grande, 1982); ISTOÉ (os ETs de Urandir e a serra de Maracaju)
---

A Serra de Maracaju não é alta. Não impressiona pela altitude nem pela beleza cênica. É uma longa costela de pedra e cerrado que corta o centro-sul de Mato Grosso do Sul, monótona o suficiente para que os moradores de Corguinho, de Maracaju e de Campo Grande a tratem como pano de fundo — cenário, nunca palco. Até anoitecer.

Foi nessa serra que, no fim de 2010, um grupo disse ter filmado uma figura de pé entre as pedras, algo alto e pálido que ninguém conseguiu identificar. Foi perto dela que, em 1982, dezenas de milhares de pessoas viram luzes coloridas pairar sobre um estádio de futebol em Campo Grande, sem barulho, sem registro fotográfico, sem explicação. A serra acumula histórias. A maioria é contada em voz baixa, quando alguém se lembra de olhar para cima.

Eu voltei para lá não por acreditar, mas por exaustão. Depois de dez anos escrevendo sobre fenômenos aéreos para sites que ninguém lê, cansei de repetir as mesmas três teorias: balão meteorológico, aeronave secreta, alucinação coletiva. Aluguei um carro, comprei câmeras com visão noturna e fui acampar nas redondezas de Corguinho, a cem quilômetros da capital, com a pretensão de provar que as luzes de Maracaju não passavam de reflexo de farol ou do planeta Vênus — a explicação preguiçosa que serve para encerrar qualquer conversa antes que ela comece.

A primeira noite foi decepcionante. O céu estava limpo, cheio de estrelas, e a única luz incomum foi o feixe de um caminhão que passava na BR-060. Deitei no capô do carro, fumei, e pensei que havia perdido o tempo. Até as duas da madrugada, quando algo mudou na qualidade da escuridão.

Não foi uma luz que apareceu. Foi uma ausência. Um trecho do céu, entre duas estrelas, deixou de ser escuro para se tornar… denso. Como se um pedaço da noite tivesse engrossado, ganhado peso, e estivesse olhando para baixo.

Acendi a câmera. O visor mostrava o mesmo céu vazio que meus olhos viam. A diferença é que a câmera não sente arrepios. Eu senti.

Durante as semanas seguintes, voltei toda noite. Sempre o mesmo horário, entre uma e três da manhã. As luzes não apareciam sempre. Mas quando apareciam, faziam coisa que luzes não fazem: paravam no ar sem som, mudavam de direção em ângulos que não respeitam inércia, e, às vezes, pareciam responder ao movimento da minha lanterna. Se eu apontava o feixe para cima, elas piscavam — ou aquilo que eu interpretava como piscar. Se eu desligava tudo e ficava em silêncio absoluto, elas se aproximavam da linha da árvore, baixas demais para serem aviões, silenciosas demais para serem drones.

Comecei a anotar. Data, horário, direção, duração, cor. Depois comecei a anotar coisas que não cabiam em planilha: a sensação de que alguém estava contando meus passos, o frio repentino na nuca mesmo no verão do cerrado, o fato de que os cães da fazenda vizinha pararam de latir exatamente nas noites em que as luzes vieram mais perto.

Foi na terceira semana que a gravação deu problema. Revisei as imagens no notebook, ainda na barraca, e vi o que não deveria estar lá: nas noites em que eu jurava não ter visto nada, as câmeras mostravam luzes pairando acima da minha cabeça. Luzes que eu não lembrava de observar. Luzes que, em alguns frames, estavam alinhadas com a direção da minha tenda — como se tivessem parado para olhar dentro dela.

A partir daí, passei a dormir com a câmera ligada, apontada para mim mesmo. E foi nos vídeos dessas noites que encontrei a parte que não consigo explicar, e que me impede de dormir com a porta aberta.

Em um dos registros, às três e vinte e duas da madrugada, sou eu deitado no saco de dormir, imóvel, respiração regular. Por cima de mim, através do teto de lona da barraca, passa uma luz fraca, azulada, que se move de um lado para outro como se estivesse me escaneando. No vídeo, eu não me mexo. Não acordo. Não pisco. É como se meu corpo tivesse simplesmente… esperado. Quando a luz some, volto a me mexer normalmente, como se nada tivesse acontecido. Nenhum registro de medo, de reação, de movimento. Apenas o vazio entre o momento em que a luz entra e o momento em que ela sai.

Isso é o que fica com quem volta. Não a certeza de que algo existe lá fora. É a certeza de que algo já entrou, que assistiu enquanto você dormia, e que você não tem memória disso porque não houve momento de percepção — apenas a ausência de si mesmo, preenchida por outra coisa.

Voltei para Campo Grande na quarta semana. Devolvi o carro, guardei as câmeras, cancelei as próximas saídas. Não consegui escrever a matéria que planejava. Não porque faltem provas — há horas de gravação —, mas porque não sei mais qual de mim escreveu as anotações. Foi eu quem decidiu voltar para a serra? Ou fui convencido, a algum nível que não lembro, a colocar meu corpo exatamente onde algo queria observá-lo?

As luzes continuam lá. Toda noite, entre uma e três da madrugada, algo paira acima da Serra de Maracaju sem fazer barulho, sem deixar registro, sem que ninguém seja obrigado a acreditar. E o pior não é não saber o que são. O pior é saber que elas sabem exatamente onde eu estou, e que, quando decido olhar para o céu, eu não estou olhando para um fenômeno. Estou sendo devolvido ao olhar de algo que já me viu mais do que eu me vejo.

A serra não guarda segredos. Ela guarda observadores. E a diferença entre os dois é que o segredo, no fim, você pode contar. O observador, não.

## Fontes de inspiração

- G1 — “Como o maior avistamento coletivo de OVNIs do Brasil assustou 23 mil pessoas e virou lenda no futebol” (Campo Grande, Estádio Morenão, 6 de março de 1982). Reportagem sobre luzes multicoloridas no céu sem registro fotográfico oficial.
- ISTOÉ — “Os ETs de Urandir” (relatos de contatos e luzes na região da serra de Maracaju, Corguinho, MS).

Ambas as fontes serviram apenas como inspiração geográfica e temática. Os personagens, os fatos e os eventos descritos são ficção.
