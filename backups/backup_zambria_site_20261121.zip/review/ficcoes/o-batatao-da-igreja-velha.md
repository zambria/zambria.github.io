---
titulo: "O Batatão da Igreja Velha"
resumo: "Um homem volta ao sertão para documentar uma igreja em ruínas antes da demolição e encontra as luzes que, segundo dizem, apontam onde algo foi enterrado — e que não querem ser encontradas."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "o-batatao-da-igreja-velha"
tipo: "ficcao"
fonte_pesquisa: "G1 (luzes no interior de Pernambuco); Agro em Campo (fogo-fátuo/batatão no sertão); lugaresdememoria.com.br (igreja inacabada de Barra do Guaicuí)"
---

# O Batatão da Igreja Velha

O céu do sertão não é cenário. É um testemunho. E, na noite em que Marcos Varela cruzou o portão derrubado da Igreja Velha de Caxingó, o testemunho decidiu falar.

Ele não acreditava em batatão. Isso foi a primeira coisa que disse ao padre — ou ao que restara dele, um homem de casaco surrado e mãos tremulas que morava sozinho na casa paroquial de fato, a uns vinte quilômetros de distância, naquela cidadezinha de poucas ruas de chão batido que o mapa só consulta por obrigação. Marcos era jornalista, ou melhor, fora jornalista; passara uma década escrevendo matérias de fim de semana sobre patrimônio tombado para um suplemento cultural que ninguém lia, e decidira empreender por conta própria um inventário das ruínas do interior antes que a prefeitura as derrubasse para erguer nada. A Igreja Velha de Caxingó era a parada daquela viagem. Século XVII, de acordo com a placa ferrugenta que alguém ainda não tinha roubado. Jesuíta, possivelmente. Abandonada, certamente. E pronta para virar escombros na segunda-feira seguinte.

O padre não disse não. Apenas olhou para o céu — de onde vinham as luzes — e perguntou se Marcos tinha coragem de ficar até a noite.

— Elas aparecem depois das sete — disse o homem, com a voz de quem repete uma sentença já proferida centenas de vezes. — Não são aviões. Não são satélites. Não são balões. São batatão. E batatão não deixa ninguém contar o que viu.

Marcos riu. Era cético de profissão, acostumado a desmontar lendas com dois parágrafos e uma fonte oficial. Pegou sua câmera, o tripé, o gravador de bolso e entrou no templo. A porta girava em gonzos de ferro que rangiam como ossos quebrados. Dentro, o cheiro era de umidade, de gesso desmoronado e de algo mais velho que a madeira apodrecida — um cheiro de terra molhada e de vela apagada há muito tempo, de fumaça que se recusava a sair das paredes. A luz do lanterna de mão cobria pouco. O chão de tijolos estava irregular, solto em alguns pontos, como se algo debaixo dele tivesse se movido recentemente.

Ele começou a fotografar. A nave, o altar sem imagem, o teto exposto às estrelas através de buracos que pareciam mordidas. O campanário não passava de três barras de madeira, como numa forca, sustentando um sino mudo. Marcos subiu os degraus rangentes, olhou para o poço do sino, e ali, no escuro acima de sua cabeça, algo cintilou. Não era reflexo da lanterna. Era uma luz que vinha de fora, pairando a poucos metros do telhado, dourada, silenciosa.

Ele desceu as escadas aos tropeços, saiu pelo portal, e viu.

Não era uma luz só. Eram duas, três, talvez quatro esferas douradas, pairando baixo sobre o pasto atrás da igreja, entre a vegetação rala e o capim seco. Moviam-se sem ruído, mudavam de direção em ângulos impossíveis, como se o ar fosse líquido e elas conseguissem nadar nele. Não piscavam. Não faziam barulho. E, quando uma delas se aproximou do muro, Marcos sentiu o ar ficar pesado, quente, e seus dedos travaram sobre o disparador da câmera. Não conseguia tirar a foto. Não porque o equipamento falhasse — a bateria estava cheia, o cartão vazio — mas porque seus próprios músculos pareciam ter recebido ordem contrária, de algum lugar mais profundo que a vontade.

Ficou parado, olhando. As luzes pairaram por minutos que pareceram horas, depois se afastaram em linha reta, sumindo atrás da serra. O ar voltou ao normal. Os dedos se soltaram. Marcos respirou com dificuldade, como se tivesse subido uma montanha sem sair do lugar.

Apertou o botão da câmera. A foto saiu preta. Não havia nada ali. Apenas escuridão e o contorno do muro.

Ele reviu as imagens anteriores. Nenhuma luz. Nenhuma esfera. Apenas a igreja, o céu, o vazio.

Marcos passou a noite na casa paroquial. Não dormiu. O padre deixara um quarto com lençóis amarelados e uma janela que dava para o pasto. De lá, ele via as luzes aparecerem de novo, mais longe agora, acima da mata, como olhos que observassem a casa. Cada vez que uma se aproximava, o silêncio se fechava ao redor dele, denso, como se o mundo deixasse de existir além de alguns metros. Ele pegou o gravador e tentou falar, mas a voz saía estranha, abafada, como se o ar recusasse levar as palavras. Desligou o aparelho. Não queria gravar aquilo. Não queria provar nada.

Na manhã seguinte, voltou à igreja. Caminhou pelo pasto até onde as luzes haviam pairado. O chão estava seco, sem marcas, sem pegadas, sem rastros de que algo houvesse pairado a poucos centímetros da grama. Mas, perto do muro dos fundos, algo chamou sua atenção: uma área de terra mais escura, mais macia, como se tivesse sido cavada e novamente tampada há pouco tempo. Marcos se ajoelhou, tirou as luvas, e começou a cavar com as mãos.

A terra cedia com facilidade. A uns trinta centímetros de profundidade, os dedos bateram em algo duro. Não era pedra. Era madeira. Uma caixa, pequena, envolta em tecido apodrecido, presa com pregos de ferro oxidado. Marcos a desenterrou, sacudiu a terra, e abriu a tampa.

Dentro, não havia ouro. Não havia tesouro. Havia ossos. Ossos pequenos, de criança, dispostos com cuidado, como se alguém tivesse arranjado as peças de um quebra-cabeça sagrado. E, entre os ossos, um objeto de metal, uma medalha ou um pingente, com uma gravação ilegível, coberta de ferrugem e de algo escuro que Marcos não quis identificar como sangue.

Ele fechou a caixa. Colocou-a de volta. Enterrou de novo. Cobriu com terra, pressionou com as mãos, saiu dali sem olhar para trás.

O padre estava esperando na porta da casa paroquial. Não perguntou o que Marcos tinha encontrado. Apenas disse:

— Agora elas sabem que você sabe.

Marcos saiu de Caxingó naquela mesma tarde. Dirigiu com os vidros fechados, o rádio desligado, os olhos na estrada e no retrovisor. No espelho, via apenas a poeira e o asfalto. Mas, quando parou para abastecer em uma cidade qualquer, antes de escurecer, olhou para o céu e viu uma luz dourada pairando acima do posto de gasolina, entre as bombas e o céu limpo do interior. Silenciosa. Dourada. Observando.

Ele entrou no carro, trancou as portas e não saiu mais até o dia seguinte.

O batatão não vem para avisar. Vem para marcar. E quem é marcado, cedo ou tarde, volta para o lugar onde enterrou o que não deveria ter desenterrado.

## Fontes de inspiração

- G1 / Globo — “Luzes são vistas no céu no interior de Pernambuco” (objetos não identificados, rastros de alta velocidade, rejeição de satélite/avião/balão).
- Agro em Campo — “Fogo-fátuo: a ciência por trás do mistério luminoso dos campos” (fenômeno do batatão no sertão, interpretação popular como presságio e sinal de tesouros enterrados).
- lugaresdememoria.com.br — “Barra do Guaicuí: uma mescla de História, Lendas e Literatura” (igrejas inacabadas, abandono, lendas de enchentes e tesouros nas ruínas).

*Nota: todos os nomes, locais e personagens são fictícios. A pesquisa serve apenas como inspiração atmosférica; a história é ficção.*
