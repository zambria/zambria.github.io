---
titulo: "A Segunda Camada"
resumo: "Em um abrigo-sob-rocha da Serra da Capivara, uma equipe de arqueologia descobre sobre a arte rupestre milenar uma camada de ocre que ninguém aplicou — figuras sem rosto que, depois de vistas, começam a percorrer os sonhos de quem as olhou."
categoria: "arqueologia"
data: "2026-11-21"
slug: "a-segunda-camada"
tipo: "ficcao"
fonte_pesquisa: "Parque Nacional Serra da Capivara (UNESCO/IPHAN), governo do Piauí, reportagens sobre o sítio"
---

# A Segunda Camada

O calor do sertão piauiense não chega sozinho. Traz o cheiro de pedra queimada, poeira fina e um silêncio que não é ausência de som, mas presença de algo que se recusa a responder. Foi nesse silêncio que a Dra. Marta Varella entrou, numa manhã de outubro, no abrigo-sob-rocha que sua equipe batizara, sem criatividade, de Toca do Sussurro — a quarenta minutos de caminhada de São Raimundo Nonato, porta de entrada do Parque Nacional da Serra da Capivara.

Marta não é dada a superstições. Passa a vida cavando o que outros enterraram, lendo estratos como quem lê registros de falência, e sabe que a arqueologia lida com ausências. Ainda assim, parou na entrada da toca e sentiu o peso de um olhar vindo da parede oposta. Não era o olhar de quem está ali. Era o de quem espera para ser pintado.

A Serra da Capivara guarda o maior e mais antigo conjunto de sítios pré-históricos das Américas. Criado em 1979, tombado pelo IPHAN em 1993 e declarado Patrimônio Cultural da Humanidade pela UNESCO em 1991, o parque reúne mais de mil sítios catalogados em cerca de 129 mil hectares de caatinga. Nos abrigos-sob-rocha, as pinturas rupestres datam, em parte, de 26.000 a 22.000 anos antes do presente — fragmentos de parede encontrados no Boqueirão da Pedra Furada —, enquanto a maior parte dos painéis, atribuídos às tradições Nordeste e Agreste, oscila entre 10.000 e 4.000 anos antes de agora. Cervídeos, humanos com braços erguidos, cenas de ritual, animais da fauna extinta: tudo ali foi registrado por gente que não nos deixou escrita, apenas pigmento sobre arenito.

Marta conhecia aquele painel. Em fotografias da FUNDHAM de 1978, a parede mostrava uma dança de figuras humanas em ocre vermelho, mãos no alto, corpos esbeltos no estilo Nordeste. Na manhã de outubro, sobre aquelas figuras milenares, havia uma segunda camada.

Não uma sobreposição descuidada. Não grafite de visitante. Um traço fino, ainda brilhante, de ocre que ninguém da equipe havia aplicado — a toca foi selada na véspera e só eles tinham acesso. As novas figuras são alongadas, sem traços faciais, sem mãos, dispostas em fila indiana, apontando com dedos afinados para o solo da toca. Respeitam o contorno das pinturas antigas como se as usassem de guia, como se alguém tivesse descido até ali para completar um trabalho interrompido há milênios.

Dra. Helena, a conservadora, retirou amostras. O laboratório não encontrou aglutinante orgânico suficiente para datação por carbono-14. O pigmento não se fixa em nenhuma escala conhecida. Parece, dizia Helena enquanto esfregava as luvas, como se a pedra tivesse suado ocre, como se a rocha estivesse exalando a imagem de dentro para fora, e não de fora para dentro.

Naquela noite, Marta sonhou com a procissão sem rosto descendo da parede e parando ao pé de seu colchonete. Leo, o assistente de campo, sonhou exatamente o mesmo — os mesmos dedos apontando para o chão, o mesmo cheiro de poeira quente. Helena acusou Marta de lhe ter contado o sonho antes dela contar; Marta não contou a ninguém. Elias, o guia de Coronel José Dias, recusou-se a voltar à toca no dia seguinte. "Essa pintura não foi feita por gente", disse. "Foi feita por algo que ainda não terminou de descer."

O que selou a decisão de Marta foi um documento no acervo da prefeitura de São Raimundo Nonato. Um relatório de 1943 de um geólogo do extinto DNPM que trabalhara na região: ele reportara que, em certo abrigo perto do Boqueirão da Pedra Furada, "as figuras nas paredes mudavam de posição entre o acender e o apagar da lamparina". O geólogo saiu de campo em junho de 1943 e nunca chegou a Teresina. O processo foi arquivado como "abandono de serviço". Nunca houve inquérito, nunca houve comunicado oficial, nunca houve corpo.

Na tarde seguinte, a equipe abriu um teste de sondagem de cinquenta centímetros na base da parede, exatamente onde as figuras sem rosto apontam. A terra estava compacta, inalterada por milênios. Aos oitenta centímetros, encontraram uma laje de arenito entalhada com o mesmo traço fino, quente demais para a hora da manhã, coberta por uma película de ocre ainda úmido. Algo fora selado de baixo para cima, e não ao contrário. Algo ficara embaixo, pressionando para subir.

Marta assinou o termo de encerramento de campo como "nenhum achado relevante". A toca foi refechada. O IPHAN nunca recebeu menção alguma. Helena pediu transferência para Recife. Leo desapareceu por dois dias; reapareceu no hostel sem falar, apenas desenhando em um caderno filas de figuras sem rosto com lápis de cor vermelha até romper a ponta. Marta não publicou nada. Sua carreira segue normalmente.

Três semanas depois, em seu apartamento no Recife, Marta acendeu a luz do quarto e parou. Na parede acima da cama, a tinta branca estava quebrada por uma mancha de ocre, ainda úmida ao cheiro, com traços finos que formam uma fila de figuras sem rosto apontando para o chão — a mesma fila da Toca do Sussurro, agora em sua parede, pintada de baixo para cima, como se algo estivesse subindo pelo gesso. Ela não ligou para o IPHAN. Não ligou para a universidade. Apagou a luz e observou, no escuro, a mancha crescer lentamente, um traço de cada vez, enquanto pensava na frase do geólogo de 1943: as figuras mudam de posição entre o acender e o apagar da lamparina.

Algumas camadas não devem ser raspadas. Não porque guardem tesouros, mas porque o que está embaixo ainda não terminou de vir à tona — e o silêncio oficial nunca foi prova de que nada aconteceu. Foi apenas a primeira camada do encobrimento.

## Fontes de inspiração

- Governo do Piauí — "Berço do homem americano: Serra da Capivara completa 47 anos como patrimônio mundial" (pi.gov.br): criação do parque em 1979, mais de mil sítios arqueológicos, patrimônio cultural piauiense.
- UNESCO — World Heritage List n° 606, Serra da Capivara National Park: abrigos-sob-rocha decorados, datações de 26.000 a 22.000 a.C., tradições Nordeste e Agreste de 10.000 a 4.000 a.C.
- Reportagens sobre São Raimundo Nonato e o Boqueirão da Pedra Furada (Aventuras na História e UAI): pinturas de mais de 25 mil anos, caatinga e sertão piauiense.

Todas as fontes serviram apenas de inspiração geográfica e histórica. A narrativa, os personagens e os fatos narrados são inteiramente fictícios.
