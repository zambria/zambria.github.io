---
titulo: "O Enterro que Não Acabou"
resumo: "No cemitério de um distrito mineiro, as sepulturas são encontradas abertas na manhã seguinte, os corpos reposicionados como se algo tivesse saído e voltado. O coveiro decide passar uma noite esperando para ver quem — ou o que — entra na terra."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "o-enterro-que-nao-acabou"
tipo: "ficcao"
fonte_pesquisa: "relatos de luzes misteriosas e folclore mineiro (Mãe do Ouro, bola de luz, serras de Minas Gerais) — opovo.com.br, g1.globo.com, correiodeminas.com.br
---

No distrito de Barra do Córrego, a algumas dezenas de quilômetros de qualquer cidade com nome em mapa, o cemitério é o único lugar que não fecha à noite. Não porque esteja aberto — não tem portão, nunca teve — mas porque ninguém consegue dizer, com certeza, onde termina o terreiro dos mortos e começa a mata. A grama cresce desigual, como se algo abaixo dela empurrasse a terra para cima em alguns pontos e a afundasse em outros. O cheiro é de umidade, cal viva e madeira apodrecendo, e à noite, depois das dez, o silêncio fica tão denso que o som do próprio fôlego parece uma invasão.

Antônio é o coveiro há trinta e dois anos. Enterrou pais, filhos e netos de famílias inteiras, e aprendeu que um buraco bem feito mede dois metros e setenta centímetros de profundidade, e que a terra deve ser devolvida em camadas, pisada com o calcanhar, para que o assento não afunde com as chuvas. Nunca viu nada como o que começou a aparecer nas manhãs de setembro.

Na primeira vez, ele achou que fora um descuido seu. A sepultura de Dona Alzira, fechada na véspera, estava aberta ao amanhecer. A tampa de madeira fora arrastada para o lado, não levantada — arrastada, com marcas no solo que não batiam com nenhuma ferramenta que ele possuísse. O caixão estava no lugar, mas a tampa dele fora deslizada uns dez centímetros, o suficiente para ver a face da morta, rígida e maquiada, com os olhos entreabertos como se estivesse observando algo acima do nível da terra. Nada fora roubado. Não havia pegadas. Não havia indício de que alguém tivesse descido ali e subido de volta.

Deveria ter sido um caso isolado. Não foi.

Na semana seguinte, a sepultura do velho Seu Benedito foi encontrada na mesma condição. Depois, a da menina de nove anos morta de febre. Depois, a de um viajante sem identidade enterrado às pressas. Sempre o mesmo padrão: a terra mexida, a tampa do caixão deslizada, o corpo reposicionado — braços cruzados sobre o peito, mãos sobre o abdômen, a cabeça levemente virada para a direita, como se estivesse ouvindo algo que só os mortos ouvem. Nenhum objeto faltava. Nenhum corpo desapareceu. Apenas foram tocados. Reacomodados. Recebidos.

A paróquia se recusou a abençoar as novas sepulturas. O padre disse que a terra do cemitério estava "pesada", que não assinaria atestado de sepultamento enquanto não houvesse uma explicação oficial. Não houve explicação oficial. O prefeito do município atribuiu o fenômeno a vandalismo de adolescentes e à umidade excessiva, e arquivou o assunto. Antônio não esperava outra coisa: no interior, quando o inexplicável bate à porta, as autoridades primeiro fingem que não ouvem, depois fecham a porta com chave. É mais barato do que investigar.

Antônio começou a passar as noites no cemitério. Leva uma lanterna de pilha fraca, uma garrafa de cachaça para não tremer de frio e um caderno onde anota a hora e a posição de cada sepultura. Na quarta vigília, às duas e dezessete da madrugada, ele ouve o som.

Não é um grito. Não é um choro. É um arrastar lento, contínuo, como se algo pesado e úmido estivesse sendo puxado pela terra, de baixo para cima, grão a grão. A lanterna treme na mão dele. Ele apaga a luz e espera no escuro, deitado entre duas sepulturas recentes, o ouvido colado ao chão.

Aí vem a luz.

Não é a bola de fogo que os mais antigos chamam de Mãe do Ouro, nem o relâmpago em forma de esfera que acompanha as tempestades de verão. É uma luz amarela, fraca, que se move entre as lápides sem projetar sombra, parando exatamente acima da sepultura da menina de nove anos. Ela fica ali, pairando, e então sobe — devagar, sem pressa — até ficar ao nível dos olhos de Antônio, que está deitado no chão. A luz não tem formato. Não tem fonte. Ela apenas está, e nela Antônio sente que algo está olhando para ele, não com curiosidade, mas com o reconhecimento de quem encontra um objeto que pertence a outro lugar.

Ele levanta. A luz se apaga. O som de arrastar para de repente, como se o que estivesse debaixo da terra tivesse percebido que ele está acordado.

No dia seguinte, Antônio abre a sepultura da menina. O caixão está fechado. A tampa de madeira, no lugar. Ele retira a tampa do caixão. A menina está ali, vestida com o mesmo vestido azul de algodão, os braços cruzados sobre o peito, as mãos sobre o abdômen, a cabeça levemente virada para a direita. Os olhos estão fechados agora. A pele está fria e branca, como deve estar. Nada está fora do lugar.

Exceto um detalhe: sob as unhas dela, há terra fresca. Terra do próprio cemitério, úmida, ainda com cheiro de chuvada recente. Terra que não podia estar ali, porque o caixão nunca foi aberto, porque a sepultura foi fechada por ele mesmo, de próprio punho, na tarde anterior.

Antônio fecha o caixão. Fecha a sepultura. Desliga a lanterna e senta numa lápide inclinada, esperando o amanhecer com a certeza fria de que algo ali embaixo não está morto — está apenas esperando que alguém, do lado de fora, decida desenterrá-lo.

Ele não conta para ninguém. No distrito, as pessoas já evitam o cemitério à noite. Dizem que, nas madrugadas sem lua, se vê uma luz amarela entre as lápides, e que, se escutar com atenção, ouve o som de algo sendo arrastado pela terra. Antônio não confirma nem nega. Ele apenas continua o trabalho: abrir, fechar, pisar a terra com o calcanhar, anotar no caderno.

Na última sexta-feira, ele enterrou a si mesmo no caderno. Não literalmente — ainda. Escreveu, de próprio punho: "Antônio Silva, coveiro, falecido em data a definir." Separou um terreno no canto esquerdo, perto da mata, onde a grama cresce mais alta e a terra afunda mais fácil. Cavou o buraco. Mediu dois metros e setenta centímetros. Está esperando.

A luz amarela volta todas as noites, um pouco mais perto. Cada vez, ela fica um pouco mais parada acima da sepultura que ele preparou para si. Antônio deita ali, entre os mortos que foram tocados, e observa o céu. Aqui em cima, o céu é apenas cenário. Aos poucos, ele está aprendendo que, embaixo da grama desigual do cemitério de Barra do Córrego, o céu deixou de ser cenário e se tornou palco. E o espetáculo não precisa de plateia. Só precisa de alguém que ainda não esteja deitado o suficiente.

## Fontes de inspiração

Relatos jornalísticos sobre luzes misteriosas no céu de Minas Gerais, incluindo o fenômeno conhecido como Mãe do Ouro e bolas de luz pairando sobre serras e plantações, além de registros do folclore regional sobre luzes noturnas e aparições. Fontes: opovo.com.br, g1.globo.com e correiodeminas.com.br. Todos os nomes, lugares e eventos da história são fictícios.
---
