---
titulo: "O Hóspede da Morgue"
resumo: "Na noite de 21 para 22 de janeiro de 1996, um auxiliar de serviços gerais do Hospital Humanitas, em Varginha, descobre que o quarto fechado sob guarda militar abriga algo que não consta em nenhum prontuário."
categoria: "criptozoologia"
data: "2026-11-21"
slug: "o-hospede-da-morgue"
tipo: "ficcao"
fonte_pesquisa: "Prefeitura de Varginha; Revista UFO"
---

# O Hóspede da Morgue

O corredor do terceiro andar do Hospital Humanitas cheirava a lixívia e a medo. Era o cheiro de sempre, de plantão noturno, mas naquela semana de janeiro de 1996 o medo vinha embrulhado em fita isolante e ordens de boca. Eu era auxiliar de serviços gerais, trinta e dois anos, insônia crônica e nenhuma ambição além de completar o mês sem levar advertência do supervisor. Minha função era simples: varrer, recolher lixo, lavar chão, não fazer perguntas. Na noite de 21 para 22 de janeiro, no entanto, o terceiro andar decidiu quebrar essa rotina.

Tudo começou com a fita. Fita isolante preta, grossa, colada nas dobradiças da porta do quarto 12 — uma sala de observação comum que, a partir da noite de 20 de janeiro, passou a figurar nos boletins internos como “ocupação especial”. Dois soldados do Exército ficaram de plantão do lado de fora, fuzis nos ombros, olhos fixos no nada. Nenhum médico entrava. Nenhum enfermeiro assinava prontuário. Apenas um macacão branco de proteção, deixado do lado de fora da porta como oferenda, e um número que ninguém pronunciava em voz alta.

Eu soube do que estava ali não por boato de corredor, mas por acaso. Fui chamado para limpar um vazamento no banheiro da sala ao lado, e a porta do quarto 12 estava entreaberta — apenas um palmo, o suficiente para o cheiro escapar. Não era cheiro de corpo morto. Não era cheiro de ferida gangrenada, de fezes ou de sangue velho. Era algo entre ozônio e carne molhada, um odor metálico que grudava no fundo da garganta e não saía nem depois de três goles de água da torneira do frasco de enxágue.

Olhei para dentro. Por três segundos — três segundos que depois me perseguiram em cada noite mal dormida — vi um corpo sobre a maca. Não era humano. Não exatamente. Tinha a pele cinzenta, fina como pergaminho velho, esticada sobre ossos que não batiam certo com a anatomia que eu conhecia de dois anos de curso de auxiliar de enfermagem abandonado antes de terminar. Os pés, o que consegui ver antes de fechar a porta com a mão trêmula, eram pequenos e deviam ter uma curvatura estranha, como se os ossos do tornozelo não pertencessem a esta parte do mundo. Não vi rosto. O lençol cobria a cabeça, e algo em mim agradeceu por isso.

Na manhã seguinte, o oficial responsável — um capitão de voz baixa que nunca tirou os óculos escuros, mesmo sob luz fluorescente — me abordou na recepção. Não disse meu nome. Não precisava. Disse apenas que o quarto 12 estava fora dos meus encargos, que eu não deveria passar por ali, e que qualquer coisa que eu tivesse visto, ou achado que viu, não existia. “Hospitais são lugares de histórias imaginárias”, disse, e sorriu com os lábios finos, sem mover o resto do rosto. Saí dali com o gosto de cobre na boca e a certeza de que acabara de assinar, sem saber, um termo de sigilo que não levei para casa.

O que se seguiu foram três dias de silêncio oficial. A imprensa local falava de morador estranho, de “Mudinho”, de garotas que viram coisas no mato. O Exército, quando finalmente falou, disse que nada havia acontecido. Os jornais de Brasília publicaram notas curtas sobre investigação concluída, caso encerrado, nenhuma prova. E eu continuava varrendo o terceiro andar, evitando o quarto 12, sentindo o cheiro de ozônio e carne molhada grudado nas minhas narinas como se o corredor inteiro estivesse contaminado.

Na noite de 22 para 23 de janeiro, entrei no quarto 12 sozinho.

Não sei por que fiz isso. Não foi coragem. Foi uma espécie de obrigação sombria, a necessidade de confirmar que não havia sonhado com aquilo, ou pior: a necessidade de confirmar que sonhar era a única explicação possível. A porta abriu sem resistência. A fita isolante havia sido removida. Os soldados tinham saído. A maca ainda estava ali, coberta pelo lençol branco, mas o corpo já não estava. Não havia mancha de sangue, não havia fluido, não havia marca de que algo tivesse sido transportado dali apressadamente. Apenas o lençol, amassado, como se algo tivesse se levantado e saído por conta própria.

Fiquei ali parado por tempo demais. Ouvi os passos de alguém vindo do fim do corredor — passos militares, pesados, ritmados — e saí de volta antes que me vissem. Na semana seguinte, pedi transferência para o turno da tarde. No mês seguinte, pedi demissão. Nunca mais trabalhei em hospital.

Passaram-se quase trinta anos. Nunca contei isso para ninguém, exceto agora, nestas linhas. Não porque me peçam provas — não tenho nenhuma. Não porque queira convencer — ninguém convence quem não quer ver. Conto porque, de vez em quando, ainda cheiro ozônio e carne molhada quando passo perto de um prédio abandonado à noite, e porque me pergunto o que fazem com quem volta. Ou com quem nunca deixou de estar aqui, apenas escondido atrás de uma porta fita isolante preta, sob a guarda de soldados que sabiam muito mais do que deixavam transparecer.

O Hospital Humanitas ainda funciona. O quarto 12 existe, com outro número, outra porta, outro lençol. E eu ainda me pergunto, em silêncio, se o que estava naquela maca morreu ali de verdade, ou se apenas esperou a hora certa de sair pela porta da frente, disfarçado de gente.

## Fontes de inspiração

- Prefeitura de Varginha — cronologia pública do episódio de 20 de janeiro de 1996 (capturas, transferências e destino das criaturas), disponível no portal oficial da prefeitura.
- Revista UFO — “Caso Varginha: 25 anos de investigações, mistérios e controvérsias”, sobre os depoimentos de militares no Hospital Humanitas e a conclusão oficial do Exército.

---

*Texto de ficção. Qualquer semelhança com pessoas, locais ou eventos reais é parcialmente intencional, mas a narrativa é uma recriação literária, não um relato documental.*
