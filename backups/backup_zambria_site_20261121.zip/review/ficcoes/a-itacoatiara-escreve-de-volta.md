---
titulo: "A Itacoatiara Escreve de Volta"
resumo: "Um documentador enviado para registrar os sulcos milenares da Pedra do Ingá encontra um signo novo na rocha — um que não estava lá antes, e que parece conhecer marcas do próprio corpo."
categoria: "arqueologia"
data: "2026-11-21"
slug: "a-itacoatiara-escreve-de-volta"
tipo: "ficcao"
fonte_pesquisa: "Wikipedia — Pedra do Ingá; G1/Globo Reporter — inscrições misteriosas da Pedra do Ingá
---

O paredão tem quarenta e seis metros de comprimento por três metros de altura. É de gnaisse, cinza, com bordas lascadas pelo tempo, e fica à margem do rio Bacamarte, no agreste da Paraíba, oitenta e cinco quilômetros de João Pessoa. Ninguém sabe ao certo quem riscou ali aqueles sulcos em baixo-relevo — se povos originários há seis mil anos, navegadores fenícios desorientados ou qualquer outra hipótese que preenche o silêncio com certeza. O que importa é que as marcas não dizem nada a quem as lê hoje. São um enigma de pedra, e um enigma não exige acreditar; exige apenas que alguém continue olhando.

Eu fui esse alguém. Cheguei ao fim de uma tarde de outubro, contratado para atualizar o laudo fotogramétrico da itacoatiara, com o registro de 2024 como referência. O calor vinha do chão e do céu ao mesmo tempo, e o ar cheirava a umidade e pedra quente. Um guia local me mostrou onde estacionar, disse que a pedra não gosta de ser medida, e saiu rindo. Levei a sério o suficiente para não rir de volta.

Nos dois primeiros dias, tudo conferiu. Sobrepunha as fotos do presente às de dois anos atrás — as mesmas espirais, as mesmas figuras que lembram seres humanos com braços erguidos, as mesmas estrelas que ninguém consegue datar. O software apontava diferença zero fora da variação de iluminação. Até que, na terceira manhã, revendo a seção do lado direito do painel, encontrei um sulco fino de cerca de doze centímetros que não existia no registro anterior. Não havia lascas no solo, nem poeira recente, nem marca de ferramenta. O traço parecia simplesmente ter aparecido, como se a rocha tivesse decidido riscar a si mesma durante a noite.

Voltei no dia seguinte na mesma hora. O glifo estava lá, idêntico. Fotografava a mesma seção de hora em hora, comparava no laptop, ajustava exposição. O sulco persistia. Na quinta manhã, um segundo traço novo apareceu, maior, na parte central do paredão, abaixo de uma das figuras humanas esculpidas. Tinha doze centímetros de comprimento, uma linha quase reta com uma ponta arredondada — exatamente a forma e a proporção da cicatriz que tenho no antebraço esquerdo, uma queimadura de infância que nunca contei a ninguém e que não consta em nenhum documento meu.

A partir daí, a documentação virou obsessão. Parei de anotar em papel; passei a gravar tudo em áudio, com medo de que o próprio ato de escrever pudesse ser lido de volta pela pedra. Evitei olhar diretamente para o paredão. Usava a visão periférica, espelhos de mão, câmeras com o obturador fechado entre os disparos. Nos dias em que precisei ficar perto, sentia os sulcos se moverem quando não olhava diretamente — ilusão de cansaço, dizia a mim mesmo, até não conseguir mais dizer.

Os outros pesquisadores da equipe não viram nada. Para eles, a pedra continuava a mesma de sempre: inerte, milenar, sem significado. E é exatamente nessa inércia que residia o horror. A pedra não precisava correr nem gritar. Ela só precisava ser observada. Cada olhar, cada fotografia, cada medição era um registro que ela poderia incorporar. Comecei a sonhar com sulcos na própria pele. Acordava com a sensação de que algo estava sendo gravado em mim enquanto dormia, algo que ainda não sabia ler.

No oitavo dia cancelei o laudo. Recusei-me a entregar as fotos. Pedi transferência.

Na última noite, antes de ir embora, voltei sozinho ao paredão com uma lanterna. Apaguei todas as luzes do acampamento e projetei o feixe contra a rocha. Na sombra do meu próprio corpo, o contorno do perfil coincide exatamente com um sulco que não estava lá na semana passada — ainda raso, ainda úmido de poeira fina, esperando ser aprofundado pelo próximo observador. Desliguei a lanterna e saí andando, sem olhar para trás.

A Pedra do Ingá continua ali, quarenta e seis metros de paciência, e o tempo dela não é o nosso. O laudo nunca será concluído. Não porque se perdeu, mas porque cada versão dele já está gravada em algum lugar que não perdoa apagamentos.

## Fontes de inspiração
- Wikipedia, "Pedra do Ingá" — monumento arqueológico de inscrições rupestres em Ingá, Paraíba, com painel de aproximadamente 46 metros por 3 metros e signos de significado desconhecido, objeto de teorias que vão de povos originários a navegações fenícias.
- G1 / Globo Reporter, "A pedra com inscrições misteriosas que até hoje intrigam cientistas" — inscrições notadas por colonizadores no século 18, atribuídas a povos originários há cerca de seis mil anos, com estrelas, espirais e figuras sem interpretação conclusiva.
