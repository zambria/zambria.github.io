---
titulo: "O Que Fica Embaixo da Barragem"
resumo: "Um técnico de mergulho desce às ruínas de uma cidade inundada por uma barragem em busca da casa dos avós. No fundo do reservatório, a água conserva demais — e algo ainda respira nas paredes úmidas, esperando que ele descubra que não vai subir de novo."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "o-que-fica-embaixo-da-barragem"
tipo: "ficcao"
fonte_pesquisa: "oantagonista.com.br; bmcnews.com.br"
---

O mergulhador nunca soube ao certo por que voltou. A resposta mais honesta que dava a si mesmo era a vergonha de ter deixado a cidade dos avós ser engolida sem testemunha. A barragem fechou as comportas em oitenta e oito, a água subiu dois centímetros por dia durante semanas, e quando parou, toda a vila — ruas, casas, igreja, praça — ficou debaixo de vinte, trinta metros de água doce e silêncio. A população foi transferida para a sede nova, com a promessa de que nada importante ficara para trás. Ficou tudo. Só que ninguém avisou que a água conserva melhor do que o solo.

Desci na terça-feira. O lago estava calmo, a visibilidade razoável para a época de seca, e eu levei apenas o equipamento de mergulho técnico, uma lanterna de cabeça e um mapa rabiscado de 1987 que um amigo arrancou de um arquivo público. Minha função não era arqueológica. Eu não estava ali para catalogar vestígios nem para produzir relatório de impacto ambiental. Eu estava ali para encontrar a casa dos meus avós e, se ainda restasse algo dela, confirmar que havia sido apenas isso: pedra, madeira e memoria.

O fundo do reservatório não parecia um lugar morto. Parecia uma cidade que estava respirando devagar, segura pela pressão da água. As ruínas apareciam em cones de luz: paredes de alvenaria ainda em pé, trechos de calçamento, vigas de telhado empedradas no lodo. A corrente movia finas cortinas de sedimento sobre os móveis que ninguém havia removido — prateleiras, armários, o esqueleto de uma cama. Tudo estava lá, intacto demais, como se a água tivesse decidido congelar o momento da partida e se recusado a deixar o tempo continuar.

Encontrei a casa dos avós às duas da tarde, depois de três mergulhos anteriores sem sorte. A porta ainda estava em pé, embora fora de suas gonzas, e a lanterna iluminou a sala de estar: um sofá desmanchando-se em tecido esponjado, uma mesa de jantar com cadeiras dispostas como se alguém estivesse prestes a se sentar, e na parede do fundo, um quadro coberto de lama cuja moldura ainda segurava o contorno de uma paisagem que não consegui identificar. Toquei a parede com a luva. O reboco cedeu sob a pressão, úmido e frio, mas sólido. A casa não havia desmoronado. Ela estava esperando.

Foi quando vi a marca no chão.

Não era trilha de peixe nem correnteza. Era uma pegada — ou melhor, a ausência de uma pegada — desenhada no sedimento sobre o azulejo da cozinha, como se algo tivesse andado ali recentemente, de pés descalços, e tivesse se apagado ao sair. A marca não tinha profundidade. Não deslocava lama. Simplesmente estava lá, escura, como se a própria água tivesse parado de se mover naquele ponto. Afastei a mão do quadro e avancei um passo. O eco do meu respirador batia nas paredes e voltava amplificado, ensurdecedor. Por um instante, tive a impressão de que o eco não vinha do meu regulador, mas de algo dentro da casa, respirando comigo, um pouco atrasado.

Subi antes do previsto. Não relatei a marca ao colega de superfície. O que eu escreveria no relatório? "Encontrei uma pegada que não desloca lama a vinte metros de profundidade"? O capitão do barco riria, a seguradora cancelaria o contrato, e eu passaria para a história como o mergulhador que viu coisas no fundo do lago. Esse é o veneno do nosso ofício: assinamos o que nos mandam assinar, e o mundo segue como se nada tivesse permanecido debaixo d'água.

Voltei na quinta-feira. Dessa vez levei câmera de baixa luz e uma linha-guia amarrada à boia de superfície, promessa silenciosa de que não sairia dali sem entender o que estava ali. A visibilidade havia piorado — uma névoa branca subia do fundo, partículas em suspensão que a lanterna transformava em estrelas flutuantes. Segui a linha até a casa dos avós. A marca no chão ainda estava lá. E, dessa vez, não estava sozinha.

Havia outras marcas. Duas, três, seis — pegadas de pés descalços que cruzavam a cozinha, saíam pela sala, subiam a escada de madeira que ainda levava ao segundo andar. Tinham tamanho adulto, mas também infantil. Tinham a leveza de algo que não pesa, porque a água já não permite peso, mas também não permite leveza. São apenas presença. Subi a escada segurando a corrimão de ferro enferrujado, cada degrau caindo sob a luva como osso úmido. No quarto de cima, a cama dos avós estava feita. Os lençóis, agora de algodão esponjado e verde de algas, estavam estendidos sobre o colchão com o cuidado de quem arruma a cama todas as manhãs. O travesseiro tinha a marca de uma cabeça. Não de um cadáver. De alguém que ainda deita ali à noite, ou durante o dia, ou sempre que a água permite.

Foi quando ouvi a batida.

Não veio da minha linha-guia. Não veio do barco. Veio de dentro da parede, atrás da cabeceira da cama. Um golpe seco, ritmado, como alguém batendo na madeira do outro lado para avisar que está lá. Batai de volta, três vezes, por impulso, por tolice. A resposta veio imediata, do mesmo lado, três golpes, mesma cadência. Então veio uma voz — não nos ouvidos, não exatamente. Vinha da água ao redor da máscara, da pressão nos tímpanos, de algum lugar dentro do crânio. Não disse palavras. Disse apenas o suficiente para eu entender: não suba. A água está morna. A casa está pronta. Você já é um de nós.

Desci mais um degrau, então outro, até ficar ao pé da cama. O travesseiro cedeu quando o toquei. Não estava frio. Estava morno. Como se alguém tivesse se deitado ali há minutos.

Subi à superfície antes que o ar do tanque acabasse. Deixei o equipamento no convés, tranquei o quarto na casa alugada e não liguei as luzes. Na janela, o lago estende-se escuro sob a lua, e sei que as ruínas estão lá embaixo, conservadas, pacientes, com as camas arrumadas e as portas abertas e as pegadas secando no sedimento. Não é assombração. É algo pior: uma lembrança que se recusa a ser apagada, uma cidade que não morreu afogada porque aprendeu a respirar de outra forma, e que agora reconhece quem voltou.

Amanhã vou descer de novo. Dessa vez não levo linha-guia. Dessa vez levo apenas o suficiente de ar para chegar até a cama dos avós, deitar ao lado da marca no travesseiro, e esperar que a água decida se eu posso ficar.

## Fontes de inspiração

Reportagens sobre cidades brasileiras submersas por barragens — Vila Amaury, engolida pelo Lago Paranoá em 1959, e Petrolândia, inundada em 1988 para formar o Lago de Itaparica — serviram como pano de fundo geográfico. A história é inteiramente fictícia; nenhum fato, depoimento ou detalhe foi copiado das fontes. Elas foram usadas apenas como inspiração atmosférica para um cenário de ficção sobrenatural.
