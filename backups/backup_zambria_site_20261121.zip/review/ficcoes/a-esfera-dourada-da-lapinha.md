---
titulo: "A Esfera Dourada da Lapinha"
resumo: "Um documentarista freelance viaja a Santana do Riacho, Minas Gerais, para filmar as bolas de fogo que, dizem, brotam das paredes de calcário de Lapinha. O que a esfera dourada esconde dentro da galeria abandonada da mina não é ouro — e não perdoa quem a segue."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "a-esfera-dourada-da-lapinha"
tipo: "ficcao"
fonte_pesquisa: "Em.com.br — O chão que grita e a santa que caminha: os mistérios subterrâneos de Minas; Em.com.br — Mistério da bola de ouro que ilumina as noites intriga povoado de Minas"
---

Cheguei a Lapinha no fim da tarde, quando o sol já não queimava as paredes de calcário do distrito de Santana do Riacho, no interior de Minas Gerais. A pousada era uma casa branca de um só andar, com janelas de grade e um cachorro que não latia. O dono, um homem chamado Marcelo com as mãos ressecadas de cal, entregou a chave sem olhar para minha câmera.

— Não saia depois do escuro com o equipamento ligado — disse. E nada mais.

Não conhecia Marcelo. Não conhecia ninguém ali. Havia sido contratado por uma produtora de streaming de orçamento inconfessável para gravar um curta sobre as "bolas de fogo" de Lapinha — globos luminosos que, segundo moradores, cruzam as falhas de quartzo nas noites de baixa umidade, flashes silenciosos que parecem brotar da rocha. A ciência chama o fenômeno de piezoeletricidade. Os moradores chamam de outra coisa. Fui para descobrir qual das duas versões era menos mentira. A produtora queria imagens bonitas e um pouco de mistério embalado; eu queria um pagamento que não dependesse de edição criativa.

No dia seguinte, antes do almoço, conheci o senhor Cardoso, aposentado da CPRM, que passou trinta anos mapeando falhas geológicas na região. Sentou-se comigo na varanda de concreto, fumou um cigarro e explicou com paciência de professor: sob pressão mecânica ou térmica, os cristais de quartzo do maciço liberam descargas elétricas que ionizam o ar. Globos, faíscas, relâmpagos silenciosos. Fenômeno real, raro, documentado. Não há mistério, disse, apenas física de rocha.

— A pedra geme quando é espremida — resumiu.

Fui até a saída da galeria abandonada, uma boca de mina de prospecção desativada desde os anos setenta, quando a empresa que procurava ouro aqui sumiu junto com os equipamentos, os arquivos e, dizem, parte dos funcionários. O mato havia retomado a entrada, mas a placa de ferro enferrujada ainda apontava para o buraco. Gravei relâmpagos silenciosos estalando nas paredes durante o crepúsculo — faíscas azuis que nasciam e morriam sem trovão. Bonito, inofensivo, explicável. A produtora vai adorar, pensei.

Mais tarde, na única mercearia do distrito, Dona Alzira me viu com a câmera e mudou de assunto três vezes antes de falar:

— Aquela luz não é pedra gemendo, moço. É a Mãe do Ouro. Ela mostra onde está o metal, mas cobra o preço em gente. Quem segue, não volta igual. Ou não volta.

Sorri. A velha costumava deixar feitiço na porta de quem não acredita, segundo os vizinhos. Voltei para a pousada com a história de mais um morador e o trabalho quase pronto.

À noite, a esfera apareceu.

Não foi um relâmpago. Não nasceu da parede nem morreu no ar. Desceu sozinha sobre o mato, uma bola de ouro opaco do tamanho de uma cabeça humana, pairando a meio metro do chão, movendo-se com a lentidão de quem examina algo. Não fazia barulho. Não projetava sombra. Liguei a câmera. A esfera parou, como se sentisse a luz do visor, e então se dirigiu à entrada da galeria. Deslizou para dentro da escuridão da mina, devagar, como quem convida.

Fui atrás.

O interior cheirava a umidade e a ferro velho. Minha lanterna cobria dois metros à frente, não mais. O chão de terra batida cedia sob as botas. Cada passo ecoava de volta atrasado, como se a galeria devolvesse o som depois de pensar. A esfera estava à frente, sempre à mesma distância, flutuando sobre um curso d'água que não existia no mapa — ou existira, antes da mina ser selada.

Em certo ponto, o túnel se abriu em uma câmara pequena. A esfera parou no centro, imóvel, e a luz dela passou a piscar no ritmo de uma respiração. Liguei o zoom. Foi aí que percebi: dentro da esfera não havia luz. Havia um reflexo. Meu reflexo. Eu estava filmando a mim mesmo parado do lado de fora da galeria, de costas, segurando a câmera, enquanto meu corpo aqui dentro nunca se mexera.

Desliguei tudo. A escuridão que ficou não era ausência de luz. Era presença.

Corri. O eco dos meus passos tornou-se múltiplo, vozes atrás de vozes, e quando saí correndo pelo mato a esfera já subira sobre as paredes de calcário, juntando-se aos relâmpagos silenciosos da noite. Marcelo estava na varanda da pousada, acendendo um cigarro.

— Viu? — perguntou, sem se voltar.

— O que é aquilo? — perguntei.

— Não é o que é. É o que quer. A luz não é o fenômeno, rapaz. A luz é a isca.

No dia seguinte, a produtora cancelou o contrato por e-mail. As imagens da noite estavam corrompidas — todos os arquivos, exceto um único quadro. Nesse quadro, a esfera dourada paira sobre a entrada da galeria, e no reflexo bruto da lente, algo escuro se aproxima de mim por trás, com as mãos sobre meus ombros.

Não saio depois do escuro com o equipamento ligado. Marcelo não me disse por quê, mas agora eu sei: algumas luzes não iluminam nada. Apenas mostram onde você fica melhor para ser visto.

## Fontes de inspiração

- Em.com.br, "O chão que grita e a santa que caminha: os mistérios subterrâneos de Minas" — relatos de bolas de fogo sobre paredões de calcário em Lapinha, Santana do Riacho, e a explicação geológica do piezoeletricismo.
- Em.com.br, "Mistério da bola de ouro, que ilumina as noites, intriga povoado de Minas" — o folclore da Mãe do Ouro como esfera luminosa que sinaliza jazidas e suas consequências para quem a procura.
