---
titulo: "O Último Apito de Monte Santo"
resumo: "Um homem retorna à estação ferroviária desativada de Monte Santo de Minas para entender o trem que seu avô conduziu em dezembro de 1984 e nunca chegou a lugar nenhum. Nas ruínas sem trilhos, ele descobre que o silêncio oficial escondia algo muito mais antigo do que a economia."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-ultimo-apito-de-monte-santo"
tipo: "ficcao"
fonte_pesquisa: "Folha de S.Paulo (blog Sobre Trilhos), Vitruvius/Arquiteturismo, Wikipedia (Estação Pedra Mole)"
---

Monte Santo de Minas fica a 432 quilômetros de Belo Horizonte, e hoje a cidade se resume a três coisas: café, mato alto e uma estação de trem sem trilhos. Cheguei pouco depois do pôr do sol, com o motor do carro ainda quente no silêncio de um município que não sabe mais o que fazer com a própria memória. A fachada restaurada ostenta agora o nome de Estação Cultura Maria Batista de Oliveira. Foram investidos R$ 1,43 milhão para transformar a ruína em salas de oficina, salas de aula e um anfiteatro. Tudo muito bonito. Tudo deserto à noite.

Eu não fui pelas oficinas. Fui porque meu avô, Carlos Eduardo Moraes, foi maquinista da Companhia Mogiana de Estrada de Ferro, e porque em dezembro de 1984 ele apitou uma última vez numa composição que partiu de Monte Santo, passou por uma ponte sobre a qual ninguém mais quis falar, e nunca chegou a lugar algum. Pelo menos não voltou. A versão oficial fala de encerramento de ramais, de ônibus mais baratos, de progresso. Minha versão é mais simples: alguma coisa saiu da estação naquela noite, e alguma coisa ficou.

A estação foi inaugurada em 1913, no auge do ramal de Passos, para escoar o café das fazendas da região até o porto de Santos. Recebeu passageiros até 1976; cargas passaram por ali até o início dos anos 1990, quando os trilhos foram retirados e a linha decretada morta. Nos anos 80 o prédio abrigou uma escola. Depois virou depósito, depois lixo, depois esquecimento. Até a restauração de dois anos atrás, quando a memória local foi pintada de cores originais e entregue ao artesanato.

É engraçado como as cidades tratam o luto. Tiraram os trilhos porque deixaram de dar lucro, dizem. Eu duvido. Trilho não se tira porque o comércio mudou; se tira trilho quando se quer enterrar algo debaixo do leito férreo e garantir que ninguém, jamais, volte a passar por ali.

Meu avô não era um nome da lista oficial. No documento que consultei sobre a estação Aureliano Mourão — outra ponta da mesma malha esquecida da Estrada de Ferro Oeste de Minas — o último trem de dezembro de 1984 saiu sob o comando do ferroviário Francisco Marques Sobrinho, com os maquinistas Carlos Alberto e Luis Henrique, apelido Mamão. Ainda se conta, naquela região, sobre uma ponte pavorosa na qual vagões e passageiros jamais foram vistos novamente. O trem do meu avô não constava desse papel. Constava apenas de uma folha amarelada que ele deixou em casa, com a hora, o número da composição e uma única frase sublinhada a lápis: "eles não queriam o café". Eu tinha dez anos quando ele desapareceu. Vinte quando decidi que precisava ver Monte Santo com meus próprios olhos.

Desci do carro com uma lanterna e um caderno. A plataforma está lá ainda, de concreto rachado, coberta por trepadeiras que sobem pelas paredes como se quisessem puxar o prédio de volta para a terra. O cheiro é de umidade antiga, de gesso moído e de algo mais doce, como carne deixada demais no sol. Caminhei pelo leito onde os trilhos ficavam. Não há mais aço, apenas sulcos no chão, travessas apodrecidas e o silêncio denso de um lugar que aprendeu a não responder.

Dei passos lentos. Cada um produzia um eco que voltava um pouco atrasado, como se a estação estivesse ouvindo com atraso. Do fundo do poço — se é que há um poço sob essa plataforma — parecia vir uma observação paciente. Não digo isso no sentido romântico de que o lugar está assombrado. Digo no sentido de que algo ali me via, e sabia exatamente por que eu havia voltado.

Ao pé da plataforma, sob uma tábua solta, encontrei uma caixa de lata de óleo, enferrujada, com o brasão da Mogiana. Dentro: um relógio de parada parado às 23h17, um crachá com o nome Carlos Eduardo Moraes e uma lista de nomes escrita à mão, em letra trêmula. Não eram passageiros. Eram coisas, ou pessoas reduzidas a coisas. Cada linha trazia um nome, um peso em quilogramas e um destino: "para a ponte", "para o fundo", "para o que espera". Meu avô não era passageiro. Ele era o que levava a carga.

Foi então que ouvi o apito.

Não foi um som de metal sobre metal — não há mais trilhos em Monte Santo. Foi um som de garganta, longo e rouco, vindo de debaixo do chão, do leito vazio onde os trilhos foram arrancados. As luzes da estação piscaram uma vez, duas. Não há fiação funcionando ali desde a restauração; confirmei. E mesmo assim, por um instante, vi luzes sobre o leito vazio: dois faróis baixos, paralelos, avançando sobre o mato e o concreto quebrado numa linha que não existe mais.

Ouvi o nome do meu avô chamado pela lista. Não em voz alta. No papel, ao lado do nome dele, o peso havia mudado. Agora havia um número novo, escrito a tinta fresca: o meu.

Entendi, então, por que os trilhos foram retirados. Não para impedir que o trem passasse. Para que ninguém saísse da estação sozinho. Para que a carga não escapasse antes da hora. O encerramento oficial, o investimento em cultura, as oficinas de artesanato — tudo isso é boas-vindas para quem chega, e um caixão fechado para quem tenta sair.

Fiquei parado no leito vazio, com a lista na mão e o apito cada vez mais perto, vindo de nenhum lugar. Não corria. Não adiantaria correr sobre trilhos que não existem para um trem que não aparece nos horários. O silêncio oficial de Monte Santo nunca foi sobre economia. Era sobre o que ainda desce pela linha, sobre o que ainda espera na ponte, e sobre o que acontece com quem volta para procurar resposta.

O próximo apito será meu. E quando o trem passar — sobre o leito vazio, sob a plataforma restaurada, no silêncio da cultura oficial —, alguém lerá meu nome em uma lista trêmula e marcará ao lado: entregue.

## Fontes de inspiração

- Folha de S.Paulo, blog Sobre Trilhos: estação de Monte Santo de Minas, inaugurada em 1913, ponto do ramal de Passos da Estrada de Ferro Mogiana; desativada para passageiros em 1976, com trilhos removidos nos anos 1990 e restaurada como espaço cultural com investimento de R$ 1,43 milhão.
- Vitruvius/Arquiteturismo: Estação Aureliano Mourão, Estrada de Ferro Oeste de Minas; último trem em dezembro de 1984 sob comando de Francisco Marques Sobrinho, Carlos Alberto e Luis Henrique (Mamão); relato de ponte onde vagões e passageiros jamais foram encontrados.
- Wikipedia: Estação Pedra Mole, Ipatinga, MG; desativada após cerca de oito anos por solo instável e doenças tropicais; área usada como cemitério até 1942.

Todas as fontes acima serviram apenas como inspiração de cenário e contexto histórico. Os personagens, os eventos e a narrativa são inteiramente fictícios.
