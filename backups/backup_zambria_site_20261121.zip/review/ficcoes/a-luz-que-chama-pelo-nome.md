---
titulo: "A Luz que Chama pelo Nome"
resumo: "No brejo às margens do rio, luzes flutuantes surgem todas as noites e chamam os moradores pelo nome. A ciência chama de fogo-fátuo; quem vive ali chama de convite."
categoria: "fenomenos-naturais"
data: "2026-11-20"
slug: "a-luz-que-chama-pelo-nome"
tipo: "ficcao"
fonte_pesquisa: "IG Agro em Campo (fogo-fátuo: decomposição de matéria orgânica, gases de metano, fosfina e difosfano) e Futura Sciences (hipóteses de origem dos fogos-fátuos; ausência de explicação única e definitiva)
---
# A Luz que Chama pelo Nome

O brejo não dorme. Ele segura a respiração, e quando solta, o ar sai cheiroso de matéria podre, água parada e algo entre enxofre e flor molhada. Rio Fundo é um nome que inventei para o lugar, mas ele existe em dezenas de cópias pelo delta do Amazonas, à beira de igarapés que ninguém mapeia direito, onde a lama engole botina e o céu aparece só em pedaços entre as copas das árvores. Ali todo mundo conhece a regra desde criança: se uma luz flutuante chamar seu nome à noite, você não responde. Não olha. Não se aproxima. E nunca sai de barco sozinho depois do anoitecer.

Eu quebrei as três regras. Não por crença. Por raiva.

Meu irmão sumiu no brejo em 2019. Vinte e três anos. Saiu de casa numa quinta-feira dizendo que ia fotografar as luzes, e não voltou. A polícia encontrou a mochila perto de um igarapé, a câmera dentro, e a última foto: uma chama laranja sobre a água, sem fonte, sem trilho, sem nada ao redor que justificasse o clarão. O laudo falou em afogamento acidental. Não havia corpo. Não havia processo. Havia um relatório arquivado, e o silêncio pesado de quem prefere não investigar o que o brejo devolve — ou não devolve.

A ciência tem uma explicação pronta, limpa e seca, do tipo que acalma leitores de jornal no café da manhã: decomposição anaeróbica de matéria orgânica em ambientes pobres em oxigênio libera gases como metano e fosfina, que ao entrar em contato com o ar podem se inflamar sozinhos, criando pequenas chamas azuladas que dançam sobre pântanos, brejos, cemitérios velhos. Chama-se fogo-fátuo. Will-o'-the-wisp. Nome bonito para um fenômeno que ninguém consegue reproduzir em laboratório com certeza absoluta — porque a ignição espontânea do metano em condições ambientais é improvável, porque algumas luzes parecem se mover com intenção, porque várias observações relatam ausência de calor. As hipóteses se multiplicam: microdescargas elétricas entre bolhas de gás, bioluminescência de fungos, reflexos ópticos, ilusão de movimento criada pelo ar deslocado por quem caminha perto. Tradução honesta: ninguém sabe ao certo, mas todo mundo prefere acreditar que é apenas gás. Gás é inofensivo. Gás não escolhe vítima.

Gás não chama pelo nome. Gás não imita a voz do irmão.

Dona Lourdes, que mora na última casa antes do igarapé, diz que a luz não queima, não assusta, não persegue: ela convida. Seu marido seguiu uma delas em 1984 e voltou três dias depois, a cinco quilômetros de onde entrou, descalço, com a roupa intacta e a pele tão branca que parecia papel de embrulho. Não falou nunca mais. Morreu dois anos depois de uma febre que nenhum médico de Belém soube nomear. Lourdes ainda acende um lampião na janela todas as noites, não para espantar a luz, mas para que ela, se vier, saiba que alguém está olhando de volta.

Voltei para Rio Fundo dois anos depois do sumiço. Aluguei um barco de alumínio, levei lanterna, gravador, faca de cabo de madeira. Não levei bom senso. Na terceira noite, vi a luz. Não era a dançarina azulada dos livros de ciência. Era maior, branca, quase estática, pairando a pouco menos de dois metros da superfície do igarapé, sem projetar sombra — luz que vem de todos os lados ao mesmo tempo, portanto de nenhum lugar. E então ela chamou.

Não foi em português correto. Foi com a voz do meu irmão, com o tom dele, com aquela risada na última sílaba que só ele tinha. Veio da luz, ou do brejo atrás da luz, ou da minha cabeça — nunca saberei com certeza, e essa é exatamente a espécie de dúvida que te mata aos poucos. "Vem," ela disse, ou algo parecido. "Vem ver o que fica embaixo."

Não fui. Gravei. A luz aproximou devagar, sem deixar rastro na água. Os grilos pararam. A água parou de fazer barulho. O brejo segurou a respiração e não soltou mais. Quando a luz se afastou, voltando em direção à mata alagada, minha lanterna não acendia mais, o gravador tinha registrado apenas silêncio, e do outro lado do igarapé, entre troncos submersos, algo se moveu com a passada de quem anda descalço sobre lama — mas sem afundar. Sem deixar marca.

Voltei para a cidade no dia seguinte. Não contei o que vi. O que conto agora é isto: as luzes continuam lá, toda noite, chamando. A ciência chama de gás. Os moradores chamam de ilusão. E ninguém para de caminhar perto da beira do brejo depois do anoitecer porque todo mundo acha que é imune enquanto não ouvir o próprio nome saindo de uma chama que não projeta sombra. Meu irmão não voltou. Talvez nunca tenha sido levado. Talvez tenha apenas respondido, e a luz tenha ficado com a voz dele para chamar o próximo.

## Fontes de inspiração
- IG Agro em Campo — "Fogo-fátuo: a ciência por trás do mistério luminoso dos campos" (decomposição anaeróbica de matéria orgânica, liberação de metano, fosfina e difosfano, ignição espontânea em áreas pantanosas, brejos e cemitérios).
- Futura Sciences — "De onde vêm os misteriosos fogos-fátuos? A ciência explica este fenômeno" (hipóteses de origem: gases de pântano, fosfina, difosfano, microdescargas elétricas, bioluminescência; ausência de uma explicação única e definitiva para todos os relatos).
