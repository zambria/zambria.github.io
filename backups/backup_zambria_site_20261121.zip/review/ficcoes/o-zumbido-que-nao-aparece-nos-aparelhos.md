---
titulo: "O Zumbido que Não Aparece nos Aparelhos"
resumo: "Em um vilarejo do sertão pernambucano, uma minoria de moradores começa a ouvir um zumbido grave de origem desconhecida, inaudível para todos os outros e inexistente para os equipamentos de medição. O silêncio oficial só torna o som mais alto."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-zumbido-que-nao-aparece-nos-aparelhos"
tipo: "ficcao"
fonte_pesquisa: "em.com.br; terra.com.br; olhar digital.com.br
---

No vilarejo de Riacho Seco, a noite não chega em silêncio. Chega carregada de um zumbido grave, contínuo, parecido com o motor de um caminhão velho parado a quilômetros de distância, ou com o baixo distante de uma festa que ninguém mais ouve. José Almeida, professor de história de quarenta e três anos, é um dos poucos que o ouvem. Ouviu pela primeira vez numa quarta-feira de outubro, deitado na cama, janela fechada, o cessete do abafador de poeira desligado há horas. O som não vinha de fora — não exatamente. Vinha de algum lugar entre o ouvido e o pensamento, grave o suficiente para vibrar nas costas e agudo o bastante para impedir o sono.

Nas semanas seguintes, o zumbido se instalou. Não se trata de um barulho de rua, de trator ou de gerador. Moradores de Riacho Seco, em sua maioria lavradores e feirantes, juram que nada há de errado com o silêncio da noite. Cães não latem. Galinhas não se agitam. O vento no carnaubeira continua o mesmo de sempre. E, no entanto, José e mais quatro ou cinco pessoas da vila — a dona de um mercadinho, um pedreiro aposentado, uma professora de escola primária — relatam a mesma coisa: um zumbido de baixa frequência, mais forte dentro de casa, especialmente à noite, impossível de localizar e, o pior, impossível de provar.

José foi ao posto de saúde. O médico, um jovem recém-formado de Petrolina que passava quinze dias por ali, examinou os ouvidos com um otoscópio de bateria fraca e disse que não havia cera, não havia infecção, não havia nada. Sugeriu repouso e um chá de erva-cidreira. José saiu da consulta com a sensação de que o médico o havia acreditado até a porta da sala, e parado de acreditar logo em seguida.

Procurou o filho de um parente que tinha um celular com aplicativo de decibelímetro. Ficaram em pé na varanda à meia-noite, o aparelho apontado para o céu escuro do sertão. O marcador não saiu dos trinta decibéis — o ruído de fundo de um quarto silencioso. O zumbido, para José, soava como um trem subterrâneo passando sob os pés. Para o celular, não existia.

Isso é o centro do mistério, e também o centro do medo. O som, quando é real para quem o ouve, não deixa marca no mundo mensurável. Não aparece em aparelhos. Não assusta os animais. Não acende luzes, não derruba paredes. É um fenômeno que existe apenas na cabeça de uma minoria, o que o torna, aos olhos da maioria, uma espécie de loucura compartilhada.

Há registros desse tipo de som em outros lugares do mundo. Na cidade de Taos, no Novo México, cerca de dois por cento da população relatam ouvir um zumbido baixo e contínuo durante décadas, sem que cientistas consigam identificar uma fonte sonora externa. Em Bristol, na Inglaterra, relatos semelhantes surgiram já na década de 1970. Estudos recentes apontam que, para a maioria dos ouvintes, o som pode nascer dentro do próprio sistema auditivo — uma forma de zumbido de baixa frequência, conhecida como tinnitus, embora a maioria das pessoas associe o tinnitus a sons agudos. Outros casos, no entanto, resistem a essa explicação. Sons de baixa frequência conseguem percorrer longas distâncias, atravessar paredes e escapar de equipamentos de medição comuns, que nem sempre são configurados para captar frequências entre trinta e oitenta hertz.

José leu sobre isso em um site acessado com dificuldade no sinal fraco da vila. Não encontrou conforto. Se o som nasce dentro da cabeça, por que começou apenas agora? Por que atinge apenas alguns moradores de Riacho Seco e não todos? Por que parece mais forte quando ele se deita, como se o silêncio da noite abrisse um canal direto entre o mundo exterior e o miolo do seu crânio?

Aos poucos, o zumbido mudou de caráter. No início, era apenas um ruído de fundo, irritante mas suportável. Com o tempo, José começou a notar variações. Às vezes o som parecia se aproximar, como uma fonte invisível deslizando pelo telhado de zinco. Outras vezes, parecia vir de debaixo da cama, do chão batido de terra, do poço seco no quintal. Ele passava horas acordado, ouvindo a própria respiração competindo com o zumbido, imaginando o que poderia estar enterrado sob o solo vermelho do sertão — tubos quebrados, cabos esquecidos, estruturas metálicas que ressoassem com alguma frequência vinda de longe.

Conversou com a dona do mercadinho, Dona Lourdes, numa tarde de sábado, enquanto ela pesava açúcar numa balança antiga.

— O senhor também ouve? — ela perguntou, sem levantar os olhos do produto.

José confirmou. Ela sussurrou que o zumbido começara por volta da mesma época, outubro, e que piorava nas noites de lua cheia. Não falava disso com ninguém senão com ele agora, porque as pessoas achariam que ela estava ficando senil. Aos sessenta e sete anos, Dona Lourdes conhecia cada vizinho, cada cachorro, cada árvore do vilarejo. Não era mulher de imaginar coisas.

O pedreiro aposentado, Seu Antônio, relatou algo ainda mais estranho: o zumbido parava quando ele saía de casa, mas voltava tão logo cruzava a porta. Como se a própria casa fosse um ressonador, uma câmara de amplificação para um som que vinha de fora — ou de dentro das paredes.

José começou a caminhar à noite. Saía de casa com uma lanterna e andava pelas estradas de terra do vilarejo, ouvindo. No centro da vila, o som diminuía. Quanto mais se afastava das casas, mais fraco ficava. Perto do cemitério, na borda do sertão, quase sumia. Então, de volta ao seu quintal, o zumbido retomava com força total, como se o lugar o reclamasse.

Começou a perder noites de sono. A perda de sono trouxe irritação. A irritação trouxe desconfiança. José passou a olhar os vizinhos com desconfiança, se perguntando quem mais ouvia o som e fingia não ouvir, quem ria dele às costas, quem acreditava que ele havia enlouquecido de verdade. A professora da escola primária, Dona Marisa, parou de cumprimentá-lo na feira. Não disse nada, apenas desviou o olhar. José não sabia se ela era uma dos que ouvem ou se apenas ouvira falar do "professor doido que escuta zumbido no escuro".

A curadoria do vilarejo não se pronunciou. Não havia motivo para se pronunciar. Não havia desaparecimentos, não havia mortes, não havia danos materiais. Apenas cinco ou seis pessoas reclamando de um som que ninguém mais percebia e que nenhum aparelho registrava. Para as autoridades, Riacho Seco continuava o mesmo vilarejo silencioso e esquecido de sempre.

José comprou um gravador de fita velho numa feira de Caruaru. Gravou o quarto à noite, a varanda, o quintal, o interior da casa com todas as janelas fechadas. Ouviu as fitas no dia seguinte, com fones de ouvido. Não havia zumbido. Havia apenas o chiado da fita, o barulho da própria respiração, o vento distante. O som não entrava no aparelho. Não entrava no celular. Não entrava no ouvido dos outros.

Na oitava semana, José sonhou com o fundo de um poço. Não era o poço do seu quintal, era um poço mais fundo, mais escuro, revestido de algo que não era pedra. De lá subia um zumbido grave, constante, que preenchia todo o sonho e continuava quando ele acordou. Ele levantou, foi até a janela e olhou o sertão sob a lua. Nada se movia. Nenhuma luz. Nenhum rastro no céu. Apenas o zumbido, agora mais forte do que nunca, preenchendo o silêncio da noite como se o silêncio fosse apenas a camada fina sobre algo muito maior e muito mais antigo.

Ele não dormiu mais naquela noite. Não dormiu nas seguintes também. O zumbido passou a ocupar o dia também, não apenas a noite. Um ruído baixo e permanente, que ninguém mais ouvia, que nenhuma máquina detectava, que ninguém levava a sério. José passou a evitar as pessoas. Passou a evitar o espelho, onde via um homem com olheiras profundas e o olhar fixo em algo que só ele enxergava.

Dona Lourdes morreu duas semanas depois. Não foi do zumbido — foi um infarto, dizem, enquanto fechava o mercadinho à noite. José passou pela casa dela no dia seguinte. A porta estava aberta, as luzes apagadas. Ouviu, num instante de silêncio absoluto, o zumbido parar. Parar de verdade. Não diminuir. Parar. Então recomeçar, mais forte, como se algo estivesse respirando dentro das paredes e tivesse notado sua presença.

Ouviu também, pela primeira vez, uma voz. Não palavras, não uma linguagem. Uma ressonância grave, como se o zumbido tivesse aprendido a falar através dele. Não entendeu o que foi dito, se é que algo foi dito. Entendeu apenas que o som não vinha de fora nem de dentro. Vinha do meio — do ponto onde o silêncio do sertão encontra o ouvido de quem não deveria ouvir.

Na manhã seguinte, José saiu de casa antes do amanhecer. Caminhou até a borda do vilarejo, onde a estrada de terra desaparece na caatinga. Deixou para trás a casa, o gravador, as fitas em branco, o emprego na escola. Não disse adeus a ninguém. Não havia quem entendesse.

Às vezes, nas noites muito quietas, moradores de Riacho Seco relatam ver uma figura andando pelas estradas de terra, olhando para o céu, ouvindo algo que ninguém mais ouve. Dizem que é o professor doido. Dizem que ele ficou surdo. Dizem que ainda ouve o zumbido, e que o zumbido o observa de volta.

A ciência explica boa parte desses casos como um distúrbio interno do ouvido, um fantasma auditivo gerado pelo próprio cérebro. Talvez seja. Talvez em Riacho Seco haja algo sob a terra que ressoa com uma frequência que apenas alguns ouvidos conseguem captar. A diferença, para quem ouve, é irrelevante. O som continua. Os aparelhos continuam em silêncio. E o mistério não está na origem do zumbido, mas na pergunta que ele impõe: o que acontece com quem escuta o que o mundo inteiro prefere ignorar?

## Fontes de inspiração

- Em (em.com.br) — reportagem sobre o Zumbido de Taos e as dificuldades de medição do ruído de baixa frequência ouvido por uma minoria da população.
- Terra (terra.com.br) — matéria sobre The Hum, relatado por 2% a 4% da população mundial, e as hipóteses científicas sobre sua origem.
- Olhar Digital (olhardigital.com.br) — estudo sobre o Hum como possível forma de tinnitus de baixa frequência, sem descartar fontes externas não identificadas.

A história acima é ficção. Os fatos citados servem apenas de inspiração atmosférica; não há cópia integral de nenhuma fonte externa.