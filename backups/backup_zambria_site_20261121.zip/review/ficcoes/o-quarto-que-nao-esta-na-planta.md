---
titulo: "O Quarto Que Não Está na Planta"
resumo: "Um restaurador encontra um cômodo que não consta em nenhuma planta de uma casa colonial mineira. Lá dentro, o espelho não reflete exatamente o que está à sua frente."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-quarto-que-nao-esta-na-planta"
tipo: "ficcao"
fonte_pesquisa: "nulo"
---

# O Quarto Que Não Está na Planta

A casa do Coronel Antenor Neves ficava na parte alta de uma cidade histórica de Minas Gerais, onde o sol da tarde bate direto nas paredes de pedra-sabão e o ar cheira a churrasqueira e a umidade de porão. Fui contratado para restaurar os acabamentos internos — estuque de gesso, frisos de teto, pintura de madeira — depois de trinta anos de abandono e de uma única, tardia campanha de limpeza feita pelos herdeiros. Não conhecia a família. Não conhecia a cidade. Aceitei o serviço porque o pagamento era adiantado e porque, naquele momento da minha vida, qualquer lugar sem gente me parecia melhor do que o meu próprio apartamento.

A planta da casa, em papel amarelecido e guardada numa pasta de couro no quarto do fundo, datava de 1893. Não havia registros de reformas. As paredes, segundo o documento, estavam onde deveriam estar. Meu trabalho era devolver-lhes a aparência, não questionar a geometria.

Comecei pela sala de jantar, onde o estuque do teto havia desmoronado em três pontos. Medir as paredes é o primeiro passo de qualquer restauração séria: você precisa saber o que está consertando antes de tocar na matéria. Na quinta medição, percebi que algo não fechava. A distância entre a parede da cozinha antiga e a parede da escada, somada à largura da porta de serviço e ao vão da estante embutida, deixava um excedente de pouco mais de um metro que não podia ser atribuído a erro de fita nem à irregularidade do piso. Havia, em outras palavras, um cômodo que a planta ignorava.

Não foi uma surpresa imediata. Casas antigas acumulam mentiras silenciosas: paredes rebocadas duas vezes, portas entulhadas de gesso, armários construídos sobre vãos esquecidos. O que me incomodou foi a localização. O excedente ficava exatamente atrás da estante de carvalho na sala de jantar, numa parede que, segundo a planta, deveria ser maciça.

Tirei a estante. Atrás dela, a pintura estava intacta, o reboco liso, sem emenda, sem fresta. Uma parede comum. Batendo os nós com os nós dos dedos, o som era o mesmo em toda a superfície — sólido, oco na medida certa de uma parede de alvenaria. Tinha que haver uma porta, porém. Não havia outra explicação para o metro sobrando.

Procurei por sinais de arrombamento antigo, por marcas de chaves, por desníveis no rodapé. Nada. Então comecei a retirar o reboco, aos poucos, com uma espátula fina, no ponto onde o som parecia um tom mais grave. Após três horas de trabalho, a lâmina encontrou madeira. Não era madeira da casa — era mais escura, mais pesada, como se estivesse envernizada com algo que não fosse verniz. Raspando mais, apareceu o contorno de um batente. E, dentro do batente, uma porta também selada de gesso e pintada da mesma cor da parede.

Quem quer que tivesse fechado aquele quarto não queria que ele fosse encontrado, mas também não tinha se dado ao trabalho de esconder bem. Uma porta selada é um convite mais eficaz do que um letreiro.

Removi o reboco da porta, depois a madeira do batente. Abri a porta — não havia maçaneta, apenas uma frouxidão na madeira que cedeu quando pressionei — e entrei.

O quarto tinha pouco mais de dois metros de largura por três de profundidade. Sem janelas. Sem móveis. No centro do teto, um soquete de lâmpada exposto, com fios descendo pelo canto até o chão, onde terminavam numa fita isolante cortada. O chão tinha uma inclinação leve, quase imperceptível, que empurrava qualquer objeto solto em direção à parede do fundo. As paredes eram de reboco cru, pintadas de branco numa camada única e mal aplicada. E, presa diretamente à parede do fundo, um espelho antigo de moldura escura, sem pano de proteção, sem data, sem marca de fabricante.

O espelho era grande o suficiente para refletir a figura inteira de um homem. Fiquei parado na porta, olhando para ele. Via a mim mesmo: a camiseta suja de gesso, as calças de trabalho, o rosto cansado. Até aí, nada de estranho.

O estranho começou quando me movi.

Levantei a mão direita. A imagem no espelho levantou a mão direita — mas com um atraso. Uma fração de segundo, talvez menos. O suficiente para ser notada se você estivesse esperando por algo. Eu não estava esperando por nada, e por isso demorei para perceber. Quando percebi, já estava parado diante do vidro, movendo a cabeça devagar, observando a imagem acompanhar meus gestos como quem aprende a dançar uma música que ainda não aprendeu.

Sai do quarto. Fechei a porta de madeira — a porta real, da casa, que dava para a sala de jantar — e voltei no dia seguinte.

Não contei a ninguém. Em obras de restauração, o segredo é parte do ofício: você não fala do que ainda não entendeu, porque o cliente quer resultados, não mistérios. Passei a usar o quarto como depósito de ferramentas. Levei uma caixa de lixas, um pote de massa corrida, uma escova de cerdas macias. Deixei os objetos no chão, na linha da inclinação. No dia seguinte, estavam para onde a inclinação os levava. Nada de anormal.

O que mudou foi o espelho.

Em certo dia, ao entrar, vi que o reflexo mostrava uma cadeira de madeira no centro do quarto — uma cadeira simples, de assento vazio, que não existia. Olhei para trás de mim, para o quarto real: nada. Apenas as paredes nuas e o soquete no teto. Voltei os olhos para o espelho. A cadeira continuava lá, imóvel, refletida numa luz que não vinha de lugar algum, já que o quarto não tinha janela nem lâmpada acesa.

Fechei os olhos. Abri. A cadeira havia sumido.

Comecei a passar mais tempo no quarto. Sentava no chão, de costas para a parede do espelho, e esperava. Não esperava por algo específico. Esperava para ver se o silêncio mudava. E mudava. Depois de uns minutos, o silêncio do quarto deixava de ser ausência de som e passava a ser uma presença — algo denso, como se o ar estivesse segurando a respiração.

Uma noite, sozinho na casa, ouvi respiração. Não vinha da rua, não vinha do andar de cima. Vinha do quarto atrás da estante. Saí da sala de jantar, tirei a estante de novo, abri a porta de madeira, entrei. O quarto estava vazio. O espelho mostrava o quarto vazio. A respiração, no entanto, continuava — vinha do canto esquerdo, o canto onde as paredes se encontram embaixo do espelho. Olhei para o canto. Nada. Olhei para o espelho. No vidro, aquele canto não existia: o espelho refletia a porta selada do lado de fora, a parede da sala de jantar, como se o espaço onde eu estava em pé fosse invisível para o reflexo.

Saí do quarto e não voltei por duas semanas.

Quando retornei, levei uma câmera. Coloquei-a em cima da caixa de ferramentas, apontada para o espelho e para o canto cego, e programei para gravar durante a noite. Deixei a casa, voltei pela manhã. O arquivo mostrava oito horas de quarto vazio. Luz apagada o tempo todo — eu não deixara nenhuma acesa. A imagem era granulada, preta, quase ilegível.

No minuto três e dezessete, algo mudou.

No vídeo, às 03:17, a porta de madeira se abriu sozinha. Não havia vento na casa. Não havia ninguém do lado de fora — eu havia trancado a porta principal com duas chaves. A porta se abriu, e a luz de fora — um único ponto laranja, talvez um réverbio da rua — entrou no quarto e iluminou o soquete vazio no teto. E então, no espelho, apareceu algo que não estava no quarto real: uma figura de pé ao lado de onde eu tinha deixado a caixa de ferramentas, uma figura pálida, de roupas escuras, com o rosto voltado para a câmera.

Desativei a gravação. Fiquei olhando para a tela, sem respirar. A figura não se movia. Esperava.

Na manhã seguinte, vendi minhas ferramentas e devolvi as chaves da casa aos herdeiros. Não terminei a restauração. Não quero nunca mais entrar naquela casa.

Mas é tarde demais para isso.

Ontem à noite, em meu próprio apartamento, entrei no banheiro para lavar o rosto. O apartamento é pequeno, planta simples, sem quartos secretos que eu saiba. Olhei para o espelho acima da pia. Via meu rosto, cansado, os olhos inchados de sono. Até que a imagem piscou. Um piscar lento, desalinhado com o meu. Meus olhos estavam abertos. A imagem no espelho fechou as pálpebras e as abriu novamente, sozinha.

Saí do banheiro deixando a água correndo.

Não sei o que é aquele quarto. Não sei se é um buraco na planta do mundo, se é um espelho que aprendeu a guardar cópias, se é algo que entrou na casa do Coronel Antenor Neves em 1893 e nunca saiu, apenas esperou alguém curioso o suficiente para tirar o reboco da parede. O que sei é que, desde aquela noite, sinto a inclinação do chão debaixo dos meus pés mesmo quando estou na rua. Sinto que, em algum canto da minha própria casa, há um espaço que não consta em nenhuma planta. E sinto que, quando apago a luz do quarto e fico parado em frente ao espelho, algo do outro lado do vidro está aprendendo a esperar do lado de fora.

## Fontes de inspiração

Ficção original. Nenhuma fonte externa foi consultada; todos os elementos — a casa, o coronel, o quarto e o espelho — são criações do autor.
