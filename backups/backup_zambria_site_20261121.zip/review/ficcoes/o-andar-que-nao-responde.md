---
titulo: "O Andar Que Não Responde"
resumo: "Daniel mora sozinho no último andar de um prédio velho e começa a ouvir passos e móveis sendo arrastados no piso acima. O problema é simples: não existe andar acima do seu. A investigação transforma o teto do apartamento em uma fronteira, e a fronteira, em uma porta."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-andar-que-nao-responde"
tipo: "ficcao"
fonte_pesquisa: 'Vic Tandy e Tony Lawrence, "The Ghost in the Machine" (Journal of the Society for Psychical Research, 1998) — usada apenas como referência atmosférica sobre sons que o corpo sente sem ouvir; a história é ficção pura.'
---

Daniel alugou o apartamento do último andar porque era o único que o senhorio mostrava sem pedir fiador. O prédio tinha seis andares, ou cinco, dependendo de quem contasse. A planta original, amarelada e guardada no síndico, assinada por um arquiteto morto em 1973, desenhava seis. O elevador, porém, parava no quinto. O sexto existia no papel e no concreto da laje, mas não tinha porta de andar, nem botão, nem número. Ficava acima do teto de Daniel, separado por trinta centímetros de concreto e uma escotilha selada com argamassa e desinteresse.

Nos primeiros trinta dias, o silêncio do último andar foi o argumento de venda. Depois vieram os passos.

Começaram como algo que a casa fazia sozinha — um tique da estrutura, a expansão do concreto no frio da madrugada, o encanamento gemendo. Daniel não era supersticioso e se irritava com programas de televisão sobre "mistérios"; atribuiu ao prédio velho. Até que, numa terça-feira de chuvas contínuas, ouviu algo sem desculpa térmica: o arrasto de um móvel pesado sobre o assoalho, direto acima da cabeça dele, no cômodo que seria a sala se o sexto andar existisse.

Ele olhou para o teto. O teto não olhou de volta. Ou pelo menos não demonstrou.

Passou a semana seguinte registrando os horários em um caderno, como se preenchesse um ponto de trabalho. Os passos ocorriam entre duas e quatro da madrugada, sempre em passadas lentas, sempre de cima, nunca de baixo, nunca do lado. Nunca do lado. Daniel morava no último andar. Acima dele havia apenas a laje, a caixa d'água compartilhada e o vazio do telhado. Não havia vizinho de cima. Não havia ninguém.

No décimo primeiro dia, bateu à porta do síndico, um homem gordo e permanente chamado Sérgio, que cheirava a café velho e desconfiança.

— Ouço coisas no sexto andar — disse Daniel.

Sérgio coçou a barriga com a mão que não segurava o controle remoto.

— Sexto andar? Não existe sexto andar. O prédio tem cinco.

— A planta diz seis. O elevador não chega lá, mas a laje existe. Acima do meu teto há trinta centímetros de concreto e depois… nada. Ou deveria haver nada.

Sérgio deu um riso curto, sem humor.

— Morador novo sempre ouve coisa. O prédio geme. A tubulação lateja. O vento entra pela laje do telhado e faz barulho de gente andando. Vá dormir, Daniel.

Daniel não dormiu. Pelo contrário, começou a ouvir mais. Não apenas passos. Vozes, às vezes, baixas demais para serem palavras, mas altas demais para serem sonho. Um chiado de roupa sendo arrastada. O som de uma porta que abre e fecha devagar, como se quem a abrisse não quisesse ser ouvido, mas falhasse no silêncio.

Ele comprou um estetoscópio de farmácia, daqueles baratos de estudante de enfermagem, e o encostou no teto da sala, na esquina mais próxima da escotilha selada. Ouvia o próprio sangue, o coração, e, por baixo de tudo, um passo. Um único passo. Depois outro. O ritmo de alguém que anda de um lado para o outro, esperando.

Uma noite, depois de três semanas, Daniel decidiu subir.

Não havia escada. A escotilha no teto do corredor do quinto andar — o último que o elevador alcançava — estava selada com argamassa, camada sobre camada, como se alguém tivesse se empenhado em enterrar o acesso não por decreto, mas por nojo. Daniel pegou uma escada de pintor, um martelo e uma cinzel. Quebrou a selagem aos poucos, noite após noite, sem acordar ninguém. O síndico não subia até lá. Os vizinhos não se importavam. O prédio, como muitos prédios velhos, era uma coleção de pessoas que fingem não se ver.

Quando o buraco ficou grande o bastante para passar o corpo, Daniel acendeu uma lanterna e subiu.

O espaço acima do teto não era um andar. Era uma laje grossa, escura, cheia de vigas de madeira apodrecida e feixes de fiação exposta que pareciam nervos ressecados. No centro, uma porta. Não a porta de um apartamento. Uma porta de serviço, estreita, de madeira maciça, com uma maçaneta de latão oxidada. Ela dava para uma parede de tijolos. Não havia corredor. Não havia escada para outro lugar. A porta se abria para um tijolo.

Daniel encostou a mão na madeira. Estava quente.

Ouviu, então, do outro lado da porta — ou da laje, ou do próprio crânio — o mesmo passo. Lentamente. Diretamente acima da cabeça dele, mesmo que estivesse de pé no espaço acima do teto, mesmo que não houvesse mais nada acima além do telhado e do céu.

Ele abriu a porta.

Do outro lado não havia tijolo. Havia o apartamento dele. A sala. O sofá. A mesa com o caderno dos horários ainda aberto na página da terça-feira. E, parado de costas para ele, junto à janela, um homem que se vestia com as roupas de Daniel — a mesma camisa, a mesma calça, os mesmos pés descalços — e olhava para a rua como se esperasse alguém chegar.

Daniel não gritou. Não conseguiu. O homem se virou, devagar, e Daniel viu que o rosto era o dele, mas com os olhos fechados. Costurados, não. Simplesmente ausentes, como se a pele tivesse crescido sobre as órbitas enquanto ele ainda estava vivo.

O homem abriu a boca. Não saiu som. Saiu, sim, o passo. O passo de cima, agora vindo de baixo, de dentro de Daniel, do peito, do estômago, do lugar onde o medo mora antes de ter nome.

Daniel fechou a porta. Desceu pelo buraco. Volou a escada, trancou a porta do apartamento, apagou a luz.

Agora, deitado na cama, ele ouve os passos. Não vêm de cima. Vêm de dentro do quarto. Vêm do lado de dentro da porta fechada. Vêm do espelho, da sombra da cama, do próprio respirar.

E ele entendeu, com a clareza fria de quem finalmente lê a letra miúda de um contrato que assinou sem querer, que o sexto andar nunca esteve acima. Estava abaixo. Estava dentro. Estava esperando Daniel terminar de subir para que pudesse, finalmente, descer.

O vizinho do andar de cima não existe. O problema é que Daniel, a partir de agora, mora no andar de baixo de si mesmo.

## Fontes de inspiração

- Vic Tandy e Tony Lawrence, "The Ghost in the Machine", Journal of the Society for Psychical Research, abril de 1998 — referência atmosférica sobre fenômenos de baixa frequência que o corpo percebe sem ouvir conscientemente. A história é ficção; nenhuma afirmação causal real é feita com base nessa fonte.
