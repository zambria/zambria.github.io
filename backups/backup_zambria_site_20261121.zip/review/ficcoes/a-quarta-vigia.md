---
titulo: "A Quarta Vigia"
resumo: "Na vigília fúnebre de um parente em uma cidade do interior, uma mulher é deixada sozinha com o corpo entre três e seis da madrugada — o turno que ninguém quer. Ela descobre que espelhos cobertos, velas acesas e pés voltados para a porta não são superstição: são contenção."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "a-quarta-vigia"
tipo: "ficcao"
fonte_pesquisa: "Aseman Curitibanos — rituais de passagem na Serra Catarinense; HiperHistória — funerais e ritos do velório rural no Brasil; Central Cemitérios — origem do velório; Meus Sertões — ritos fúnebres do sertão
---

# A Quarta Vigia

A sala de estar de Izabel tornou-se um templo às sete e meia de um sábado chuvoso de junho, quando o corpo de Seu Onofre — meu tio-avô, setenta e quatro anos, parado por um aneurisma enquanto mastigava o almoço — foi deitado sobre uma mesa coberta por lençol branco no centro do cômodo, como manda o rito do interior. Quatro velas nos cantos da urna. Espelhos cobertos com tecido escuro. Janelas fechadas. O sino da igreja já tinha dobrado por ele duas vezes: uma na hora da morte, outra no momento em que o corpo saiu do hospital e entrou nessa casa.

Fui designada para a quarta vigia: das três às seis da madrugada, o turno que ninguém quer. O mais longo. O mais frio. O mais próximo do amanhecer — e, segundo as rezadeiras, o mais perigoso.

Não que as outras três vigias fossem seguras. Dona Lourdes, a rezadeira da paróquia, rezou o terço ao meu lado às oito da noite, de pé, com o terço entre os dedos e o olhar fixo no corpo. Quando acabou, apertou meu braço com uma força que não condizia com sua idade e disse apenas: "Não deixa ele sozinho, minha filha. Corpo que fica mole, levanta." Depois foi embora com as outras mulheres, levando as coroas de flores e o chá, deixando-me sozinha com Onofre e com o silêncio.

A casa cheirava a cera de abelha, incenso barato e café frio. Os pés do defunto estavam voltados para a porta da frente — "para a alma encontrar a saída", explicara Izabel, varrendo o pó dos móveis com uma pressa nervosa. Uma bacia com água ficara debaixo da mesa — "inibe o odor", disseram. Dentro da urna, um galho verde — caso o corpo não endurecesse, sinal de que ainda não terminara seu trabalho e viria buscar outro em breve. Eu não acreditava em nada disso. Ou pelo menos é o que repeti para mim mesma enquanto acendia a quarta vela e sentava na cadeira de madeira ao lado da mesa, de costas para a parede, frente ao lençol branco.

As três da manhã chegaram sem aviso. O relógio de parede parou às duas e cinquenta e cinco, ou foi eu que parei de olhar para ele. A vela da cabeceira apagou sozinha, sem corrente de ar, sem janela aberta. Eu a acendi novamente. Em seguida, a vela dos pés se apagou. Acendi de novo. Na terceira vez, não acendi. Deixei o escuro fazer o que queria.

Foi então que percebi o lençol se mexer.

Não era vento. Não havia vento naquela sala fechada. O lençol branco, esticado sobre o corpo de Onofre, subiu devagar, como se algo debaixo dele estivesse inspirando. Uma vez. Duas vezes. O peito do morto subiu e desceu, ritmado, silencioso. Fiquei imóvel, as mãos apoiadas nos joelhos, a respiração presa na garganta. O corpo não estava rígido. Quando estiquei o braço e toquei a mão dele, a pele estava quente. Mais quente que a minha. Macia. Maleável. Corpo mole.

Lembrei do galho verde. Lembrei de Dona Lourdes. Lembrei de por que os pés apontam para a porta: não é para a alma sair. É para o corpo não encontrar o caminho de volta — ou para que, quando ele decidir ir embora, saia direto, sem precisar derrubar nada.

A vela da cabeceira se acendeu sozinha. A chama era baixa, amarela, sem tremor. Na luz, vi o rosto de Onofre debaixo do lençol. Os olhos estavam abertos. Não piscavam. Não eram os olhos de um homem de setenta e quatro anos morto há dezoito horas. Eram olhos que assistiam.

— Quarta vigia — disse uma voz que saiu da boca de Onofre, mas não era a voz de Onofre. Era mais baixa, mais úmida, como se falasse debaixo d'água. — Você vai ficar comigo ou vai ir embora?

Fui para a porta. Ela estava trancada de fora, com o trinco de ferro que Izabel havia engatado antes de sair, "para ninguém entrar e perturbá-lo". Ninguém entra. Ninguém sai. Eu estava trancada com o corpo mole.

Corri para a janela. Fechada, trancada, gradeada. O espelho da cômoda, coberto pelo tecido escuro, começou a ficar úmido, como se alguém do outro lado estivesse respirando contra o vidro. Uma marca de dedo apareceu no tecido, de dentro para fora.

Entendi, então, para que servem os espelhos cobertos. Não é para proteger a alma do morto. É para impedir que o que está dentro do corpo veja quem está vigiando. Para que ele não escolha.

O lençol deslizou. Onofre — ou o que usava o corpo de Onofre — sentou-se na borda da mesa. Os pés, ainda voltados para a porta, tocavam o chão sem fazer barulho. A pele estava cinzenta agora, fina como papel de seda, e os olhos não piscavam jamais.

— Você é a quarta — disse. — As outras três foram embora. Você ficou. Agora a vaga é sua.

Não esperei para ver o resto. Saí correndo pela casa, chutando móveis, derrubando a bacia de água, até alcançar a porta da frente. O trinco de ferro se abriu sozinho. Ou nunca esteve trancado. Do lado de fora, o amanhecer ainda não chegara; só uma luz cinza e doente sobre a cidade, e o cheiro de cera, incenso e café frio saindo da casa atrás de mim.

Voltei para o meu apartamento antes do sol nascer. Tranquei a porta. Coloquei uma cadeira embaixo da maçaneta. Cubri o espelho do banheiro com uma toalha escura. Escrevo isso sentado no chão, com as costas na porta, ouvindo.

De algum lado desse apartamento, algo caminha com os pés arrastando um lençol branco. Ainda não me viu. Ou talvez tenha visto e esteja esperando a hora certa — a quarta vigia, o turno que ninguém quer, o mais perto do amanhecer.

O velório de Onofre ainda não acabou. E o corpo, afinal, nunca esteve morto. Apenas estava esperando alguém ficar sozinho o bastante para assumir o lugar dele.

## Fontes de inspiração

- Aseman Curitibanos — "Os rituais de passagem na Serra Catarinense": velório realizado na sala de estar da residência, corpo sobre mesa ou cavaletes, quatro velas acesas nos cantos do caixão, janelas fechadas, espelhos cobertos com tecido escuro para impedir que a alma fique presa no reflexo.
- HiperHistória — "Funerais no Brasil: ritos e conservação": corpo velado em casa por doze a vinte e quatro horas, deitado sobre mesa ou tábua coberta por lençol branco, presentes revezando-se em orações durante a noite.
- Central Cemitérios — "Origem do velório": o termo "velar" vem da vigia feita ao corpo para observar se o falecido não acordaria; velórios de vinte e quatro horas por falta de eletricidade e recursos de conservação.
- Meus Sertões — "Ritos fúnebres": pés do defunto voltados para a porta da frente, bacia com água debaixo do caixão, varinha verde no ataúde caso o corpo não endureça — corpo mole é sinal de que vem buscar outro em breve.

Todos os nomes, personagens e eventos narrados são fictícios; os costumes citados servem apenas como inspiração para a ficção.