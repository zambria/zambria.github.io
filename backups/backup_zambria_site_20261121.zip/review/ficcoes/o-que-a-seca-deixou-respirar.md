---
titulo: "O Que a Seca Deixou Respirar"
resumo: "Quando uma seca histórica esvazia a Represa do Jaguari e devolve à luz a cidade afogada de Velha Igaratá, o que emerge do lamaçal não é o que as águas afogaram — é algo mais velho que a represa mantinha adormecido."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-que-a-seca-deixou-respirar"
tipo: "ficcao"
fonte_pesquisa: "Super Rádio Tupi — Velha Igaratá reaparece com seca da Represa do Jaguari"
---

O reservatório não secou por acidente. Secou porque o céu deixou de ser prometesa e se tornou sentença. Nos últimos meses do outono de 2026, o interior paulista perdeu a chuva como quem perde a memória, gota a gota, até que o nível da Represa do Jaguari baixou ao ponto de expor, pela primeira vez em mais de quatro décadas, o esqueleto de Velha Igaratá.

Eu fui lá na terceira semana de outubro, quando a imprensa já havia esgotado o adjetivo "histórico" e os curiosos começaram a pisar no lodo com a leveza de turistas em ruínas de cartão-postal. Levei câmera, caderno e a mesma presunção de quem acredita que um lugar submerso é, por definição, um lugar morto. Saí de lá com a certeza contrária.

O que as águas da CESP afogaram, entre os anos 1960 e o início dos 70, não foi apenas uma sede de município. Foram ruas, lojas, a igreja, as casas de alvenaria e de taipa, os quintais, os cemitérios, o barulho cotidiano de uma população que o Estado removeu à força para assentá-la na nova Igaratá, seca e planejada, fora do alcance do reservatório. A velha cidade foi deixada debaixo d'água com a intenção tácita de que nunca mais voltasse a ver o sol. A natureza, porém, não honra intenções tacitas. A seca abriu a comporta do esquecimento.

Quando cheguei, o leito do reservatório parecia um deserto cinzento, rachado pelo sol, com poças escuras que refletiam um céu de chumbo. No centro do que restava da velha praça, emergiam os alicerces de uma construção de pedra, desalinhados, como dentes quebrados. À volta, restos de calçamento, um cano de ferro entortado, o que restara de um poste de luz. Nada disso me surpreendia. O que me prendeu, de fato, foi a estrutura mais afastada, um poço ou cisterna de alvenaria que não constava de nenhum dos mapas de desapropriação que consultei antes de viajar. Estava fora do perímetro da cidade antiga, numa área que, segundo os registros, nunca fora habitada. E, no entanto, estava ali, intacta, como se alguém a tivesse construído deliberadamente no escuro, muito antes de a represa existir.

Desci até ela. O chão de lama suga o tornozelo com uma paciência que só os lugares submersos conhecem. O poço era raso — uns três metros —, revestido de pedras escuras, úmidas mesmo no auge da estiagem. No fundo, não havia água, mas algo que me fez parar: um cheiro. Não de podre, não de peixe morto, mas de terra queimada e de metal velho, um odor que parecia grudar nas narinas e recusar a sair. Me incliquei. Do fundo do poço subia um sopro, leve, quase imperceptível. Um ar quente, com um ritmo.

Respirei fundo — erro.

Foi então que o vi. No canto mais escuro do poço, um bloco de pedra maior que os outros, lascado, com uma entalhe que não parecia obra da natureza. Não era um símbolo, não era uma letra. Era uma depressão, como se algo tivesse sido pressionado ali com força, repetidas vezes, durante muito tempo. Passei o dedo sobre o entalhe. A pedra estava quente.

De repente, o sopro parou. O silêncio que se seguiu não foi o silêncio do deserto. Foi o silêncio de quem ouve de volta.

Voltei ao carro com as mãos tremendo e a impressão nítida de que algo, naquele lamaçal, havia acabado de notar minha presença. Não vi nada. Não ouvi nada. Mas o ar, no caminho de volta à nova Igaratá, parecia mais denso, como se a secura do ar tivesse sido trocada por uma umidade que vinha de baixo para cima.

Nos dias seguintes, comecei a reparar nos detalhes que a imprensa havia omitido. As notícias mostravam turistas tirando fotos nas ruínas da igreja, mergulhadores amadores coletando tijolos como lembrança, prefeitos falando em "patrimônio submerso" como se fosse um museu a céu aberto. Ninguém mencionava o cheiro. Ninguém mencionava que, nos pontos mais baixos do reservatório, a lama não secava completamente, por mais que o sol castigasse. Ninguém mencionava que os cães da região, nas vilas próximas, haviam parado de latir à noite, exatamente desde o dia em que o nível da água começou a cair.

Pesquisei Velha Igaratá antes de ser inundada. Antes de ser Igaratá, o vale do Jaguari era ocupado por pequenos sítios, fazendas, e, muito antes disso, por quem vieram antes dos portugueses. Não encontrei registros de uma cisterna naquela coordenada. Não encontrei registros de nada, de fato, além do nome de um fazendeiro que abandonou a terra na década de 1950, dizendo, em depoimento a um jornal local, que "o fundo do poço não estava vazio". O depoimento não foi seguido de explicação. O fazendeiro morreu pouco depois, de causas que o atestado médico não especificou.

Voltei a Velha Igaratá na última semana de outubro. A chuva havia começado a voltar, timidamente, e o nível da represa subia de novo, devagar, como se as águas estivessem com pressa de cobrir o que a seca havia exposto. Naquela tarde, o poço já estava parcialmente submerso — meio metro de água turva cobria os alicerces de pedra. Me aproximei, desci até a borda da água, e encostei o ouvido na superfície.

Não ouvi ondas. Ouvi respiração.

Uma respiração lenta, ritmada, vinda de debaixo da água, como se algo grande estivesse ali, deitado, esperando o reservatório encher de novo para retomar o sono que a seca interrompera por uns dias. Ou, pior: como se algo tivesse usado a baixa das águas para esticar os membros, encher os pulmões de ar, e agora, com a água voltando, estivesse se preparando para fechar os olhos — ou abri-los de verdade.

Saí dali antes do anoitecer. Na estrada de volta, o céu estava carregado, prometendo mais chuva. Pensei nas fotos que publiquei nas redes sociais, nas turistas que ainda caminhavam pelo lamaçal exposto, nas crianças brincando nas ruínas da igreja enquanto o sol ainda brilhava. Pensei no fazendeiro de 1950, no cheiro de metal queimado, no sopro quente do fundo do poço.

A represa vai encher. Velha Igaratá vai voltar a dormir debaixo d'água. Mas algo, agora, sabe que a seca pode voltar. Sabe que o esquecimento é temporário. E sabe que, quando o nível baixar novamente, haverá algo do lado de fora esperando para entrar — ou algo do lado de dentro que já aprendeu a respirar no ar.

Não volto mais. Mas, às vezes, à noite, quando o vento bate nas janelas e o ar de dentro de casa fica pesado demais, eu me pergunto se o poço não encontrou um jeito de me seguir. Se algo, naquele lamaçal cinzento, não aprendeu a respirar pelo meu nariz.

## Fontes de inspiração

- Super Rádio Tupi: reportagem sobre a reaparição de Velha Igaratá durante a seca extrema da Represa do Jaguari, no interior paulista, baseada em fontes públicas sobre a inundação da cidade original pela CESP na década de 1960. Usado apenas como referência geográfica e histórica para a ficção; todos os personagens, eventos sobrenaturais e detalhes narrativos são invenção do autor.
