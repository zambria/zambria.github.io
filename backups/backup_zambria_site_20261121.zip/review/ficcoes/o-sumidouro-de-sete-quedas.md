---
titulo: "O Sumidouro de Sete Quedas"
resumo: "Na noite em que a terra engoliu a praça de Sete Quedas, o silêncio oficial começou mais cedo que o buraco. Algo subiu do subsolo, e ninguém ousa nomear."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-sumidouro-de-sete-quedas"
tipo: "ficcao"
fonte_pesquisa: "Desastre do Lago Peigneur (1980); reportagens sobre sumidouros naturais no Brasil"
---

# O Sumidouro de Sete Quedas

A chuva começara no fim da tarde e não parara. Era uma dessas chuvas de interior que não lavam nada, apenas amaciam o solo até ele perder a vergonha. Em Sete Quedas — vilarejo de dois quarteirões asfaltados e o resto poeira, no triângulo mineiro onde o cerrado começa a desistir de ser verde — ninguém olhou para o céu naquele momento. As pessoas estavam nas portas, conversando sobre a barragem do Córrego dos Bois, que vinha rachando desde setembro, e sobre a ausência de chuva nos anos anteriores, ironia que a chuva de agora não consertava.

Por volta das vinte e uma horas, o chão gemeu.

Não foi um trovão. Foi mais baixo, mais úmido, como um estômago engolindo uma pedra grande demais. Quem estava perto da praça central disse depois que sentiu o pé afundar um centímetro no asfalto, como se a rua tivesse virado massa de pão quente. Então a terra abriu.

Não houve explosão, não houve faísca, não houve aquele barulho cinematográfico de metais a se rasgarem. A praça simplesmente deixou de existir. Um sumidouro, limpo e circular, com uns vinte metros de diâmetro no começo, engoliu o coreto de madeira, o chafariz seco, duas árvores de ipê e um cachorro vira-lata que dormia no banco de concreto. O buraco parou sozinho, ou parou porque não havia mais nada para engolir ali. Ficou a noite inteira escuro e quieto, com cheiro de terra úmida e de algo mais antigo — mineral, queimado, não identificável.

Na manhã seguinte, o prefeito chegou com dois homens de terno que não se identificaram. Não deram entrevistas. Não falaram com a imprensa de Uberaba, que já ligava perguntando se era rompimento de barragem, terremoto, acidente com gás. Disseram apenas que a área estava isolada por questões de segurança pública, interditou o acesso à praça com fitas vermelhas e sumiu antes do almoço. A fita durou até o meio-dia, quando um grupo de curiosos a rompeu e se aproximou da beira para olhar.

Foi quando viram que o buraco havia crescido.

Agora tinha uns quarenta metros. As bordas não eram regulares: pareciam roídas, como se algo estivesse comendo a terra de baixo para cima, em silêncio. Não havia água no fundo, não havia pedras soltas, não havia ecos quando jogavam pedaços de tijolo. Apenas escuridão, e uma pressão estranha nos ouvidos de quem se aproximava demais, como descida rápida em estrada de serra.

O geólogo que a prefeitura eventualmente mandou — um senhor de óculos grossos que chegou de Belo Horizonte com um malete de aço — olhou para o buraco por exatamente três minutos. Depois fechou o malete, entrou no carro e não disse uma palavra aos repórteres. No dia seguinte, pediu demissão do cargo de consultor e saiu da cidade com a família. Nunca mais foi visto em Sete Quedas.

O buraco não parou.

A cada manhã, era maior. Três dias depois, engolia metade da igreja. Uma semana depois, alcançara a padaria e o posto de saúde. Os moradores começaram a sair, claro. Uns foram para parentes em Uberaba, outros para a capital, outros simplesmente sumiram sem deixar endereço. Ficaram os teimosos, os sem para onde ir e os que diziam ouvir coisas à noite. Sussurros que vinham de debaixo do chão. Nomes chamados em vozes de gente morta.

E então começou a subir.

Não sei descrever direito o que subiu, porque ninguém viu inteiro. Aos poucos, do fundo do sumidouro, surgiram pedaços de coisas que não pertenciam à superfície: um pedaço de cabo de aço enferrujado, com etiqueta de empresa que não existia mais; uma Bíblia aberta em uma página onde o texto havia sido riscado com caneta preta; um par de botas de couro, ainda com os pés dentro, os pés enegrecidos, cobertos de uma camada branca que cheirava a cal virgem; e, numa noite de lua minguada, uma mão. Uma mão humana, pálida, sem unhas, que se apoiou na borda do buraco e ficou ali, imóvel, até o amanhecer, quando voltou a descer sozinha.

Os poucos moradores restantes não saíram mais de casa após o escurecer. Fechavam as janelas com tábuas, rezavam ou não rezavam, e esperavam. O sumidouro agora ocupava quase toda a praça e começava a morder a esquina da farmácia. Ainda não havia explicação oficial. Não havia laudo, não havia comissão, não havia culpa. Era apenas um buraco que crescia, e algo que subia dele.

No último dia em que alguém ainda morava em Sete Quedas, uma mulher chamada Iara — que não tinha parentes, não tinha para onde ir e dizia que o buraco a chamava pelo nome — saiu de casa com uma lanterna e caminhou até a beira. Não gritou, não caiu. Seus vizinhos, que observavam pelas frestas das tábuas, disseram depois que ela ficou ali, olhando para baixo, por longos minutos. Então sorriu. Um sorriso estreito, sem alegria. Deixou a lanterna cair no buraco. O vidro não se quebrou. A luz simplesmente apagou, ainda no ar, como se algo a tivesse apagado com os dedos. Iara deu um passo à frente e desapareceu.

O som que veio depois não foi de impacto. Foi um engolir. Um único som, úmido e definitivo, que fez os cachorros dos arredores pararem de latir ao mesmo tempo.

Quando a manhã chegou, o sumidouro tinha o dobro do tamanho da noite anterior. E havia, grudada na borda de concreto que restava, uma única impressão digital. Grande. Úmida. Não humana.

O governo nunca emitiu um comunicado sobre Sete Quedas. O vilarejo saiu dos mapas atualizados, não por decreto, mas por esquecimento conveniente. Se você passar por ali hoje — se conseguir encontrar o lugar, pois as estradas de terra foram cobertas pelo mato e os sinais foram removidos — verá apenas um campo vazio, úmido, com cheiro de terra queimada. E, se ficar quieto o suficiente, ouvirá algo abaixo dos pés, respirando devagar, esperando que você se aproxime demais para olhar no fundo do buraco.

Não olhe. A terra não está aberta por acidente. Ela está aberta porque algo decidiu que era hora de subir.

## Fontes de inspiração

- Desastre do Lago Peigneur (Luisiana, 1980): colapso de um lago em uma mina de sal após erro de perfuração, demonstrando como o subsolo pode engolir a superfície sem aviso.
- Reportagens sobre sumidouros naturais e crateras que se abrem de repente em diferentes regiões, incluindo ocorrências documentadas no Brasil (Minas Gerais, São Paulo, Bahia).
- Lendas locais da Ilha da Queimada Grande (litoral de São Paulo): mistérios, desaparecimentos e histórias que a população conta sobre lugares onde a terra não é segura.
