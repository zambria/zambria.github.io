---
titulo: "O Rosto na Laje"
resumo: "Na seca recorde de 2023, o Rio Negro expôs em Manaus petróglifos de até dois mil anos: rostos esculpidos na rocha que a população chama de caretas. Uma arqueóloga escalada para documentá-los encontra um rosto que não constava nos registros — e que parece observar de volta."
categoria: "arqueologia"
data: "2026-11-21"
slug: "o-rosto-na-ponta-das-lajes"
tipo: "ficcao"
fonte_pesquisa: "Folha de S.Paulo, Olhar Digital, Mídia Max e Iphan (reportagens sobre a Ponta das Lajes na seca de 2023)"
---

Em outubro de 2023, o Rio Negro fechou o mês abaixo de treze metros — a cota mais baixa registrada em mais de um século. Na zona leste de Manaus, a água recuou como se estivesse se retirando de propósito, expondo lajes de pedra que ninguém via desde 2010. Na Ponta das Lajes, sítio de cerca de 150 mil metros quadrados às margens do rio, o Iphan estima gravuras entre mil e dois mil anos de idade: rostos esculpidos na rocha, conhecidos popularmente como caretas. Rosto após rosto, faces levemente quadradas, bocas entreabertas, alguns sem nariz, entalhes que ninguém consegue datar com precisão. São imagens de um povo que não deixou registros escritos, apenas essas marcas na pedra, esperando que a água abaixasse o suficiente para alguém olhar de volta.

Letícia Moraes foi chamada para documentar tudo antes que o rio subisse novamente. Arqueóloga de contrato, trinta e dois anos, passara os últimos seis anos entre urnas funerárias e cacos de cerâmica no interior do Pará. Nunca havia visto nada como aquelas caretas. Tinha duas semanas, uma prancha de luz, um drone emprestado e um medo silencioso de que a água não fosse a única coisa a subir enquanto ela trabalhava.

O trabalho começou às seis e meia da manhã, quando o barro ainda estava úmido e o cheiro de peixe morto subia das poças deixadas pela vazante. O nível do Rio Negro tinha caído quinze metros desde julho, segundo os relatos, deixando expostas vastas extensões de rocha e areia onde não havia praia. Letícia dividiu a praia de lajes em setores, fotografou cada face visível e comparou as imagens com o catálogo de 2010, quando o sítio aflorara pela primeira vez nas décadas modernas. As caretas estavam todas lá: os rostos quadrados, as bocas, as bacias de polimento, os sulcos onde, acredita-se, povos pré-coloniais afiavam flechas e lanças. Nada fora do catálogo.

Até o décimo segundo dia.

Na laje do setor C, perto da borda onde a água ainda formava uma lâmina fina, Letícia encontrou uma face que não constava em nenhum registro. Tinha os mesmos traços — a testa ligeiramente quadrada, a boca entalhada com um único golpe de machado — mas não havia nada parecido nas fotos de 2010. Nem nos relatórios do Iphan, nem nos arquivos da Universidade Federal do Amazonas. A pátina da rocha ao redor do entalhe era a mesma de tudo o resto, o que sugeria que não se tratava de algo recente. Simplesmente não estava lá antes. Ou ninguém tinha notado.

Ela fotografou a face de todos os ângulos. À noite, no quarto do hotel, passou as imagens uma a uma no laptop. Em cada uma, o entalhe parecia ocupar uma posição ligeiramente diferente na laje. Não era muito — alguns milímetros, talvez nada — mas o queixo da careta parecia mais próximo da borda da pedra na foto das cinco da manhã do que na de onze da noite. Ela atribuiu a cansaço, à luz irregular da prancha, ao truque da memória. Pareidolia, disse Marcos, o estagiário que a ajudara nos primeiros dias, quando ela lhe mostrou as imagens. O cérebro humano é treinado para ver rostos em tudo: em nuvens, em tomadas, em manchas de umidade. Você passou duas semanas olhando caretas. Agora vê caretas em tudo.

Letícia concordou, mas não parou de olhar.

Na décima terceira noite, ela voltou sozinha à Ponta das Lajes. A previsão apontava chuva para o dia seguinte; o nível do rio começaria a subir, e as lajes voltariam a desaparecer debaixo da água antes que o Iphan terminasse o laudo. Ela levou a prancha de luz e ficou até depois da meia-noite, fotografando a mesma face a cada trinta minutos. A luz da lua refletia na lâmina de água que restara ao redor da pedra, e nesse reflexo Letícia jurou que viu a careta mover a cabeça — não muito, apenas o suficiente para que o olho esquerdo, o único que ainda existia, ficasse voltado diretamente para ela.

A água do Rio Negro, naquele ponto, não fazia barulho. Não havia correnteza forte, nem ondas. Apenas o silêncio denso de um rio que secara demais e depressa, como se algo estivesse bebendo-o de baixo para cima. Letícia encostou a mão na laje. A pedra estava fria, úmida, porosa. O entalhe da boca estava cheio de água da chuva, e por um instante ela sentiu que a face não estava olhando para ela — estava olhando para baixo, na direção de onde a água havia saído, como se estivesse esperando que o nível baixasse ainda mais para que algo, debaixo da pedra, pudesse finalmente enxergar a superfície.

Na manhã seguinte, o Rio Negro subiu vinte centímetros. As lajes da Ponta das Lajes foram cobertas novamente, e o sítio voltou ao seu estado natural: invisível, submerso, esquecido. Letícia deixou Manaus com o laudo concluído, as fotografias arquivadas e a certeza de que nada de anormal constava nos registros.

O que consta nos arquivos dela, no entanto, é uma sequência de imagens que ela nunca mostrou a ninguém. Nessa sequência, a careta da laje do setor C aproxima-se, milímetro a milímetro, da borda da pedra. Na última foto, tirada minutos antes da água cobrir tudo, o rosto não está mais centrado no entalhe. Está nas bordas, olhando para fora, como se tivesse saído da rocha para ficar onde a água não alcança.

E o que mais incomoda Letícia não é o fato de o rosto ter se movido. É a certeza, cada vez mais forte, de que as caretas não foram esculpidas para serem vistas do alto, do céu ou da margem do rio. Foram esculpidas para olhar de baixo para cima, esperando o dia em que a água baixasse o suficiente para que algo, debaixo da laje, pudesse ver quem passa na beira.

## Fontes de inspiração

A história é ficção, mas se baseia em reportagens reais sobre a seca histórica do Rio Negro em 2023, que expôs petróglifos no sítio arqueológico Ponta das Lajes, em Manaus. Fontes consultadas apenas como inspiração, sem reprodução de textos:

- Folha de S.Paulo — "Gravuras rupestres são expostas pela seca no Amazonas" (2023)
- Olhar Digital e Mídia Max — reportagens sobre as "caretas" da Ponta das Lajes reveladas pela vazante de 2023
- Iphan — estimativa de cronologia dos petróglifos entre 1.000 e 2.000 anos e registro do afloramento do sítio em 2010 e 2023
