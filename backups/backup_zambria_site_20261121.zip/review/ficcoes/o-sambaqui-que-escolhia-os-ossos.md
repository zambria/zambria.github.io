---
titulo: "O Sambaqui que Escolhia os Ossos"
resumo: "Um arqueólogo escava um sambaqui não catalogado na costa e descobre que os ossos não foram sepultados: foram montados. E a montagem ainda não terminou."
categoria: "arqueologia"
data: "2026-11-21"
slug: "o-sambaqui-que-escolhia-os-ossos"
tipo: "ficcao"
fonte_pesquisa: "Revista Pesquisa FAPESP; BBC News Brasil"
---

# O Sambaqui que Escolhia os Ossos

O cheiro do sambaqui não era o cheiro do mar. Era o cheiro de concha moída queimada ao sol, de osso queimado lentamente, de uma paz que alguém havia decidido não quebrar. Vitor Morais passara três semanas raspando o monte não catalogado entre Paraty e Ilha Grande, e desde o segundo dia as conchas pareciam contar algo que ele não sabia ouvir.

Não o silêncio vazio de um lugar abandonado, mas o silêncio de quem está esperando ser ouvido.

Cada peneirada, cada raspão de espátula na camada de calcário orgânico, trazia à superfície um fragmento de costela, um dente, um otólito de peixe, e Vitor tinha a impressão nítida de que os objetos se acomodavam na caixa de coleta em uma ordem que ele não havia imposto. Como se o monte estivesse escolhendo o que entregar, e quando. Os sambaquis — montes de conchas, ossos, areia e terra erguidos pelos povos do litoral entre oito mil e dois mil anos atrás — serviram de cemitério, de moradia, de marco territorial e de palco cerimonial. Esse era o lugar-comum dos livros. Vitor, contudo, começava a desconfiar de que aquele monte em particular não havia parado de funcionar.

Na quarta camada, o problema apareceu.

A estratigrafia não mentia, ou pelo menos não mentia de forma óbvia. Conchas de amêijoa e mexilhão, cinzas de fogueira, lascas de sílex, restos de peixe. Tudo na ordem esperada, tudo antigo. Exceto um anel de conchas inteiras, dispostas em círculo perfeito de uns trinta centímetros de diâmetro, no centro do qual jaziam restos humanos. Não um esqueleto. Vários fragmentos, de pelo menos três indivíduos diferentes, dispostos não em posição anatômica, mas como se alguém houvesse tentado remontar um corpo com peças de fora. Um fêmur de adulto onde deveria estar um crânio. Uma caixa torácica de criança sobreposta a uma bacia pélvica de idoso. Os ossos estavam limpos, polidos até, como se tivessem sido manuseados muito depois de secos — e, no entanto, estavam ali, no mesmo nível das conchas mais antigas do sítio.

Vitor mandou datação por carbono de três fragmentos. O laboratório voltou com números que não conversavam entre si: um osso dizia dois mil anos; outro, quatro mil; um terceiro, um resultado que o técnico, ao telefone, leu com a voz de quem não queria ser entendido. Algo sobre "anomália de reserva de carbono marinho". Em tradução mais honesta: não sabemos explicar, não assine esse laudo.

Ele voltou ao sítio ao anoitecer. A maré estava baixa e o manguezal cheirava a enxofre e concha aberta. Foi então que ouviu.

Clique. Clique. Clique.

Som de concha batendo em concha. Um ritmo lento, deliberado, que vinha de dentro do monte. Vitor parou. A lanterna tremia na mão. Ele deu um passo em direção ao círculo, e o som parou. Deu outro passo, e recomeçou, mais rápido. Não era o vento. Não era o iate de algum turista ancorado na baía. Era o monte contando, e agora estava contando ele.

Na sexta-feira, o velho pescador do cais — o único morador que ainda se aproximava daquele trecho de costa — apareceu com uma garrafa de cachaça e nenhum cumprimento.

"Não tira osso de sambaqui, moço. O monte não gosta que tirem. Ele guarda porque escolheu guardar. E escolhe quem entra na próxima camada."

Vitor sorriu, pela primeira vez em semanas, e foi um sorriso seco. O arqueólogo profissional em si ria desses boatos: histórias de ribeirinho para justificar não mexer em terreno sagrado, ou maldito, ou simplesmente inconveniente. A ciência não lida com monte que escolhe. A ciência lida com amostras, estratigrafia, datação. Mas Vitor, naquela noite, sonhou com uma língua que não tem palavra para mar, nem para barco, nem para céu — apenas para concha, para osso e para a palavra que significa "espera". Acordou com a boca cheia de areia salgada e a certeza de que algo, debaixo de seus pés, havia lido seus sonhos.

No domingo, abriu a terceira unidade de escavação. Abaixo do anel de conchas, encontrou o que não deveria estar ali: uma camada de fragmentos recentes. Conchas quebradas — não erodidas pelo tempo, quebradas à força, com arestas vivas e úmidas. Entre elas, ossos que não pertenciam a nenhum sítio conhecido da região. Um rádio húmero com a epífise ainda consolidada, como se tivesse pertencido a alguém vivo há poucos meses. Um dente do siso com cárie recente. Vitor olhou para a própria mão, tremendo, e percebeu que o dente do siso do rádio húmero era do lado esquerdo, exatamente como o seu. Não comprovava nada. Provava tudo.

A ciência gosta de dizer que os sambaquis são monumento dos mortos para os vivos. Que são memoriais, marcadores territoriais, festim de conchas acumulado ao longo de gerações. É uma explicação confortável. Tira do monte qualquer intenção. Tira dos ossos qualquer vontade. O problema é que Vitor, deitado na lona da tenda às três da madrugada, ouvia as conchas se movimentando embaixo do colchonete. Um arrasto lento, como se algo estivesse subindo pelas camadas, escolha feita, ordem definida. O monte não era um arquivo do passado. Era uma fila. E ele acabara de ser chamado para a próxima posição.

Na segunda-feira, Vitor não desceu para a escavação. Deixou as peneiras, o GPS, o caderno de campo, tudo trancado na tenda. Caminhou até a beira do monte e ficou ali, de pé, olhando o círculo de conchas inteiras. A maria, a chuva fina da costa, começava a cair. Ele não sentiu frio. Sentiu, sim, o primeiro clique — baixo, dentro do próprio crânio — seguido de outro, e outro, e outro, numa contagem que não parava mais.

Não sabe se ainda respira. Não sabe se os ossos que arrumou na caixa de coleta na sexta-feira ainda são apenas amostras. Sabe apenas que o sambaqui entre Paraty e Ilha Grande continua crescendo, camada sobre camada, e que alguém precisa ocupar o lugar vazio do anel. O monte escolhe. O monte espera. E agora sabe o nome dele.

## Fontes de inspiração

- Revista Pesquisa FAPESP, "Pesca pré-histórica": mais de dois mil sambaquis conhecidos na costa brasileira; povos pescadores-coletores enterravam seus mortos em covas rasas cobertas por conchas e restos de peixe; sítios entre a baía de Ilha Grande, em Angra dos Reis, e a Ilha do Cabo Frio, em Arraial do Cabo, com idade de 5.600 a 700 anos.
- BBC News Brasil, "Sambaquis: as descobertas sobre as monumentais construções de 8 mil anos no litoral do Brasil": montes de até 40 metros de conchas, ossos, areia e terra; usados como marcadores territoriais, moradias, cemitérios e locais cerimoniais; construídos entre 8 mil e 2 mil anos atrás por povos sambaquieiros.

Nota: obra de ficção. Locais, personagens e eventos são inventados. As fontes servem apenas como ponto de partida atmosférico; nada aqui é apresentado como fato ou relato real.
