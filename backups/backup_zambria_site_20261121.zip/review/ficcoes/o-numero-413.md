---
titulo: "O Número 413"
resumo: "Um pesquisador encontra uma lacuna na numeração do Fundo OVNI do Arquivo Nacional e solicita o documento ausente pela Lei de Acesso à Informação. A resposta exime o Estado por exceção. No arquivo, o que falta costuma ser o que mais importa."
categoria: "conspiracos"
data: "2026-11-21"
slug: "o-numero-413"
tipo: "ficcao"
fonte_pesquisa: "gov.br (Arquivo Nacional — Fundo OVNI; Ministério da Defesa; ouvidorias.gov.br); opovo.com.br
---

Brasília, setembro. O subsolo do Arquivo Nacional cheira a papel velho misturado com ar-condicionado mal mantido. Marcos Varela conhece esse cheiro de cor. Vem de segunda, quarta e sexta, das dez às dezessete horas, ocupa a mesma mesa de consulta pública, coloca a caixa de luvas de nitrilo e lê. Lê o Fundo OVNI.

O Fundo OVNI — referência BR DFANBSB ARX — é o que restou da obsessão da Força Aérea Brasileira por objetos nos céus do país. Setecentos e cinquenta e oito documentos, de 1952 a 2016: questionários preenchidos à caneta, relatórios de controladores de voo, fotografias, recortes de jornal, gravações de rádio. O mais antigo mostra um objeto em formato de prato com cúpula sobre a Barra da Tijuca, no Rio de Janeiro, em 1952. O mais recente, de 2016, já não interessa a quase ninguém.

Varela não é ufólogo. É ex-assessor de gabinete na Câmara dos Deputados, tempo livre e uma obsessão profissional por burocracias. Descobriu o fundo por acaso, via Lei de Acesso à Informação — a LAI, Lei 12.527/2011. Desde então lê tudo, em ordem. Sabe o número de cada documento, a data, o remetente. Sabe que o Comando de Defesa Aeroespacial Brasileiro, o Comdabra, arquivava os avistamentos em Brasília antes de enviá-los ao Arquivo Nacional. Sabe que existiu o SIOANI, o Sistema de Investigação de Objetos Aéreos Não Identificados, criado em 1969, e que os militares tratavam o assunto com seriedade chata: sem exclamações, sem sensacionalismo de programa de TV, apenas formulários, assinaturas e tramitação.

E depois de setecentos e cinquenta e oito documentos lidos, Varela encontrou o buraco.

Na numeração sequencial do fundo, entre o documento 412 — o relato da Noite Oficial dos OVNIs, 19 de maio de 1986, vinte e um objetos rastreados no radar, jatos da FAB decolando em interceptação — e o documento 414, um questionário de um lavrador do Piauí assinado em 1989, deveria existir o documento 413. Não existe. Não está extraviado, não queimado, não guardado em outro porão. O número 413 nunca foi registrado. Nunca apareceu em nenhum inventário.

Para um homem que passa a vida lendo atas e portarias, isso é mais estranho do que qualquer disco voador.

Varela fez o pedido pelo e-SIC, amparado na LAI. Solicitou o documento 413 do Fundo OVNI. A resposta chegou em vinte dias úteis, assinada por um servidor cujo nome ele nunca vira antes: acesso negado. O documento, dizia a resposta, está classificado. Exceção. Prazo legal. A frase vinha copiada de uma nota do Ministério da Defesa de 2018, quando a pasta recebeu ufólogos e prometeu tornarem públicos todos os documentos militares sobre OVNIs. "A regra geral é disponibilizar todos os documentos. Alguns casos ainda têm que obedecer ao prazo legal," disse na época Adriano Portella, diretor do Departamento de Organização e Legislação. Esse prazo acabou há anos. O documento 413 não saiu.

Varela recorreu. Recurso à Comissão de Reavaliação de Informações. A resposta voltou: não provido. Sem justificativa nova, sem número de processo, sem data para nova análise. A exceção, pelo jeito, é permanente.

Foi então que ele foi até o depósito físico, no subsolo. A prateleira com a etiqueta 413 existe. A caixa também existe, lacrada — mas o lacre está rasgado e recolado com fita de cor diferente. A caixa está vazia. Dentro dela, só um envelopinho marrom sem etiqueta e um recibo de transferência assinado por alguém cuja assinatura Varela não reconhece.

Um funcionário mais velho da sala de conservação o observou da porta. Não disse nada no início. Quando Varela fechou a caixa, o homem falou baixo:

— Nem todo número tem um documento, senhor Varela. Alguns números são apenas marcas de onde algo foi retirado. É melhor não pedir o que não tem número.

Varela saiu do arquivo naquela tarde com uma constatação fria. A transparência do Estado não é o oposto do sigilo; é a própria forma como o sigilo se mantém. Liberam setecentos e cinquenta e oito documentos para satisfazer a curiosidade pública, preenchem o Arquivo Nacional com papéis inofensivos, e mantêm o que importa sob a cláusula de exceção, por tempo indeterminado. Os documentos publicados são o ruído. Os documentos ausentes são o sinal.

No dia seguinte, Varela protocolou outro pedido de acesso. Não perguntou pelo documento 413. Pediu a relação completa de todos os números ausentes do Fundo OVNI. Sabe que a resposta já está escrita. Sabe que será negada, novamente por exceção. Enquanto isso, continua indo ao subsolo às segundas, quartas e sextas, senta na mesma mesa, lê os setecentos e cinquenta e oito documentos que lhe entregaram, e se pergunta — como se pergunta qualquer pessoa que passa muito tempo lendo o que o Estado decidiu mostrar — o que está escrito no número 413, e por que alguém se deu ao trabalho de apagar o número antes de apagar o documento.

## Fontes de inspiração

- Arquivo Nacional (gov.br) — Fundo Objeto Voador Não Identificado (BR DFANBSB ARX), 758 documentos de 1952 a 2016, relativos a avistamentos de OVNIs nos céus brasileiros.
- Ministério da Defesa (gov.br) — reunião de 2018 com ufólogos sobre desclassificação de documentos militares sobre OVNIs sob a Lei de Acesso à Informação.
- Ouvidorias.gov.br — transferência de documentos de OVNIs do Comando da Aeronáutica para o Arquivo Nacional; existência do SIOANI.
- O Povo (opovo.com.br) — SIOANI e a Noite Oficial dos OVNIs (1986), com rastreamento de objetos no radar e interceptação de jatos da FAB.
