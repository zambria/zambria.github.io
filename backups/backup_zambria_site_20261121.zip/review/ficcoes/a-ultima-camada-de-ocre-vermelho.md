---
titulo: "A Última Camada de Ocre Vermelho"
resumo: "Uma técnica de fotogrametria descobre, nos paredões da Serra da Capivara, uma figura pintada que não pertence ao milênio em que foi feita — e percebe que a pedra está observando de volta."
categoria: "arqueologia"
data: "2026-11-21"
slug: "a-ultima-camada-de-ocre-vermelho"
tipo: "ficcao"
fonte_pesquisa: "Senado Federal (reportagem sobre a Serra da Capivara), UAI (pinturas de 25 mil anos no Piauí), CNN Brasil (pigmentos e técnicas das pinturas rupestres)"
---

A calça de campanha de Elena ainda cheirava a enxofre do fogareiro quando ela encostou o ombro na parede de arenito do Abrigo 14 e viu, pela primeira vez, o pulso.

Não era um pulso qualquer. Era o pulso de uma figura humana pintada em ocre vermelho sobre a rocha, cerca de dez mil anos antes de existir o conceito de relógio de pulso — ou, pelo menos, esse era o consenso que ela tivera de decorar para as visitas de turistas no Centro de Visitantes do Parque Nacional da Serra da Capivara.

Elena de Coimbra, vinte e nove anos, técnica de fotogrametria do projeto de documentação do sítio, não era dada a superstições. Passara os últimos dezoito meses agachada em abrigos rochosos do sul do Piauí, traçando malhas de pontos sobre imagens de paredões, registrando caças, danças, partos e o famoso beijo de doze mil anos que alguém, algum dia, decidiu imortalizar em hematita e resina de jatobá. Conhecia a rotina: acordar antes das cinco, carregar tripé, escala de cor e gerador até o abrigo do dia, fotografar cada centímetro quadrado de pintura sob luz controlada, voltar para a base de São Raimundo Nonato antes que o sol transformasse a caatinga em forno.

O Abrigo 14 não constava nos mapas oficiais. Aparecera nos registros como um sítio "de difícil acesso, pendente de revisão", o que em linguagem de arqueologia de campo significa que ninguém queria subir aquelas rochas de novo. Elena subiu porque o coordenador — um homem que fala de Clóvis e do Estreito de Bering como se fossem inimigos pessoais — precisava de alguém que não reclamasse de escorpião na bota.

Era a quarta tarde no abrigo quando ela viu o pulso.

Sobre um painel de onze metros — veados em fuga, grupos em fila, o vermelho-sangue já desbotado pela chuva e pelo tempo — havia uma figura isolada, perto da borda direita, com o braço esquerdo erguido e, no pulso, um círculo perfeito de ocre escuro com um ponto no centro. Um relógio. Ou algo que Elena, com seu viés do século XXI, insistia em ler como relógio.

Ela fotografou. Fez a sobreposição das imagens. Esperou o dia seguinte.

Quando voltou ao abrigo às seis da manhã, o círculo no pulso ainda estava lá — mas o braço da figura havia se movido cerca de cinco centímetros. A mão, antes aberta, agora segurava algo longo e fino que não aparecera na foto de véspera. Um bastão? Um fuzil? Não importava: a pintura não se move sozinha. Areia não sobe sozinha por uma parede vertical. Ocre não reaplica sobre ocre durante a noite sem deixar borda, sem deixar uma camada de separação visível ao microscópio.

Elena ficou ali uma hora inteira, de joelhos na poeira, olhando para aquilo que não devia existir. A caatinga lá fora estava quieta demais. Mesmo os pássaros haviam sumido.

Ela começou a fazer uma coisa que nunca fizera antes: fotografou o mesmo painel a cada duas horas. Ao anoitecer, a diferença era inconfundível. A figura tinha virado a cabeça. Agora olhava diretamente para o ponto onde Elena ficara em pé na primeira foto.

Na base, o coordenador riu — um riso seco, de quem já ouvira demasiadas teorias sobre alienígenas na Pedra Furada e não tinha paciência para mais uma. "Pareidolia", disse. "Umidade. Lichens. Sua cabeça preenche o que o olho não consegue ler. São dez mil anos de tinta, Elena, não um filme de terror."

Ele estava errado, mas Elena deixou passar. Não era sua função convencer o coordenador. Sua função era documentar.

Foi então que encontrou o caderno de campo de um técnico anterior, lotado no mesmo projeto em 2008, esquecido dentro de uma caixa de equipamentos do abrigo de apoio. As anotações paravam abruptamente na página 37:

> Parece que a pedra adiciona traços novos quando ninguém olha. Não consigo datar a camada superior: o carbono-14 dá idade moderna para tinta que está sobre pigmento de dez milênios. Pediram minha saída do sítio. Eu peço a mesma coisa para quem ler isto: não durma com o olhar virado para a parede. Ela está de olho aberto.

A assinatura era ilegível. A data: três dias antes de o técnico ser demitido por "abandono injustificado de campo".

Elena leu aquilo três vezes. Na terceira, notou que a tinta da última frase havia borrado, como se alguém tivesse passado o dedo sobre a página enquanto a caneta ainda estava úmida. O caderno estava fechado dentro de uma caixa lacrada.

Ela não dormiu naquela noite. Ou, melhor: dormiu, e sonhou com paredes de arenito quente, com o cheiro de terra molhada que não vinha de lugar nenhum — porque naquela época do ano não chovia na Serra da Capivara há meses.

No dia seguinte, ela voltou ao abrigo com a câmera na mão antes do sol nascer. A figura do pulso não estava mais sozinha. Do lado esquerdo do painel, onde na véspera havia apenas uma mancha de lichen branco, surgira uma segunda figura: deitada, o braço esquerdo estendido em direção ao centro da rocha, as pernas dobradas como se estivesse caindo para dentro da pedra. Elena reconheceu a pose. Era a dela própria, da tarde anterior, deitada no chão do abrigo para fotografar um detalhe no nível do solo.

A roupa batia. A fivela do cinto batia. O fio do fone de ouvido pendendo do ombro esquerdo batia.

Ela tirou a foto. Tirou dez. Em todas, a figura estava lá. E em todas, nos cantos superiores do painel, pequenos pontos vermelhos haviam aparecido — como se alguém, do lado de fora da rocha, estivesse jogando gotas de tinta em direção a ela.

Elena fechou o equipamento. Empacotou o tripé, a escala de cor, o gerador. Não falou com o coordenador. Não deixou bilhete. Só queria descer daquela serra e nunca mais olhar para um paredão de arenito.

Na mochila, ao abrir para guardar o notebook, encontrou uma lasca de arenito pequena, úmida, cheirando a terra de caatinga depois de chuva — embora não tivesse chovido, embora o abrigo estivesse seco, embora a lasca não houvesse estado lá quando ela fechara a mochila na noite anterior.

Ela pegou o caderno de campo, a página em branco de hoje, e passou a caneta. Não riscou nada. Ao virar a página, havia ali um traço de ocre vermelho, úmido, ainda brilhando, que ela não tinha feito. O traço começava na margem e subia pela folha, como se a mão que o traçara estivesse do outro lado do papel.

A Serra da Capivara guarda mais de mil sítios arqueológicos, e mais de seiscentos deles contêm pinturas. Alguns registros têm vinte e cinco mil anos. Outros, dizem pesquisadores, podem chegar a cinquenta e nove mil. O debate científico continua: quem chegou primeiro, quando, por onde. Datações de carbono-14, fogueiras antigas, ferramentas líticas. Tudo isso importa muito para quem quer escrever livros. Para quem fica sozinho com a pedra, importa menos.

O que importa é isto: a pintura não registra o passado. Ela anuncia. E quem passa tempo demais encarando a parede acaba virando parte da próxima camada.

Elena não saiu do Abrigo 14. Pelo menos, não saiu inteira. Se você for até lá — não vá, mas se for — e olhar com atenção para o painel direito, perto da borda, verá uma figura nova que não consta nos relatórios de campo: uma mulher de calça de campanha, braço esquerdo erguido, e no pulso um círculo de ocre escuro com um ponto no centro. Olhando direto para você.

E se esperar o suficiente, sem piscar, verá o círculo começar a girar.

## Fontes de inspiração

- Senado Federal — "O Brasil pré-histórico: tesouros arqueológicos da Serra da Capivara" (reportagem sobre o parque, as pinturas rupestres e as pesquisas de Niède Guidon).
- UAI — "Pinturas de 25 mil anos: o destino no sertão piauiense que se tornou o maior tesouro arqueológico do Brasil" (sítios arqueológicos, datações e reconhecimento pela UNESCO).
- CNN Brasil — "Técnica que preservou pinturas rupestres de 12 mil anos no Piauí utilizava uma mistura de vermelho-sangue e resina de jatobá" (pigmentos de hematita e aglutinantes usados nas pinturas).
