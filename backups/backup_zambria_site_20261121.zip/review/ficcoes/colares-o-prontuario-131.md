---
titulo: "O Prontuário 131 — Colares, 1977"
resumo: "Em 1977, luzes sobre a ilha de Colares queimaram a pele de dezenas de pessoas. Três décadas depois, a filha de uma das vítimas encontra um prontuário militar com seu nome e uma lacuna de memória que ninguém quis preencher."
categoria: "ufos"
data: "2026-11-21"
slug: "colares-o-prontuario-131"
tipo: "ficcao"
fonte_pesquisa: "Wikipedia — Operação Prato; CNN Brasil — documentos sobre interesse do Pentágono/BAASS no caso Colares (2009); O Antagonista — registros da missão da FAB no Pará
---

# O Prontuário 131

O relógio de parede da cozinha marcou três horas e dezessete minutos quando encontrei o envelope. Não era carta, nem telegrama, nem qualquer coisa que eu esperasse encontrar entre os papéis do pai depois de seu enterro. Era um prontuário médico da Força Aérea Brasileira, com o carimbo do I COMAR de Belém, datado de 21 de outubro de 1977. No cabeçalho, o nome de minha mãe, Tereza, então com dezenove anos. O diagnóstico ocupava duas linhas: "Queimadura eritematosa, região torácica esquerda. Duas marcas pontuais em alinhamento vertical." Abaixo, uma observação de próprio punho, assinada por um capitão cuja letra nunca vira antes: "Paciente apresenta lacuna de memória do episódio. Recomenda-se observação por setenta e duas horas."

Setenta e duas horas. Três dias da vida de minha mãe apagados do próprio corpo, registrados em tinta militar e arquivados como se não importassem.

Colares é uma ilha de pescadores na foz do Amazonas, no Pará, e no fim de 1977 seu céu deixou de ser apenas cenário para se tornar palco. Moradores ribeirinhos relataram luzes que desciam baixas sobre as casas e os igarapés, feixes estreitos que alcançavam as pessoas no peito ou no pescoço, deixando queimaduras, fraqueza, tontura e a sensação súbita de ter sido esvaziada de algo que nunca mais voltaria. A população apelidou o fenômeno de chupa-chupa — não por brincadeira, mas porque acreditavam que a luz estava drenando o sangue, a energia, a memória.

Eu nasci em 1980, três anos depois de a Operação Prato encerrar seus trabalhos na ilha. Nunca ouvi minha mãe falar daquelas noites. Não era esquecimento: ela simplesmente não sabia que algo faltava. Cresci sob um silêncio liso como pedra de rio, e só aos quarenta e dois anos, empurrando gavetas velhas da escrivaninha do pai, deparei com o envelope que a Aeronáutica havia deixado para trás.

A primeira coisa que fiz foi procurar o nome dela nos relatórios publicados. A força aérea registrou cento e trinta observações entre 1977 e 1978, oitenta e duas delas em mil novecentos e setenta e sete, quarenta e oito em mil novecentos e setenta e oito. Cada entrada trazia data, horário, direção estimada, cor do objeto, nome da testemunha. O nome de Tereza não aparecia em nenhuma. Havia cento e trinta casos, e o dela seria o cento e trinta e um — o caso que nunca entrou no diário de bordo.

Não que isso a surpreendesse, suponho. Minha mãe sempre dizia que dormia profundamente naquela época, que acordava cansada mesmo depois de doze horas de cama, que o quarto às vezes ficava claro demais às três da manhã, como se a lua tivesse decidido entrar pela janela sem pedir licença. Meu pai ria e atribuía ao reflexo da água no rio. Ninguém acendia fogueira no quintal. Ninguém soltava foguete para espantar o céu, como faziam os vizinhos nas noites de outubro.

Viajei para Colares em um novembro abafado, trinta e cinco anos depois dos fatos. A ilha continua do mesmo tamanho, a mesma poeira de estrada batendo nas pernas, o mesmo cheiro de maresia misturado a peixe seco. Fui até a casa onde minha mãe morava, agora ocupada por uma viúva de pescador que me recebeu com café forte e desconfiança. Perguntei se ela lembrava das luzes de mil novecentos e setenta e sete. A mulher olhou para a janela, fechou as cortinas devagar e disse que lembrava de tudo — e que, por isso mesmo, preferia não falar.

Saí andando pela orla no escuro. O rio Pará é largo, escuro, impaciente. Na água, reflexos de lanternas de barcos que não chegam a lugar algum. Sentei em um banco de madeira e esperei. Nada apareceu. Ou talvez tenha aparecido e eu não soubesse distinguir uma estrela de um corpo luminoso, um satélite de algo que não vem de nenhum satélite. Foi nesse momento que entendi o ponto do prontuário: não era para provar o que aconteceu. Era para registrar que algo aconteceu e, ao mesmo tempo, negar que tenha ocorrido. Duas marcas no peito, uma lacuna de memória, um relatório arquivado. O sistema funciona assim — documenta o suficiente para acalmar os nervos, mas nunca o suficiente para fazer alguém dormir tranqüilo de novo.

Procuramos a doutora que atendeu os feridos na época. Já não está mais na ilha, disseram. Morou em Belém, depois mudou para longe. Deixou, no entanto, depoimentos: tratou dezenas de pessoas com queimaduras parecidas com marcas de agulha, mulheres em sua maioria, marcas no seio esquerdo, mancha marrom como de iodo. Nenhum exame laboratorial conseguiu explicar a origem. Nenhum oficial da Aeronáutica voltou para dizer o que aquelas luzes eram. Anos depois, soube por um documento de jornal que o Departamento de Defesa dos Estados Unidos também se interessou pelo caso — em dois mil e nove, uma equipe discreta desembarcou no norte do Brasil, instruída a não chamar atenção. Também não trouxe respostas públicas.

Voltei para casa com o envelope sob o braço e uma certeza fria: minha mãe não perdeu sangue naquela noite de outubro. Perdeu a própria lembrança do que lhe fizeram. E talvez eu também tenha perdido algo, crescendo ao lado de uma mulher que dormia com um medo sem nome, um medo que ela não conseguia nomear porque a memória havia sido entregue a um capitão da Aeronáutica e nunca mais devolvida.

Hoje, quando apago a luz da varanda, mantenho os olhos na linha escura do horizonte sobre a água. Às vezes, algo passa ali — silencioso, sem barulho de motor, sem luz de navegação. Não é estrela, não é avião. É apenas o céu de Colares fazendo o que sempre fez: observar, e deixar que ninguém prove nada.

O arquivo está fechado. Mas o céu de Colares não fecha nada.

## Fontes de inspiração

- Wikipedia — Operação Prato (investigação da FAB sobre OVNIs em Colares, Pará, 1977–1978; fenômeno conhecido como chupa-chupa; 130 observações registradas).
- CNN Brasil — documentos revelando o interesse do Pentágono, via empresa BAASS, no caso Colares em 2009.
- O Antagonista — registros da missão secreta da Aeronáutica na Amazônia e depoimentos de moradores sobre as luzes.

Todos os nomes, personagens e eventos narrados são fictícios; os fatos históricos citados servem apenas como inspiração para a ficção.
