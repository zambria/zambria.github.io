---
titulo: "A Seca que Trouxe Vozes"
resumo: "Na seca de noventa e sete, o açude secou e o lamaçal devolveu ossos e vozes que ninguém deveria ouvir. Dezesseis anos depois, o nível baixa de novo e o que ficou embaixo do barro começa a responder."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "a-seca-que-trouxe-vozes"
tipo: "ficcao"
fonte_pesquisa: "PMC/Frontiers in Behavioral Neuroscience (estudo de infrassom e afeto humano); Olhar Digital (povoado de Canudos submerso pelo açude Cocorobó)"
---

# A Seca que Trouxe Vozes

O açude secou pela segunda vez na vida de Marcola. Na primeira, em noventa e sete, ele tinha doze anos e assistiu o lamaçal devolver o que a água havia engolido: tijolos de uma casa que não existia mais, um tanque de lavar roupa ainda preso à parede de um quarto desabitado, e o crânio de uma criança com os dentes intactos, virado para o céu como se pedisse desculpa por estar ali. Na segunda, o nível baixou mais devagar, como se a terra tivesse aprendido a reter o que restava, e foi então que o som começou.

Não era barulho. Barulho se ouve com o ouvido. Isso Marcola sentiu no peito, nos dentes, na ponta dos ombros — um zumbido baixo, contínuo, abaixo do limiar do que o ouvido humano consegue captar. O vento varria as rachaduras do barro seco, passava por fendas entre pedras semienterradas, e produzia uma frequência que não tinha nome para os ouvidos, mas tinha efeito no corpo: o peso no estômago, a irritação sem motivo, a certeza vaga de que alguma coisa observava do fundo do poço vazio.

Marcola morava na vila nova, erguida depois que o governo deslocou as famílias do leito alagado, mas voltara ao açude para fiscalizar o restante de lama sob contrato da prefeitura. Tinha passado os últimos dezesseis anos evitando aquele lugar. Agora caminhava entre rachaduras em polígonos, poeira que subia em nuvem fina a cada passo, e ouvia vozes.

No começo pensou que eram os outros funcionários, ou o rádio de alguém acampado na borda. Depois percebeu que as vozes vinham de baixo do barro, de dentro das fendas onde a umidade ainda não havia escapado. Chamavam pelo nome dele. Chamavam pela voz de Ana, sua mulher, afogada ali quando o açude ainda era açude de verdade, antes da seca de noventa e sete, antes de o povoado velho ser coberto pela barragem e as pessoas serem levadas para longe como se nunca tivessem existido.

O povo da vila nova chama aquilo de defunta do barro. Dizem que em noite de lua murcha dá para ouvir alguém coxixando na beira seca, e que ninguém se senta ali, nem por reza, nem por coragem besta. Marcola nunca acreditara em defunta. Acreditava em barragem, em laudo técnico, em nível de reservatório. Agora acreditava no zumbido, porque o zumbido não mentia: ele estava ali, abaixo de vinte hertz, abaixo da audição, e fazia o corpo reagir antes que a mente entendesse o que estava acontecendo.

Há pesquisas que tratam disso. Estudos recentes expuseram pessoas a sons abaixo do limiar da audição, dezoito hertz, imperceptíveis ao ouvido, e mediram o que acontecia depois: cortisol mais alto na saliva, irritação, desinteresse, tristeza. O ouvido não capta, mas o organismo responde. É uma espécie de pressão invisível que imita o medo sem entregar sua origem. Marcola leu algo assim numa reportagem velha, ou ouvira o irmão dizer — não importava a fonte. Importava que o fenômeno tinha nome e que o nome não salvava ninguém.

Ele levou um gravador ao leito seco. Deixou o aparelho ligado durante a noite, microfone voltado para as rachaduras do barro. Na manhã seguinte, a fita não continha nada além do sopro do vento. Quando acelerou a reprodução, no entanto, ouviu o próprio nome dito por uma garganta que não tinha pulmões, e depois o sussurro de Ana, com o mesmo tom de quem fala debaixo d'água: cheio, pesado, distante. Marcola desligou o gravador e não o ligou de novo.

Na terceira noite, as vozes pararam de chamar de baixo do barro e passaram a vir de dentro da cabeça. Não eram mais sussurros. Eram conversas inteiras, discussões antigas que ele e Ana haviam tido quando o açude ainda cobria o povoado, palavras que só os dois conheciam. Algo embaixo do barro não apenas imitava vozes. Algo as havia aprendido, durante décadas debaixo d'água, e a seca era a primeira oportunidade em dezesseis anos de chegar até quem morava em cima.

Marcola desceu até o ponto mais profundo do leito, onde a lama rachada formava um funil natural. Lá, o zumbido era forte o suficiente para fazer a visão tremer. Ele viu pegadas na lama — não humanas, não de animal conhecido — que saíam do funil e seguiam em direção à vila nova, parando a cada poucos metros como se quem as tivesse deixado estivesse aprendendo a andar novamente.

Foi então que entendeu. A seca não havia trazido as vozes. A seca apenas parou de afogá-las. Enquanto o açude esteve cheio, o que quer que estivesse embaixo do barro ficou preso, impossibilitado de usar a garganta, impossibilitado de sair. Agora, com o leito exposto, as vozes eram iscas, e as pegadas eram prova de que algo estava saindo.

A chuva voltou duas semanas depois. O nível do açude subiu, as rachaduras se fecharam, as ruínas do povoado velho sumiram debaixo da água mais uma vez. Marcola mudou-se para a cidade e não voltou. Mas às vezes, em noites de lua murcha, ele sonha com o som baixo no peito, e acorda com a certeza de que algo está do lado de fora da janela, esperando a próxima estiagem para aprender a falar com a voz dele.

## Fontes de inspiração

Estudo sobre infrassom e afeto humano (Frontiers in Behavioral Neuroscience, indexado no PMC): frequências abaixo de 20 hertz, imperceptíveis ao ouvido, associadas a elevação de cortisol, irritação e tristeza em ouvintes que não sabiam estar expostos.
https://pmc.ncbi.nlm.nih.gov/articles/PMC13158192/

Reportagem sobre o povoado de Canudos, destruído na guerra de 1897, reconstruído e depois submerso pelas águas do açude Cocorobó, na Bahia, com ruínas que reaparecem em períodos de estiagem.
https://olhardigital.com.br/curiosidades/2026/11/12/um-povoado-brasileiro-foi-destruido-por-uma-guerra-reconstruido-e-depois-desapareceu-outra-vez/

Nota do autor: todos os nomes, lugares e eventos desta história são fictícios. As fontes acima servem apenas de inspiração atmosférica; nenhum trecho delas foi copiado.
