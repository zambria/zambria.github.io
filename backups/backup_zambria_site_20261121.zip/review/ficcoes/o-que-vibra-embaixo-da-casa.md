---
titulo: "O Que Vibra Embaixo da Casa"
resumo: "Um engenheiro acústico é contratado para medir um zumbido inaudível que atormenta moradores de Pedra Seca; o som, porém, não vem de fora — está afinado ao corpo de quem escuta."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-que-vibra-embaixo-da-casa"
tipo: "ficcao"
fonte_pesquisa: "Zumbido de Taos / The Hum (em.com.br, portal6.com.br); estudo de infrassom de 18 Hz e cortisol (Frontiers in Behavioral Neuroscience, via DW e G1)"
---

# O Que Vibra Embaixo da Casa

Mauro Lorca chegou a Pedra Seca num ônibus que não voltaria até o dia seguinte. Desceu sozinho no terminal de pedra lascada, sob um céu cinza de interior mineiro, com a mala de equipamentos de medição aos pés e uma carta da prefeitura pedindo que descobrisse, em duas semanas, o que exatamente os moradores do bairro da Serra ouviram nas paredes de suas casas à noite.

Chamavam de "o zumbido". Não era o mesmo para todos: uns descreviam um motor de geladeira velho, outros um avião parado nas nuvens, a maioria um ronco grave, contínuo, que não diminuía quando tapavam os ouvidos. A prefeitura havia recebido dezenove reclamações formais, todas de pessoas que dormiam mal, acordavam com dor de cabeça e a sensação de pressão nos tímpanos, como se descessem rápido demais em um elevador. O prefeito queria um laudo. Mauro queria o pagamento adiantado, que recebeu.

A primeira casa foi a da senhora Alzira Mendes, viúva, aposentada, dono de um cachorro que havia parado de latir no exato dia em que o zumbido começou. Mauro instalou o microfone de medição no canto do quarto, onde o som era mais forte segundo ela, e ligou o analisador de espectro. Vinte hertz, cem, dois mil: nada fora do padrão. Silêncio limpo, cidade morta. Então ele baixou a faixa de análise abaixo dos vinte hertz, território do infrassom — o som tão grave que o ouvido não o registra como som, embora o corpo ainda o sinta. Apareceu um pico em torno de sete ponto oito hertz, constante, vindo do assoalho. Não era audível. Era vibração.

Visitou mais seis casas. Mesmo padrão. Só uma minoria ouvia — dois em cada dez, conforme a estimativa para fenômenos como esse relatados em Taos, Bristol e Windsor, lugares distantes com queixas idênticas: ronco de baixa frequência, fonte invisível, aparelhos que não detectam nada. Em Pedra Seca, a prefeitura já havia chamado eletricista, encanador e até um padre. Nenhum encontrou fonte. Nenhum saiu do prejuízo.

Mauro começou a duvidar dos próprios equipamentos, não das pessoas. Até que, numa noite de chuva fina, ele próprio ouviu. Não nos ouvidos: no esterno. Um pulsar lento, vindo de baixo da cama do hotel, sincronizado com nada. Dormiu três horas. Acordou com zumbido nos ouvidos e a certeza de que algo estava ouvindo de volta.

Foi até a borda da cidade, onde fica a mina de ferro desativada, fechada em 1974 depois de um desabamento que matou catorze mineiros. Oficialmente, o poço de ventilação foi selado com concreto armado por questão de segurança. Extra-oficialmente, ninguém na prefeitura quis assinar o laudo de vistia dos últimos dez anos. Mauro encontrou um tubo de ventilação parcialmente aberto, largado entre mato e entulho. Desceu um gravador por um fio de aço, deixou quarenta minutos rodando, puxou de volta.

Ouviu a fita no quarto, fones nos ouvidos, volume alto. Não havia vento, não havia goteira, não havia maquinário. Havia um pulso rítmico, lento, não mecânico, não geológico. Respiração de pedra. A frequência coincidia com a dos quartos da Serra. Com a de seu próprio peito.

A partir daí, o zumbido não parou mais. Acompanhou Mauro ao supermercado, ao banheiro, ao silêncio absoluto do quarto às três da manhã. Tampou os ouvidos com cera de parafina: o som estava dentro. Passou a sonhar com algo arranhando debaixo do assoalho, unhas em concreto, paciência de décadas.

Nos arquivos da câmara, em uma pasta amarelada que ninguém pediu para ele ler, encontrou a ordem de selamento de 1974. Não assinada pelo engenheiro de segurança, mas por um prefeito cujo nome não constava nos registros oficiais. O trecho relevante tinha uma linha só: "A emissão sonora deve ser mantida. O selo é o som." Não havia explicação. Não precisava. O som não era um sintoma. Era a contenção. Uma frequência mantendo algo abaixo, quieto, esperando que alguém com ouvido afinado fosse bastante toco para medir.

Mauro mediu. Gravou. Amplificou. Afiou o instrumento à mesma ressonância de baixo. O som não saiu do poço. Entrou nele. Agora ele é um dos que ouvem, e ouvir deixou de ser opção.

Na última noite em Pedra Seca, o zumbido sumiu. Alívio momentâneo, quase alegria. Mauro deitou no escuro, agradeceu o silêncio, fechou os olhos. Então sentiu a vibração nas costelas, mais lenta que seu coração, sincronizando com ele. Algo estava afinando-se a Mauro. Quando o bater do seu coração diminuir o suficiente para encontrar o ritmo de baixo, não haverá mais diferença entre o ouvinte e o som. Pedra Seca terá mais um morador que não consegue dormir — mesmo depois de morto.

## Fontes de inspiração

- Reportagens sobre o "Zumbido de Taos" ou "The Hum": fenômeno de baixa frequência (cerca de 30–80 Hz) ouvido apenas por uma parcela da população, persistente, mais forte em ambientes internos, sem fonte identificada por equipamentos de medição (em.com.br; portal6.com.br).
- Estudo publicado na Frontiers in Behavioral Neuroscience sobre infrassom (~18 Hz): efeitos fisiológicos como elevação de cortisol, irritabilidade e tristeza, mesmo quando o som não é detectado conscientemente (reportado por DW e G1).

A ficção acima reinterpreta esses fenômenos; não apresenta eventos reais nem pessoas reais de Pedra Seca, cidade inventada para os efeitos desta narrativa.