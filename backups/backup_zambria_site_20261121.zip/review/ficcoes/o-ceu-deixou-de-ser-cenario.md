---
titulo: "O Céu Deixou de Ser Cenário"
resumo: "Um operador de drone grava algo que não deveria estar no céu do interior de Minas Gerais e descobre que voltar para casa não significa ter ficado inteiro."
categoria: "ufos"
data: "2026-11-21"
slug: "o-ceu-deixou-de-ser-cenario"
tipo: "ficcao"
fonte_pesquisa: "Incidente de Varginha (1996) — Wikipedia e otherworlders.com; arquivos de OVNIs da FAB no Arquivo Nacional — G1 e O Globo (agosto de 2024)"
---

O céu de Minas Gerais nunca foi apenas céu para Raul Mendes, mas ele demorou anos para admitir isso. Até os trinta e quatro, tratava o firmamento como pano de fundo: azul opaco ao meio-dia, preto pontilhado à noite, algo que servia para ser atravessado pelo olhar e imediatamente esquecido. Piloto de drone amador, filmava fazendas, rebanhos e imóveis para corretores de uma cidade vizinha. Sua relação com o céu era técnica — altitude, vento, carga da bateria, linha de visão —, nunca poética.

Tudo mudou na noite de 14 de outubro.

Raul saiu sozinho, como fazia quase todo fim de semana, levando o drone para a serra fora da cidade, um trecho de estrada de terra onde a poluição luminosa ainda não chegara. O plano era simples: filmar o luar sobre as copas, testar um novo filtro de densidade neutra, voltar antes da uma da manhã. A decolagem foi às vinte e três e dez. O drone subiu, estável, e Raul manteve os olhos na tela do controle remoto.

Às vinte e três e quarenta e sete, algo entrou no quadro.

Não era avião: não tinha luzes de navegação, não emitia som que o microfone do controle captasse, e não voava em linha reta. A luz — branca, fria, sem fonte aparente — pairou acima da mata, desceu em linha vertical até cerca de vinte metros das copas, parou, e então mudou de direção em um ângulo que nenhuma aeronave conhecida consegue fazer sem se despedaçar. Raul seguiu o objeto com o drone. A imagem tremia. Nos últimos segundos antes de o sinal cortar, o aparelho capturou algo maior e escuro atrás da luz, sem contornos definidos, sem luzes de posição, pairando silenciosamente acima da copa das árvores.

O sinal sumiu às vinte e três e cinquenta e dois.

Raul ficou parado na estrada, mãos no controle, olhando para o céu vazio. Quando o drone retornou sozinho — ou quando Raul o encontrou, ele jamais soube dizer ao certo —, faltavam noventa e três minutos de voo que a bateria de lítio não explicava. O cartão de memória continha os minutos normais, exceto um arquivo corrompido entre vinte e três e quarenta e sete e vinte e três e cinquenta e dois. Raul abriu o arquivo num editor de vídeo. Vários frames estavam pretos. Alguns mostravam apenas árvores. Dois, talvez três, mostravam o corpo escuro pairando acima da mata, e em um deles, se Raul aproximasse o suficiente, pareciam ter olhos. Dois pontos vermelhos, pequenos, fixos nele.

Ele levou o drone para casa. Não contou a ninguém.

Na manhã seguinte, Raul acordou no sofá da sala com a televisão ligada num canal de ruído e não lembrava de ter subido as escadas, de ter tirado as roupas, de ter deixado o drone sobre a mesa. O relógio de pulso marcava dez horas. O celular, sobre o criado-mudo, estava desligado — bateria zerada, embora tivesse carregado na noite anterior. Sentiu uma dor latejante na base do crânio, atrás da orelha esquerda. Foi ao espelho. Ali, sob o cabelo, havia uma marca pequena, linear, de cerca de um centímetro, vermelha e inchada, como um corte muito fino que ele não se lembrava de ter feito. Não tinha machucado a cabeça. Não tinha batido em nada.

Foi o começo do que, em outros lugares e outras línguas, chamam de tempo perdido.

As semanas que vieram depois não foram de busca por respostas, mas de erosão. Raul passou a acordar com roupas que não lembrava de vestir, com areia nos sapatos — morava a cem quilômetros da praia mais próxima —, com a sensação física de que alguém havia estado em seu quarto enquanto ele dormia, ou dentro de seu corpo. Dormir virou um ato de coragem, depois um ato impossível. Cada vez que fechava os olhos, sentia o vazio: não escuridão, mas ausência, como se parte de sua consciência tivesse sido desligada e religada com peças trocadas. Começou a gravar áudio enquanto dormia. Ouviu-se, numa das fitas, falando sozinho numa língua que não reconhecia, por quase quatro minutos. Nunca aprendeu outra língua além do português.

Raul não é um homem dado a delírios. Não bebe, não usa drogas, não frequenta grupos de ufologia. Quando procurava respostas, foi para os arquivos oficiais, não para fóruns de internet. Descobriu que a Força Aérea Brasileira mantém registros de objetos voadores não identificados desde 1952 — cerca de oitocentos documentos, dois mil e quinhentas páginas, relatórios de pilotos, militares, lavradores e caminhoneiros, agora disponíveis no Arquivo Nacional, em Brasília. A Aeronáutica diz que não estuda o fenômeno, apenas cataloga e encaminha. Em outras palavras: o Estado brasileiro coleta histórias como a de Raul, arquiva-as em caixas e nunca pergunta o que aconteceu com as pessoas que viram.

Ele entrou em contato com um ufólogo aposentado em Campinas. O homem ouviu o relato, examinou o vídeo corrompido, e não disse que era um balão meteorológico. Não disse que era Vênus. Não disse nada. Pediu para Raul apagar o arquivo, esquecer a noite, seguir a vida. Quando Raul perguntou por quê, o homem olhou para o teto, como se esperasse algo cair dele, e respondeu apenas: "Alguns céus não perdoam quem olha de volta."

Raul não apagou o vídeo. Fez cópias. Enviou para endereços que não sabe se existem. Guardou o drone desligado numa gaveta, mas o aparelho, algumas noites, liga sozinho. A luz azul de standby pisca no escuro.

Agora, meses depois, Raul dirige pela estrada de terra com frequência. Não vai à serra para filmar. Vai para esperar. No mês passado, parou o carro no mesmo trecho, desligou o motor e olhou para cima. A luz branca voltou. Não desceu desta vez. Não fez manobras impossíveis. Simplesmente ficou ali, imóvel, observando-o de volta, como quem examina uma peça numa prateleira. Raul não sentiu medo. Só sentiu frio, um frio que começava atrás da orelha esquerda, naquela marca que não sumiu, e subia até o crânio.

É nessa hora que a constatação chega, fria e definitiva: eles não vieram buscá-lo para levá-lo a algum lugar distante. Vieram porque já estavam aqui. O céu deixou de ser cenário e se tornou palco, e Raul Mendes não é mais o espectador. Ele é parte do cenário agora — um objeto entre objetos, uma marca no mapa de alguém que não precisa pedir desculpas, e toda noite, quando apaga a luz do quarto, ele espera não acordar deitado no chão da sala, com areia nos sapatos e o céu vigiando através da janela.

## Fontes de inspiração

- Incidente de Varginha (1996), Varginha, Minas Gerais — relatos de avistamentos de criaturas e OVNIs, movimentação militar e a conclusão oficial dos militares de que as testemunhas confundiram um civil com um ser extraterrestre. Fontes: Wikipedia (en.wikipedia.org/wiki/Varginha_UFO_incident e pt.wikipedia.org/wiki/Incidente_de_Varginha) e otherworlders.com.
- Arquivos de OVNIs da Força Aérea Brasileira no Arquivo Nacional — cerca de oitocentos registros de fenômenos aéreos não identificados entre 1952 e 2023, transferidos à consulta pública; a Aeronáutica afirma que apenas cataloga e não analisa os relatos. Fontes: G1 (g1.globo.com) e O Globo (oglobo.globo.com), agosto de 2024.
