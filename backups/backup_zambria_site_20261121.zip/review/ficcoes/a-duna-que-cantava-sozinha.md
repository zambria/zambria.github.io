---
titulo: "A Duna que Cantava Sozinha"
resumo: "Uma bioacústica investiga uma duna dos Lençóis Maranhenses que, segundo o ICMBio, não deveria cantar — e grava um som que vem de debaixo da areia, sem vento, sem avalanche, e sem explicação."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "a-duna-que-cantava-sozinha"
tipo: "ficcao"
fonte_pesquisa: "BBC News Brasil, Revista Pesquisa FAPESP, relato de travessia dos Lençóis Maranhenses"
---

Elena Marra nunca havia pisado nos Lençóis Maranhenses para admirar a paisagem. Foi para verificar um boato.

Um ciclista publicou, num fórum de travessias, que uma das dunas do parque cantar. Não metáfora. Não o sussurro do vento entre as cristas de areia. Ele dizia que, ao descer uma encosta à noite, ouviu um som grave vindo do interior da montanha de areia — um ronco contínuo, como um violoncelo em ressonância, que duraria minutos e parava abruptamente. Procurou o ICMBio. Nenhum registro de dunas cantantes nos Lençóis. Nem nunca houve. A resposta oficial foi o silêncio burocrático de quem não quer abrir inquérito sobre fenômeno que não aparece nos mapas.

Elena é bioacústica. Seu trabalho é registrar sons que as pessoas não ouvem, ou que ouvem e preferem esquecer. Carregou um gravador de campo de quatro canais, microfones de contato, um sismógrafo de bolso e pouca água. Nomeou a duna de "Cinza" — sem nome oficial, sem coordenadas publicadas, apenas a aproximação do relato do ciclista, três dias de caminhada a partir do último apoio.

A ciência já sabe, mais ou menos, como as areias cantam. Em desertos de três dezenas de locais pelo mundo, algumas dunas emitem um ruído de frequência bem definida quando milhões de grãos deslizam em avalanche pelas encostas. Não é o ar comprimido entre os grãos. É o movimento coletivo, parcialmente sincronizado, que faz a superfície da duna vibrar como o cone de um alto-falante. Frequências entre noventa e cento e cinco hertz. Audível a quilômetros de distância, às vezes. Condições exigidas: areia seca, grãos de tamanho adequado, camada superficial com umidade controlada. Só cerca de dez por cento das dunas cantam. Cada uma, de um jeito diferente. É um problema não resolvido, dizem os físicos. Um mistério com equação inacabada.

A Duna Cinza cantou na primeira noite.

Elena provocou o desmoronamento sozinha, despejando areia da crista com uma pá de jardim. A camada escorregou e a duna ressoou: um baixo contínuo, oco, que demorou dois minutos e meio para morrer. Ela gravou. Analisou o espectrograma na tenda, ao lado de uma garrafa de água morna. A frequência estava em torno de noventa e dois hertz. Dentro do esperado. Natural. Seguro.

Na segunda noite, o vento soprou forte o suficiente para fazer a areia deslizar sozinha. A duna cantou de novo, dessa vez por quatro minutos, um barulho que ela sentiu nas costelas antes de ouvir. Elena deitou de ouvido no solo, com o microfone de contato preso à areia úmida perto da base. A vibração vinha da superfície, dos grãos caindo. Tudo dentro da explicação.

Foi na terceira noite que o problema começou.

Não havia vento. Não havia avalanche. Elena estava deitada, ouvindo a gravação do dia anterior em fones de ouvido, quando o som veio de fora. Do alto da duna, a poucos metros da tenda. Um tom grave, constante, sem começo nem fim perceptíveis. Não era o estalo granular das avalanches. Era uma nota sustentada, modulando sutilmente, subindo e descendo como uma respiração. Um sopro em cavidade imensa.

Ela saiu da tenda com o gravador na mão. A lua quase cheia banhava as dunas de branco. A Duna Cinza estava silenciosa aos olhos — nenhuma areia se movia, nenhuma sombra deslizava. Mas o som estava ali, preenchendo o espaço entre os montes de areia, vindo de baixo. Elena colocou o microfone de contato no solo e enterrou a ponta a cerca de trinta centímetros. A vibração não diminuía com a profundidade. Pelo contrário, ganhava corpo. Vinha de mais abaixo ainda, de algo com dois, três metros de areia por cima, como se o interior da duna fosse um órgão e o som fosse o ar saindo dele.

O sismógrafo de bolso não registrou tremor tectônico. Registrou pulsos rítmicos, lentos, quase perfeitos: um ciclo a cada quatro segundos, aproximadamente. Não era sismo. Era batimento.

Elena voltou ao acampamento e não dormiu. Acordou na manhã seguinte com a sensação de peso no peito, como se algo estivesse sentada sobre seu estômago, e o ouvido esquerdo zumbindo numa frequência que não correspondia a nenhum som externo. A areia da duna, examinada de perto à luz do dia, era quieta. Inerte. Quartzo acima de noventa e cinco por cento, grãos redondos, incoerentes ao vento. A duna não constava nos mapas do parque. Não existia, para o ICMBio, para os físicos, para ninguém além dela e do ciclista que talvez tivesse sonhado.

Ela resolveu ficar mais uma noite.

Na quarta noite, Elena não usou a pá. Não provocou nada. Deitou-se na crista da Duna Cinza, o ouvido direito pressionado contra a areia, o microfone de contato enterrado a meio metro de distância, o fone no ouvido esquerdo para monitorar em tempo real. Às três horas e dezessete minutos da madrugada, o canto começou. Sem aviso. Sem vento. Sem grãos caindo.

Ela acelerou a gravação em seguida. A nota contínua, quando desfragmentada, revelou padrões. Não palavras. Não língua humana. Mas cadência. Ritmo de inspiração e expiração. Algo, debaixo da areia, respirava. E algo ainda mais estranho: quando Elena segurava a própria respiração, o som da duna falhava, como se perdesse o fôlego junto com ela. Quando ela expirava, o tom subia um semitom.

Não era a duna que cantava.

Era o que estava enterrado debaixo dela, usando a areia como pulmão.

Elena passou a quinta noite acordada, ouvindo o zumbido dentro do crânio mesmo com o gravador desligado. A areia ao redor da tenda mudou de posição durante a noite — não muito, apenas o suficiente para formar uma depressão rasa aos pés da entrada, como se algo tivesse se aproximado enquanto ela dormia. Ela decidiu ir embora no dia seguinte. Pegou o laptop, exportou o espectrograma da última gravação, e ficou olhando para as três linhas de frequência que apareciam no gráfico.

Duas delas eram dela e da duna, sincronizadas em perfeita fase, como dois corpos respirando ao mesmo tempo. A terceira linha era mais baixa, mais antiga, e estava ali desde a terceira noite. Não parou quando ela desligou o gravador. Não parou agora, com o laptop fechado no colo e o silêncio da manhã maranhense lá fora.

Elena fechou os olhos e sentiu a areia dos Lençóis entrando pelos ouvidos, descendo pela garganta, se alojando nos alvéolos. O canto não precisava mais de duna. Não precisava de vento. Não precisava de Elena Marra para continuar.

Ela só precisava que alguém escutasse.

## Fontes de inspiração

- BBC News Brasil — reportagem sobre o físico francês que estudou as areias cantantes do deserto, o movimento sincronizado dos grãos e as condições que tornam o fenômeno possível (areia seca, grãos redondos, verniz mineral).
- Revista Pesquisa FAPESP — entrevista com físico sobre dunas da costa brasileira, incluindo Lençóis Maranhenses e Jericoacoara; o canto das dunas como som de avalanches de areia, fenômeno presente em apenas cerca de dez por cento das dunas, com explicação ainda não totalmente resolvida.
- Relato de travessia dos Lençóis Maranhenses — depoimento de ciclistas que ouviram uma duna cantar durante a travessia, som grave vindo do interior da areia, sem registro prévio junto ao ICMBio.

Todos os fatos acima serviram apenas como inspiração para esta obra de ficção. Personagens, locais específicos e eventos são criações do autor.
