---
titulo: "O Que Ainda Chama do Fundo"
resumo: "O vigia noturno da barragem de Furnas começa a ouvir seu nome vindo do fundo do lago, onde uma vila inteira foi submersa em 1963. Algo ficou enterrado debaixo d'água — e algo ainda não terminou de esperar."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-que-ainda-chama-do-fundo"
tipo: "ficcao"
fonte_pesquisa: "Lago de Furnas e Barra Velha submersa (G1, Brasil em Folhas, Revista Oeste, Olhar Digital)
---

# O Que Ainda Chama do Fundo

A primeira vez que Hélio ouviu o próprio nome sair da água, ele achou que fosse zumbido da turbina. Trabalha como vigia noturno na Usina Hidrelétrica de Furnas, no Sul de Minas, numa casinha de alvenaria a trezentos metros da comporta principal. O ofício é simples: andar pelo pátio, checar disjuntores, anotar o nível do lago no caderno de plantão e garantir que ninguém entre na área restrita depois das dezoito horas. O lago, que os moradores chamam de Mar de Minas, cobre mil e quatrocentos e quarenta quilômetros quadrados de vale antigo. Abaixo da superfície, de acordo com os jornais e com os mergulhadores que às vezes aparecem por ali, ruas inteiras, fogões a lenha, pontes, currais e até um ônibus permanecem conservados a quarenta, oitenta metros de profundidade. Tudo porque, em mil novecentos e sessenta e três, as comportas fecharam, as águas subiram e a antiga Barra Velha deixou de existir no mapa.

Hélio sabe dessa história há anos. O que ele não sabia — até a primeira semana de novembro, numa noite de estiagem severa — é que o lago devolve nomes.

O nível havia baixado o suficiente para revelar, nas margens de São José da Barra, marcas de túmulos e pedaços de rua que ninguém lia há mais de sessenta anos. Os jornais falam disso como curiosidade local, fenômeno natural da variação do reservatório, turismo mórbido de domingo. Hélio, que faz suas rondas com lanterna e crachá, ouviu o nome dele vindo da beirada da água às duas e dezessete da manhã. Não foi um grito. Foi uma fala clara, como se alguém estivesse a meio metro de seus ombros, falando baixo, com a voz úmida de quem fala debaixo d'água: *Hélio*.

Ele parou. Direcionou a lanterna para o lago. A superfície escura só refletia o poste do pátio. Deixou a luz se mover lentamente sobre a neblina que sobe do rio Grande quando a temperatura cai. Nada. Apenas o barulho constante das turbinas lá dentro, aquele ronco grave que vibra no peito e que, depois de anos, vira silêncio. Hélio voltou para a cabina de vigia, anotou no caderno: *Nível abaixo do normal. Nada anormal.* E tentou dormir.

A voz voltou na noite seguinte. E na outra. Sempre na mesma hora, sempre da mesma direção: do ponto onde o leito da antiga igreja de Barra Velha deveria estar, hoje submersa a uns noventa metros de profundidade, segundo os mapeamentos dos mergulhadores. Na terceira noite, Hélio já não estava sozinho na cabeça. Começou a sonhar com paredes de tijolo soterradas por lama e com o cheiro de umidade que não sai da roupa, não importa quantas vezes se lave. Nos sonhos, alguém caminha à sua frente no fundo do lago, com uma lanterna cuja luz não atravessa a água, e chama seu nome com a voz do próprio avô — o avô que fora vigio desta mesma barragem antes dele, e que pediu transferência para Ubá seis meses antes do enchimento, dizendo apenas que o vale *não estava vazio*.

Hélio nunca tinha ouvido essa história. O avô morreu quando ele tinha onze anos, e a família nunca falou do motivo da mudança. Até encontrar, numa caixa de ferramentas velha na cabina de vigia, um relógio de pulso parado nas quatro e dezessete da manhã, com a pulseira de couro apodrecida e a caixa de aço intacta, como se tivesse passado décadas protegida de algo. Dentro do relógio não havia mecanismo. Havia apenas um papelzinho, escrito com a letra trêmula de um homem idoso: *Não responda quando a água chamar seu nome. O que está embaixo não é gente afogada.*

Naquela mesma noite, Hélio decidiu descer até a borda do reservatório. A estiagem continuava. O nível do lago caíra o suficiente para expor, na lama, alicerces de pedras que não constam de nenhum projeto da usina. Estruturas mais antigas que a represa. Ele caminhou entre os blocos com a lanterna na mão, o calcanhar afundando no barro, até chegar a um ponto onde a água parava abruptamente, como se o leito terminasse em um desnível natural. Ali, na lama quase seca, algo brilhou.

Era uma fotografia. Um grupo de pessoas diante de uma casa de telhado alto, sorrindo para a câmera, sob um céu que não parecia ter pressa. No verso, a data: mil novecentos e cinquenta e oito. E um endereço: Rua do Ouvidor, Barra Velha. Hélio reconheceu o rosto do avô, mais jovem, ao lado de uma mulher que não era a avó dele. Uma criança no colo da mulher, segurando um brinquedo de madeira. A criança tinha os olhos de Hélio.

Ele voltou para a cabina com a fotografia embaixo do braço e passou a noite inteira olhando para ela. Às quatro e dezessete da manhã — a hora marcada no relógio parado — a água começou a bater nas paredes da casa de vigia. Não chuva. Não enchente. O lago, que ficava a trezentos metros, estava subitamente mais perto. Hélio saiu correndo, lanterna na mão, e viu o que não deveria estar lá: uma neblina espessa e escura, quase preta, rastejando sobre o solo seco entre a cabina e o reservatório, subindo em fina camada sobre as pedras, avançando em direção à casa como se tivesse peso e intenção. E dentro da neblina, luzes pequenas, amarelas, piscando como janelas de uma casa que não existia mais.

A voz não veio mais do lago. Veio de dentro da cabina, do corredor, do quarto atrás da porta de madeira que Hélio havia trancado com chave. Chamou seu nome com a voz da criança da fotografia. Chamou com a voz do avô. Chamou com a voz dele próprio, sussurrando do lado de fora da porta fechada: *Hélio. Abre. Está frio lá embaixo.*

Hélio ficou imóvel, encostado na porta, ouvindo as unhas — ou algo que funcionasse como unhas — arranharem a madeira de dentro para fora. Ele pensou nos mergulhadores que encontraram casas inteiras preservadas debaixo d'água, fogões ainda no lugar, camas arrumadas, ruas com calçamento visível a noventa metros de profundidade. Pensou que as águas de Furnas não cobriram uma cidade apenas para gerar energia. Coberturas são feitas para esconder corpos, e represas são feitas para manter níveis. O nível certa. A pressão certa. A profundidade certa para que o que mora no fundo não precise subir para respirar.

A estiagem terminou naquela semana. As chuvas voltaram, o reservatório encheu, e a neblina sumiu. O relógio parado continua na gaveta da cabina, marcado em quatro e dezessete. A fotografia também. Hélio ainda faz as rondas, anota o nível do lago, checa os disjuntores. Mas parou de ir até a beirada da água à noite. E, quando passa pelo pátio e ouve o ronco das turbinas, ele escuta por baixo do barulho algo mais antigo: o som de algo que aprendeu a nadar, e que agora sabe o nome de quem vigia a superfície.

Não responda quando a água chamar seu nome. O avô escreveu isso demais tarde para si. Hélio leu o bilhete depois que a primeira resposta já havia saído de seus próprios lábios, ainda que ele não se lembre de ter falado. Algo está embaixo. Algo não é gente afogada. E o lago, desse jeito calmo, desse jeito infinito, não é um cenário. É um palco. E a peça está prestes a recomeçar, com Hélio no elenco, seja ele vigia ou não.

## Fontes de inspiração

- Reportagens sobre a submersão de Guapé e de Barra Velha/São José da Barra com a formação do Lago de Furnas (represa de 1963), incluindo reaparecimento de túmulos e ruínas durante estiagens (G1, abril de 2026).
- Matéria sobre mergulhadores que mapeiam cidades submersas no Lago de Furnas, com ruas, casas, ponte, ônibus e Kombi preservados a dezenas de metros de profundidade (Brasil em Folhas, Revista Oeste, Olhar Digital, abril de 2026).

Todas as fontes acima serviram apenas como inspiração geográfica e histórica. A narrativa, os personagens e os eventos são ficcional.
