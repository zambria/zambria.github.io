---
titulo: "O Homem do Fundo da Foto"
resumo: "Um restaurador de fotografias antigas nota um desconhecido no fundo de cada imagem de uma mesma família ao longo de três décadas — e que ele ficou cada vez mais perto, até sair do quadro."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-homem-do-fundo-da-foto"
tipo: "ficcao"
fonte_pesquisa: "Fotografia espírita de William Mumler; história de Ouro Preto, Minas Gerais"
---

Arthur Moraes vive de devolver a imagem a coisas que o tempo roubou. No ateliê de fundo de casa, em Belo Horizonte, restaura fotografias antigas para colecionadores e herdeiros que não sabem mais quem são as pessoas sorrindo nos papéis amarelados. Seu ofício exige paciência, lente de aumento e uma certa frieza: não se afeiçoa a rostos. Um rosto, para ele, é mancha, prata, gelatina e poeira.

Na terça-feira em que tudo mudou, chegou um pacote de Ouro Preto sem remetente identificável, apenas o nome da cliente escrito a caneta: Lívia Varella. Dentro, cinquenta e três impressões em papel brometo, datadas entre 1942 e 1972, guardadas em envelopes de sulfite ressequidos. Fotos de família de uma casa de pedra na encosta de um morro da cidade histórica: casamentos, aniversários, formaturas, um batizado na Igreja de São Francisco de Assis. O trabalho seria rotineiro. Não foi.

Ao ampliar a primeira imagem — um grupo de sete pessoas no jardim, 1943 — Arthur percebeu um detalhe errado. No fundo, perto da grade de madeira da varanda, estava um homem. Roupas de corte antigo, calça com pregas, camisa de punhos longos, as mãos cruzadas atrás das costas. O rosto era pálido, os olhos fixos direto na câmera. Não parecia um parente: não sorria como os outros, não olhava para o lado, não fazia parte da composição. Estava simplesmente ali, como quem chega antes de todo mundo e decide ficar.

Arthur primeiro achou um estrago do papel, uma mancha de mofo ou um arranhão no negativo original. Mas a figura continuava ali em todas as cópias daquela sessão. E, quando abriu o segundo envelope, de 1948, encontrou o mesmo homem. Mesmo terno, mesma postura, mesmo olhar. Estava atrás da noiva, à esquerda do quadro, meio oculto por uma árvore pequena. Em 1952, ano em que o patriarca dos Varella, o senhor Antônio, morreu de um enfarte aos sessenta e quatro anos, o homem aparecia atrás do caixão — não no cortejo, não entre os enlutados, mas encostado na porta da casa, observando quem enterrava o dono do lar.

Foi então que Arthur notou o padrão. O homem não envelhecia. As fotos dos Varella cobriam trinta anos, e ele parecia o mesmo em todas: cerca de quarenta anos, cabelos escuros penteados para trás, traços nítidos como se tivesse sido impresso sobre cada imagem depois delas já existirem. Pior: ele estava se aproximando. Em 1943 ficava a metros do grupo, quase fora de foco. Em 1958, ao lado da mesa do aniversário da caçula, a menos de um metro dos convidados. Em 1963, em um negativo nunca revelado que Arthur encontrou sob umas das pastas, o homem tinha a mão no ombro da moça de dezenove anos, a filha mais nova de Antônio, e ela não se dava conta. O sorriso dela era o de quem posa sozinha.

Arthur passou semanas com aqueles papéis. Comparou negativos, verificou datas, procurou sinais de manipulação — dupla exposição, colagem, retocamento à mão. Nada. As impressões eram autênticas, os danos compatíveis com a idade, a química do papel inalterada. O homem simplesmente estava ali, em cada quadro, como parte da cena, e ninguém na família jamais o viu enquanto posava. Ou se viu, não quis dizer.

Ele rastreou os Varella. Antônio morreu em 1952, como dizia o registro. A esposa, Helena, morreu em 1969. Os três filhos cresceram, saíram de Ouro Preto. Sobrou Lívia, neta de Helena, moradora de Belo Horizonte, herdou as fotos e, segundo o bilhete dentro do pacote, queria que fossem restauradas "antes que sumam de vez". Arthur ligou para ela. A voz ao telefone era cautelosa, quase distante.

— O senhor conhece alguém chamado… não, não conheço — ela disse, quando ele descreveu o homem. — Minha avó nunca mencionou ninguém assim. Mas algumas fotos dela me incomodam. Sempre achei que era a má conservação do papel.

Arthur não contou tudo. Não contou que, nas noites seguintes, começou a sonhar com o corredor da casa de pedra, com os pés de alguém parando na porta do quarto enquanto ele dormia. Não contou que, ao revelar uma cópia de 1972 — a última da série, uma foto de Natal com dez pessoas ao redor de uma árvore artificial — o homem não estava mais no fundo. Estava ao lado de Lívia, então com cinco anos, a mão no ombro dela, o rosto recortado em foco perfeito, como se estivesse prestes a sair do papel.

Na semana seguinte, Arthur viajou a Ouro Preto. Queria ver a casa. Queria entender por que aqueles negativos guardavam um hóspede que não tinha direito de estar lá. A casa ainda existe, de pedra e cal, na encosta próximo à estação velha da ferrovia. Uma família diferente mora lá agora. O jardim da varanda foi cercado, a grade de madeira sumiu, mas o ângulo é o mesmo. Arthur montou sua câmera de formato médio, uma Rolleiflex antiga que ainda carrega filme de 120, e apontou para o mesmo ponto do jardim onde, em 1943, o grupo dos Varella posou sob o sol de Minas.

Esperou a luz certa. Fez a foto. Revelou o negativo no banheiro do hotel, com as próprias mãos, banho de revelador, parada, fixador. Quando pendrou o filme para secar e o examinou sob a lupa, o sangue escorreu do rosto. No centro do quadro, ao lado dele — ao lado de Arthur Moraes, de pé no lugar onde o senhor Antônio ficava nas fotos de família — estava o homem do terno antigo. Mesmo terno, mesmo olhar direto para a câmera, mesma mão cruzada atrás das costas. A uma distância de menos de cinquenta centímetros. Respirando. Não havia ninguém ali quando Arthur disparou o obturador. Ele lembrava do quintal vazio, do silêncio, do vento nas árvores. O homem não estava lá. Está na imagem.

Voltou para Belo Horizonte no dia seguinte. Não dormiu. Instalou a câmera digital no tripé, apontou para o espelho do hall, ligou o flash. Nada. O espelho mostrava só ele, o quarto vazio, a luz branca. Então pegou o celular e fotografou o espelho. Na tela, ao fundo, atrás do próprio ombro de Arthur, o homem. Mais perto do que nas fotos de Ouro Preto. Tanto que Arthur conseguia ver os poros da pele, o cinza dos olhos, a leve umidade nos lábios. Uma respiração fina, quase imperceptível, como se o vidro estivesse embaçado de um só lado.

Arthur desligou o celular. Colocou as fotos dos Varella de volta nos envelopes. Guardou o negativo de 1963 dentro de um livro, longe da luz. Não sabe se fazer isso ajuda. Sabe apenas uma coisa, com a certeza fria de quem revela imagens há vinte anos: algumas coisas só existem quando alguém as registra. Antes de Arthur olhar aquelas cópias, o homem era um segredo da casa em Ouro Preto, um vulto sem testemunha. Agora foi capturado em filme, em pixels, na câmera de um restaurador que tem o olhar treinado para ver o que os outros não veem. Saiu do fundo para o primeiro plano. E da próxima foto — a próxima que Arthur tirar, a próxima que você tirar — ele estará esperando, um passo mais perto do que da última vez.

## Fontes de inspiração

- História da fotografia espírita: o caso de William H. Mumler, fotógrafo norte-americano que, a partir de 1861, vendeu imagens de supostos espíritos ao lado de clientes vivos; julgado por fraude em 1869, nunca se comprovou exatamente como produzia as aparições (BBC News Brasil; Zap/AEIOU; Wikipedia, "Fotografia espírita").
- Contexto histórico e arquitetônico de Ouro Preto, Minas Gerais: casarões coloniais, encostas da cidade, estação ferroviária e o esvaziamento populacional após a transferência da capital para Belo Horizonte, em 1897 (Prefeitura de Ouro Preto; gov.br; Wikipedia, "Ouro Preto").

As fontes serviram apenas de inspiração para elementos de cenário e atmosfera. Todos os personagens, eventos e fotografias descritos são ficcionais.
