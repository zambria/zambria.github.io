---
titulo: "O Corte que Não Sangra"
resumo: "Um veterinário é chamado a uma fazenda do Pantanal de Mato Grosso do Sul para investigar bois encontrados mortos, sem sangue e com órgãos retirados com precisão cirúrgica. O que começa como suspeita de ataque de predador acaba em uma constatação mais fria: algo está colhendo amostras, e os laudos oficiais foram arquivados para nunca responder."
categoria: "criptozoologia"
data: "2026-11-21"
slug: "o-corte-que-nao-sangra"
tipo: "ficcao"
fonte_pesquisa: "G1, 'Chupa-cabra: há 20 anos, lenda sobre bicho que mutilava animais assustou moradores no interior de SP' (2019); resumo expandido EPHIS 2021 (Editora PUCRS), sobre casuística ufológica e mutilações de gado endêmicas no Pantanal de Mato Grosso do Sul"
---

# O corte que não sangra

O telefone tocou às cinco e meia da manhã. Do outro lado da linha, a voz de Sebastião não tremia. Tremia o silêncio que a precedeu — o tipo de silêncio que só o Pantanal sabe fabricar, quando os sapos param de cantar e o vento deixa de empurrar a palhada. Sete quilômetros de estrada de terra nos separam do rio Paraguai, no sul de Mato Grosso do Sul, onde a lama é negra, espessa e guarda o cheiro de húmus misturado a bicho morto há muito tempo.

Fui chamado como veterinário. Cheguei com a sensação de que Sebastião precisava, na verdade, de um legista.

Na varanda da fazenda, ele me mostrou as fotos. Uma vaca de leite, deitada de lado no pasto alagado, sem uma gota de sangue no solo ao redor. O olho esquerdo retirado com precisão cirúrgica. A língua, ausente. Sem marcas de luta, sem pegadas de onça-pintada, jacaré-açu ou cão selvagem nos vinte metros ao redor do corpo. A pele estava intacta até onde o corte começava, como se algo tivesse aberto a carne com um bisturi e fechado o local em seguida — ou como se a pele nunca tivesse tido razão para sangrar.

— O terceiro em trinta e dois dias — disse Sebastião. — Um bezerro, uma égua e agora esta. Sempre o mesmo padrão. Sempre sem sangue.

Não era a primeira onda deste tipo naquela região. Anos antes, na década de 1990, o interior de São Paulo inteiro parou para falar do chupa-cabra: galinhas, cabras, cavalos e bois encontrados mortos, praticamente sem sangue, inquéritos policiais arquivados sem autoria, moradores fechando as portas ao anoitecer. No Pantanal de Mato Grosso do Sul, o fenômeno é mais antigo e mais discreto. Um resumo acadêmico que li depois, de uma pesquisa sobre a casuística ufológica do estado, lista os órgãos mais visados: língua, tetas, olhos — e, muito raramente, o cérebro. Narrativas que remontam aos anos 1970, quando luzes misteriosas atacavam pessoas e animais às margens dos rios.

No quarto dia de investigação, encontrei o peão de Sebastião acocorado à beira do rio, olhando para a água. Não disse nada quando me aproximei. Apenas apontou para o escuro entre os juncos, na outra margem, e murmurou: "Desceu. Subiu. Não fez borbulhar."

Na noite seguinte, fiz a vigia sozinho. Sentei em uma cadeira de lona no curral, rifle do dono ao lado — ele atirava, eu apenas observava. Lanterna, relógio, caderno. O Pantanal à noite é um barulho contínuo de insetos, sapos e sopro de vento; até que, perto das quatro da manhã, tudo parou. O silêncio voltou, mais denso que antes. Na beira do salobra, a uns quarenta metros de onde eu estava, algo permaneceu imóvel entre as folhas de aroeira. Não era uma onça: onça se move, respira, faz a lama ceder sob as patas. Aquilo não deixou marca. Era alto, pálido, e não piscava. Observou o curral. Observou a mim. Quando dirigi a lanterna na direção, já não havia nada — apenas a lama, intacta, e a água parada.

Voltei para a casa ao amanhecer. Sebastião já estava de pé, pálido. O oitavo animal: um bezerro dentro do curral, a menos de vinte metros da residência. Corte na base do crânio. Cérebro removido. Língua e olhos também. Sem sangue. Sem pegadas. Sem barulho, segundo ele — e ele dorme com a janela aberta.

Enviei amostras para o laboratório da universidade. O laudo voltou duas semanas depois: inconclusivo. Não havia DNA de predador, não havia veneno, não havia causa natural que explicasse a ausência de hemorragia em um animal de quatrocentos quilos exsangue. O inquérito, se é que alguém abriu um, seria arquivado como "ataque de animais desconhecidos" — a categoria padrão para aquilo que ninguém quer nomear.

Não é um predador. Predador come. Isso coleta. Retira órgãos específicos com precisão que nenhum cão selvagem possui, deixa o corpo inteiro no pasto como amostra devolvida, e desaparece sem deixar rasto que a ciência consiga medir. As luzes que o peão viu — ou não viu, pois negou ter visto qualquer coisa quando perguntei no dia seguinte — são apenas o pano de fundo. O palco é o silêncio oficial: laudos arquivados, veterinários que assinam "inconclusivo", fazendeiros que fecham as portas e não falam mais sobre o assunto por medo de parecerem tolos.

Fechei o meu relatório com a mesma frase de sempre. O que me assusta não é a criatura em si, seja ela o que for. É a constatação de que algo percorre este Pantanal há pelo menos cinquenta anos, retira o que precisa de quem não pode se defender, e vai embora antes que alguém consiga olhar de perto. E o que me deixa com o sono leve não é o medo de encontrá-la no escuro. É saber que, quando ela voltar, eu já sei o suficiente para não gritar. O próximo boi sem sangue já está de pé, em algum lugar desta lama negra, esperando a noite cair.

## Fontes de inspiração

- G1, "Chupa-cabra: há 20 anos, lenda sobre bicho que mutilava animais assustou moradores no interior de SP" (2019) — relatos de animais de criação encontrados mortos e praticamente sem sangue, cortes precisos, inquéritos arquivados sem autoria.
- Resumo expandido apresentado no EPHIS 2021 (Editora PUCRS) — casuística ufológica e mutilações de gado endêmicas no Pantanal de Mato Grosso do Sul: remoção de língua, tetas, olhos e, raramente, cérebro; fenômeno documentado desde os anos 1970, associado a luzes misteriosas.

Como toda ficção do ZAMBRIA, este texto é uma criação original. Os fatos citados servem apenas de inspiração; nenhum trecho foi copiado de fontes externas.
