---
titulo: "O Zumbido de Pedra Branca"
resumo: "Um homem passa a ouvir um zumbido de baixa frequência que ninguém mais percebe em uma cidadezinha mineira. Sem fonte aparente, o som invade o silêncio da noite e começa a consumir seu sono — até que ele descobre que não é o único ouvinte, e que o silêncio oficial esconde algo mais velho que a cidade."
categoria: "fenomenos-naturais"
data: "2026-11-20"
slug: "o-zumbido-de-pedra-branca"
tipo: "ficcao"
fonte_pesquisa: "em.com.br; Acoustical Society of America"
---

# O Zumbido de Pedra Branca

Começou em um apagão.

Não houve trovão, nem queda de árvore sobre a rede. A luz simplesmente se foi, e com ela o zumbido branco da geladeira, o chiado do televisor em standby, o ruído de fundo que nunca notamos até que ele some. Foi então que ouvi o outro som.

Pedra Branca é um daqueles municípios de Minas Gerais que aparecem no mapa apenas porque alguém precisava preencher um espaço entre dois rios. Fica no sopé de uma crista de quartzito, ao lado de um represa construída nos anos 1970 e hoje cheia de águas verdes e lentas. Não há fábrica, não há rodovia de grande tráfego, não há parque eólico nem linha de transmissão de alta tensão a menos de trinta quilômetros. À noite, o silêncio é tão denso que se ouve o cachorro do vizinho latir a três quarteirões. Eu morava ali há oito meses, desempregado, ex-técnico de som de uma rádio que fechara, com tempo demais e sono de menos.

Naquela noite de inverno, deitado no escuro, ouvi um zumbido grave, contínuo, entre o motor de uma geladeira antiga e um avião distante em aproximação. Não vinha de fora da janela — ou talvez vinha de todos os lugares ao mesmo tempo. Sentia-o mais no peito do que nos ouvidos, uma vibração baixa que ressoava nas costelas. Levantei, desliguei o disjuntor geral, tirei os plugs da tomada, abri a porta da geladeira. O som permaneceu. Perguntei à vizinha do lado se ela ouvia alguma coisa. Ela olhou para mim como se eu fosse um doido e disse que não, que a noite estava quieta como sempre.

Doeu perceber que eu era o único.

Nos dias seguintes, o zumbido se instalou. Aparecia ao anoitecer, ganhava força depois da meia-noite e sumia pouco antes do amanhecer, como um funcionário noturno de alguma planta invisível. Tentei medir. Baixei aplicativos de decibelímetro no celular, emprestei um medidor de nível de som de um amigo engenheiro — nada. Nenhum pico abaixo de oitenta hertz, nada fora do padrão. O equipamento não registrava nada que explicasse o que eu ouvia.

Pesquisei. Descobri que o fenômeno tem nome em outros lugares: o Zumbido de Taos, no Novo México, relatos semelhantes em Bristol, Kokomo, Bondi, e até no Brasil, em cidades que ninguém menciona nos telejornais de mistério. É um som de baixa frequência, geralmente entre trinta e oitenta hertz, faixa em que a maioria dos sistemas de monitoramento ambiental não está configurada para focar. Apenas uma minoria da população o percebe — estimativas falam de dois a quatro por cento. As autoridades, quando não ignoram, atribuem a tinnitus, a estresse, à imaginação. Os aparelhos não captam. A ciência hesita. O som permanece.

Falei com o médico da cidade. Receitou um ansiolítico e sugeriu que eu procurasse um otorrinolaringologista na capital, a quatro horas de ônibus. Falei com o prefeito. Ele riu, ofereceu um café e disse que Pedra Branca não aparecia em nenhum mapa de ruído industrial, muito obrigado, prossiga. Fui ao bar da praça, naquela hora em que os homens velhos jogam truco e discutem política como se o país fosse deles. Perguntei se alguém mais ouvia um zumbido à noite. Silêncio. Depois, risadas secas. Um deles disse que eu devia parar de beber cachaça antes de dormir.

Foi então que conheci Dona Lurdes.

Viúva, setenta e dois anos, mora sozinha em uma casa de taipa na beira da crista. Ela me esperava na porta com uma xícara de chá e disse, sem ser perguntada: ouvi também. Ouvi há anos. Nunca contei porque acharam que eu estava ficando louca. Ela descreveu o mesmo som grave, contínuo, noturno. Me mostrou recortes de jornal amarelados dos anos oitenta, quando encheram o represa: moradores reclamavam de um ronco da terra que vinha de debaixo do solo, de dormir mal, de cães que uivavam para nada. Um geólogo que passou pela cidade na época falou de uma falha geológica sob o quartzito, de rochas que se movem milímetros por ano, de vibrações que ninguém sabia medir direito. O jornal esqueceu a matéria. A represa continuou cheia. O zumbido, segundo Dona Lurdes, nunca saiu — apenas esperou que alguém novo ouvisse.

Comecei a perder o sono de verdade. O zumbido não era alto, mas era constante, e o pior é que não dava para fugir dele. Saía de casa, e ele vinha junto. Subia a crista, e ele parecia subir com o vento. Deitava na rocha à noite, de ouvido contra o quartzito, e sentia a vibração nos dentes, no crânio, como se o planeta estivesse respirando com frequência de diesel velho. Dizia para mim mesmo que era tinnitus, que era estresse, que era a cabeça criando sons para preencher o silêncio de uma cidade vazia. Mas Dona Lurdes ouvira o mesmo som trinta anos antes, e ela não tinha minha idade nem meus problemas de sono.

Uma noite, fui até o ponto mais alto da crista, acima da represa, onde o quartzo se lasca em lascas brancas e o solo racha em finas fissuras. Deitei de bruços, coloquei o ouvido direto na pedra, fechei os olhos. O zumbido veio do chão. Não era um som vindo do céu, nem de uma máquina escondida no mato. Vinha de baixo. Da falha. Da rocha esticando-se ao longo de uma fratura mais antiga que Pedra Branca, mais antiga que o represa, mais antiga que qualquer memória humana registrada ali. A terra zumbia. E eu, por acidente de biologia ou maldição de ouvido, era um dos poucos capazes de escutá-la.

Passei semanas tentando encontrar uma explicação racional. Linhas de transmissão, micro-sismos oceânicos convertidos em som, instalações industriais distantes, sensibilidade auditiva anormal. Nada se encaixava. Nenhum aparelho confirmava. Nenhuma autoridade assumia. Nenhum vizinho confirmava. Ficava só eu, Dona Lurdes e um velho jornal amarelado que ninguém mais lia.

Até que o zumbido parou.

Foi numa terça-feira. Deitei à noite, esperei o ronco grave começar, e nada. Silêncio. Silêncio absoluto. A casa respirava, o grilo cantava, o vento mexia nas folhas do pé de manga, mas o zumbido havia sumido. Deveria ter me aliviado. Não me aliviou. Fiquei acordado até o amanhecer, ouvindo o silêncio, esperando que ele retornasse. Quando o sol subiu, ainda estava acordado, e pensei na coisa mais assustadora que já pensei em toda a minha vida: e se o zumbido não estava fora de mim? E se parar de ouvi-lo significa apenas que ele encontrou um novo lugar para ressoar — ou um novo ouvinte?

Agora, quando a noite cai em Pedra Branca, eu fico deitado no escuro e escuto o silêncio. E oro — embora não reze — para que ele continue sendo apenas silêncio.

## Fontes de inspiração

- em.com.br — "O estranho som que algumas pessoas ouvem no silêncio: o que é o Zumbido de Taos e o que a ciência já descobriu" (relato sobre o fenômeno The Hum, percepção por minoria da população, frequência entre 30 e 80 hertz e ausência de registro em equipamentos).
- Acoustical Society of America — "The mystery of the Taos hum" (investigação sobre ouvintes seletivos, som de baixa frequência persistente e ausência de fonte acústica ou sísmica identificada).
