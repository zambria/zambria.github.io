---
titulo: "O Tom que Não Deveria Existir"
resumo: "Um engenheiro acústico enviado para medir ruídos em uma serraria desativada grava um tom de dezessete hertz que não deveria estar ali — e descobre que o som o observa de volta."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-tom-que-nao-deveria-existir"
tipo: "ficcao"
fonte_pesquisa: "IstoÉ Dinheiro; O Antagonista (infrasom abaixo de 20 Hz)"
---

# O Tom que Não Deveria Existir

Serra da Prata, ou o que restava dela. Uma serraria desativada nos arredores de um município que o mapa trata como vilarejo. Fui enviado para lá com um medidor de nível de pressão sonora, um gravador de campo e a ordem de checar se o local ainda violava o NR-15 — ruído ocupacional, limites de exposição, proteção auditiva. Papel de escritório, na maior parte. A serraria estava desativada há doze anos. Não havia máquina ligada, não havia funcionário, não havia razão para ruído algum.

A primeira noite foi o aviso. O gravador, deixado no chão de concreto da oficina principal, capturou um tom contínuo de dezessete hertz. Dezessete. Abaixo do limite da audição humana. O ouvido não o registra, mas o corpo sente: pressão no peito, inquietação, a impressão vaga de que algo está errado no ambiente. Infrasom. A ciência explica o desconforto, não a fonte.

Voltei na segunda noite. Levei um analisador de espectro. O tom estava lá, estável, vindo de algum ponto abaixo do piso da oficina — ou pelo menos é o que o equipamento sugeria, porque o som não tinha direção. Infrasom não se comporta como som audível: envolve, preenche, não aponta para lugar nenhum. Colhi medidas por três horas. Dezessete hertz, constante, nível de pressão variando entre sessenta e cinco e setenta e dois decibéis. Sem fonte visível. Sem motor, sem gerador, sem linha de transmissão próxima.

Na terceira noite, o tom mudou. Passou a pausar quando eu falava e a retomar quando eu calava. Resposta. Não é geologia, não é tubulação, não é vento passando por uma fresta na telha de zinco. Algo estava me ouvindo, ou ao menos reagindo à minha presença.

Passei os dias seguintes a montar um mapa sonoro do prédio. Quatro gravadores, dispostos em cruz, sincronizados. A serraria é uma caixa de madeira e concreto, um ressonador perfeito. Qualquer ruído lá dentro se multiplica, se distorce, se devolve. O tom de dezessete hertz preenchia o espaço inteiro com a mesma intensidade, como se o prédio fosse apenas um alto-falante gigante e invisível.

O laudo do NR-15 nunca foi minha preocupação real. O que me prendeu foi a constatação de que o som não vinha de fora. Não havia vibração nas máquinas paradas, não havia estrutura em ressonância, não havia origem no solo. O medidor mostrava o tom mais forte no centro da oficina, exatamente onde eu ficava parado. Como se a fonte fosse eu.

Comecei a dormir mal. O corpo reage ao infrasom mesmo sem ouvi-lo: irritabilidade, sono fragmentado, a sensação de presença. Na quarta noite, deixei o gravador ligado e saí do prédio. Fiquei do lado de fora, no mato, ouvindo através do fone de monitoramento a transmissão ao vivo. O tom estava lá, estável, dentro da serraria vazia. Então toquei a porta de saída e voltei. No momento em que cruzei a porta, o tom cessou. Por três segundos, silêncio completo. Depois voltou, um pouco mais alto.

No quinto dia, decidi encontrar a fonte. Desmontei o piso de concreto da oficina, martelo e cinzel, em vez de continuar preenchendo planilhas de exposição ocupacional. Debaixo do piso havia terra batida, nenhuma câmara, nenhum duto, nenhum equipamento enterrado. Apenas terra e a umidade de sempre. O tom, no entanto, não parou. Se algo, ficou mais nítido.

Na sexta noite, o tom subiu para dezenove hertz. Perto do limite. Comecei a ouvi-lo — não como som claro, mas como uma vibração atrás dos olhos, uma pressão nos tímpanos que não cedia ao engolir em seco. Fiquei sentado no centro da oficina, gravador no colo, esperando. O tom subiu para dezenove ponto cinco, dezenove ponto oito. Próximo de vinte. Próximo de se tornar audível de verdade.

Foi quando percebi o padrão. O tom não estava subindo sozinho. Ele acompanhava minha respiração. Inspirava, o tom subia. Expirava, descia. Não era o prédio que ressoava. Era eu.

Infrasom abaixo de vinte hertz é inaudível, dizem os manuais. O corpo sente, a mente interpreta, a ciência atribui ao desconforto ambiental. Nunca dizem que o som pode estar ouvindo você de volta.

Saí da serraria ao amanhecer com o gravador na mão e o laudo inacabado. No carro, coloquei os fones e pressionei play. A gravação da última noite trazia o tom de dezessete hertz, estável, vazio de origem. E, no fim, sob o ruído de fundo, uma pausa curta — exatamente do tamanho de uma respiração contida — seguida pelo som da minha própria voz, sussurrando algo que eu não lembro de ter dito.

Desliguei o gravador. O silêncio do carro era pesado, mas não era vazio. Algo, debaixo do concreto da oficina, ou dentro do meu crânio, ainda estava acompanhando minha respiração.

## Fontes de inspiração

- IstoÉ Dinheiro — "A ciência por trás do desconforto em locais 'assombrados'" (infrassom abaixo de 20 Hz, reações corporais sem percepção consciente, cortisol).
- O Antagonista — "Existe um som que você não ouve, mas seu corpo sente" (infrassom como vibração/pressão, desconforto em ambientes fechados).

Essas fontes serviram apenas de inspiração para o fenômeno acústico; a narrativa é ficcional e todos os personagens, locais e eventos são inventados.
