---
titulo: "A Última Camada do Sambaqui"
resumo: "Uma arqueóloga escava um sambaqui não catalogado no litoral catarinense e descobre que os montes de concha não foram erguidos para honrar os mortos, mas para manter algo enterrado."
categoria: "arqueologia"
data: "2026-11-21"
slug: "a-ultima-camada-do-sambaqui"
tipo: "ficcao"
fonte_pesquisa: "G1, Superinteressante, Wikipédia (pt), Prefeitura de Santos"
---

# A Última Camada do Sambaqui

O sambaqui não aparecia em nenhum mapa. Pelo menos não em nenhum mapa que eu tivesse permissão para ver. Era uma elevação de conchas e ossos disfarçada de morro, a meia hora de caminhada da última praia deserta do litoral norte de Santa Catarina, coberta de vegetação rasteira e de um silêncio que não parecia produto do vento. Minhas botas afundavam ligeiramente a cada passo. Sob os pés, a terra não era terra: era milhares de anos de resíduos comprimidos — cascas de molusco, espinhas de peixe, carvão de fogueiras extintas, ossos de animais e, diziam os velhos da vila mais próxima, ossos de gente.

Fui chamada para aquilo porque sou arqueóloga, e porque ninguém mais queria ir. O sambaqui de Queimadas — batizei assim, sem cerimônia, para preencher um formulário de liberação do IPHAN — não constava nos cadastros oficiais. Tinha cerca de seis metros de altura, formato ovoide, coroado de ipês anões e panico. Do alto, via-se o mar cinzento de inverno e a linha de arrebentação que nunca parava. Sambaqui vem do tupi *tabaki*: *taba*, marisco; *ki*, amontoado. Trata-se, em resumo, de montanhas de lixo organizado que alguém decidiu transformar em monumento. Erguidos entre oito mil e dois mil anos atrás por pescadores-coletores que precederam os tupis-guaranis, alguns sambaquis guardam mais de quarenta mil corpos. Outros, poucos. Todos guardam segredos.

Comecei a escavação na extremidade norte, onde a encosta havia desabado em parte, expondo as camadas. Segui o protocolo padrão: unidade de um metro quadrado, escavação em níveis de dez centímetros, peneira, etiquetas, registro fotográfico. Nos primeiros dois dias, não saiu nada além do esperado. Conchas de amêijoa, mexilhão e caramujo. Espinhas de tainha e pescada. Cinzas. Um fragmento de cerâmica Tupiguarani, muito mais recente, jogada ali por descuido séculos depois. Os sambaquis crescem por acumulação, camada sobre camada, como um rocambole de resíduos e sepultamentos. Um corpo em posição fetal — encolhido como bebê no ventre — é coberto de conchas; sobre ele, um novo morto; e outro; por mil anos. Isso é o que os livros dizem. É também o que os sambaquieiros queriam que acreditássemos, suponho.

No terceiro dia, a peneira reteve algo que não deveria estar ali.

Um relógio de pulso. Pulseira de couro em avançado estado de decomposição, caixa de metal oxidado, vidro estilhaçado. Estava preso ao pulso de um esqueleto deitado em posição fetal, a noventa centímetros de profundidade, envolvido por conchas que, segundo a datação preliminar do sambaqui, teriam entre três e quatro mil anos. Não havia relógios no litoral brasileiro em mil a.C.

Conferei a etiqueta, a profundidade, as fotos. Não houve erro de camada. A terra em volta estava intacta, sem sinais de intrusão recente, sem toca de animal, sem raiz que pudesse arrastar o objeto para baixo. O relógio simplesmente estava lá, como se alguém o tivesse colocado ali, junto ao morto, há milênios. Ou como se o morto o tivesse usado até morrer — o que é impossível.

Parei a escavação naquela unidade e abri uma nova, cinco metros mais adentro. A quarta camada trouxe um segundo esqueleto, também fetal, também sob conchas milenares, com uma moeda no peito. A moeda não era portuguesa, nem holandesa, nem de qualquer colonizador que eu conhecesse. Era de um metal escuro, leve, com uma face lisa e outra gravada com algo que lemhava um olho fechado. Guardei-a em um saco plástico e anotei: material não identificado.

Os pescadores da vila pararam de me cumprimentar por volta daí. Quando me viam, desviavam o olhar e cruzavam os dedos. Um deles, numa quarta-feira de chuva miúda, segurou meu braço enquanto eu subia a ladeira de volta ao acampamento.

— Senhora, não escave à noite. Os mortos do sambaqui não gostam de ser acordados.

— Mortos não gostam de nada, já estão mortos — respondi, secamente.

— Os desse sambaqui ainda não terminaram de morrer — ele disse, e soltou meu braço.

Ignorei. Sou arqueóloga. Ignorar avisos de pescadores supersticiosos faz parte do ofício.

A sexta camada foi onde as coisas deixaram de fazer sentido. Encontrei um terceiro esqueleto. Desta vez, não estava fetal. Estava de bruços, os dedos das mãos arranhando a terra, os braços dobrados atrás do corpo como se tivesse tentado se levantar — ou se enterrar sozinho. O crânio faltava. Não havia sinais de corte, de ferimento, de animal. O osso simplesmente não estava ali, como se a cabeça tivesse se dissolvido ou sido retirada com cuidado cirúrgico.

Na sétima camada, a terra escureceu. Cheiro de úmido, de algo apodrecido sob pressão. Encontrei um zoólito — aquelas estatuetas de pedra que os sambaquieiros enterravam com os mortos, supostamente para guiá-los numa viagem espiritual. Este zoólito não tinha forma humana. Tinha pernas demasiadas, uma cabeça que não terminava, e as mãos estendidas para baixo, como se estivesse segurando algo no chão. Ou pressionando algo contra ele.

Foi então que percebi o padrão. Cada camada de conchas, cada sepultamento fetal, cada corpo pressionado contra o próximo — não era um cemitério. Era uma prensa. Os sambaqui não foram erguidos para honrar os mortos. Foram erguidos para pesá-los. Para manter o que quer que estivesse embaixo, no fundo do poço, bem no fundo, onde as conchas se fundem com a rocha, preso pelo peso de milhares de toneladas de marisco acumulado durante milênios.

A oitava camada era o leito rochoso. E no leito rochoso havia uma cavidade. Uma cavidade perfeitamente circular, com cerca de meio metro de diâmetro, escura, úmida, quente. Coloquei a mão dentro. O ar que saía dela cheirava a maresia e a algo mais velho que o mar. Tirei a luva. O toque foi úmido, viscoso, e contra a minha pele algo se moveu — não dentro da cavidade, mas em volta do meu pulso, como dedos finos e sem ossos testando a resistência.

Retirei a mão rápido demais. Quando olhei para o poço, a camada de conchas acima dela havia se deslocado. Um centímetro, talvez dois. Peso suficiente para manter algo enterrado por quatro mil anos, e agora se mexendo sozinho.

Desci a encosta no escuro, sem olhar para trás. No acampamento, tratei de arrumar as coisas. Minha colega de equipe perguntou por que eu estava tão pálida. Disse que era gripe. Ela não perguntou mais.

Na estrada de volta, passei pela vila. Os pescadores estavam na beira da praia, de costas para o mar, olhando para o morro do sambaqui. Nenhum deles falava. Quando passei de carro, um deles ergueu a mão e apontou para o banco do passageiro, onde minha mochila de trabalho repousava sobre as anotações, as fotos, o saco plástico com a moeda de olho fechado.

Não parei.

Cheguei em casa à meia-noite. Deixei a mochila na sala. Fui preparar um copo d'água. Quando voltei, a mochila estava aberta — eu a tinha fechado com zíper — e o caderno de campo repousava sobre a mesa, aberto na página da sétima camada. A foto do zoólito de pernas demasiadas estava virada para baixo. Sobre a mesa, ao lado do caderno, havia uma concha de amêijoa. Única. Úmida. Cheirando a maresia.

Não moro no litoral. Moro a trezentos quilômetros do mar mais próximo.

Deitei, apaguei a luz. No escuro do quarto, ouvi algo se arrastar no corredor. Passos leves, úmidos, como algo sem ossos tentando aprender a andar. Fiquei imóvel, olhos arregalados, ouvindo o barulho parar diante da porta. Depois, um sopro. Um cheiro de maresia e de concha antiga.

O sambaqui não foi construído para guardar os mortos. Foi construído para que eles não saíssem. E eu acabei de tirar a tampa.

Agora algo está subindo pelas camadas.

## Fontes de inspiração

- G1 — “O que são os sambaquis, misteriosos monumentos milenares da pré-história” (notícia sobre sambaquis como monumentos de conchas, ossos e sepultamentos, com até 8 mil anos).
- Superinteressante — “Empilhadores de conchas” e “O que são sambaquis?” (sambaqui como amontoado de conchas; sepultamentos em posição fetal; zoólitos; sambaquis como casas e cemitérios ao mesmo tempo).
- Wikipédia (pt) — “Sambaqui” (definição, datação entre 8 mil e 2 mil anos antes do presente, função cerimonial e funerária).
- Prefeitura de Santos — “Velhos e novos habitantes do litoral: homens de sambaqui” (etimologia tupi de tabaki; enterros em posição fetal cobertos de conchas e ossos).

Todas as fontes acima serviram apenas como inspiração de campo. A história, os personagens e os fatos narrados são inteiramente fictícios.
