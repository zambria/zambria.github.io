---
titulo: "A Marca na Pedra Lisa"
resumo: "No ponto mais alto de São Paulo há uma rocha polida onde, dizem, se desliza para baixo e algo volta subindo. Uma noite de novembro, o narrador foi verificar se a lenda era verdadeira."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "a-marca-na-pedra-lisa"
tipo: "ficcao"
fonte_pesquisa: "Insoonia (lenda do Pico do Jaraguá), Aventurebox (Lendas do Pico do Jaraguá), Wikipédia (Pico do Jaraguá), Brasil Mining Site (paredão de quartzo do Jaraguá)"
---

# A Marca na Pedra Lisa

O Pico do Jaraguá tem mil cento e trinta e cinco metros e é o ponto mais alto do município de São Paulo. Isso soa menos impressionante do que é: dizer que é o ponto mais alto de uma metrópole é como dizer que um cachorro raivoso é o maior animal de um quarto fechado — tecnicamente verdadeiro, e razão suficiente para você não querer ficar lá sozinho à noite.

A rocha tem mais de quinhentos milhões de anos, segundo as placas do parque estadual. Os guaranis a chamam de Itaju marã e'y, pedra dourada primordial, e a tratavam como sagrada. Depois vieram os bandeirantes, a mineração, o ouro que não existia e o sangue que existia de sobra. Afonso Sardinha e seus capatazes guerrearam dez anos contra Carijós e Guaranis. Quando venceram, construíram a casa no sopé, exatamente sobre o cemitério indígena. Tudo isso circula em livros de história local, blogs de bairro e conversas de seguranças que nunca voltam a subir a trilha depois do primeiro turno.

Mas a lenda que me interessa não está nos livros. Está na Pedra Lisa.

Pedra Lisa é uma laje inclinada, polida pelo tempo ou por pés — depende de quem você pergunta. Deslizar nela de barriga para baixo, de noite, na lua cheia, é uma espécie de prova de coragem para garotos do Jaraguá. A versão suave da lenda diz que você sente um sopro na nuca ao chegar embaixo. A versão que circula nos fóruns de exploração urbana diz que quem desliza de noite não chega ao fundo sozinho: algo sobe junto, devagar, e fica com a marca.

Eu não sou garoto, não acredito em prova de coragem e não gosto de fóruns. Fui porque queria ver se a pedra realmente estava lisa, e porque São Paulo, vista de cima à noite, parece um circuito elétrico queimado — bonito de longe, perigoso de perto.

Subi sozinho. Lanternas, roupa escura, sem avisar ninguém. O parque fecha às seis da tarde, mas o portão do Jaraguá-Itu é uma sugestão, não uma barreira. O paredão de quartzo da mineradora dos anos 1930 — aquele que arqueólogos chamam de "ponta de um iceberg" da mineração paulista — aparece do lado esquerdo da trilha como uma cicatriz cinza. Blocos de quartzo extraídos da própria montanha, empilhados sem argamassa. Parece obra de civilização antiga até você ler o laudo e perceber que é apenas ganância disfarçada de patrimônio. Isso costuma acontecer em São Paulo: a gente confunde mineração com monumento, e depois se surpreende quando o monumento devolve o olhar.

Cheguei ao cume pouco depois das onze. A cidade inteira lá embaixo, um mar de laranja e branco sob a névoa. E a Pedra Lisa, no centro do platô, uma língua de rocha inclinada de uns quatro metros, úmida, escura, sem brilho.

Desci. De barriga, roupa raspando a pedra. Frio. Silêncio.

Ao chegar ao fundo, virei.

Algo estava lá, no alto da laje, parado. Não era pessoa. Não tinha movimento de pessoa. A figura era alongada, desproporcional, como se tivesse sido esmagada por um peso invisível e depois esticada de volta. A cabeça caída para o lado, os braços pendurados mais abaixo do que deveriam. Não vi rosto — ou melhor, o rosto estava voltado para a pedra, como se olhasse para dentro dela, não para fora.

Fiquei imóvel. A lanterna tremia na minha mão.

A figura não se mexeu. Não desceu. Não subiu. Apenas permaneceu ali, no alto da Pedra Lisa, olhando para a rocha como se lesse algo gravado que eu não conseguia ver.

Depois de minutos — ou foram horas? — ela se inclinou para frente, devagar, e ergueu uma mão. Não para me acenar. Para apontar. O dedo indicador traçou no ar uma linha reta, da Pedra Lisa em direção à cidade, como se dissesse: o que você procura não está em cima. Está embaixo.

Apaguei a lanterna e desci a trilha correndo. Não olhei para trás. Não porque fosse corajoso, mas porque sabia que, se olhasse, a figura ainda estaria apontando — e desta vez, para mim.

Na semana seguinte, voltei de dia. A Pedra Lisa parecia apenas uma rocha úmida e sem graça, polida por milhares de pés de turistas e escoteiros. Não havia marca, não havia figura, não havia nada além de lixo de embalagem de salgado preso numa fenda.

Ou quase nada. No centro da laje, onde meu corpo havia raspado a pedra na noite anterior, há uma impressão. Não é minha. É menor, mais larga, com dedos que se dobram para o lado errado. Está ali agora. Quem passar a mão, vai sentir. Quem se deitar lá de noite, vai sentir também — mas não o suficiente para sair correndo antes que algo desça junto.

A Pedra Lisa não é um monumento. Não é um mirante. É uma porta de espessura zero, e alguém do outro lado já passou o dedo na marca.

## Fontes de inspiração

- Insoonia, "Brazilian Horror Story: Pico do Jaraguá" — relato sobre a história do pico, o bandeirante Afonso Sardinha e as lendas do casarão no sopé.
- Aventurebox, "Lendas Pico do Jaraguá" — altitude do pico, os guaranis, a Nuvem do Adeus e a história de violência na região.
- Wikipédia, "Pico do Jaraguá" — dados geográficos, Itaju marã e'y ("pedra dourada primordial") e primeiro registro de ascensão.
- Brasil Mining Site, "Paredão no Jaraguá revela história pouco conhecida da mineração em SP" — o paredão de quartzo da mineradora dos anos 1930.
