---
titulo: "O Apontador do Posto 50"
resumo: "Um apontador ferroviário no Mato Grosso do Sul começa a registrar a chegada de um trem que nunca chega — até a noite em que as luzes no trilho pedem para ele embarcar."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-apontador-do-posto-50"
tipo: "ficcao"
fonte_pesquisa: "Revelando os Brasis — luzes do trem fantasma entre Estação Agente Inocêncio e Posto 50, Mato Grosso do Sul (1977)"
---

O apito não soou. Não havia trem no horário, não havia ordem de tráfego, não havia motivo para a linha férrea tremer sob os pés de Rui Tavares às duas e dezoito da madrugada. Ele estava sozinho na casinha de madeira do Posto 50, trecho entre a Estação Agente Inocêncio e o Pantanal, com nada além de um caderno de apontamentos, uma lanterna de pilha fraca e o silêncio dos trilhos que ninguém mais usava. A Estrada de Ferro Noroeste do Brasil já era, em 1977, uma memória mal enterrada. O Posto 50 existia apenas no papel — e Rui era o único funcionário que ainda assinava o ponto ali, num caderno que ninguém jamais leria.

Foi então que a luz apareceu.

Não era farol de locomotiva. Tinha o branco arroxeado de uma lâmpada que se acende num lugar errado, e vinha do sentido contrário ao da subida do Pantanal, o que impossibilitava qualquer trem regular. Rui apanhou o caderno e anotou: "Luz não identificada, trilho sul, 02h18, sem correspondência de tráfego." Fechou o caderno, saiu da casinha e ficou na plataforma de concreto rachado olhando para os trilhos. A luz se aproximou devagar, sem barulho de rodas, sem estalos de dilatação do aço, sem o cheiro de óleo queimado que todo ferroviário conhece de cor. Aproximou-se e parou a uns dez metros dele, como se alguém tivesse freado um veículo invisível no meio da noite.

Rui voltou para dentro, trancou a porta com o ferrolho de ferrugem e não apagou a lanterna. Esperou que a luz se fosse. Não se foi. Ela pulsou, uma vez, como um coração que acelera ao ver alguém conhecido.

No dia seguinte, Rui escreveu no caderno: "03/11/1977 — Luz no trilho sul às 02h18. Sem trem. Sem origem. Registro anexado ao apontamento de rotina." Entregou o caderno no escritório da estação, como sempre fazia, e ninguém disse nada. Ninguém jamais dizia. O Posto 50 era um ponto de passagem que ninguém mais passava, e a papelada era apenas papelada.

Mas a luz voltou.

Na segunda noite, apareceu às 02h17. Na terceira, às 02h16. Na quarta, às 02h15. Rui começou a adiantar o relógio de pulso dez minutos antes das duas, para não ser pego de surpresa. Anotava tudo. A cada noite, a luz parava um pouco mais perto. Na sétima noite, estava a cinco metros. Na oitava, a três. Rui parou de trancar a porta da casinha. Não adiantava. A luz não entrava. Ela ficava lá fora, imóvel, esperando, e Rui descobriu que esperar do lado de dentro era muito pior do que esperar do lado de fora.

Ele começou a reconhecer padrões. A luz não vinha sozinha. Atrás dela, no vazio entre os dormentes, havia algo que se movia com o ritmo de passos pesados — não de um homem, de algo maior, algo que não soltava calor e não deixava marca no cascalho. Rui passou a levar um revólver calibre 38 que não atirava desde o serviço militar. O revólver não servia para nada contra uma luz, mas o fazia sentir menos inútil.

Na décima segunda noite, a luz chegou à porta da casinha. Rui estava do lado de fora, de pé na plataforma, o revólver na mão direita, o caderno debaixo do braço esquerdo. A luz parou a um braço de distância e, pela primeira vez, não era apenas luz. Dentro dela havia uma forma — longa, alongada, como um vagão de carga visto através de uma neblina quente, com janelas que não refletiam nada e portas que não se abriam para fora. Rui sentiu o cheiro de óleo velho, de carvão molhado, de sangue seco num piso de madeira que ninguém limpara há quarenta anos.

Ele abriu o caderno e escreveu: "15/11/1977 — A luz tem forma de vagão. Chegou até a porta. Não entrou. Anoto que sinto falta de ar."

A página, quando fechou o caderno, já não estava em branco. Algo havia sido escrito ali por uma mão que não era a dele, com tinta que ainda úmida cheirava a ferrugem. Rui não leu em voz alta. Leu com os olhos, uma vez, duas vezes, e depois rasgou a página. Rasgou e jogou fora, no cascalho, e a luz não se moveu. Não precisou. Rui sabia que tinha lido. Sabia que o remetente sabia que tinha lido.

Nas noites seguintes, Rui parou de anotar. Não havia mais o que anotar. A luz ficava na plataforma enquanto ele dormia na casinha, ou fingia dormir, e às vezes ele acordava com a sensação de que alguém estava em pé ao lado da cama, olhando para ele com o branco arroxeado de uma lâmpada que não projetava sombras. Ele parou de levar o revólver. O revólver era um lembrete de que ele ainda acreditava em balas.

Na vigésima primeira noite, o apito soou.

Rui estava na plataforma, de pijama, descalço, o caderno aberto na mão. O apito veio de algum lugar entre a luz e o horizonte, longo, grave, um apito de locomotiva que não ecoou nos morros porque não havia morros para ecoar — ecoou dentro do crânio dele. A luz se separou da plataforma e recuou para o trilho sul. Atrás dela, agora visível, vinha o trem. Não era o trem que Rui esperava. Era mais longo do que deveria, com vagões que mudavam de comprimento à medida que passavam, janelas que acendiam e apagavam em sequência inversa, e uma fumaça que subia para baixo, como se a gravidade do lugar tivesse se cansado de funcionar.

O trem parou. A porta do primeiro vagão se abriu com um estralo de metal frio, e uma plataforma de madeira apareceu ao nível do solo — exatamente onde Rui estava parado.

Não houve convite. Não houve voz. Apenas a porta aberta, o vazio dentro, e o apito que ainda ressoava no osso temporal de Rui. Ele deu um passo à frente. O caderno caiu no cascalho, aberto na última página, e o vento da noite — o primeiro vento que Rui sentira ali desde que chegara — folheou as páginas como se alguém estivesse procurando algo escrito.

Rui subiu na plataforma do vagão. O chão de madeira rangia com um peso que não era só o dele. A porta se fechou atrás dele com um silêncio absoluto, não um tranco, não um barulho de ferrolho, apenas o fim do som, como se o mundo de fora tivesse sido desligado num interruptor. Dentro do vagão estava escuro, mas não um escuro comum. Era o tipo de escuridão que tem textura, que você pode tocar com a ponta dos dedos e sentir que ela toca de volta. Rui andou até o fim do vagão. Não havia bancos, não havia passageiros, não havia nada além de uma fileira de cadernos empilhados sobre um banco de madeira, todos com a capa rasgada e a primeira página faltando.

Ele pegou o caderno de cima. Abriu. A primeira linha estava escrita com a letra dele.

"15/11/1977 — A luz tem forma de vagão. Chegou até a porta. Não entrou. Anoto que sinto falta de ar."

Rui fechou o caderno. Devolveu ao lugar. Pegou outro. Abriu. A primeira linha, novamente com a letra dele, dizia: "Não entregue o caderno no escritório. Ninguém lê, mas alguém arquiva." Ele fechou. Pegou outro. "Eles não querem o caderno. Querem quem escreve no caderno." Outro: "A luz não é o trem. A luz é o que resta depois que o trem leva o homem."

Rui empilhou os cadernos de volta no lugar, exatamente como estavam, e caminhou de volta até a porta. Ela não se abriu. Ele tentou o ferrolho. Não havia ferrolho. Apenas madeira e escuridão, e do outro lado a plateforme fria onde seu corpo ainda estava de pé, de pijama, segurando um caderno que não seria entregue a ninguém.

O trem deu arranque.

Rui ficou na porta aberta vendo o Posto 50 se afastar — não recuando, mas sendo deixado para trás, como se a distância não fosse medida em metros mas em decisões tomadas. A luz branca arroxeada ficou na plataforma, imóvel, e Rui percebeu, com a clareza fria de quem já não tem nada a perder, que a luz nunca tinha vindo buscá-lo. Ela vinha buscar o caderno. E o caderno, agora, estava com ele.

Na estação, no dia seguinte, um ferroviário encontrou o caderno de apontamentos de Rui Tavares abandonado na plataforma do Posto 50, aberto na última página, o vento virando as folhas. Abriu o caderno. A última entrada, escrita com letra firme, dizia apenas: "Hoje entrei no vagão. Não escrevi isso. Alguém escreveu por mim, e eu estou lendo com os olhos de quem já não volta."

O ferroviário fechou o caderno, colocou na pilha de papelada do escritório e não disse nada a ninguém. Ninguém jamais dizia. O Posto 50 continuava existindo no papel, e algum dia, entre duas e meia e três da madrugada, a luz branca arroxeada apareceria novamente no trilho sul. Sempre na mesma hora. Sempre esperando. Sempre com um lugar vago no vagão da frente.

## Fontes de inspiração

Revelando os Brasis — "Trem fantasma volta após 37 anos ao Centro-Oeste do país". Relatos de ferroviários sobre luzes de trem entre a Estação Agente Inocêncio e o Posto 50, perto de Porto Esperança, Mato Grosso do Sul (1977), com fogos na linha férrea sem queima constatada. Fonte utilizada apenas como inspiração atmosférica; personagens, enredo e conclusão são fictícios.
