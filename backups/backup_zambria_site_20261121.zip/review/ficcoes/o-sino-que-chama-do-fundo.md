---
titulo: "O Sino que Chama do Fundo"
resumo: "Quando a seca abaixa o nível de um reservatório mineiro, reaparece o campanário de uma igreja alagada décadas atrás. O sininho, porém, foi retirado antes da inundação — e ainda assim toca à noite, chamando pelo nome de quem saiu."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-sino-que-chama-do-fundo"
tipo: "ficcao"
fonte_pesquisa: "Olhar Digital; G1; Publikagem; Cinco Chaves"
---

# O Sino que Chama do Fundo

Há coisas que a água não apaga. Apenas empresta ao esquecimento.

Em outubro, quando a estiagem rompeu o recorde de noventa anos no vale do Rio Manso, o reservatório da Usina de Salto Verde revelou o que mantinha submerso desde 1983: o campanário de tijolo e pedra-sabão da antiga Igreja de Nossa Senhora da Piedade, erguendo-se do leito seco como um dedo quebrado apontando para o céu. A água parou cinco metros abaixo da câmara dos sinos, deixando a torre exposta ao sol e aos corvos, enquanto o restante da vila de Cachoeira da Redenção continua trancado debaixo de lodo e silêncio.

Não havia plano de resgate para o sino. Antes de fecharem as comportas, a empresa removeu o bronze — ou disse que removeu. O ato constava em um formulário de dez linhas, assinado por um engenheiro que nunca pisara na vila. O povo reassentado a quinze quilômetros dali garante que o sino tocou pela última vez na noite em que a água invadiu as últimas casas. E garante, também, que ouviu o sino tocar de novo, na semana passada, debaixo de vinte metros de água.

Elias foi o primeiro a voltar.

Não morava em Cachoeira da Redenção quando a barragem fechou. Tinha nove anos e levavam as coisas em caminhão, enquanto os adultos falavam baixo sobre progresso e perda inevitável. A nova casa, na vila planejada, tinha energia elétrica, banheiro de azulejo e a sensação constante de que algo faltava no ar — algo que não se compraria em loja nenhuma. Quando as notícias da seca começaram a circular, com fotos do campanário solto no meio do nada, Elias sentiu um puxão no peito que não soube nomear. Pegou o carro, dirigiu até o reservatório e ficou parado diante da torre, de mãos nos bolsos, observando a água recuar como um réptil paciente que decide devorar devagar.

Na primeira noite, acampou aos pés do campanário. Não por coragem, mas por teimosia. Queria provar para si mesmo que não passava de concreto úmido e pedras soltas. Dormiu com a mochila travesseiro e despertou pouco antes da meia-noite com um som que não veio do lado de fora, mas de dentro do crânio. Um bronze grave, longo, insistente. O sino. Tocou três vezes, espaçadas, como quem conta algo, e parou.

Elias abriu os olhos. A lua cheia banhava a torre. Não havia ninguém por perto. O sino tinha sido removido. Mesmo que ainda estivesse lá, debaixo de metros de água, não faria som. A física não permite. Ele fechou os olhos e tentou dormir de novo.

Tocou mais uma vez, às três da madrugada. Dessa vez Elias ouviu o próprio nome.

Não era uma voz. Era o som do sino, mas seu cérebro traduziu a frequência em sílabas: E-li-as. Como se o bronze soubesse quem ele era, como se o sino não tocasse para anunciar a hora, mas para chamar pessoas específicas pelo nome. Elias saiu da barraca com o coração acelerado, iluminou a torre com a lanterna. As pedras estavam secas. O bronze, se lá estava, permanecia invisível dentro da câmara escura. O silêncio voltou, mais pesado que antes.

Ele passou os dois dias seguintes vasculhando o leito do reservatório. Encontrou vestígios da vida alagada: o batente de uma porta de cozinha, um cano enferrujado, o que restou de um poço com a pedra da beira lascada. Caminhou pelas ruas de terra agora à mostra, tentando reconhecer o lugar onde ficava a casa da avó, onde ficava a mercearia, onde ficava a igreja. Nada restou além de fundações e memória. E, no centro de tudo, o campanário, imóvel, desafiando a lógica de ter sido esvaziado.

Na terceira noite, decidiu subir.

A escada de ferro estava corroída, mas segurava. Elias subiu degrau a degrau, cada passo rangendo como um gemido, até alcançar a câmara dos sinos. Estava vazia. Vazia de bronze, de cordas, de qualquer coisa que pudesse soar. Apenas paredes úmidas, musgo e um buraco no teto pelas quais as estrelas entravam frias. Ele encostou a mão na pedra fria, fechou os olhos e esperou.

O sino tocou.

Não veio de cima. Não veio de fora. Veio de baixo — do fundo do poço sem fundo que a torre se tornara. O som subiu pelas pedras, entrou nos pés de Elias, subiu pelas pernas, pelo tórax, até estalar dentro do crânio como um sino de verdade batendo dentro do cérebro. E com o som veio a voz: não o nome dele desta vez, mas o nome da mãe, falecera dez anos antes, na vila nova, em uma cama de azulejo que nunca substituiu o cheiro de lenha da cozinha velha.

— Volte — disse o sino. Ou algo que soou como isso.

Elias desceu da torre com as mãos trêmulas. Não dormiu mais aquela noite.

Começou a pesquisar. Não encontrou nada nos arquivos da empresa: nenhum sino doado, nenhum bronze fundido de novo, nenhum registro de que o objeto tivesse saído do local. Encontrou, sim, depoimentos de mergulhadores que, nos anos seguintes à inundação, afirmaram ver a torre iluminada à noite, debaixo d'água, e ouvir badaladas que nenhum barco próximo conseguia explicar. Encontrou a lenda do padre que se recusou a deixar a igrejinha no Lago da Soledade, em Ouro Branco, e que, dizem, ainda ronda a região depois da meia-noite vestido de preto. Encontrou, em um crônica regional esquecida, a menção a "sinos que chamam as almas das águas", deixados para trás por falta de tempo ou por decisão simbólica — como se o bronze não pertencesse à igreja, mas ao lugar onde a igreja foi construída.

Elias passou a frequentar o reservatório todas as noites. O nível da água seguia baixando, centímetro por centímetro, como se a seca não fosse fenômeno meteorológico, mas uma retirada deliberada. O campanário emergia mais a cada dia, revelando pedras que ninguém via desde 1983. E o sino tocava. Toda noite. Às vezes chamava o nome de Elias. Às vezes, o de pessoas que ele nunca tivera — crianças mortas na enchente de 1983, segundo os jornais da época, embora os registros oficiais falassem apenas de "remanejamento populacional sem incidentes".

Na décima quarta noite, Elias levou um gravador e um martelo. Não sabia o que ia fazer com o martelo. Sabia apenas que não suportava mais o som vindo de dentro da própria cabeça.

Subiu novamente. A câmara estava vazia, como sempre. Colocou o gravador no chão, apontou o microfone para o buraco do teto e esperou. O sino tocou à meia-noite e vinte. Três badaladas, espaçadas, e então o nome: E-li-as. O gravador capturou tudo. Elias ouviu o áudio depois, com fones, sentado no banco do carro. No registro, o som do sino era limpo, nítido, impossível de negar. E por trás dele, quase imperceptível, uma respiração. Algo respirando dentro do bronze.

Foi quando a água começou a subir.

Não chovia. O céu estava limpo, seco, sem nuvem à vista. Mas o nível do reservatório subiu trinta centímetros em menos de uma hora, cobrindo novamente a base da torre, lambendo os degraus que Elias dera horas antes. O vento mudou. O silêncio do leito seco foi substituído por um barulho de correnteza que não vinha de lugar algum — vinha de baixo, do fundo do reservatório, de onde a água havia se retirado e para onde agora voltava com pressa.

Elias olhou para o campanário, agora parcialmente submerso, e entendeu.

A seca não tinha revelado a torre por acaso. A água não tinha recuado por falta de chuva. Algo estava puxando o reservatório para baixo, abrindo o caminho, expondo o sino, para que o som pudesse viajar. O sino não estava tocando para lamentar os mortos. Estava tocando para recrutar os vivos. Cada badalada era um convite. Cada nome chamado, uma reserva feita no fundo do lago. A torre não era um monumento ao que se perdeu. Era um isco.

E Elias, de pé na margem lúgubre do reservatório, sentiu o puxão no peito novamente — mais forte desta vez, mais certo. O sino tocou pela décima quinta vez, e dessa vez ele não traduziu apenas o nome. Traduziu o lugar. Traduziu o fundo. Traduziu o que estava esperando debaixo da água, com paciência de réptil, com tempo de século, com a certeza de que, cedo ou tarde, todo mundo que saiu volta para buscar o que deixou para trás.

Elias desligou o gravador. Deixou o martelo no banco do carro. Caminhou até a água, agora quente e escura, e não olhou para trás quando o sino tocou de novo, dessa vez bem perto, dentro de seus próprios ossos, chamando-o para casa.

## Fontes de inspiração

- Olhar Digital — "Quando a seca baixa o nível da represa, reaparece a torre da igreja de uma cidade inteira..." (ruínas da antiga cidade de Nova Ponte, MG, reveladas durante estiagem, incluindo a torre da antiga igreja e fundações visíveis no leito seco do reservatório).
- G1 — "Engolida pelas águas de Furnas, cidade mineira se reconstrói..." e "Imagem de São Francisco revela o passado submerso..." (cidades mineiras inundadas por barragens na década de 1960, remoção de populações e vestígios como cemitérios e igrejas reaparecendo em períodos de seca).
- Publikagem — "Vilarejo que fica dentro do lago da Soledade em Ouro Branco" (igreja e casa de campo submersas pela barragem de 1976 e a lenda do padre que ronda a região depois da meia-noite).
- Cinco Chaves — "O Mistério dos Sinos Submersos em Templos Antigos" (menções regionais a sinos deixados para trás em barragens de Minas Gerais e à ideia de "sinos que chamam as almas das águas").

Todas as fontes acima serviram apenas como inspiração de atmosfera e contexto. A história, os personagens e os eventos são ficção.
