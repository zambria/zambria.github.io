---
titulo: "O Estrondo da Costa"
resumo: "Em uma cidade costeira do sul do Brasil, um estrondo grave, parecido com um canhão distante, e ouvido apenas por alguns moradores em dias de céu limpo. Sem fonte identificável, o som começa a se aproximar."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-estrondo-da-costa"
tipo: "ficcao"
fonte_pesquisa: "The Hum (Anomaly Registry); O Antagonista e Terra (Zumbido de Taos / The Hum)"
status: "pendente de curadoria"
---

Na primeira vez que ouviu, Tomás acreditou que fosse um trovão. Errou duas vezes: não era trovão, e o céu estava limpo.

Era um som grave, baixo, como o disparo de um canhão a muitos quilômetros de distância, ou o eco de uma explosão subterrânea. Veio por volta das três da manhã, em uma quarta-feira de outubro, quando a cidade costeira onde ele morava dormia sob um silêncio pesado. Tomás estava na cozinha, tomando água, quando o estrondo sacudiu os copos na prateleira. Ele saiu à calçada em roupão. Os vizinhos dormiam. Os cães não ladravam. O mar, a poucos quarteirões, não tinha ondas fortes o bastante para justificar aquele ruído.

Na manhã seguinte, ninguém mencionou nada. Tomás perguntou ao dono da mercearia, ao motorista do ônibus, à vizinha do andar de cima. Todos ouviram apenas o vento, o trânsito esparso, o barulho das gaivotas. Ninguém ouvira o canhão distante.

Estrondo é uma palavra fraca para aquilo. O que Tomás escutou não estava no ar como uma música ou uma voz. Estava no peito, nos ossos, uma vibração que o corpo captava antes do ouvido entender. Uma frequência baixa, entre o audível e o sentido. Depois soube, lendo artigos soltos e relatórios esquecidos, que existem sons desse tipo registrados em Bristol, Taos e Windsor — o tal do Hum, um zumbido grave que apenas uma parcela pequena da população percebe, geralmente à noite, dentro de casa, quando tudo o mais se cala. Cientistas nunca encontraram uma fonte única. Alguns casos foram atribuídos a fábricas, fornos e turbinas. Outros, ao próprio ouvido de quem ouve. O resto permanece sem nome.

Tomás começou a ouvir mais vezes. Não todas as noites, mas o suficiente para marcar um calendário no caderno. Segunda, quarta, sábado. Sempre depois da meia-noite. Sempre com o céu sem nuvens. Nunca chovia nos dias do estrondo. Nunca havia tempestade. E, curiosamente, o som nunca aparecia em suas gravações. Ele comprou um gravador de campo, deixou o microfone virado para a janela, captou o barulho do mar, o chiado da noite, o latido distante de um cachorro. O estrondo, não. O aparelho não registrava nada que não fosse silêncio.

Foi então que percebeu que não estava sozinho.

Uma noite, na praia, encontrou um homem idoso sentado em uma das pedras do molhe, olhando para o horizonte. Não se conheciam, mas o idoso olhou para ele e disse, sem ser perguntado: "Está ouvindo de novo, não é?" Tomás confirmou. O idoso se chamou Arlindo. Disse que morava ali desde menino, que o estrondo vinha e ia em ciclos, que seu pai também o ouvia, e o pai de seu pai. "Não é do mar," Arlindo falou, com a voz rouca de quem fuma há sessenta anos. "É de baixo. Da terra debaixo da areia. Algo que não quer ser nomeado."

Tomás começou a procurar outros. Colou cartazes na mercearia, na igreja, no posto de saúde: "Ouviu um estrondo à noite? Fale comigo." Três pessoas responderam. Uma professora aposentada, um pescador, um adolescente de dezesseis anos. Nenhum dos quatro ouvia a mesma coisa exatamente, mas todos concordavam em um ponto: o som era grave, não vinha de uma direção clara, e ninguém mais na cidade parecia percebê-lo. Aparelhos de medição, quando Tomás conseguiu emprestar um decibelímetro de um amigo da universidade, não marcavam nada além do ruído ambiente. O estrondo existia apenas para alguns ouvidos.

As coisas mudaram quando o estrondo passou a vir durante o dia.

Foi em um domingo de sol, com Tomás consertando a cerca do quintal. O céu era um azul limpo, sem nuvens. O mar, calmo. De repente, o estrondo. Mais forte desta vez. Mais próximo. Tomás sentiu o peito vibrar, os dentes rangeiam, o chão cedeu sob os pés por um instante. Olhou para a vizinhança. Ninguém saía de casa. Ninguém olhava para o céu. Como se nada tivesse acontecido.

Arlindo morreu duas semanas depois. Não de causas naturais, segundo o atestado — parada cardíaca. Mas Tomás o encontrara na praia, três noites antes, sentado na mesma pedra, com os olhos fixos no horizonte e o rosto cinzento. "Está mais perto," Arlindo sussurrara. "Está aprendendo a nos encontrar." Tomás não entendeu então. Entendeu depois.

Ele começou a perder o sono. Não por causa do barulho em si, mas pelo que o barulho trazia consigo: a sensação de que algo, debaixo da costa, debaixo da areia e da rocha, estava prestes a subir. Ou que, ao ouvir o estrondo, ele estava sendo ouvido de volta.

Na última gravação que fez, Tomás deixou o aparelho ligado a noite toda, no quarto, janela fechada. De manhã, ouviu o arquivo. Havia apenas o chiado do próprio gravador, a respiração dele dormindo, o barulho da própria garganta engolindo saliva. E, no minuto três da quarta hora, um som tão baixo que só conseguiu perceber ao amplificar o volume no computador: uma vibração grave, ritmada, como um coração gigante batendo debaixo do chão. E, por cima dela, quase imperceptível, uma voz — ou algo que imitava uma voz — dizendo seu nome.

Tomás apagou o arquivo. Não contou para ninguém. Na noite seguinte, o estrondo voltou. Não veio de fora. Veio de dentro da casa, das paredes, do assoalho, como se a própria moradia estivesse sendo perfurada por algo vindo de baixo. Tomás saiu correndo para a rua, em roupão, descalço. A cidade dormia. O céu estava limpo. O mar estava calmo. E ele, agora, entendia o que Arlindo quisera dizer.

O estrondo não é um fenômeno natural. É uma chamada. E quem ouve, passa a ser ouvido.

Na manhã seguinte, Tomás não apareceu para trabalhar na oficina. O vizinho do andar de cima bateu à porta dele. Nada. Encontrou a chave debaixo do tapete, como Tomás sempre deixava. A casa estava vazia. A cama, desfeita. O gravador de campo, sobre a mesa, ainda ligado. Na fita, apenas silêncio. E, no final, um som tão baixo que a vizinha precisou encostar o ouvido no aparelho para perceber: uma vibração grave, ritmada, como um coração gigante batendo debaixo do chão. E, por cima, quase imperceptível, um nome — o nome dela, a vizinha — dito com uma voz que não era humana.

Ela desligou o gravador. Não contou para ninguém. Na noite seguinte, o estrondo voltou. E desta vez, ela também o ouviu vindo de dentro da própria casa.

## Fontes de inspiração

- The Hum — Anomaly Registry: relato de um som grave, persistente e de baixa frequência ouvido apenas por uma pequena parcela da população, em lugares como Bristol, Taos e Windsor, geralmente pior dentro de casa e à noite, sem fonte acústica identificável na maioria dos casos.
- O Antagonista e Terra (matérias sobre o Zumbido de Taos / The Hum): explicações em torno de ruídos industriais, micro-sismos oceânicos, interações eletromagnéticas e hipótese de origem no próprio sistema auditivo (zumbido de baixa frequência), com a ressalva de que não há uma explicação única e definitiva para todos os relatos.

Todos os nomes, lugares e fatos da narrativa são fictícios; as fontes serviram apenas de inspiração para a atmosfera e para o fenômeno acústico de baixa frequência.
