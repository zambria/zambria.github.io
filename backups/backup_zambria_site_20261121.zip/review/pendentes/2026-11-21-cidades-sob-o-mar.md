---
titulo: "O Abismo Engole as Ruínas: Cidades Sob o Mar e o Esquecimento Deliberado"
resumo: "O Abismo Engole as Ruínas: Cidades Sob o Mar e o Esquecimento Deliberado"
categoria: arqueologia
data: 2026-11-21
slug: 2026-11-21-cidades-sob-o-mar
---

# O Abismo Engole as Ruínas: Cidades Sob o Mar e o Esquecimento Deliberado

Há um tipo de silêncio que só existe embaixo d'água. Não é uma ausência de som — é a presença de algo que não quer ser ouvido. Quando uma cidade afunda, ela não morre de uma só vez. Ela espera. Os telhados viram topografia submarina, as igrejas se transformam em recifes de alvenaria, as ruas se tornam corredores de lama onde a luz do sol chega débil, filtrada por camadas de sedimento e tempo. A superfície continua bonita: barcos passando, pescadores lançando redes, turistas fotografando o horizonte. Ninguém desconfia que, poucos metros abaixo, há paredes ainda em pé, escadas que levam a lugar nenhum e portas que nunca mais se abrirão.

A Atlântida serve como desculpa perfeita. Platão escreveu uma ilha moralista, engolida pelos deuses como castigo pela arrogância humana, e dois milênios depois ainda queimamos documentários e livros procurando-a no fundo do Atlântico. Enquanto isso, cidades de verdade — com nomes próprios, documentos, moradores de carne e osso e datas certas de sepultamento — foram devoradas pelo oceano, por lagos e por reservatórios, e a ciência oficial as registra com a indiferença de quem guarda um processo esquecido em uma gaveta.

No estado do Rio de Janeiro, essa lenda virou episódio histórico documentado. Criada em 1739 às margens da Estrada Imperial, São João Marcos chegou a reunir dezoito mil habitantes no auge do ciclo do café, com prefeitura, cadeia, hospital, igreja, colégios, teatro e clubes. Em 1939, pressionada por planos de inundação, a população conseguiu o tombamento do município pelo Instituto do Patrimônio Histórico e Artístico Nacional — o primeiro município brasileiro a receber tal proteção. Um ano depois, em 1940, Getúlio Vargas cancelou o tombamento por decreto, atendendo à necessidade de ampliar a Usina Hidrelétrica de Ribeirão das Lajes, do grupo Light. Em 1941, a elevação da barragem do complexo alagou São João Marcos. Moradores deixaram casas, tradições e memórias para trás; as edificações foram destruídas e a cidade engolida pelas águas.

As ruínas ficaram submersas por mais de setenta anos, até que um trabalho arqueológico coordenado pelo Instituto Light em parceria com a Secretaria de Estado de Cultura do Rio de Janeiro — iniciado em 2008 e concluído em 2011 — resgatou parte da estrutura urbana. Hoje o local é o Parque Arqueológico e Ambiental de São João Marcos, em Rio Claro, descrito como o primeiro sítio arqueológico urbano do país, abrangendo cerca de novecentos e trinta mil metros quadrados de Mata Atlântica às margens da Represa de Ribeirão das Lajes. O projeto recebeu o Prêmio Rodrigo Melo Franco de Andrade, concedido pelo Iphan e pelo Ministério da Cultura, em 2011. A maior parte da cidade, no entanto, continua debaixo d'água. Só um circuito de visitação de três quilômetros, entre as praças 5 de Julho e Feliciano Sodré, junto à Igreja Matriz e à casa do Capitão-Mor, pode ser percorrido. O resto permanece submerso, inalcançável, fora da vista.

Quem é dono do que jaz debaixo d'água no Brasil? Sítios e objetos arqueológicos pertencem à União, e pesquisas em patrimônio arqueológico subaquático precisam de autorização do Iphan. As solicitações de pesquisa subaquática são encaminhadas à Marinha do Brasil, que solicita manifestação do Iphan — uma divisão de jurisdição que, na prática, complica e atrasa a proteção desses sítios. Um artigo de Gilson Rambelli, da UFBA, publicado no SciELO, critica o fato de o Brasil ainda permitir a exploração comercial — e consequentemente a destruição — desse patrimônio cultural por meio de uma legislação inadequada, inspirada nas fantasias milenares de tesouros submersos. O texto cita ainda São Vicente, no litoral paulista, cuja primeira vila foi encoberta pelo mar no século XVI, e lembra Port Royal, na Jamaica, quase toda tomada pelo mar em 7 de junho de 1692 após abalos sísmicos. A convenção da UNESCO de 2001 sobre a Proteção do Patrimônio Cultural Subaquático aparece como o marco internacional do tema — um marco que o Brasil assinou, mas que ainda parece distante da realidade de seus próprios rios e costas.

No resto do mundo, a lista de cidades afogadas é longa. Na Itália, a cerca de trinta quilômetros de Nápoles, ficam as ruínas de Baia, o balneário romano que era a "Las Vegas do Império Romano", com casas de veraneio de Júlio César e Nero e o local da morte do imperador Adriano, em 138 d.C. Submersa pelo bradisismo — o movimento gradual do solo causado pela atividade sísmica e hidrotermal dos Campos Flégreos, que fez o terreno ceder de quatro a seis metros —, Baia tem, desde 2002, suas áreas submersas protegidas como Área Marinha Protegida; apenas mergulhadores licenciados, acompanhados por guia local, podem explorar as ruínas.

No Egito, Thonis-Heracleion foi um porto próspero na foz ocidental do Rio Nilo, ponto de passagem de mercadorias de todo o Mediterrâneo, comprovado por sessenta naufrágios e mais de setecentas âncoras na região. O Decreto de Sais, uma lousa de pedra preta de dois metros com hieróglifos do início do século IV a.C., revelou detalhes do sistema fiscal egípcio e confirmou que Thonis (nome egípcio) e Heracleion (nome grego) são a mesma cidade.

Na Inglaterra, a vila de Derwent, em Derbyshire, foi submersa propositalmente em 1945 para a criação do reservatório Ladybower, que abastecia Derby, Leicester, Nottingham e Sheffield. Em verões particularmente quentes, quando o nível da água cai, as ruínas voltam a ficar visíveis, como fantasmas que a seca convoca à tona.

Na Argentina, Villa Epecuén, balneário fundado em 1920 às margens de um lago salgado na província de Buenos Aires, foi deixada sob dez metros de água salgada e corrosiva depois que uma tempestade, em novembro de 1985, rompeu uma barragem. Desde 2009, o nível da água recua e expõe a cidade novamente, em um ciclo de aparição e sumiço que parece brincar com a memória.

Na Jamaica, Port Royal, no século XVII conhecida como "a cidade mais malvada da Terra", importante centro de comércio no Novo Mundo — inclusive durante o tráfico de pessoas escravizadas —, com população estimada entre seis mil e dez mil habitantes em 1692. Perto do meio-dia de 7 de junho de 1692, um forte terremoto seguido de tsunami submergiu aproximadamente dois terços da cidade; estima-se que cerca de duas mil pessoas morreram naquele dia. Hoje, mergulhar nas ruínas preservadas exige permissão das autoridades locais.

Sítios submersos são difíceis de perceber e, por isso, fáceis de ignorar — tratados como "terra de ninguém" por autoridades e público. Enquanto a Atlântida ocupa documentários, cidades reais como São João Marcos ou Thonis-Heracleion aguardam escavações, proteção e memória. No Brasil, a disputa de jurisdição entre Marinha e Iphan e uma legislação que ainda abre brechas à exploração comercial mostram que o perigo não é só a água: é o esquecimento e o saque.

O fundo do mar não é um arquivo confiável. A corrente arrasta, o sal corrói, o sedimento enterra. Mas alguma coisa permanece. Alguma coisa sempre permanece. A pergunta que fica, uma vez que a superfície volta ao seu brilho inofensivo, é simples: o que ainda espera, intacto, no escuro abaixo das ondas — e por quanto tempo ainda conseguiremos fingir que não há nada lá?

## Fontes de inspiração

[1] Vitruvius — Arquiteturismo, "São João Marcos: Memórias de uma cidade submersa", Dayane Caputo Camacho Lopes. https://vitruvius.com.br/revistas/read/arquiteturismo/13.150-151/7499

[2] BBC News Brasil, "5 cidades ao redor do mundo que estão debaixo d'água", 30 de janeiro de 2022. https://bbc.com/portuguese/internacional-60119576

[3] SciELO — Rambelli, Gilson, "Entre o uso social e o abuso comercial: as percepções do patrimônio cultural subaquático no Brasil". https://www.scielo.br/j/his/a/Jh8pnRn7KnJ4JFHLpsMZ6Bq/?lang=pt&ilang=pt_BR
