---
titulo: "O Nome na Pedra de Esquina"
resumo: "Um restaurador chamado para vistoriar uma capela em ruínas encontra na pedra fundamental uma lista de nomes que inclui o seu, com uma data anterior ao seu próprio nascimento."
categoria: "arqueologia"
data: "2026-11-23"
slug: "o-nome-na-pedra-de-esquina"
tipo: "ficcao"
fonte_pesquisa: "Wikipedia — Pedra fundamental; Prefeitura de São Paulo — Capela de São Miguel Arcanjo"
status: "pendente de curadoria"
---

Mauro Varela chegou à capela pouco antes das sete da manhã de um sábado de junho. O céu estava cinzento sobre o bairro, uma camada baixa de nuvens que parecia pressionar os telhados, e o ar cheirava a cal velha e terra molhada. Não havia placa na entrada, nem grade fechando o terreno: apenas o arco de pedra, desfalcado pelo tempo, e o nome quase apagado sobre a verga — Nossa Senhora do Silêncio, erguida em 1891, dizia a lenda do quarteirão, pelos operários de uma fábrica de tecidos há muito demolida.

Mauro era restaurador de patrimônio. A prefeitura o contratera para assinar um laudo de estabilidade antes de liberarem a verba da reforma. Havia passado a semana anterior lendo processos empoeirados na secretaria de cultura, e nada ali o preparara para a sensação que o dominou ao cruzar o arco: a de que o lugar esperava por alguém, e que esse alguém era ele.

Dentro, a capela era menor do que parecia do lado de fora. As paredes de taipa de pilão absorviam a luz, deixando o interior numa penumbra esverdeada, como se o dia fosse filtrado por água parada. O telhado havia desabado em um dos braços da nave, e a chuva das últimas semanas transformara o chão em lama onde cresciam amontoados de capim. Mauro acendeu a lanterna de cabeça e deu os primeiros passos. O eco de seus sapatos de couro nas pedras soltas era o único som, além de um gotejamento lento vindo de algum ponto do forro comprometido.

Ele abriu o bloco de anotações. Numero as rachaduras: uma na fachada principal, outra no arco do altar, terceira na parede lateral esquerda, todas estreitas, como linhas traçadas por uma mão cansada. Fotografou os detalhes com o celular. Até ali, nada que justificasse o calafrio que o acompanhava desde a entrada. A capela estava abandonada, arruinada, esquecida — e ainda assim não estava vazia.

Algo na poeira, no cheiro de umidade, na forma como as sombras se moviam nas laterais quando ele virara a cabeça, sugeria presença. Não de pessoas. De algo que tivera tempo de se acomodar nas paredes.

Essa foi a introdução: o momento em que o cenário deixara de ser pano de fundo para se tornar palco. Mauro ainda não sabia qual peça estava prestes a começar.

Nos dias seguintes, Mauro voltou à capela sozinho. Trazia luvas, espátula de aço, lanternas de reserva. A reforma começaria na semana seguinte com uma equipe de pedreiros, mas ele queria terminar o laudo antes. Passava horas medindo espessura de paredes, anotando níveis de umidade, esboçando plantas no caderno. O bairro ao redor acordava lento: oficinas mecânicas, mercearias de portas baixas, alguns moradores idosos que o observavam das calçadas sem dizer nada.

Foi um deles quem falou, na quarta-feira, enquanto Mauro fotografava a fachada. Um homem de chapéu de feltro, casaco surrado, parado no limite do canteiro.

— Não mexe na pedra da esquina, rapaz — disse ele, sem olhar para Mauro. — Cada vez que abrem essa pedra, alguém não sai daqui.

Mauro se virou, mas o homem já havia desaparecido atrás do prédio da esquina. Ficou com a frase no ar, sem contexto, sem razão. Guarda-la no bloco de anotações de qualquer forma.

Na sexta-feira, a equipe de pedreiros chegou. Eram três homens, liderados por um mais velho, Seu Antônio, que trabalhara em restaurações no centro e conhecia a capela de vista. Mauro explicou o plano: remover a vegetação do telhado, estabilizar as paredes de taipa, reforçar o arco do altar. Não mencionou a pedra da esquina. Não mencionou o homem do chapéu.

O trabalho começou no sábado seguinte. Os pedreiros abriram a vegetação do telhado e, conforme o calendário, passaram para as fundações. Mauro os acompanhava, anotando. Foi Antônio quem encontrou a cavidade.

Estavam removendo os entulhos ao redor do canto nordeste da fachada — o ponto onde, segundo a tradição construtiva, se assenta a primeira pedra, aquela a partir da qual se decide a posição de todas as outras. A pedra da esquina. Antônio bateu o martelo na argamassa solta, e o bloco se moveu.

Debaixo dela havia um espaço, um vazio intencional construído na alvenaria. Dentro, embrulhada em um pano de algodão apodrecido, uma caixa de chumbo, de tamanho pouco maior que um livro de orações.

Mauro pediu para pararem. Colocou luvas de látex. Abriu a caixa.

Havia dentro um pergaminho, amarelado e rígido, protegido por uma fina camada de cera derretida que se despedaçou ao toque. Também um punhado de moedas de cobre, um pedaço de jornal ilegível e um alfinete de segurança enferrujado. O pergaminho era uma ata. O título, escrito em letra gótica, datava a cerimônia de 14 de outubro de 1891: lançamento da pedra fundamental da Capela de Nossa Senhora do Silêncio.

Mauro leu em voz alta, para si mesmo, enquanto os pedreiros esperavam do lado de fora.

A ata listava os presentes: o padre que abençoara a obra, o construtor, o pedreiro-mestre, os ajudantes, os moradores do quarteirão que haviam doado cal e tijolos. Cada nome acompanhado da função. E, no final da lista, escrita com uma caligrafia mais recente, mais escura, um nome que não deveria estar ali.

Mauro Varela. Data de nascimento: não constava. Data do falecimento: 23 de junho de 2026. Hoje.

Ele leu o nome três vezes. Verificou a assinatura no final da ata — um rubro ilegível, carimbado com cera vermelha. Verificou o próprio nome na carteira de identidade no bolso da camisa. Mauro Varela. Nascido em 1983. Não havia qualquer razão para que seu nome estivesse em um documento de 1891, muito menos com a data de hoje ao lado.

Guardou o pergaminho dentro da própria jaqueta. Fechou a caixa de chumbo. Pediu a Antônio que recolocasse a pedra no lugar, sem dizer por quê.

Naquele domingo, Mauro voltou sozinho à capela. Trazia o pergaminho, uma lupa, a câmera. Precisava entender. A caixa estava no lugar, a pedra reassentada, mas Mauro sabia o que havia lido. Começou a investigar a história da capela da única forma que conhecia: através dos papéis.

Na secretaria de cultura, encontrou dois processos de restauro. Um de 1939, assinado por um arquiteto chamado Luis Saia — o mesmo que restaurou a igreja de São Miguel, anos antes. Outro de 1974, assinado por uma empresa de engenharia já extinta. Ambos os processos terminavam da mesma forma: a obra concluída, o laudo aprovado, e um acidente nas semanas seguintes. Em 1939, um pedreiro caiu do telhado da capela e morreu no hospital da Santa Casa. Em 1974, um operário foi soterrado por um desabamento parcial da parede lateral durante a limpeza das fundações. Dois homens. Dois nomes. Dois acidentes.

E um detalhe que só Mauro notou: nos dois processos, o laudo final havia sido assinado por um restaurador chamado Mauro Varela.

Não o Mauro de 1983. O mesmo nome, a mesma grafia, a mesma assinatura no rodapé dos documentos. Mauro pediu cópias. Comparou as assinaturas com a sua. Idênticas. Não cópias fotostáticas — a mesma mão, o mesmo traço, como se o homem de 1939 e o homem de 1974 tivessem aprendido a escrever exatamente como Mauro escreveria cem anos depois.

A coisa ficou pior no arquivo da paróquia. O padre atual, um homem jovem que nunca estivera na capela antes da reforma anunciada, entregou a Mauro um registro de batizados e óbitos antigo, encadernado em couro rachado. Lá, entre as páginas de 1891, Mauro encontrou uma entrada:

"Mauro Varela, sepultado nos terrenos da capela em 15 de outubro de 1891, vítima de acidente durante a obra. Idade aproximada: quarenta anos."

Quarenta anos. Mauro tinha quarenta e dois. Nasceu em 1983. Não conhecia nenhum parente distante chamado Mauro Varela. Sua família era do interior de Minas, sem relação com São Paulo. E ainda assim, ali estava: o nome, a data, o local.

Ele saiu do arquivo com o registro nas mãos e andou quarteirões sem sentir os pés. O nome na pedra de esquina. O nome na ata. O nome nos laudos de 1939 e 1974. O nome no livro de óbitos de 1891. Quatro momentos, um mesmo homem — ou algo que usava esse nome como uma chave.

Na segunda-feira, Mauro foi até a capela antes dos pedreiros. Abriu a caixa de chumbo novamente. O pergaminho ainda estava lá. Dessa vez, leu a lista toda com atenção.

O padre. O construtor. O pedreiro-mestre. Os ajudantes. Os moradores. Eram os nomes da ata original. Depois deles, escritos com a caligrafia escura, vieram quatro nomes a mais: um de 1939, um de 1974, o de Mauro Varela em 23 de junho de 2026... e um quarto, que não lembrava de ter visto antes, com uma letra ainda mais trêmula: Antônio Ferreira, 14 de outubro de 2026.

Mauro fechou os olhos. A frase não fazia sentido administrativo. Fazia sentido ritualístico. A tradição da pedra fundamental, que ele lera na pesquisa, não era apenas cerimonial. Em sua forma mais antiga, o rito substituiu uma prática ainda mais antiga: enterrar uma pessoa viva nos muros de uma construção nova, para dar força e durabilidade à edificação — ou, mais especificamente, para que o fantasma irado da vítima assombrasse o local e o protegesse contra intrusos. A caixa de chumbo com a ata era o resíduo moderno desse sacrifício. A lista de nomes não era um registro de presença. Era uma lista de substitutos.

Mauro sentiu o ar faltar nos pulmões. Se a tradição se repetira a cada restauro — um nome novo acrescentado à lista, um homem morto nas semanas seguintes — então a capela não precisava de fantasmas do passado. Precisava de um presente. Precisava de Mauro.

O tempo passou. Os pedreiros chegaram na terça. Antônio olhou para Mauro e disse:

— O senhor parece um homem que já sabe o que vai acontecer.

Mauro não respondeu. Passou o dia medindo rachaduras, evitando olhar para o canto nordeste da fachada. À noite, voltou sozinho. Levou o cinzel, o martelo, uma lanterna. Precisava ver a caixa. Precisava saber se seu nome ainda estava ali, ou se havia mudado.

A capela estava mais escura do que nunca. A lua não passava pelas nuvens. Mauro abriu a caixa de chumbo pela terceira vez. O pergaminho estava lá. Ele desenrolou o documento com mãos trêmulas.

A lista agora tinha cinco nomes adicionados depois da ata original. Os nomes de 1939, 1974, 2026 e o de Antônio Ferreira estavam ali. E um quinto nome, escrito com a mesma caligrafia escura, que não estivera lá na primeira leitura: Mauro Varela, 24 de junho de 2026. Amanhã.

O coração de Mauro bateu forte, uma batida só, e parou. Não de medo — de reconhecimento. Como se o corpo já soubesse o que a mente recusava aceitar.

Ele ouviu passos no telhado. Ouviu a voz de Antônio lá embaixo, no terreiro, chamando pelo nome. Mauro fechou a caixa de chumbo, colocou o pergaminho de volta, reassentou a pedra da esquina com o martelo de pedreiro. Cada golpe soava como um batimento cardíaco nas paredes de taipa.

Quando terminou, o arco da entrada não levava mais para a rua. Levava para a mesma capela, para o mesmo chão de lama, para as mesmas paredes que absorviam a luz. Mauro tentou andar para trás. O espaço se fechou atrás dele como uma ferrugem.

A chuva começou a cair, forte, dentro e fora ao mesmo tempo. Mauro sentou no banco da frente da nave — o único banco que restara, de madeira quebrada — e esperou. Não havia mais nada a fazer. O laudo nunca seria assinado. A reforma nunca começaria. A obra só se fecha quando o último nome é selado dentro da pedra, e seu nome era o último.

Na última página do bloco de anotações, Mauro escreveu uma frase que ninguém jamais leria:

"Se você está lendo isto, não abra a pedra da esquina."

Ele colocou o bloco dentro da caixa de chumbo, ao lado do pergaminho, fechou a tampa, e esperou o amanhã chegar.

Às sete da manhã do dia seguinte — ou seria o mesmo dia? — os pedreiros encontraram a capela exatamente como a deixaram. A pedra da esquina no lugar. A caixa de chumbo dentro. O laudo de estabilidade não assinado. De Mauro Varela, nenhum sinal. O bairro disse que nunca vira um restaurador por ali. O arquivo da paróquia não continha nenhum Mauro Varela nos livros de batizados ou óbitos. Os processos de 1939 e de 1974 haviam desaparecido da secretaria de cultura.

Apenas o bloco de anotações ficou, selado na caixa de chumbo, com a frase na última página. E apenas o eco, nas paredes de taipa de pilão, de um nome que a capela conhecia muito antes de existir o homem que o carregava.

A construção, finalmente, estava completa.

## Fontes de inspiração

1. Wikipedia — "Pedra fundamental": tradição da cápsula do tempo com ata e nomes dos presentes; origem do rito como substituto do sacrifício de uma pessoa enterrada nos muros da construção.
2. Prefeitura de São Paulo — "História e restauro da igreja mais antiga de São Paulo" (Capela de São Miguel Arcanjo): histórico de restaurações, paredes de taipa de pilão e reparos ao longo dos anos.
