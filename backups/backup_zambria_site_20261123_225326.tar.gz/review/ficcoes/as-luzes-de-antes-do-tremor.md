---
titulo: "As Luzes de Antes do Tremor"
resumo: "Uma técnica sismológica registra clarões no céu que antecedem micro-tremores no interior de Minas Gerais, até perceber que as luzes não avisam o desastre — elas o anunciam."
categoria: "fenomenos-naturais"
data: "2026-11-23"
slug: "as-luzes-de-antes-do-tremor"
tipo: "ficcao"
fonte_pesquisa: "Geoscopy — Luzes de terremoto: a ciência por trás do brilho; IAG-USP — Tremores em Divinópolis-MG"
status: "pendente de curadoria"
---

# As Luzes de Antes do Tremor

A noite em que Artur Viana viu a primeira luz não foi diferente das outras dezoito noites de plantão na Estação Sísmica de São Miguel. Mesmo silêncio. Mesmo zumbido baixo dos aparelhos de ar-condicionado lutando contra o calor de Minas Gerais em novembro. Mesmo giro lento do helícordio de papel no sismógrafo de tambor, traçando a linha preta e contínua do repouso. Artur estava sozinho, como costumava estar nas madrugadas de segunda-feira. A estação ficava a quatorze quilômetros de Felixlândia, município que, nos últimos dezoito meses, havia se acostumado a acordar sob a terra tremente.

A primeira luz apareceu às duas horas e dezoito minutos da manhã. Não foi relâmpago — não havia nuvens, nem trovão, nem chuva no radar. Foi um clarão branco-azulado sobre a crista da serra a oeste, durando menos de três segundos, como se um refletor gigante tivesse varrido o topo da montanha e se apagado. Artur levantou da cadeira, caneta na mão, e olhou pela janela do pavilhão de observação. Nada. Só a escuridão dos pastos e o contorno serrado das árvores contra o céu sem lua.

Três minutos depois, às duas e trinta e um, o sismógrafo de tambor registrou um salto vertical agudo, um micro-tremor de magnitude 1,3, epicentro estimado a uns nove quilômetros dali, profundidade rasa. Nenhum morador de Felixlândia sentiu. A rede sismográfica brasileira captou, o centro em Brasília arquivou, e a vida seguiu. Artur anotou no caderno de plantão: "Luminosidade prévia ao evento MS-2247. Verificar câmera externa."

Ele não verificou na noite seguinte. Na noite seguinte, a luz voltou.

Às três horas e quarenta e cinco, um clarão mais longo, quase cinco segundos, na mesma crista da serra. Às quatro e doze, outro micro-tremor, magnitude 1,1. Artur passou a noite inteira anotando horas e coordenadas, comparando os dois registros lado a lado. O padrão era simples e absurdo: a luz vinha primeiro, o tremor vinha depois. Não ao contrário. Não simultaneamente. Primeiro o céu se acendia sobre a serra, e só então a terra se mexia.

Nos dias que se seguiram, Artur começou a caçar os clarões. Instalou uma câmera digital apontada para o oeste, com tomada contínua e gravação em cartão de memória. Revisou os arquivos da estação desde 1984, ano em que o pavilhão foi erguido. Nunca houve menção a luzes nos relatórios anuais. A sismicidade de Minas é de baixa magnitude, dispersa, sem grandes falhas ativas na superfície — ou assim diziam os livros. O estado lidera o número de registros no Brasil, mas são eventos pequenos, enxames que duram semanas e somem, abalos que asustam cachorros e fazem tremer copos na prateleira sem derrubá-los.

Foi então que Artur lembrou de Itacarambi. De São Francisco. Do norte de Minas, onde a terra já matou. O terremoto de Itacarambi, em 2007, magnitude 4,9, primeira morte oficial por abalo sísmico no Brasil, centenas de desabrigados, paredes rachadas, igrejas históricas em ruínas. O de São Francisco, em 1931, magnitude 4,9 também, sentido em vários estados. Artur leu que, nesses episódios antigos, moradores relataram clarões no céu antes e depois dos abalos — luzes que os jornais da época chamavam de "fogos no horizonte" e os padres atribuíam a sinais. Relatos folclóricos, descartados pelos sismólogos modernos. Anedotas.

Mas as anedotas de Artur agora tinham data, hora e amplitude. Ele abrira uma pasta no computador chamada "Luminosidade" e ali colava capturas: luzes em forma de orbe, folhas de luz que se desdobravam como folhas de papel caindo ao contrário, rastros curtos que subiam do solo para o céu. Não eram relâmpagos. Relâmpago ramifica, crepita, anuncia tempestade. Essas luzes apareciam com céu limpo, sem vento, sem trovão. Apariam sobre a crista da serra, ou mesmo acima dos pastos próximos à estação, rasteiras, como se a terra exalasse claridade.

Na terceira semana, Artur ampliou o monitoramento. Pediu ao colega da cidade vizinha os dados brutos da estação sismográfica mais próxima. Confirmou: cada um dos vinte e sete micro-tremores registrados em outubro e novembro havia sido precedido por um clarão, entre vinte minutos e duas horas antes. O intervalo variava, mas a ordem nunca se inverteu. Luz primeiro, terra depois.

Ele começou a perder sono. Não pelo trabalho — pelo inverso. Passava as noites acordado, vendo a câmera, e os dias dormindo mal, sonhando com cristas brilhando no escuro. No quarto dia da terceira semana, a câmera capturou algo diferente: um clarão nasceu não no céu, mas de uma fenda exposta na rocha, a meia encosta da serra, e permaneceu ali, pulando, por quase um minuto, antes de se apagar. Nenhum tremor seguiu. A linha do sismógrafo permaneceu plana.

Artur ficou sentado na cadeira, frio. A ordem tinha se quebrado. Ou talvez não tivesse quebrado — talvez tivesse se invertido.

Foi quando ele lembrou do que lira sobre as luzes de terremoto. O estudo de 2014, publicado na Seismological Research Letters, reunira sessenta e cinco casos documentados desde o ano de 1600, nas Américas e na Europa. Oito entre dez estavam associados a terremotos acima de magnitude 5,0. Oitenta e cinco por cento dos relatos ocorriam em falhas intraplaca, longe das bordas tectônicas, exatamente como Minas Gerais. E o mais importante: não havia mecanismo único, consenso, explicação fechada. Alguns geofísicos falavam de cargas elétricas geradas por rachaduras nas rochas sob tensão; outros duvidavam que qualquer relato isolado fosse prova de coisa alguma. O Serviço Geológico dos Estados Unidos observa que muitos flashes capturados em vídeo são, na verdade, redes elétricas falhando durante tempestades. Mas não havia tempestade em Felixlândia. Não havia rede elétrica na crista daquela serra.

Artur decidiu subir até lá.

Na sexta-feira, ao anoitecer, deixou a estação com o carro velho da instituição, uma câmera, um gravador de fita e uma lanterna. A estrada de terra subia entre pastos e eucaliptos, e o cheiro de terra molhada e minério ficava mais forte a cada curva. O Quadrilátero Ferrífero é uma cicatriz de mineração antiga: buracos, escórias, galerias abandonadas do século dezenove que ninguém mapeou direito. Artur parou o carro em um ponto onde a rocha aparecia exposta, uma falha escura atravessando o monte como uma cicatriz aberta, e desceu.

O escuro da serra não é o escuro da cidade. É espesso, úmido, cheio de sons que não pertencem a lugar nenhum. Artur caminhou com cuidado, lanterna baixa, até chegar à falha. Colocou o gravador no chão, ligou, recuou alguns passos. Esperou. O vento fazia um sopro baixo entre as pedras. Nada aconteceu por quase uma hora.

Ele já estava de volta ao carro quando ouviu no gravador, ao rebobinar a fita, um zumbido grave, infrassônico, algo que o ouvido não capta no momento mas o corpo sente — uma vibração nos ossos da face, uma pressão nos ouvidos. E, ao fundo, quase imperceptível, um estalo seco, como de pedra se partindo longe, muito longe, sob a terra.

Na semana seguinte, um tremor de magnitude 3,1 foi sentido em Felixlândia. Pessoas saíram às ruas em pijama. Duas casas tiveram rachaduras nas paredes. O jornal local publicou uma nota curta, sem aspas de especialistas: "Defesa Civil monitora enxame sísmico; não há risco iminente." Artur telefonou para o município na segunda-feira, pediu para falar com alguém da Defesa Civil, explicou o que vinha registrando: luzes, horários, correlação com os eventos. A atendente ouviu com paciência e disse que passaria o recado. Ninguém ligou de volta.

Artur não desistiu. Passou a dormir na estação nos dias de plantão, café forte, olho na câmera, olho no sismógrafo. Tornara-se obsessivo da forma silenciosa que só quem trabalha sozinho consegue ser. Reviu os jornais antigos da região, os boletins da Vale, os relatórios do IAG-USP sobre enxames passados em Divinópolis, Bom Sucesso, Montes Claros. Enxames que duravam meses. Sismos que vinham e iam, sem razão aparente, sem grande destruição. Minas Gerais acumula mais de novecentos eventos registrados desde 1824, e a maioria nunca passou de um susto.

Mas o susto estava mudando de natureza.

Na décima quarta noite de observação contínua, a luz não apareceu sobre a serra. Apareceu sobre o pavilhão da estação.

Artur estava na cadeira, ouvindo o zumbido do ar-condicionado, quando viu pelo canto do olho um clarão refletido na janela do pavilhão. Virou-se. Do lado de fora, nas paredes de concreto do prédio, um brilho branco-azulado subiu do chão até o beirado do telhado, durou quatro segundos, e se apagou. Ele foi até a porta, abriu, olhou ao redor. Não havia nada. Nenhum carro, nenhuma lanterna, nenhuma linha de energia rompida. Só o pasto escuro e a serra ao fundo, quieta.

Correu para o sismógrafo. Linha perfeitamente plana. Nenhum tremor. Nenhum micro-event. A terra estava quieta como nunca estivera nas últimas semanas.

Foi então que Artur entendeu, com um horror frio que não vinha do corpo, que tinha lido a ordem errada o tempo todo.

As luzes não avisavam que o tremor viria. As luzes não eram o precursor. As luzes eram o que restava depois que algo passava pela crosta. O tremor não era a causa; era o eco. O abalo sísmico era o assentamento da terra depois que a passagem já tinha acontecido. Os sismógrafos registravam o eco. As câmeras registravam a porta se abrindo.

E se a luz tinha aparecido sobre o pavilhão da estação, o eco ainda não tinha chegado — ou já tinha chegado, e Artur estava em pé sobre o lugar por onde algo havia passado, ou ainda estava passando.

Desligou as luzes da estação. Ficou no escuro, de pé no centro do pavilhão, ouvindo. O zumbido do ar-condicionado tinha parado — alguém, ou algo, havia desligado o disjuntor, ou o aparelho parara sozinho. O silêncio voltou, denso, absoluto. Artur passou a mão na mesa, encontrou o gravador de fita, apertou o botão. Não havia motivo para gravar, mas fez assim mesmo, por hábito, por teimosia.

Do lado de fora, entre o pasto e a estação, uma claridade baixa começou a se mover. Não era relâmpago. Não era lanterna. Era uma luz que rasteira pelo chão, sem fonte visível, sem sombra, aproximando-se devagar do pavilhão. Artur não saiu para verificar. Não ligou o carro. Não telefonou para ninguém. Ficou parado, escutando o próprio coração bater no silêncio da câmara de concreto, e sentiu o chão vibrar levemente sob os pés — não um tremor de sismógrafo, algo diferente, algo mais lento, mais íntimo, como se a própria terra estivesse respirando sob ele.

A última coisa que Artur escreveu no caderno de plantão, antes de a luz alcançar a janela, foi uma frase curta, sem data:

"Não tremeu ainda. Não vai tremer. A porta já está aberta."

Ele fechou o caderno. Deixou a caneta em cima. Esperou, no escuro, que o chão deixasse de ser só chão.

## Fontes de inspiração

- Geoscopy (PT-BR), "Luzes de terremoto são reais? A ciência por trás do brilho": revisão sobre os fenômenos luminosos conhecidos como luzes de terremoto (EQL), citando o estudo de Derr et al. (2014, Seismological Research Letters) com sessenta e cinco casos documentados desde 1600, a concentração de oitenta e cinco por cento dos relatos em falhas intraplaca, a ausência de mecanismo único consensual e a cautela do USGS quanto a interpretar relatos isolados como prova sólida ou confundi-los com falhas de redes elétricas.
- IAG-USP, "Tremores em Divinópolis-MG": relatório sobre o enxame sísmico de janeiro de 2022 na região de Belo Horizonte e Quadrilátero Ferrífero, incluindo o histórico de sismicidade de Minas Gerais (São Francisco 1931, Itacarambi 2007, Montes Claros 2012) e a ocorrência de surtos de sismos que duram semanas ou meses sem dano relatado.

---
