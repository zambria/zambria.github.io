---
titulo: "Eles Levam Pessoas: O Vazio da Abdução e o Medo de Dormir"
resumo: "Uma investigação sobre o fenômeno da abdução alienígena, do caso de Antônio Vilas-Boas às ocorrências de Quixadá, passando pela escala de Hynek, os contatados e as explicações científicas da paralisia do sono."
categoria: "ufo"
data: "2026-11-21"
slug: "eles-levam-pessoas-2026-11-21"
status: "draft"
tags: [abdução, contato-quarto-grau, vilas-boas, quixadá, escala-hynek, paralisia-do-sono]
---

# Eles Levam Pessoas: O Vazio da Abdução e o Medo de Dormir

## Resumo executivo

Este artigo é sobre a abdução — o encontro imediato de quarto grau na escala de Hynek — e sobre o que ela significa para quem afirma tê-la vivido e para quem tenta entendê-la com a ferramenta da ciência. Do caso inaugural de Antônio Vilas-Boas, em Minas Gerais, às noites de vigília em Quixadá, no Ceará, passando pelas explicações da paralisia do sono e pelas memórias falsas, traçamos o contorno de um fenômeno que se recusa a ser resolvido.

## Introdução

Dormir é um ato de confiança. É entregar a consciência, por algumas horas, à escuridão do quarto e à crença de que, ao despertar, estaremos no mesmo lugar onde deitamos. Para quem afirma ter sido abduzido, essa confiança é quebrada de forma violenta e silenciosa: a pessoa é levada contra a vontade, retirada de seu ambiente terrestre e levada a um lugar percebido como uma nave espacial, onde passa por exames fisiológicos e psicológicos antes de ser devolvida — às vezes para um local diferente do de origem, ou com ferimentos e roupas desarrumadas [1]. A memória da experiência pode sumir completamente, ressurgindo apenas anos depois, sob hipnose, ou nunca mais voltar [1]. O que acontece com quem volta?

## Desenvolvimento

### O que é a abdução e a escala de Hynek

A abdução alienígena, também chamada de fenômeno de abdução ou sequestro por OVNI, é o fenômeno reivindicado por pessoas que relatam terem sido sequestradas por seres extraterrestres e submetidas a experimentações físicas e/ou psicológicas [2]. Na classificação criada pelo astrônomo Josef Allen Hynek, publicada em 1972 no livro «The UFO Experience: A Scientific Inquiry», o encontro imediato de quarto grau é justamente aquele em que um ser humano é abduzido por um OVNI ou seus ocupantes [3][4]. Antes dele vêm as luzes noturnas (primeiro grau), os discos à luz do dia (segundo grau) e as observações de entidades (terceiro grau), mas é o quarto grau que carrega o peso mais sombrio: a perda do controle sobre o próprio corpo [3][4].

Pesquisadores como Thomas E. Bullard identificaram uma sequência comum nos relatos de abdução: captura, exame e procedimentos, conferência (comunicação, frequentemente telepática), tour pela nave, perda de tempo, retorno e consequências [2]. Apesar das variações culturais, os relatos apresentam elementos recorrentes: a luz que emana de fora da casa ou aparece no quarto e se transforma em figuras alienígenas; a incapacidade de resistir e ser levado; o exame médico invasivo, com ênfase nos sistemas reprodutivos; a perda de tempo e de memória [5].

### O primeiro grande caso: Antônio Vilas-Boas

Embora histórias semelhantes já circulassem, as alegações de Antônio Vilas-Boas foram um dos primeiros relatos de abdução alienígena a receber ampla atenção. Em 16 de outubro de 1957, o agricultor brasileiro afirmava ter sido levado por seres humanoides a bordo de um objeto oval e brilhante que pairara sobre o campo onde trabalhava com um trator, próximo a São Francisco de Sales, Minas Gerais [6][7]. Vilas-Boas descreveu ter sido levado ao interior da nave, despido à força, submetido à coleta de amostras de sangue por meio de tubos flexíveis e, depois, deixado a sós com uma mulher de pequena estatura, inteiramente nua, com quem acabou tendo relações sexuais [6][7]. Antes de ser devolvido ao campo, tentou pegar um objeto para provar a história, mas os seres o tomaram de volta. A nave decolou verticalmente e desapareceu [6][7].

Vilas-Boas foi examinado pelo Dr. Olavo Fontes, no Rio de Janeiro, em 22 de fevereiro de 1958, no consultório médico e na presença do jornalista João Martins [7]. Fontes relatou lesões na pele e sintomas que, em 1966, descreveu como sugestivos de exposição à radiação [6]. O caso brasileiro antecedeu em alguns anos o célebre sequestro de Betty e Barney Hill, nos Estados Unidos, em 1961, considerado a primeira alegação de abdução amplamente divulgada mundialmente [2]. Ambos os casos estabeleceram o molde narrativo que ainda hoje define o que o público entende por «abdução alienígena».

Décadas depois, surgiu uma explicação alternativa: o ex-agente da CIA Bosco Nedelcovic afirmou ter participado de uma operação da agência que borrifou drogas alucinógenas em Vilas-Boas, induzindo-o a pensar que estava sendo abduzido — uma versão que liga o caso ao controverso programa MKULTRA de controle mental [6]. Como tantas outras narrativas de abdução, o caso Vilas-Boas permanece sem verificação independente e sem conclusão definitiva [6].

## Quixadá: o sertão que recebe naves

No sertão central do Ceará, a cidade de Quixadá concentra relatos de contatos extraterrestres desde a década de 1960 [8]. Em 14 de maio de 1960, a escritora cearense Rachel de Queiroz — pessoa cética e acostumada a olhar para o céu — viu, na companhia de familiares e trabalhadores de sua fazenda, uma luz alaranjada cercada por um «halo luminoso e nevoento», que variava de intensidade, velocidade e aparência antes de sumir após mais de dez minutos [8]. Pelo menos vinte pessoas teriam presenciado o fenômeno [8].

Desde então, a região acumulou dezenas de relatos de visões e abduções, incluindo o chamado «caso Barroso», a partir de 1973, que inspirou o roteiro do filme «Área Q» (2012) [8][9]. Moradores relatam contatos de até quarto grau, quando há comunicação direta com os seres extraterrestres [8]. Weliston Paiva, estudioso da ufologia no Ceará, acompanha mais de 120 casos na região do Sertão Central e detalha que os contatos seguem padrões semelhantes: buscar pessoas que estão isoladas para fazer a abdução, levando as pessoas para suas naves para realizar estudos, e depois devolvê-las ao mesmo local [8].

O historiador Tácito Rolim, professor da Universidade Estadual do Ceará, analisou notícias que circulavam no Ceará entre 1956 e 1959 e encontrou 48 relatos de acontecimentos estranhos que causaram medo na população: aparições de objetos luminosos, clarões, estrondos e tremores de terra [8]. Ele destaca que esse foi um fenômeno mundial, parte da «Era dos Discos Voadores», vinculado ao contexto político da Guerra Fria [8].

## Os contatados e a comunicação silenciosa

Paralelamente aos abduzidos, existem os «contatados»: pessoas que afirmam manter contato voluntário e, em muitos casos, benéfico com seres extraterrestres, recebendo mensagens e sabedoria que se sentem compelidas a compartilhar [5]. Vitório Peret, tripulante aposentado que participou de vigílias em Belém, relatou ao G1 um contato de terceiro grau em 1982, na praia da Baía do Sol: por aproximadamente dez segundos, viu um extraterrestre ao seu lado, que se comunicou por sinais ou vibrações mentais, sem som vocal [9]. «Não houve diálogo, som, nada vocal. Foi mental», disse Peret [9]. Os contatados costumam descrever experiências com seres de aparência humana e espiritualmente evoluídos, em contraste com os abduzidos, que raramente relatam suas experiências de forma positiva [5].

Em 2014, Curitiba sediou o II Fórum Mundial de Contatados, reunindo cerca de 500 pessoas de todo o mundo que dizem ter estabelecido contato com seres extraterrestres e suas naves [9]. O evento ilustra como o fenômeno dos contatos se expandiu de casos isolados para fóruns mundiais e protocolos rituais de comunicação [5][9].

## O que a ciência e o ceticismo dizem

A grande maioria dos cientistas e profissionais de saúde mental explica as experiências de abdução por fatores como sugestionabilidade, síndrome da falsa memória, paralisia do sono, engano e psicopatologia [5][10]. O cético Robert Sheaffer aponta semelhanças entre os alienígenas descritos por abduzidos e aqueles retratados em filmes de ficção científica, como «Invaders From Mars» (1953) [5]. Alguns pesquisadores argumentam que a maioria dos abduzidos são pessoas sãs e comuns, e que a psicopatologia está associada apenas a alguns casos [5]. No entanto, a ciência convencional rejeita as alegações de que o fenômeno ocorre literalmente como relatado [5].

A paralisia do sono é frequentemente apontada como explicação para muitos relatos de abdução [4][10]. É uma condição noturna na qual parte do cérebro acorda enquanto o corpo permanece temporariamente paralisado, frequentemente acompanhada de alucinações de figuras ameaçadoras, pressão no peito e sensação de presença no quarto [4][10]. Pesquisadores acreditam que essas alucinações podem ter alimentado a crença nas bruxas na Europa, no início da Idade Moderna, e talvez até expliquem alguns relatos atuais de abdução por alienígenas [4]. Quase 8% dos adultos afirmam ter passado pela experiência em algum momento da vida [4].

O professor Chris French, diretor da Unidade de Pesquisa de Psicologia do Goldsmiths College, em Londres, comparou 19 supostos «abduzidos» com 19 voluntários escolhidos ao acaso e descobriu que os primeiros tinham tendência a alucinações, a acreditar em tudo que é paranormal e a dissociar a realidade, além de relatar «paralisias do sonho» [10]. Para French, milhares de pessoas no mundo poderiam experimentar lembranças falsas desse tipo [10].

O psiquiatra de Harvard John E. Mack, uma autoridade sobre os efeitos espirituais de supostas experiências de abdução, adotou uma postura mais cautelosa: «O mais longe que você pode ir neste momento é dizer que há um mistério autêntico aqui» [6]. Jacques Vallée e Mack sugeriram que a dicotomia 'real' versus 'imaginário' pode ser simplista demais para compreender um fenômeno tão complexo [6].

## Conclusão

Se a abdução é um evento físico, um produto da mente ou uma mistura de ambos, o que fica é o vazio que ela deixa. O medo de dormir, a memória fragmentada, a sensação de que algo observou e levou embora sem deixar provas que resistam à ciência — tudo isso é real para quem vive [1][8][9]. Os céus podem estar cheios de naves, ou podem estar vazios; o que é certo é que, para os abduzidos, a noite deixou de ser um lugar seguro [1][5]. E quando o dia amanhece, a pergunta permanece, fria e sem resposta: o que aconteceu enquanto dormiam, e por que eles foram os escolhidos para levar essa lembrança — ou esse esquecimento — pelo resto da vida? [4][10]

## Fontes

[1] pt.wikipedia.org — Caso Vilas-Boas. https://pt.wikipedia.org/wiki/Caso_Vilas-Boas
[2] pt.wikipedia.org — Perspectivas sobre o fenômeno de abdução. https://pt.wikipedia.org/wiki/Perspectivas_sobre_o_fen%C3%B4meno_de_abdu%C3%A7%C3%A3o
[3] ufologico.com.br — Escalas de Classificação: de Hynek & Outros. https://ufologico.com.br/escala-de-hynek/
[4] BBC News Brasil — Como a ciência explica misteriosa 'paralisia do sono'. https://www.bbc.com/portuguese/articles/c3gjqq4ljv8o
[5] en.wikipedia.org — Close encounter. https://en.wikipedia.org/wiki/Close_encounter
[6] arquivoufo.eurisko.com.br — Caso Villas Boas, o brasileiro abduzido por extraterrestres. https://arquivoufo.eurisko.com.br/2012/02/23/caso-villas-boas-o-brasileiro-abduzido-por-extraterrestres/
[7] g1.globo.com — Abduções e visões em Quixadá: cidade do sertão cearense concentra relatos de contatos extraterrestres. https://g1.globo.com/ce/ceara/noticia/2023/08/04/abducoes-e-visoes-em-quixada-cidade-do-sertao-cearense-concentra-relatos-de-contatos-extraterrestres.ghtml
[8] g1.globo.com — Fórum reúne pessoas que dizem ter sido contatadas e abduzidas por ETs. https://g1.globo.com/pr/parana/noticia/2014/05/forum-reune-pessoas-que-dizem-ter-sido-contatadas-e-abduzidas-por-ets.html
[9] ovnihoje.com — Alguns casos famosos de abdução por alienígenas. https://www.ovnihoje.com/2023/03/27/alguns-casos-famosos-de-abducao-por-alienigenas/
[10] estadao.com.br — Abdução extraterrestre é construção mental, diz estudo. https://www.estadao.com.br/ciencia/abducao-extraterrestre-e-construcao-mental-diz-estudo/

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
