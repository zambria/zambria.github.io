---
titulo: "O Quarto Grau: Quando a Luz Desce e a Pessoa Desaparece"
resumo: "Quixadá, no sertão cearense, concentra relatos de avistamentos e abduções desde os anos 1960, incluindo o caso Barroso (1973) e dezenas de contatos mapeados por ufólogos locais. Na escala de Hynek, o quarto grau é o contato em que o ser humano é levado para dentro da nave — uma categoria que a ciência oficial não reconhece."
categoria: "ufos"
data: "2026-11-21"
slug: "quarto-grau-2026-11-21"
status: "draft"
tags: [ufos, abducao, quixada, ceara, escala-hynek, quarto-grau]
---

# O Quarto Grau: Quando a Luz Desce e a Pessoa Desaparece

## Resumo executivo

Quixadá, no sertão central do Ceará, concentra relatos de avistamentos, abduções e contatos extraterrestres desde os anos 1960, incluindo o emblemático "caso Barroso", de 1973, e mais de 80 casos mapeados pelo ufólogo Weliston Paiva [1][2]. Na escala de Hynek, criada pelo astrônomo J. Allen Hynek em 1972, o quarto grau é a categoria em que um ser humano é levado para dentro de um OVNI por seus ocupantes — abdução — uma classificação que Hynek mesmo não reconheceu formalmente e que a ciência oficial não valida [3][4][5]. Os relatos cearenses incluem sequelas físicas e mentais, perda de memória e objetos introduzidos no corpo dos supostos abduzidos [1][2]. Até hoje, não há comprovação científica de nenhum dos casos [2].

## Introdução: a luz que congela

Em 3 de abril de 1973, o agricultor Francisco Barroso, de 45 anos, seguia pela estrada de uma fazenda em Quixadá na madrugada quando foi atingido por um forte raio de luz de uma nave [1][2]. Encontrado desacordado por um vaqueiro, foi levado de volta à fazenda — e nunca mais foi o mesmo. Teve regressão mental, sequelas que levaram à sua morte 17 anos depois, e recebeu pensão do INSS por consequência do episódio [2]. Mais de três décadas depois, o técnico em eletrônica Reginaldo José Batista da Silva contou que, aos 14 anos, em 1988, teve o corpo levado por uma "imensa nave de ferro" e que objetos de ferro foram introduzidos em seu nariz [2]. No sertão cearense, a luz não apenas ilumina: leva [HIPÓTESE].

## 1. Quixadá e o céu que observa de volta

Desde a década de 1950, são inúmeros os relatos de avistamentos, abduções e contatos em Quixadá [1]. Um dos primeiros documentados é o da escritora Rachel de Queiroz, que em 14 de maio de 1960 escreveu na revista Cruzeiro, em letras maiúsculas: "EU VI". Ela e pelo menos vinte pessoas viram uma luz alaranjada, com "halo luminoso e nevoento", sobre a fazenda Não Me Deixes [1]. O episódio, e o caso Barroso de 1973, trouxeram destaque nacional à cidade e atraíram estudiosos de Portugal, Itália e Espanha [1][2]. O ufólogo Weliston Paiva, coronel da reserva da Polícia Militar e piloto de helicóptero, mapeou mais de 80 casos de contato na região do Sertão Central e fala de um "corredor aéreo" que começa em Madalena, passa por Quixadá e segue para Baturité, com tráfego entre 18h e 4h da manhã [2]. Uma produção local, o filme "Área Q" (2012), levou as histórias para o cinema [1][2].

## 2. O que os abduzidos contam

Os relatos compartilham padrões: uma forte luz, seguida da abdução; pessoas encontradas desacordadas ou desaparecidas por cerca de quarenta minutos, depois devolvidas ao mesmo local [1][2]. Reginaldo relatou que seu corpo ficou cinza, queimado, e que dentro da nave objetos de ferro foram introduzidos em seu nariz — "uma dor muito grande" [2]. Luis Barroso apresentou queimaduras na pele e regressão mental, e morreu 17 anos depois do episódio [2]. Weliston afirma que as naves teriam de quatro a cinco tripulantes, um comandante e vários cientistas, e que não querem impor um sistema de governo, mas ver a humanidade evoluir [1]. Para o físico Dennis Weaver, contatos diretos são improváveis pelas distâncias cósmicas envolvidas [1].

## 3. A escala de Hynek e o quarto grau

Em 1972, o astrofísico Josef Allen Hynek, que trabalhou com a Força Aérea dos EUA entre 1948 e 1969, lançou "The UFO Experience: A Scientific Inquiry" e criou a Escala Hynek para categorizar encontros com OVNIs [4]. A escala original vai do primeiro ao terceiro grau: luzes noturnas, discos à luz do dia, detecções por radar e observação de entidades [3][4]. O quarto grau — abdução — foi adicionado depois por outros pesquisadores, como Jacques Vallée, e não faz parte da escala original de Hynek [3][5]. Na extensão de Vallée, o quarto grau também inclui experiências que transformam a percepção de realidade do observador [3][5]. Filmes como "Fogo no Céu" e "O Quarto Grau" (2009) popularizaram a categoria [4]. No caso de Quixadá, os moradores relatam contatos de "até quarto grau" — comunicação direta com os seres [1].

## 4. Fato, hipótese e lenda

Fato: Quixadá concentra dezenas de relatos documentados de avistamentos e supostas abduções desde os anos 1960 [1][2]. Fato: o caso Barroso (1973) resultou em sequelas reconhecidas pelo INSS [2]. Fato: não há comprovação científica de que qualquer abdução tenha ocorrido [2][HIPÓTESE]. Hipótese: os relatos descrevem experiências reais de contato com inteligências não-humanas [1][2][HIPÓTESE]. Lenda: naves extraterrestres abduzindo cearenses regularmente — pertence ao folclore ufológico, sem validação científica [LENDA/FOLCLORE].

## Conclusão

A luz desceu em Quixadá. Algumas pessoas disseram que foram levadas, e voltaram diferentes — ou não voltaram inteiras [1][2]. A ciência não confirma, o INSS reconheceu consequências, e o céu do sertão continua a ser observado por quem espera que a luz desça novamente [1][2]. O quarto grau, seja ele o que for, permanece entre o depoimento e a prova [HIPÓTESE].

## Fontes

[1] G1 — "Abduções e visões em Quixadá: cidade do sertão cearense concentra relatos de contatos extraterrestres" (04/08/2023): https://g1.globo.com/ce/ceara/noticia/2023/08/04/abducoes-e-visoes-em-quixada-cidade-do-sertao-cearense-concentra-relatos-de-contatos-extraterrestres.ghtml
[2] Diário do Nordeste — "Abduções, sequelas, perseguição a OVNIs: relatos de cearenses que dizem ter tido contato com ETs": https://diariodonordeste.verdesmares.com.br/regiao/abducoes-sequelas-perseguicao-a-ovnis-relatos-de-cearenses-que-dizem-ter-tido-contato-com-ets-1.3101255
[3] Ufológico — "Escalas de Classificação: de Hynek & Outros": https://ufologico.com.br/escala-de-hynek/
[4] Estadão — "De 1 a 10, você sabe classificar os contatos extraterrestres?": https://www.estadao.com.br/minha-serie/play/128005-1-10-voce-sabe-classificar-contatos-extraterrestres/
[5] Wikipédia — "Close encounter": https://en.wikipedia.org/wiki/Close_encounter

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA.