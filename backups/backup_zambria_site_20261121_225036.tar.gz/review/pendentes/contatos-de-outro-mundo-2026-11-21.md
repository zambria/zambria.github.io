---
titulo: "Contatos de Outro Mundo: Entre o Testemunho e a Crença"
resumo: "Pessoas que afirmam manter contato com seres extraterrestres, receber mensagens e transmitir sabedoria: os contatados povoam a ufologia desde os anos 1940. Entre o Caso Varginha, a escala de Hynek e os contatados de Quixadá, a linha entre testemunho e crença se estreita."
categoria: "ufo"
data: "2026-11-21"
slug: "contatos-de-outro-mundo-2026-11-21"
status: "draft"
tags: [contatado, contato-extraterrestre, escala-hynek, varginha, ufologia]
---

# Contatos de Outro Mundo: Entre o Testemunho e a Crença

Existe um tipo de testemunho que não começa com o medo, mas com um chamado. Não é o relato de quem foi levado à força, mas o de quem diz ter sido convidado — ou escolhido — para ouvir [1]. São os contatados: homens e mulheres que afirmam ter estabelecido contato com inteligências não humanas, recebido mensagens sobre o futuro da humanidade e sido incumbidos de repassar essas palavras ao mundo [1]. Desde os anos 1940 e 1950, quando o fenômeno ganhou notoriedade, até os dias de hoje, em que fóruns reúnem centenas de experienciados e protocolos rituais prometem contato deliberado, a pergunta permanece: são mensageiros de outra espécie, ou são mensageiros de algo que habita apenas a mente humana? [1][2]

Este artigo é sobre o contato — do encontro imediato de terceiro grau ao quarto e quinto —, sobre os casos que marcaram o Brasil, como o incidente de Varginha, e sobre a tensão entre testemunho e ceticismo que define a ufologia de contatos.

## Desenvolvimento

## O que é um contatado

Contatados são pessoas que afirmam terem tido experiências de contato com extraterrestres [1]. Tipicamente relatam que lhes foram dadas mensagens e/ou profunda sabedoria por seres extraterrestres, e que foram compelidos a compartilhar essas mensagens [1]. Esses encontros são frequentemente descritos como permanentes, embora alguns contatados afirmem ter tido poucos ou um único encontro [1]. Como fenômeno cultural, os contatados tiveram maior notoriedade entre o final dos anos 1940 e o final dos anos 1950, mas pessoas continuam a fazer afirmações semelhantes no presente [1].

## A escala de Hynek e os graus de encontro

A terminologia e o sistema de classificação dos encontros imediatos foram inventados pelo astrônomo e ufólogo Josef Allen Hynek em 1972, em seu livro «The UFO Experience: A Scientific Enquiry» [2]. Hynek dividiu os relatos em graus de intensidade: avistamentos a mais de 150 metros são classificados como discos diurnos, luzes noturnas ou informes visuais e de radar; os mais próximos são encontros imediatos [2]. O primeiro grau é o avistamento de um ou mais objetos voadores não identificados a menos de 180 metros, sem interação [2][5]. O segundo grau envolve percepções adicionais, como calor, radiação, danos ao terreno, círculos nas plantações, paralisia, animais assustados, interferência em máquinas e perda de memória associada ao encontro [2]. O terceiro grau é a observação de «seres animados» em associação com OVNIs [2][5]. O quarto grau, adicionado posteriormente, é a abdução: um ser humano levado por um OVNI ou seus ocupantes [2][4][5]. O quinto grau, formulado por Steven M. Greer, engloba comunicação bilateral, espontânea, voluntária e proativa entre o observador e a inteligência extraterrestre [4].

## Os contatados históricos e suas mensagens

A lista de contatados inclui nomes que marcaram a história da ufologia: George Adamski, Daniel Fry, Truman Bethurum, Orfeo Angelucci, Elizabeth Klarer, Billy Meier e Whitley Strieber, entre muitos outros [1]. Parte das histórias contém material que não resistiu ao teste do tempo, como afirmações de planetas desconhecidos dentro do nosso sistema solar ou de «irmãos espaciais» habitando planetas vizinhos [1]. As afirmações dos contatados geralmente diferem dos relatos de abdução: enquanto os contatados descrevem experiências benéficas envolvendo alienígenas com aparência humana, raramente os abduzidos relatam suas experiências de forma positiva [1]. Essa diferença é um dos pontos que mais dividem pesquisadores e céticos [1].

## O Caso Varginha: o Roswell brasileiro

Em 20 de janeiro de 1996, três jovens — as irmãs Liliane e Valquíria da Silva e sua amiga Kátia Xavier — relataram ter encontrado uma criatura estranha em um lote vazio em Varginha, cidade da região cafeeira de Minas Gerais [6][9][10]. Descreveram um ser magro, de cerca de 1,20 a 1,50 metro de altura, com pele oleosa escura, cabeça desproporcionalmente grande com três protuberâncias e olhos enormes e vermelhos brilhantes [6][9][10]. Suas versões permaneceram inteiramente consistentes ao longo de quase 30 anos [6].

A história cresceu rapidamente, reunindo alegações paralelas: que bombeiros haviam capturado uma criatura naquela manhã, que soldados capturaram uma segunda e a transportaram sob lonas, que uma morreu no Hospital Regional e que um jovem policial militar, Marco Eli Chereze, morreu semanas depois de uma suposta infecção contraída ao manusear uma criatura [6]. Nenhuma dessas alegações secundárias foi jamais documentada [6]. Não há fotografias, corpos, prontuários médicos que respaldem as alegações do hospital, nem documentação da suposta operação militar [6].

Investigações oficiais não conseguiram confirmar a existência de criatura extraterrestre. O Inquérito Policial Militar nº 908/1997, do Superior Tribunal Militar, concluiu: «Não foi possível comprovar a existência de criatura extraterrestre, tampouco explicar de forma conclusiva todos os acontecimentos narrados» [10]. O Exército brasileiro atribuiu o avistamento das meninas a um morador local conhecido como «Mudinho», um indivíduo com problemas mentais [10]. A falta de evidências do incidente, baseada unicamente em relatos e testemunhos, foi notada até mesmo por ufólogos crédulos [10].

## Os contatados de Quixadá e o II Fórum Mundial

No Brasil, o fenômeno dos contatos encontrou um de seus epicentros em Quixadá, no sertão cearense [9]. Desde a década de 1960, quando a escritora Rachel de Queiroz avistou uma luz alaranjada em sua fazenda, a região acumula relatos de visões e contatos [9]. Em 2014, Curitiba sediou o II Fórum Mundial de Contatados, reunindo cerca de 500 pessoas de todo o mundo que dizem ter estabelecido contato com seres extraterrestres e suas naves [8]. Um dos palestrantes, Vitório Peret, relatou um contato de terceiro grau em 1982, na praia da Baía do Sol, em Belém: por aproximadamente dez segundos, viu um extraterrestre ao seu lado, que se comunicou por sinais ou vibrações mentais, sem som vocal [8]. «Não houve diálogo, som, nada vocal. Foi mental», disse [8].

## O contato de quinto grau e o protocolo ritual

Nos últimos trinta anos, o contato imediato de quinto grau (CE-5) se transformou em um protocolo ritualístico praticado por uma comunidade global [8]. Adeptos se reúnem em áreas rurais ou desabitadas para iniciar a comunicação com inteligências não humanas, usando de apontadores laser a práticas de meditação [8]. Para muitos, o CE-5 não é apenas uma categoria de experiência, mas uma prática deliberada de convocação [8]. A comunidade científica permanece cética, e nenhum caso de contato extraterrestre combina atualmente uma fonte antiga inequívoca, um contexto arqueológico seguro e tecnologia não humana verificada de forma independente [8].

## A linha entre testemunho e crença

O fenômeno dos contatados se divide entre quem aceita os relatos como testemunho genuíno de contato com outra inteligência e quem os enxerga como produto de sugestão, tradição cultural e necessidade de acreditar [1][2][9]. Para os céticos, as histórias de contatados frequentemente refletem a cultura da época em que surgem, reinterpretando mitos religiosos e simbologia política sob uma lente tecnológica moderna [9]. Para os crentes, a consistência de certos elementos — naves, mensagens telepáticas, seres de aparência humana — aponta para uma experiência real, ainda que incompreensível para a ciência atual [2][9]. O fato de nenhuma evidência física direta, como ligas metálicas anômalas ou assinaturas isotópicas não terrestres, ter resistido a exames laboratoriais rigorosos mantém a teoria no campo da especulação [9].

## Conclusão

Os contatados habitam uma zona de penumbra entre a religião, a ficção científica e o testemunho [1][2][9]. Seus relatos trazem uma promessa inquietante: a de que não estamos sozinhos, e que algo — ou alguém — pode estar tentando nos falar [2][9]. Mas essa promessa vem sem provas que resistam ao escrutínio externo, e cabe a cada leitor decidir se ouve uma mensagem das estrelas ou o eco de um desejo humano de não estar sozinho no universo [1][9]. Enquanto isso, vigílias continuam, fóruns se reúnem e o céu permanece em silêncio — ou talvez apenas esperando que alguém decida começar a conversa [2].

## Fontes

[1] pt.wikipedia.org — Contatado. https://pt.wikipedia.org/wiki/Contatado
[2] en.wikipedia.org — Close encounter. https://en.wikipedia.org/wiki/Close_encounter
[3] pt.wikipedia.org — Incidente de Varginha. https://pt.wikipedia.org/wiki/Incidente_de_Varginha
[4] ufologico.com.br — Escalas de Classificação: de Hynek & Outros. https://ufologico.com.br/escala-de-hynek/
[5] pt.wikipedia.org — Perspectivas sobre o fenômeno de abdução. https://pt.wikipedia.org/wiki/Perspectivas_sobre_o_fen%C3%B4meno_de_abdu%C3%A7%C3%A3o
[6] milkywaynews.com — The Varginha Incident. https://milkywaynews.com/guide/cases/varginha-incident
[7] ufoevidence.com — The Varginha Incident. https://ufoevidence.com/case/varginha-aliens-1996/
[8] g1.globo.com — Fórum reúne pessoas que dizem ter sido contatadas e abduzidas por ETs. https://g1.globo.com/pr/parana/noticia/2014/05/forum-reune-pessoas-que-dizem-ter-sido-contatadas-e-abduzidas-por-ets.html
[9] g1.globo.com — Abduções e visões em Quixadá: cidade do sertão cearense concentra relatos de contatos extraterrestres. https://g1.globo.com/ce/ceara/noticia/2023/08/04/abducoes-e-visoes-em-quixada-cidade-do-sertao-cearense-concentra-relatos-de-contatos-extraterrestres.ghtml
[10] www.em.com.br — O que se sabe hoje sobre o Caso Varginha, três décadas depois. https://www.em.com.br/gerais/2026/01/amp/7331369-o-que-se-sabe-hoje-sobre-o-caso-varginha-tres-decadas-depois.html

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
