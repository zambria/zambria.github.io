---
titulo: "Céus Não Identificados: Quando o Vigia do Horizonte Torna-se o Observado"
resumo: "Uma investigação sobre os fenômenos aéreos não identificados nos céus do Brasil, entre registros oficiais da Força Aérea Brasileira, o acervo do Arquivo Nacional e o silêncio que envolve o que voa acima de nossas cabeças."
categoria: "ufo"
data: "2026-11-21"
slug: "ceus-nao-identificados-2026-11-21"
status: "draft"
tags: [mistério, ufo, fenômenos-aéreos, Brasil, Arquivo Nacional]
---

# Céus Não Identificados: Quando o Vigia do Horizonte Torna-se o Observado

Há uma noite no Brasil em que o céu deixou de ser apenas cenário para se tornar palco. Foi em 19 de maio de 1986, quando dezenas de objetos luminosos cruzaram os céus de quatro estados — São Paulo, Rio de Janeiro, Minas Gerais e Goiás — detectados simultaneamente pelos radares do Centro Integrado de Defesa Aérea e Controle de Tráfego Aéreo [1]. Cinco caças da Força Aérea Brasileira decolaram com ordem de interceptar. Nenhum conseguiu alcançar os alvos. O ministro da Aeronáutica de então, ao final da coletiva de imprensa, limitou-se a dizer: «Tecnicamente, não temos explicação» [1]. Desde então, aquele episódio ficou conhecido como a «Noite Oficial dos OVNIs» — oficial não porque tenha sido confirmada qualquer origem extraterrestre, mas porque o Estado brasileiro reconheceu, por escrito, que algo voou sobre o país sem identificação possível.

Este artigo é sobre o que está acima de nós quando não estamos olhando. Sobre os registros que o próprio governo brasileiro guarda, sobre as luzes que pilotos relatam e os radares às vezes captam e às vezes ignoram, e sobre a fronteira tênue entre o fenômeno natural, o artefato humano e aquilo que, ainda, não tem nome.

## O que o céu esconde à vista de todos

O termo OVNI — objeto voador não identificado — nasceu nos Estados Unidos, em 1947, quando o empresário Kenneth Arnold relatou ter visto objetos em movimento ondulante sobre o estado de Washington [2]. A imprensa traduziu «flying saucer» como «disco voador», e daí em diante a expressão passou a abranger qualquer luz ou objeto no céu cuja origem não fosse imediatamente reconhecível [2]. No Brasil, o primeiro registro oficial data de 1952, na Barra da Tijuca, Rio de Janeiro, quando jornalistas e fotógrafos afirmaram ter visto e fotografado um objeto em formato de prato com cúpula no centro [3].

Mas o que exatamente voa pelos céus brasileiros? Segundo o Observatório Nacional, os fenômenos aéreos não identificados (UAPs, na sigla em inglês) não se referem necessariamente a objetos de origem extraterrestre [4]. «Só significa algo no céu que, no momento, não tem explicação», explica o astrônomo Marcelo de Cicco, coordenador do projeto Exoss [4]. Podem ser fenômenos naturais — planetas, reflexos, nuvens, meteoros — ou objetos criados pelo homem: drones, balões, lasers, satélites [4]. Ou, em último caso, podem permanecer sem explicação [4].

Essa distinção é importante. Ela separa o fato da especulação. O fato é que há registros. A especulação é sobre o que esses registros significam.

## O acervo que o Estado não consegue ignorar

Desde 2010, por força da Portaria do Comando da Aeronáutica nº 551/GC3, os documentos sobre fenômenos aéreos não identificados produzidos pela Força Aérea Brasileira vêm sendo transferidos para o Arquivo Nacional, onde estão disponíveis para consulta pública [5]. O chamado Fundo Objeto Voador Não Identificado (BR DFANBSB ARX) reúne 758 documentos digitalizados — relatórios, depoimentos, fotos, formulários, vídeos e áudios — com a ocorrência mais antiga de 1952 e a mais recente de 2016 [5]. Em 2024, o acervo já havia ultrapassado os 893 registros, abrangendo ocorrências entre 1952 e 2023 [6].

São documentos que incluem não apenas relatos de civis, mas também de militares e pilotos comerciais. O ufólogo Thiago Luiz Ticchetti, com mais de três décadas de pesquisa no tema, explica que os registros «não se tratam, necessariamente, de extraterrestres» [6]. «Tudo que você vê no céu e não consegue uma explicação, não consegue falar que é um avião, helicóptero, satélite, você chama de óvni», diz [6]. Mas o fato de os registros existirem, de terem sido catalogados por uma instituição estatal e de serem disponibilizados ao público, é um dado concreto que exige ser levado a sério.

Entre os episódios mais documentados está a «Noite Oficial dos OVNIs», de 19 de maio de 1986. Vinte e um objetos não identificados foram rastreados por radares da FAB. Cinco caças foram enviados para interceptá-los. Os pilotos relataram contato visual com alvos que faziam curvas de 90 graus e voavam em velocidade hipersônica [1]. O dossiê oficial, liberado apenas 23 anos depois, concluiu que os fenômenos «são sólidos e refletem, de certa forma, inteligência, devido à capacidade de seguir e manter distância dos observadores, bem como voar em formação» [1]. Não necessariamente tripulados, nem necessariamente alienígenas — mas inteligentes em seu padrão de movimento [1].

## Quando o governo dos EUA olha para o Brasil

O interesse pelo que voa sobre o Brasil não se limita às fronteiras nacionais. Em novembro de 2026, documentos divulgados pelo Departamento de Guerra dos Estados Unidos revelaram que equipes ligadas a um programa de investigação de inteligência americana viajaram ao Pará em 2009 para reunir arquivos e aprofundar informações sobre a Operação Prato, conduzida pela FAB entre 1977 e 1978 na região de Colares [10]. O relatório, de 538 páginas e identificado como DOW-UAP-D172, reúne informações sobre 179 ocorrências de fenômenos aéreos não identificados registradas naquela região [10]. Desse total, 151 foram relatadas pela equipe militar brasileira, e os próprios integrantes da FAB teriam observado diretamente 94 dessas ocorrências [10].

A Operação Prato nasceu de relatos de moradores sobre luzes misteriosas no céu, supostos ataques a pessoas e sinais físicos deixados nos corpos de vítimas — um fenômeno conhecido como «chupa-chupa» [3]. A investigação militar foi encerrada sem uma conclusão pública definitiva [3]. Décadas depois, documentos tornaram-se públicos e alimentaram novas teorias. O fato de um governo estrangeiro ter investido recursos para investigar um episódio ocorrido em solo brasileiro sugere que o assunto transcende o folclore local [10].

## O que os céus recentes ainda nos dizem

Os avistamentos não são fenômeno do passado. Em 2025, pelo menos 18 casos envolvendo OVNIs foram relatados no Brasil por pilotos, controladores de tráfego aéreo e outras pessoas do setor aéreo, conforme documentos da FAB transferidos ao Arquivo Nacional [7]. Londrina, no Paraná, concentrou cinco ocorrências; o Ceará, quatro [7]. Um comandante da Latam relatou, em 1º de setembro de 2025, sobre Guarulhos (SP), ter visto «bolas de luzes fortes, quantidade de 2 a 3, luzes brancas, vermelhas, amarelas, com movimento irregular», além de ter sofrido «uma turbulência seca» [7].

No mesmo ano, o Arquivo Nacional divulgou 26 novos relatos de avistamento de óvnis no Brasil, incluindo casos descritos como «contato imediato a olho nu» por pilotos [8]. Em Caraguatatuba (SP), um aviador relatou ter visto uma forma redonda branca e laranja, três vezes maior que um avião, movendo-se «muito rápido», sem emitir som [8]. Perto de Teresina (PI), dois pilotos informaram ter visto «três aeronaves com luzes brilhantes se aproximando e afastando aparentemente na mesma altitude» por cerca de dez minutos [8].

O Observatório Espacial Heller & Jung, no Rio Grande do Sul, recebia em novembro de 2025 uma média de quatro mensagens diárias sobre possíveis objetos voadores não identificados [9]. Seu pesquisador, Carlos Fernando Jung, explicado que boa parte dos registros pode ser atribuída aos satélites da rede Starlink [9] — uma explicação plausível para alguns casos, mas não para todos.

## Entre a razão e o mistério

Há duas leituras possíveis para esses registros. Uma é cética-metódica: a maioria dos fenômenos tem explicação natural ou humana, e o que permanece sem identificação é, simplesmente, não identificado — não inexplicável por princípio, mas não explicado ainda [4] [6]. A outra leitura reconhece que, entre centenas de registros, há um pequeno número de casos que resistem a todas as explicações convencionais: objetos rastreados por radar e vistos por pilotos simultaneamente, luzes que executam manobras impossíveis para aeronaves conhecidas, episódios que mobilizaram forças armadas sem solução conclusiva [1] [10].

Não cabe a este artigo escolher entre as duas leituras. Cabe apenas registrar que ambas coexistem nos mesmos documentos oficiais. O Arquivo Nacional não se posiciona sobre a origem dos objetos; ele apenas guarda os relatos [5]. A FAB afirma que «não realiza estudos e análises acerca do tema, apenas cataloga as informações prestadas por terceiros» [6]. O silêncio oficial não é uma resposta — é uma ausência de resposta. E nessa ausência, o mistério cresce.

## Conclusão: o céu que nos observa de volta

Os céus não identificados do Brasil não são apenas uma coleção de histórias estranhas. Eles são um registro oficial, mantido por instituições estatais, de algo que voou acima do país e que, décadas depois, ainda não tem nome. Seja reflexo atmosférico, satélite, drone militar secreto ou algo que ainda não compreendemos, o fato permanece: há objetos no nosso espaço aéreo que ninguém consegue identificar [1] [4] [5] [6].

E talvez a pergunta mais inquietante não seja o que esses objetos são, mas o que significa viver sob céus que, vez ou outra, nos devolvem o olhar. Quando o vigia do horizonte se torna o observado, resta ao cidadão comum uma constatação fria: estamos olhando para cima, mas não sabemos, ao certo, quem ou o que está olhando de volta.

## Fontes

[1] Governo do Brasil — «Official UFO Night in Brazil». https://www.gov.br/en/government-of-brazil/latest-news/2022/official-ufo-night-in-brazil
[2] Arquivo Nacional — «Os OVNIs no Arquivo Nacional». https://querepublicaeessa.an.gov.br/index.php/que-republica-e-essa/assuntos/temas/302-os-ovnis-no-arquivo-nacional
[3] O Globo — «Além do E.T. de Varginha: relembre alguns dos principais casos envolvendo óvnis no Brasil». https://oglobo.globo.com/brasil/noticia/2026/01/07/alem-do-et-de-varginha-relembre-alguns-dos-principais-casos-envolvendo-ovnis-no-brasil.ghtml
[4] Observatório Nacional (gov.br) — «O que são os fenômenos aéreos não identificados (UAPs)?». https://www.gov.br/observatorio/pt-br/assuntos/noticias/o-que-sao-os-fenomenos-aereos-nao-identificados-uaps-1/
[5] Arquivo Nacional (gov.br) — «Conheça o fundo sobre OVNIs do Arquivo Nacional». https://www.gov.br/arquivonacional/pt-br/canais_atendimento/imprensa/conheca-o-fundo-sobre-ovnis-do-arquivo-nacional
[6] G1 — «Relatos sobre óvnis: entenda os registros feitos pela Força Aérea Brasileira e entregues ao Arquivo Nacional». https://g1.globo.com/df/distrito-federal/noticia/2024/08/22/relatos-sobre-ovnis-entenda-os-registros-feitos-pela-forca-aerea-brasileira-e-entregues-ao-arquivo-nacional.ghtml
[7] CNN Brasil — «Pilotos e controladores relataram 18 casos de OVNIs no Brasil em 2025». https://www.cnnbrasil.com.br/ciencia/pilotos-e-controladores-relataram-18-casos-de-ovnis-no-brasil-em-2025/
[8] O Globo — «Arquivo Nacional divulga 26 relatos de avistamento de óvnis no Brasil». https://oglobo.globo.com/brasil/noticia/2025/06/13/arquivo-nacional-divulga-26-relatos-de-avistamento-de-ovnis-no-brasil-contato-imediato.ghtml
[9] Diário do Pará — «Bruna Lombardi posta compilado de supostos OVNIs e cita falha no controle aéreo dos EUA». https://diariodopara.com.br/cotidiano/bruna-lombardi-compartilha-videos-de-supostos-ovnis-e-questiona-o-que-esta-acontecendo-nos-ceus/
[10] Diário do Pará — «Americanos vieram ao Pará investigar OVNIs em 2009; documentos secretos revelam missão». https://diariodopara.com.br/cotidiano/americanos-vieram-ao-para-investigar-ovnis-em-2009-documentos-secretos-revelam-missao/

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
