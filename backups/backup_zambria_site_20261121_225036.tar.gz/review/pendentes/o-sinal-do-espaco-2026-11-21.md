---
titulo: "O Sinal do Espaço: O Mistério do Wow! Que Nunca se Repetiu"
resumo: "Em 15 de agosto de 1977, um radiotelescópio captou um sinal de rádio de 72 segundos, 30 vezes mais intenso que o ruído do espaço profundo, vindo da direção da constelação de Sagitário. Nunca mais foi detectado. Batizado de Sinal Wow!, permanece o maior candidato a uma mensagem extraterrestre — e o maior mistério não resolvido do SETI."
categoria: "ufo"
data: "2026-11-21"
slug: "o-sinal-do-espaco-2026-11-21"
status: "draft"
tags: [sinal-wow, seti, rádio, extraterrestre, mistério]
---

# O sinal do espaço

Este artigo é sobre o Sinal Wow!: o que foi captado, as hipóteses para explicá-lo e por que, quase cinquenta anos depois, ele continua sem resposta [1][2][3][4][5].

## A detecção: Big Ear e o SETI

O sinal Wow! foi um forte sinal de rádio recebido no dia 15 de agosto de 1977 pelo radiotelescópio Big Ear, nos Estados Unidos, que era então usado para apoiar a pesquisa por vida extraterrestre [1][3]. O radiotelescópio, operado pela Universidade Estadual de Ohio, foi designado em 1973 para a busca científica da inteligência extraterrestre (SETI), o programa mais antigo de seu tipo na história [1]. Em 1959, físicos da Universidade de Cornell, Philip Morrison e Giuseppe Cocconi, especularam que qualquer civilização alienígena tentando comunicar via sinais de rádio poderia usar a frequência de 1420 MHz, emitida naturalmente pelo hidrogênio, o elemento mais comum do universo [1]. O SETI calibrou seus receptores precisamente nessa frequência, na hipótese de que possíveis formas de vida evoluídas utilizariam esse mesmo canal para enviar mensagens [4].

## O momento: 6EQUJ5 e o "Wow!"

Na manhã seguinte à detecção, o astrônomo voluntário Jerry Ehman revisava os relatórios emitidos pelo computador do telescópio quando se deparou com um sinal que durou exatamente a janela completa de 72 segundos durante a qual o Big Ear pôde observá-lo [1][2][3]. O sinal era representado pelo código alfanumérico "6EQUJ5", com a letra U indicando um sinal cerca de 30 vezes mais forte que o ruído ordinário do espaço profundo [2][3]. Nem havia modulação detectável — a técnica usada para transmitir informações através de ondas de rádio [1]. Diante da surpresa, Ehman circulou a leitura na impressão do computador e escreveu "Wow!" ao lado, em tinta vermelha [1][2][3]. O nome pegou, e o sinal passou a ser conhecido mundialmente como o Sinal Wow! [1][2][3].

## O sinal nunca voltou

Desde a descoberta de Ehman, nenhum outro cientista conseguiu detectar o sinal "Wow" outra vez, nem determinar de onde ele veio [2][3][4]. O sinal subiu e caiu de uma forma consistente com o feixe do telescópio varrendo um ponto fixo no céu — sugerindo uma origem celeste, e não terrestre [3]. Ele se apagou imediatamente quando o telescópio voltou a observar naquela mesma direção, indicando que tinha uma origem inteligente, e não de um fenômeno natural, segundo Robert Dixon, diretor do observatório na época [2][3]. Múltiplas tentativas de reobservação com outros telescópios foram malsucedidas, e o mistério permanece perpétuo [3][5]. "É emocionante pensar nisso, mas não é necessariamente uma verdade comprovada", disse Seth Shostak, astrônomo do SETI Institute [2].

## As hipóteses — e o porquê de nenhuma convencer

Muitas hipóteses foram criadas para explicar a origem do sinal, incluindo formas naturais e feitas por humanos, mas nenhuma delas explicou adequadamente o sinal [1][3]. A possibilidade de ser algum sinal emitido da própria Terra, rebatido por um satélite, foi descartada: não havia nenhum objeto na mira do radiotelescópio [5]. Entre as explicações mais recentes está a do astrônomo Antonio Paris, que propôs que o sinal poderia ter sido produzido por dois cometas, 266P/Christensen e 335P/Gibbs, passando perto do sinal em 1977, liberando uma nuvem de hidrogênio que geraria a emissão de 1420 MHz [4][5]. No entanto, essa é apenas uma das muitas teorias, e não existe evidência que permita classificar o sinal como uma transmissão de uma civilização extraterrestre [1][4][5]. Até hoje, o Sinal Wow! continua sendo o candidato mais forte para uma transmissão de rádio alienígena já detectada — e o mais frustrante, por nunca ter se repetido [1][3][5].

## Conclusão

Quarenta e nove anos depois, o Sinal Wow! continua sem resposta [1][2][3]. Ele veio, brilhou por 72 segundos, e desapareceu — deixando para trás a pergunta mais antiga de todas: estamos sozinhos? [1][2][3][4][5] A ciência pode propor cometas, interferências, fenômenos naturais, mas nenhum deles explica completamente o que foi captado naquele agosto de 1977 [1][4][5]. O sinal não provou que existe vida extraterrestre, mas também não provou que não existe [1][3]. Ele simplesmente está lá, na história do SETI, como um aviso de que o cosmos pode falar — e que talvez nunca ouçamos a mesma voz duas vezes [2][3][5].

---

## Fontes

[1] es.wikipedia.org — Señal Wow!. https://es.wikipedia.org/wiki/Se%C3%B1al_Wow!
[2] en.wikipedia.org — Wow! signal. https://en.wikipedia.org/wiki/Wow!_signal
[3] bbc.co.uk — "Wow!", la misteriosa señal espacial que recibieron los astrónomos hace 40 años y que todavía no saben de dónde provino. https://bbc.co.uk/mundo/noticias-40942084
[4] arxiv.org — Arecibo Wow! I: An Astrophysical Explanation for the Wow! Signal. https://arxiv.org/html/2408.08513v1
[5] nationalgeographic.com — This mysterious radio signal has puzzled astronomers for nearly 50 years. https://www.nationalgeographic.com/science/article/wow-radio-signal-aliens-mystery
[6] latercera.com — Qué es la señal Wow! captada en 1977 y que podría ser un raro fenómeno astrofísico. https://www.latercera.com/tendencias/noticia/que-es-la-senal-wow-captada-en-1977-y-que-podria-ser-un-raro-fenomeno-astrofisico/BLJVRIBGJVDBHMJHCWUHB2VUCY/
[7] es-us.noticias.yahoo.com — Caso reabierto: misteriosa señal Wow! "extraterrestre" não seria lo que pensábamos. https://es-us.noticias.yahoo.com/caso-reabierto-misteriosa-se%C3%B1al-wow-170700134.html
[8] elconfidencial.com — por fin se ha resuelto el misterio de la "señal Wow!". https://www.elconfidencial.com/tecnologia/ciencia/2024-08-22/resuelto-misterio-senal-extraterrestre-1977-1qrt_3947252/
[9] arxiv.org — The Ohio SETI Program – The Last Decades. https://arxiv.org/html/2606.11102
[10] arxiv.org — The Search for Extraterrestrial Civilizations: A Scientific. https://arxiv.org/pdf/2302.06446

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
