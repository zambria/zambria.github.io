---
titulo: "Mensagens nos Campos: Agroglyphos entre a Fraude Humana e o Mistério"
resumo: "Os crop circles, ou agroglifos, são padrões geométricos complexos que aparecem de repente em plantações ao redor do mundo. Entre a confissão de Doug Bower e Dave Chorley, os agroglifos de Ipuaçu e a ausência de consenso científico, o fenômeno oscila entre fraude humana e mistério não resolvido."
categoria: "ufo"
data: "2026-11-21"
slug: "mensagens-nos-campos-2026-11-21"
status: "draft"
tags: [crop-circles, agroglifos, mistério, ufologia, fraude]
---

# Mensagens nos Campos: Agroglyphos entre a Fraude Humana e o Mistério

Aparecem na noite, sem testemunhas, e só podem ser compreendidos do alto [1][2]. Não são mensagens escritas em papel nem sinais de rádio: são campos inteiros de trigo, cevada ou milho achatados em padrões simétricos, complexos, precisos, que surgem do nada e deixam agricultores, cientistas e curiosos diante de uma questão sem resposta [1][2][3]. São os agroglifos — ou crop circles, círculos nas plantações — fenômeno que, há mais de quatro décadas, divide o mundo entre quem vê a mão do homem e quem enxerga a assinatura de algo que não é daqui [1][2][4][5].

Este artigo é sobre os agroglifos: o que a ciência diz sobre eles, o que os defensores da hipótese extraterrestre afirmam, o caso brasileiro de Ipuaçu, em Santa Catarina, e por que o mistério persiste mesmo depois da confissão de que grande parte das formações é obra humana [1][3][6].

## Desenvolvimento

## O que são os círculos nas plantações

Os círculos nas plantações, também chamados de agroglifos, são formações de tamanho considerável criadas por meio do achatamento de uma cultura, como cereais, colza, cana e capim [1]. Normalmente complexas e nem sempre circulares, essas marcas aparecem de forma misteriosa e aparentemente inexplicável, intrigando cientistas, ufólogos e entusiastas do paranormal há décadas [1][7]. Para quem olha do chão, são apenas plantas deitadas. Do alto, revelam geometrias que parecem exigir planejamento prévio e uma execução silenciosa e rápida [1][7].

## A história: dos relatos antigos à era moderna

Relatos de formações semelhantes datam de séculos atrás: em 1686, o naturalista britânico Robert Plot descreveu anéis e arcos de cogumelos em campos, e uma carta de 1880 à revista Nature relatou círculos criados por uma tempestade [1]. Mas o fenômeno moderno surgiu no final dos anos 1970, com hoaxes de Doug Bower e Dave Chorley, inspirados por um caso na Austrália [1]. Foi a partir da década de 1970 que os círculos ganharam notoriedade, com o aumento significativo de casos e a ampla divulgação pela mídia internacional [2]. Os primeiros círculos modernos foram registrados na Inglaterra, e desde então milhares de formações foram documentadas em diferentes partes do mundo [7].

## A confissão: Doug Bower e Dave Chorley

O ponto de virada para a explicação convencional veio em 1991, quando dois artistas ingleses, Doug Bower e Dave Chorley, revelaram a um jornal britânico ter feito mais de 200 agroglifos na última década, usando tábuas e pedaços de cordas [1][3]. As tábuas eram usadas para amassar a plantação, enquanto as cordas asseguravam movimentos precisos [1][3]. Um ano depois, um concurso de círculos nas colheitas na Inglaterra mostrou que estudantes e amadores conseguiam recriar formações impressionantes: 11 dos 12 times conseguiram padrões razoavelmente impressionantes seguindo um design proposto [3]. Para o consenso científico, isso prova que quase todos os círculos são obra humana [1][3].

## Os agroglifos de Ipuaçu

No Brasil, o fenômeno ganhou um ponto de atenção em Ipuaçu, no interior de Santa Catarina, onde enormes formas geométricas apareceram em um campo de trigo [3]. Desde 2008, os agroglifos já foram avistados pelo menos outras quatro vezes na cidade, segundo a prefeitura, tornando o pequeno município de pouco mais de 7 mil habitantes um destino para ufólogos [3]. Para o astrônomo Adolfo Stotz Neto, as imagens são feitas sempre em plantações de grãos e cereais, fáceis de esmagar, e não há radioatividade no solo nem modificações na estrutura dos vegetais — algo que qualquer ser humano pode fazer tranquilamente [3]. O historiador Hernan Mostajo acrescenta que não há evidência de algo supostamente extraterrestre [3]. Mesmo assim, ufólogos atribuem as gravuras à atividade de seres de outro mundo [3].

## As teorias em disputa

Existem diversas hipóteses para explicar os círculos: atividade humana (artistas que usam ferramentas simples durante a noite), fenômenos naturais (ventos, redemoinhos de ar, descargas elétricas) e intervenção extraterrestre (mensagens ou sinais deixados por seres de outros planetas) [2][7]. Apesar das diferentes explicações, não há consenso científico sobre uma única causa para todos os casos registrados [2][7]. A maioria dos estudos conclui que grande parte dos círculos pode ser explicada por ação humana, especialmente aqueles com padrões mais complexos [2][7]. Ainda assim, a ausência de provas definitivas mantém o tema em constante debate [2][7].

## Por que o mistério persiste

Parte da persistência do mistério está na própria natureza das formações: padrões cada vez mais elaborados, simetrias impressionantes, formas geométricas sofisticadas que parecem exigir mais tempo e habilidade do que uma noite permitiria [2][7]. Para os crentes, a complexidade e a precisão são indícios de que nem tudo pode ser reduzido a tábuas e cordas [7]. Para os céticos, a falta de testemunhas oculares durante a criação e a confissão de Bower e Chorley são suficientes para explicar o fenômeno sem recorrer a extraterrestres [1][3]. O debate continua, e novas formações surgem regularmente, mantendo viva a fascinação em torno desse enigma que desafia a compreensão humana [7].

## Conclusão

Os crop circles são, acima de tudo, um espelho do que queremos acreditar [1][2][3]. Para alguns, são prova de que a humanidade já foi capaz de criar qualquer mistério com as próprias mãos, usando tábuas e cordas sob a luz da lua [2][3]. Para outros, são mensagens que ainda não conseguimos decifrar, sinais de uma inteligência que escolheu os campos da Terra para se comunicar [2][7]. A verdade, por ora, fica suspensa entre a confissão e a incerteza: quase todos os círculos podem ser obra humana, mas nem todos foram explicados, e enquanto houver uma formação sem autor, a pergunta permanecerá pairando sobre as plantações — do alto, do chão e da imaginação de quem olha e se pergunta o que, afinal, está sendo dito nos campos [2][7].

## Fontes

[1] pt.wikipedia.org — Círculos nas plantações. https://pt.wikipedia.org/wiki/C%C3%ADrculos_nas_planta%C3%A7%C3%B5es
[2] estadao.com.br — Agroglifos: O que diz a ciência sobre os desenhos que aparecem em plantações. https://www.estadao.com.br/ciencia/agroglifos-o-que-diz-a-ciencia-sobre-os-desenhos-que-aparecem-em-plantacoes/
[3] valor.globo.com — Agroglifos: o que são e como surgem os círculos nas plantações. https://valor.globo.com/agronegocios/stories/agroglifos-o-que-sao-e-como-surgem-os-circulos-nas-plantacoes.ghtml
[4] metropoles.com — Visita alienígena? Saiba o que a ciência diz sobre os agroglifos. https://www.metropoles.com/ciencia/visita-alienigena-ciencia-agroglifos
[5] gauchazh.clicrbs.com.br — Agroglifos: o que diz a ciência sobre os desenhos que aparecem em plantações. https://gauchazh.clicrbs.com.br/tecnologia/noticia/2022/10/agroglifos-o-que-diz-a-ciencia-sobre-os-desenhos-que-aparecem-em-plantacoes-cl8ym9508000901eevvjiiwlt.html
[6] www1.folha.uol.com.br — Marcelo Gleiser: Agroglifos: mensagens ou fraude?. https://www1.folha.uol.com.br/fsp/ciencia/fe1906201102.htm
[7] compre rural.com — Desenhos gigantes aparecem em lavouras no Brasil e no mundo e intrigam há décadas. https://www.comprerural.com/desenhos-gigantes-aparecem-em-lavouras-no-brasil-e-no-mundo-e-intrigam-ha-decadas/
[8] revistaquestaodeciencia.com.br — Os fazedores de círculo estão migrando para o Nordeste?. https://revistaquestaodeciencia.com.br/artigo/2019/06/18/os-ets-estao-migrando-para-o-nordeste

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
