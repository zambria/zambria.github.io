---
titulo: "Eles Vieram das Estrelas: Astronautas Antigos e a Hipótese do Contato Pré-Histórico"
resumo: "A teoria dos astronautas antigos propõe que extraterrestres visitaram a Terra na antiguidade e influenciaram religiões, monumentos e civilizações. Popularizada por Erich von Däniken, a hipótese é culturalmente influente, mas carece de validação científica — permanecendo entre a especulação e a crença."
categoria: "ufo"
data: "2026-11-21"
slug: "eles-vieram-das-estrelas-2026-11-21"
status: "draft"
tags: [astronautas-antigos, von-daniken, tsoukalos, pseudociência, arqueologia]
---

# Eles vieram das estrelas

---
titulo: "Eles Vieram das Estrelas: Astronautas Antigos e a Hipótese do Contato Pré-Histórico"
resumo: "A teoria dos astronautas antigos propõe que extraterrestres visitaram a Terra na antiguidade e influenciaram religiões, monumentos e civilizações. Popularizada por Erich von Däniken, a hipótese é culturalmente influente, mas carece de validação científica — permanecendo entre a especulação e a crença."
categoria: "ufo"
data: "2026-11-21"
slug: "eles-vieram-das-estrelas-2026-11-21"
status: "draft"
tags: [astronautas-antigos, von-daniken, tsoukalos, pseudociência, arqueologia]
---

# Eles Vieram das Estrelas: Astronautas Antigos e a Hipótese do Contato Pré-Histórico

E se os deuses do passado fossem, na verdade, visitantes de outro mundo? E se as pirâmides, as linhas de Nazca e os textos sagrados guardarem, sob o simbolismo religioso, a marca de uma intervenção extraterrestre? [1][2] Essa é a promessa da teoria dos astronautas antigos: a de que inteligências não humanas pousaram na Terra milênios atrás, auxiliaram na construção de monumentos, ensinaram astronomia e agricultura, e foram lembradas pelas civilizações antigas como deuses [1][2][4]. A ideia soa como ficção científica — e, para parte do público, é exatamente isso que a torna atraente [2][4]. Mas para arqueólogos e cientistas, ela é uma hipótese que não resistiu ao confronto com as evidências [1][3][4].

Este artigo examina a teoria dos astronautas antigos, seus principais proponentes, as evidências alegadas e por que a ciência convencional a rejeita [1][2][3][4].

## O que é a teoria dos astronautas antigos

A teoria dos astronautas antigos é a hipótese de que extraterrestres inteligentes visitaram a Terra na antiguidade e influenciaram a cultura humana [1][2]. Diferentes versões atribuem visões religiosas, construção monumental, astronomia, agricultura ou origens humanas a esses visitantes [1][2]. É mais amplo do que a simples possibilidade de que a vida exista em outro lugar: é uma proposição histórica sobre contato na Terra, que, por isso, exige evidências capazes de distinguir um evento extraterrestre de religião, simbolismo político, engenharia humana, tradição oral e recontagem posterior [1]. Até o momento, nenhum caso alegado combina uma fonte antiga inequívoca, um contexto arqueológico seguro e tecnologia não humana verificada de forma independente [1].

## Como a teoria moderna se desenvolveu

Embora a ideia já tivesse sido proposta anteriormente, foi Erich von Däniken quem a levou ao público em massa com o lançamento de "Eram os Deuses Astronautas?", tornando-a uma febre mundial ao apontar uma série de evidências de possível interferência extraterrestre na história humana [2][4]. Segundo defensores, os deuses antigos na realidade eram alienígenas auxiliando a evolução tecnológica da humanidade: mostrando onde construir as pirâmides e até dando ferramentas altamente evoluídas para as civilizações da Antiguidade [2]. Hoje, a teoria é disseminada por figuras como o escritor suíço Giorgio Tsoukalos, conhecido pelo meme "Aliens", e por programas que reinterpretam monumentos megalíticos, textos sagrados e registros pictóricos sob uma lente tecnológica moderna [2][4].

## Os textos antigos não são transcrições técnicas

Um dos problemas centrais da teoria é a interpretação de textos antigos [1][3]. Os "Vigilantes" do Livro de Enoque ensinam artes proibidas dentro de uma explicação apocalíptica judaica de corrupção [1]. Os vimanas da literatura indiana variam de veículos divinos a palácios e carros ao longo de textos compostos em diferentes períodos [1]. As fontes sobre os Anunnaki descrevem grupos de deuses mesopotâmicos, não uma biografia de espécie única [1]. Cada exemplo precisa ser verificado em seu próprio contexto literário, e a maioria não sobrevive à leitura como relato de contato extraterrestre [1][3].

## Monumentos e artefatos: engenharia humana ou alienígena?

Defensores da teoria citam as linhas de Nazca, no Peru — mais de 300 enormes desenhos no solo que só podem ser vistos de grandes alturas — como evidência de contato [3]. Também apontam para antigas pirâmides do Egito, Machu Picchu no Peru e outras ruínas megalíticas, como Baalbek no Líbano, afirmando que não poderiam ter sido construídas sem capacidades técnicas avançadas [3]. Outros mencionam supostos "aeromodelos" antigos no Egito e na América do Sul, com semelhança a aviões e planadores modernos [3]. Para a arqueologia convencional, esses elementos têm explicação racional já exposta pelos próprios arqueólogos, e a maioria dos historiadores considera as alegações como pseudociência ou pseudo-história [3][4].

## A ciência e a falta de provas

Para que a hipótese de contato seja considerada cientificamente válida, exige-se evidência física direta, como ligas metálicas anômalas ou assinaturas isotópicas não terrestres [3]. Até o momento, nenhum artefato recuperado em escavações oficiais resistiu a exames laboratoriais rigorosos [3][4]. Sem a detecção de assinaturas tecnológicas remanescentes no sistema solar, a ideia de visitas físicas frequentes permanece cientificamente implausível diante dos dados observacionais atuais [3][4]. A arqueologia e a astronomia mainstream não verificaram contato extraterrestre ou artefatos em sítios antigos [3]. A teoria estabeleceu um vasto ecossistema cultural e midiático, mas carece de validação no método científico [1][3][4].

## Conclusão

Eles vieram das estrelas — ou pelo menos é o que queremos acreditar [1][2][4]. A teoria dos astronautas antigos transforma o céu em um panteão de visitantes e a história humana em um episódio de uma narrativa maior, cósmica [1][2][4]. Mas, sem evidência física que resista à ciência, o que resta é uma história poderosa, culturalmente influente, e, para a arqueologia, não comprovada [1][3][4]. Entre a certeza de que não estamos sozinhos e a certeza de que não fomos visitados, há um terreno fértil para a especulação — e um lembrete de que, às vezes, o mais extraordinário não vem do espaço, mas da própria capacidade humana de imaginar, construir e acreditar [1][3][4].

---

## Fontes

[1] pt.wikipedia.org — Astronautas antigos. https://pt.wikipedia.org/wiki/Astronautas_antigos
[2] pt.wikipedia.org — Eram os Deuses Astronautas?. https://pt.wikipedia.org/wiki/Eram_os_Deuses_Astronautas%3F
[3] infoescola.com — Teoria dos Astronautas Antigos. https://www.infoescola.com/curiosidades/teoria-dos-astronautas-antigos/
[4] terra.com.br — Por que algumas pessoas ainda acreditam que alienígenas moldaram civilizações antigas. https://www.terra.com.br/planeta/por-que-algumas-pessoas-ainda-acreditam-que-alienigenas-moldaram-civilizacoes-antigas,412e6ebc4a27feb3dcfea32a3bba02a2uw9734mj.html
[5] pt.wikipedia.org — Erich von Däniken. https://pt.wikipedia.org/wiki/Erich_von_D%C3%A4niken
[6] observador.pt — Erich von Däniken, do programa "Alienígenas". https://observador.pt/2020/02/20/erich-von-daniken-do-programa-alienigenas-acredito-que-estamos-a-ser-observados-alguem-nos-esta-a-estudar/
[7] recantodasletras.com.br — Tese de Von Däniken: Extraterrestres no passado ou pseudociência?. https://www.recantodasletras.com.br/analise-de-obras/8176872
[8] diariodepernambuco.com.br — "ETs estão aqui, nos observando", diz estudioso suíço. https://www.diariodepernambuco.com.br/noticia/cienciaesaude/2018/12/ets-estao-aqui-nos-observando-diz-estudioso-suico-em-visita-a-bra.html
[9] pt.scribd.com — Edição Comemorativa: Eram os Deuses Astronautas?. https://pt.scribd.com/document/901226903/Eram-Os-Deuses-Astronautas
[10] pt.wikipedia.org — Portal:Ufologia/Artigo selecionado/6. https://pt.wikipedia.org/wiki/Portal:Ufologia/Artigo_selecionado/6

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
