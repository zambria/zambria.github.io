---
titulo: "Discos na Arte Antiga: O Que os Artistas Viram nos Céus"
resumo: "De pinturas rupestres de 20 mil anos a obras renascentistas do século XV, a arte antiga guarda figuras que muitos interpretam como discos voadores. Entre a iconografia religiosa e a hipótese de visitantes do espaço, o que os artistas realmente viram — ou quiseram mostrar?"
categoria: "ufo"
data: "2026-11-21"
slug: "discos-na-arte-antiga-2026-11-21"
status: "draft"
tags: [arte-antiga, ovni-na-arte, renascimento, pinturas-rupestres, vaticano]
---

# Discos na Arte Antiga: O Que os Artistas Viram nos Céus

Desde pinturas rupestres de vinte mil anos até obras renascentistas do século XV, a arte humana guarda figuras que hoje muitos interpretam como discos voadores [1][2][3]. Entre a batalha de Nuremberg em 1561, a Anunciação de Crivelli e os discos na arte cristã, a linha entre símbolo religioso e possível registro de algo visto no céu se estreita — sem que exista uma resposta definitiva [1][2][3][4][5].

Este artigo examina as representações de objetos voadores na arte antiga e renascentista, a tensão entre a iconografia religiosa e a hipótese de visitantes do espaço, e por que a ciência convencional rejeita a interpretação ufológica dessas obras.

## Antes de existirem aviões: o que os artistas pintaram no céu

Antes de existirem aviões, satélites ou a palavra OVNI, alguém olhou para o céu e pintou o que viu [1][5]. Nas paredes de cavernas, em tapeçarias, em telas de mestres do Renascimento, surgem formas que hoje reconhecemos instantaneamente: discos, esferas, objetos cilíndricos com luzes, figuras que pairam sobre cenas sagradas [1][2][3]. Os historiadores de arte chamam isso de simbolismo divino — auréolas, nuvens, o Espírito Santo [2][3]. Os entusiastas de vida extraterrestre chamam de algo mais direto: evidência de que, muito antes da era moderna, humanos testemunharam navegar pelos céus algo que não era de cá [1][5]. A pergunta é antiga e permanece sem resposta: o que aqueles artistas realmente viram, e por que pintaram isso exatamente daquele jeito? [1][2][4][5]

## Pinturas rupestres: o começo de tudo

Há vinte mil anos, povos antigos na Espanha, na França e no Brasil — mais especificamente em Minas Gerais — pintaram em cavernas formas que descreviam naves e tripulantes [5]. Segundo o ufólogo Marco Antônio Petit, esses modelos retratam apenas algumas das formas de nave e de seres alienígenas estudadas pela ufologia, e a forma discoide é apenas uma entre várias — há também esféricas, charuto e ovo [5]. Embora a arqueologia convencional interprete essas pinturas como arte simbólica ou xamânica, para a ufologia elas são um dos registros mais antigos de algo que veio dos céus [1][5].

## A arte cristã e os discos no céu

Entre os séculos XV e XVII, a arte cristã produziu obras que, hoje, são relidas sob outra luz [2][3]. Na «Anunciação com Santo Emídio» (1486), de Carlo Crivelli, um feixe de luz emerge de um círculo no céu e atinge a cabeça da Virgem Maria — interpretado tradicionalmente como auréola divina, mas lido por entusiastas como um disco voador [2]. O «Batismo de Cristo» (1710), de Aert de Gelder, mostra um objeto em forma de disco irradiando feixes de luz em direção à cena [2][3]. A crucificação de Cristo, em uma pintura de mil anos exibida na Geórgia, apresenta um par do que parecem ser OVNIs, cada um com um rosto como se alguém pilotasse [2][3]. Na tapeçaria «Triunfo da Tapeçaria de Verão» (1538), de Bruges, vários objetos em forma de pires com seções semelhantes a cockpits aparecem no canto superior esquerdo [2]. Para críticos de arte, são símbolos religiosos; para ufólogos, são discos voadores pintados séculos antes dos aviões [2][3].

## A batalha de Nuremberg, 1561

Um dos registros mais famosos de objeto voador na arte pré-moderna é a xilogravura de 1566, feita por Hans Glaser para um jornal da época, que descreve um avistamento ocorrido em Nuremberg, Alemanha, em 14 de abril de 1561 [4]. De acordo com o jornal, a «terrível aparição» encheu o céu matinal com «formas cilíndricas das quais emergem esferas branco-azuladas que se movem rapidamente» [4]. Globos, cruzes e tubos começaram a lutar entre si por uma hora, e então caíram no chão como se estivessem em chamas, desaparecendo lentamente produzindo muito vapor [4]. O evento foi considerado um aviso divino [4]. Hoje, a interpretação oscila entre evidência de um antigo avistamento de OVNIs e a convergência de fenômenos meteorológicos [4]. Uma xilogravura semelhante retrata OVNIs esféricos sobre Basileia, Suíça, no mesmo ano, guardada na Coleção Wickiana da Biblioteca Central de Zurique [4].

## O Vaticano e o silêncio sobre os discos

A arte cristã guarda, segundo alguns, uma ligação secreta entre o Vaticano e a vida alienígena [3]. Artesanatos de aparência estranha começaram a aparecer na arte cristã já em 1400 [3]. Os artistas colocavam símbolos no céu, mas em alguns casos eles pareciam discos voadores [3]. Desde imagens de naves espaciais na arte cristã até objetos não identificados sobre igrejas, o Vaticano tem sido associado há muito tempo a fenômenos extraterrestres, embora tenha silenciado os crentes na vida alienígena e os acusado de heresia [3]. Se os discos na arte são registros de devoção religiosa ou evidência de algo mais, a resposta continua guardada — se é que existe [3].

## Duas interpretações, um mesmo quadro

Diante de um disco pintado em uma tela de 1486, a divergência é total [2][3]. Para o historiador de arte, trata-se de iconografia religiosa: a luz divina, a presença de Deus, o simbolismo da época [2][3]. Para o ufólogo, é o registro de uma nave extraterrestre, possivelmente testemunhada pelo artista e disfarçada sob a linguagem simbólica de seu tempo [2][3][5]. Não há prova material que decida a questão, e cada interpretação pressupõe algo que não pode ser comprovado [1][2][3][4][5]. O que resta é o próprio quadro: o disco, a luz, o céu — e a incômoda sensação de que, séculos antes de alguém usar a palavra «OVNI», alguém já havia visto algo que não conseguia nomear [1][5].

## Conclusão

A arte antiga não oferece respostas, apenas perguntas pintadas em tinta e pedra [1][2][5]. Se os discos nos quadros são símbolos de fé ou registros de visitas, a verdade permanece fora do alcance de qualquer um dos lados [1][2][3][4]. O que é inegável é que, muito antes dos céus se preencherem de aviões e satélites, humanos já olhavam para cima e viam algo que os impulsionava a registrar — para que, milênios depois, ainda estivéssemos tentando entender o que, exatamente, eles viram [1][5].

---

## Fontes

[1] hypescience.com — 10 pinturas históricas que mostram OVNIs. https://hypescience.com/pinturas-que-mostram-ovnis/
[2] ufo.com.br — Discos voadores e alienígenas nas Escrituras Sagradas. https://ufo.com.br/discos-voadores-e-alienigenas-nas-escrituras-sagradas/
[3] listverse.com — 10 Historic Paintings That Clearly Show UFOs. https://listverse.com/2016/04/24/10-historic-divine-paintings-that-clearly-show-ufos/
[4] www.youtube.com — UFO's in Christian Art - What are We Really Seeing Here?. https://www.youtube.com/watch?v=zu6RbHWnJ5w
[5] cdn.centerforinquiry.org — There's a UFO in My Painting!. https://cdn.centerforinquiry.org/wp-content/uploads/sites/29/2005/05/22164635/p22.pdf

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
