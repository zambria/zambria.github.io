---
titulo: "O Eco que Responde: Conversas com os Mortos entre a Fé e a Ilusão"
resumo: "Desde a Antiguidade, humanos tentam falar com os mortos por médiuns, mesas girantes, tabuleiros e gravadores. Espiritismo, transcomunicação instrumental e psicofonia prometem provas da sobrevivência, mas a ciência aponta efeito ideomotor, pareidolia e fraude. No Brasil, 3,18 milhões se declaram espíritas segundo o Censo 2022. Este artigo examina a história, as evidências e as controvérsias de conversar com quem partiu."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "conversas-com-os-mortos-2026-11-21"
status: "draft"
tags: [sobrenatural, mediunidade, espiritismo, evp, mortos]
---

# O Eco que Responde: Conversas com os Mortos entre a Fé e a Ilusão

**Resumo executivo:** Desde a Antiguidade, a humanidade tenta falar com os mortos — por médiuns, mesas girantes, tabuleiros ouija e gravadores de fita [1] [8] [13]. Espiritismo, transcomunicação instrumental e psicofonia prometem provas de que a consciência sobrevive e pode ser contatada [1] [14]. A ciência, no entanto, aponta para o efeito ideomotor, a pareidolia auditiva, a apofenia e a fraude como explicações mais prováveis [5] [7]. No Brasil, 3,18 milhões de pessoas se declaram espíritas, segundo o Censo 2022 [10]. Este artigo reconstrói a história dessas conversas, pesa as evidências e examina por que o silêncio do além continua a ser preenchido com nossas próprias vozes [5] [9].

## Introdução

O gravador fica ligado em um quarto vazio. Só há estática — o chiado branco de um rádio fora de sintonia. Então, entre o ruído, surge um sussurro que soa como um nome próprio. Uma voz que não deveria estar ali. Quem nunca ouviu uma gravação dessas sente o arrepio apenas de imaginar; quem ouviu, passa a temer o silêncio de casa [3] [13].

A vontade de conversar com os mortos é, talvez, a mais antiga e a mais desesperada das necessidades humanas. Não é a morte que assusta: é a certeza de que, uma vez morta, a pessoa deixa de responder. Espiritistas, médiuns e caçadores de fenômenos afirmam ter preenchido esse vazio. Cientistas e a Igreja Católica afirmam que o vazio só parece preenchido [5] [9]. Entre os dois, restam os vivos, perguntando em voz baixa se algo responde do outro lado — e o que acontece com quem passa a acreditar que alguém responde.

## 1. A história: convocar os mortos

A evocação dos mortos não nasceu com o espiritismo. Enterros com flores e objetos acompanham o homem desde o Neandertal, há centenas de milhares de anos, sinal de que a crença em alguma continuidade após a tumba é quase tão antiga quanto a nossa espécie [15] [FATO]. Na Antiguidade, a necromancia — a adivinhação por meio dos cadáveres e dos espíritos dos falecidos — era prática corriqueira entre muitos povos, e os textos religiosos já a restringiam: Moisés proibiu ao seu povo evocar os mortos [16] [FATO]. Essa tensão entre o desejo de falar com os defuntos e a proibição de fazê-lo percorre séculos.

O ponto de inflexão moderno ocorreu em 1848, em Hydesville, no estado de Nova York. As irmãs Catherine e Margaretta Fox, de 11 e 14 anos, afirmavam se comunicar com uma entidade por meio de batidas nas paredes — o espírito de um certo Charles B. Rosna [1] [6] [FATO]. Um amigo da família, Isaac Post, numerou letras e pediu que o ente formasse palavras por golpes; diz a história que os Fox escavaram o porão da casa e encontraram ossos humanos [1] [LENDA/FOLCLORE]. A notícia cruzou o Atlântico; em 1853, salões de Paris e Londres já faziam sessões de mesas girantes, e o espiritualismo moderno se tornara um movimento social [6] [FATO].

Foi nesse cenário que o pedagogo francês Hippolyte Léon Denizard Rivail entrou. Declaradamente cético, passou a investigar as manifestações mediúnicas e, por conselho dos próprios espíritos, adotou o nome Allan Kardec. Na segunda metade dos anos 1850, publicou O Livro dos Espíritos e codificou a Doutrina Espírita, transformando a comunicação com os mortos em uma doutrina com regras, classes de espíritos e métodos — as reuniões mediúnicas, a psicografia e a psicofonia [1] [7] [FATO]. Para Kardec, o médium era o "instrumento de laboratório" pelo qual o mundo invisível se tornaria patente [7] [HIPÓTESE].

## 2. As evidências alegadas: mesas, placas e vozes eletrônicas

O espiritismo transformou a conversa com os mortos em técnica. Nas mesas girantes, os participantes colocavam as mãos sobre uma mesa e aguardavam movimentos, inclinações ou pancadas que soletrariam respostas por meio de um alfabeto [7] [FATO]. Victor Hugo participou de dezenas de sessões em Jersey e acreditou ter contatado a própria filha, Léopoldine, e grandes escritores como Shakespeare e Molière [7] [LENDA/FOLCLORE].

O tabuleiro Ouija, patenteado em 1891 por Elijah J. Bond, surgiu desse mesmo impulso: o empresário Charles Kennard perguntou aos espíritos como a invenção deveria se chamar e, segundo a lenda do produto, a prancheta soletraria "Ouija" [8] [LENDA/FOLCLORE]. No Brasil, a variante virou a "brincadeira do copo" [8] [FATO].

Nas décadas seguintes, a tecnologia entrou na sessão. Thomas Edison previu, em 1920, uma máquina capaz de captar mensagens fantasmagóricas — um "telefone espiritual" que nunca patenteou e que, segundo o New York Times de 1926, pode ter sido uma lorota [3] [4] [LENDA/FOLCLORE]. A partir dos anos 1950, o artista sueco Friedrich Jürgenson captou em fitas o que acreditou ser a voz de sua mãe falecida, e o psicólogo letão Konstantin Raudive gravou setenta e duas mil vozes em fitas magnéticas, convencido de que vinham do além [3] [4] [LENDA/FOLCLORE]. Em 1952, os frades Agostino Ernetti e Pellegrino Gemelli teriam gravado a voz do pai de Gemelli, que usava seu apelido de infância, "Zucchini" — um caso que só veio a tona em 1994 [3] [LENDA/FOLCLORE].

Hoje, a transcomunicação instrumental (TCI) e o fenômeno de voz eletrônica (EVP) prometem contatar os mortos por aparelhos domésticos — rádios fora de sintonia, gravadores, até o home theater [3] [13]. No Brasil, grupos como a Associação Nacional de Transcomunicadores, o Instituto Brasileiro de Pesquisas Psicobiofísicas e o I.P.A.T.I., de Sônia Rinaldi, investigam o fenômeno [2] [FATO].

Na outra frente, a mediunidade tradicional produz psicografias. Chico Xavier deixou mais de quatrocentos livros atribuídos a espíritos [1] [5] [LENDA/FOLCLORE], e em 1991 o perito grafotécnico Carlos Augusto Perandréa relatou que caligrafias psicografadas correspondiam mais de perto à dos supostos autores falecidos do que à do próprio Xavier [5] [HIPÓTESE].

## 3. A controvérsia: o que a ciência e a Igreja realmente veem

A ciência nunca encontrou provas confiáveis de que médiuns se comuniquem com os mortos. O consenso dos estudos sobre mediunidade é de que não há evidências replicáveis aceitas pela comunidade científica; os acertos relatados são atribuídos à leitura a frio, ao efeito Forer (ou Barnum), ao relato seletivo, ao vazamento sensorial ou à fraude [5] [FATO]. Programas como o VERITAS, de Gary Schwartz, foram criticados por controles insuficientes; o Instituto Windbridge testou protocolos triplo-cegos com resultados anômalos, mas não replicados de forma independente; uma meta-análise de 2021, de Tressoldi e colaboradores, encontrou efeito pequeno e estatisticamente significativo, com ressalvas de heterogeneidade e viés de publicação [5] [HIPÓTESE]. A ciência dominante considera a alegação central — a comunicação com os mortos — sem fundamento [5] [FATO].

O mecanismo físico mais citado para fenômenos como mesas girantes e Ouija é o efeito ideomotor: em 1853, Michael Faraday demonstrou experimentalmente que os próprios participantes moviam as mesas de forma involuntária, e uma comissão da Academia Francesa de Ciências chefiada por Chevreul chegou à mesma conclusão em 1854 [7] [FATO]. O mesmo se aplica ao marcador da placa ouija [7] [FATO]. A história da mediunidade física está cheia de fraudes desmascaradas — Eusápia Palladino, William Eglinton — e Harry Houdini expôs truques de médiuns famosos [7] [FATO].

As vozes eletrônicas não escapam. O entendimento científico é que o EVP é pareidolia auditiva, uma forma de apofenia — o cérebro impõe padrões a ruídos aleatórios — auxiliado por artefatos de equipamento, interferência de rádio e sugestão [2] [3] [4] [FATO]. O psicólogo James Alcock, do Comitê de Investigação Científica das Alegações de Paranormalidade, observa que parapsicólogos sérios praticamente abandonaram o EVP e que a literatura moderna da parapsicologia não mostra evidência de paranormalidade nessas gravações [3] [FATO]. Christopher French e Anna Stone explicam que, quanto mais ambíguo o som, mais a imaginação preenche as lacunas — e que, uma vez sugerida uma frase, é impossível "não ouvi-la" [4] [FATO].

A Igreja Católica vai além: considera a evocação dos mortos pecaminosa e totalmente desaconselhada, enquadrando-a na necromancia e na adivinhação proibidas (CIC 2115-2117); o Santo Ofício, em 1856 e 1917, declarou ilícita qualquer participação em sessões espíritas, mesmo como mero espectador [9] [FATO]. Para a Igreja, nunca foi demonstrada prova suficientemente contrastada de que seja possível falar com os mortos por médiuns, bruxos ou adivinhos [9] [FATO].

## 4. Interpretações: por que ainda falamos com os mortos

Duas interpretações competem. Para espiritualistas e espíritas, a comunicação com os mortos é real: os espíritos continuam sendo as mesmas pessoas, apenas invisíveis a nossos olhos, e o contato ocorre por mediunidade psicofônica ou psicográfica, sem ritos mágicos [14] [16] [HIPÓTESE]. Para a ciência dominante, o fenômeno nasce da necessidade psicológica de dar sentido à perda, da sugestibilidade e da tendência a encontrar significado no caos — o luto transforma o silêncio em voz [6] [9] [HIPÓTESE].

No Brasil, o apelo continua forte. O Censo 2022 registrou 3,18 milhões de espíritas — 1,8% da população, queda frente aos 2,2% (3,56 milhões) de 2010 [10] [FATO]; a Federação Espírita Brasileira estima trinta milhões de simpatizantes [11] [FATO]. O espiritismo "deu certo" no Brasil como em nenhuma outra nação, associando um contorno supostamente científico à promessa de que a morte não encerra a conversa [11] [HIPÓTESE]. A neurociência tem começado a olhar o próprio estado mediúnico — um estudo de 2012 com SPECT encontrou atividade alterada em regiões de atenção e autoconsciência de médiuns em transe de psicografia — mas não prova de onde vêm as informações [5] [HIPÓTESE].

O que une crentes e céticos é o mistério da morte: dogmáticas ou não, as respostas sobre o que vem depois ficam fora do escopo da ciência empírica [6] [FATO]. O psicólogo Wellington Zangari, da USP, lembra que a ciência não pode demonstrar a existência de Deus ou de um universo sobre-humano, mas pode testar se alegadas forças do além-vida agem no mundo físico — e até agora nada foi comprovado [6] [FATO].

## Conclusão

O verdadeiro arrepio não está na ideia de que os mortos respondem. Está na constatação de que ninguém jamais respondeu de forma que resistisse a uma gravação controlada, a um protocolo triplo-cego ou à luz do dia [5] [7]. O sussurro na estática é nosso: pareidolia, apofenia, o cérebro casando ruído com a voz que mais queremos ouvir [4]. O tabuleiro se move pelas nossas próprias mãos, sem que percebamos [7].

Quem conversa com os mortos, no final, está conversando consigo mesmo — com a falta, com o medo do silêncio, com o vazio de memória de quem partiu. O além continua em silêncio. E o mais assustador pode não ser a ausência de resposta, mas a disposição de acreditar que ela veio.

## Fontes

1. Super Abril — "Espiritismo — Uma ponte com o além". super.abril.com.br/historia/espiritismo-uma-ponte-com-o-alem/. Jornalística (Superinteressante/Abril). Acesso: 21/11/2026.
2. Wikipédia — "Fenômeno da voz eletrônica". pt.wikipedia.org/wiki/Fen%C3%B3meno_da_voz_eletr%C3%B3nica. Enciclopédia. Acesso: 21/11/2026.
3. Super Abril — "Vozes do Além: Os mortos querem falar". super.abril.com.br/comportamento/vozes-do-alem-os-mortos-querem-falar/. Jornalística (Superinteressante/Abril). Acesso: 21/11/2026.
4. Revista Galileu (Globo) — "Fenômenos de voz eletrônica (EVP): lacunas preenchidas pela imaginação". revistagalileu.globo.com/blogs/olhar-cetico/noticia/2015/06/fenomenos-de-voz-eletronica-evp-lacunas-preenchidas-pela-imaginacao.html. Jornalística/cética. Acesso: 21/11/2026.
5. Wikipédia — "Estudos sobre mediunidade". pt.wikipedia.org/wiki/Estudos_sobre_mediunidade. Enciclopédia. Acesso: 21/11/2026.
6. Revista Questão de Ciência — "Caça-fantasmas: truques antigos, vítimas novas". www.revistaquestaodeciencia.com.br/dossie-questao/2021/06/11/caca-fantasmas-truques-antigos-vitimas-novas. Jornalística/cética. Cesar Baima. 11/06/2021. Acesso: 21/11/2026.
7. Wikipédia — "Mesas girantes". pt.wikipedia.org/wiki/Mesas_girantes. Enciclopédia. Acesso: 21/11/2026.
8. Aventuras na História — "Tabuleiro Ouija: Brincando com os mortos". aventurasnahistoria.com.br/noticias/almanaque/historia-tabuleiro-ouija-brincando-com-os-mortos.phtml. Jornalística. Acesso: 21/11/2026.
9. Aleteia — "É possível falar com os mortos?". pt.aleteia.org/2021/08/12/e-possivel-comunicar-se-com-os-mortos-1-de-4/. Jornalística religiosa (posição da Igreja Católica). 12/08/2021. Acesso: 21/11/2026.
10. BBC News Brasil — "Censo 2022 religião: o que pesquisa revela sobre evangélicos e mais 7 dados inéditos". bbc.com/portuguese/articles/crk2p5xr0m7o. Jornalística. Thais Carrança. 06/06/2025. Acesso: 21/11/2026.
11. BBC News Brasil — "Espiritismo no Brasil, 160 anos: por que religião 'vingou' tanto no país?". bbc.com/portuguese/articles/c5yerdr22zzo. Jornalística. Edison Veiga. 20/09/2025. Acesso: 21/11/2026.
12. Unicamp — "Por uma ciência da morte: fenômenos, fatos e provas" (Cap. 6, Eliane Moura Silva). www2.unicamp.br/~elmoura/CAP6.DOC. Acadêmica. Acesso: 21/11/2026.
13. Além da Ciência — "Fenômeno de Voz Eletrônica: vozes dos mortos?". www.alemdaciencia.com/fenomeno-de-voz-eletronica-vozes-dos-mortos/. Divulgação científica/cética (James E. Alcock, Skeptical Inquirer). 05/09/2005. Acesso: 21/11/2026.
14. Geo Legado de Allan Kardec — "Evocações e Reuniões Mediúnicas: Fundamentos Científicos Segundo Allan Kardec". www.geolegadodeallankardec.com.br/artigos/em-destaque/evocacoes-e-reunioes-mediunicas-fundamentos-cientificos-segundo-allan-kardec/. Alternativa/espírita. Acesso: 21/11/2026.
15. Espírito.org.br — "Estudos da Mediunidade Antes da Codificação Kardequiana". espirito.org.br/artigos/estudos-mediunidade-antes-codificacao-kardequiana/. Alternativa/espírita. Djalma Argollo. 03/03/2015. Acesso: 21/11/2026.
16. Associação Espírita Allan Kardec (Rio Preto) — "Mortos – comunicação". kardeccriopreto.com.br/mortos-comunicacao/. Alternativa/espírita. Donizete Pinheiro. Acesso: 21/11/2026.

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA