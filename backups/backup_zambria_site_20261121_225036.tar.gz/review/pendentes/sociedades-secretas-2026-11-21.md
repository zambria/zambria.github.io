---
titulo: "Sociedades Secretas: Dos Illuminati da Baviera ao Túmulo de Yale"
resumo: "Illuminati da Baviera, Maçonaria e Skull and Bones são sociedades secretas reais, documentadas e, em parte, dissolvidas. Entre fatos verificáveis e teorias de conspiração, este artigo separa o que se sabe de quem controla o mundo do que permanece na esfera da especulação."
categoria: "conspiracao"
data: "2026-11-21"
slug: "sociedades-secretas-2026-11-21"
status: "draft"
tags: [conspiracao, sociedades-secretas, illuminati, skull-and-bones]
---

# Sociedades Secretas: Dos Illuminati da Baviera ao Túmulo de Yale

**Resumo executivo.** Sociedades secretas são organizações reais, muitas vezes documentadas, cujos rituais e membros não são divulgados. Os Illuminati da Baviera existiram de 1776 a 1785; a Maçonaria moderna data do início do século XVIII; a Skull and Bones foi fundada em 1832 na Universidade de Yale. Teorias de conspiração afirmam que tais grupos controlam governos e eventos mundiais, mas não há prova empírica de um plano secreto de dominação — apenas especulação fundada em circunstâncias inusitadas. [1][2][3][4][5]

## Introdução com suspense

Existe um edifício sem janelas no campus de Yale, conhecido como "The Tomb" — o Túmulo. Dentro dele, quinze estudantes por ano juram lealdade a uma sociedade cuja existência é real, mas cujas reuniões e práticas permanecem em segredo absoluto [4][5]. Do outro lado do Atlântico, uma ordem fundada em uma floresta perto de Ingolstadt, na Baviera, em 1º de maio de 1776, durou menos de uma década antes de ser banida — e, no entanto, seu nome continua a ser invocado como o cérebro oculto por trás de revoluções e governos [1][2][3]. Sociedades secretas fascinam porque prometem acesso a um conhecimento que o restante do mundo não possui. A pergunta, no entanto, é se esse conhecimento é poder real ou apenas a sombra dele.

## Illuminati da Baviera: a ordem que durou menos de dez anos

Historicamente, o termo Illuminati refere-se, na maior parte das vezes, aos Illuminati da Baviera, uma sociedade secreta da época do Iluminismo fundada em 1 de maio de 1776 por Adam Weishaupt, professor de Direito Canônico na Universidade de Ingolstadt, e pelo barão Adolph von Knigge [1][2][3]. Seus membros chamavam-se a si mesmos de "perfectibilistas". O grupo buscava opor-se à superstição, ao obscurantismo, à influência religiosa sobre a vida pública e aos abusos de poder do Estado [1][2]. Atraiu intelectuais e políticos progressistas, incluindo Johann Wolfgang von Goethe, e recrutou membros nas lojas maçônicas da Alemanha [1][2]. Em 1784, 1785, 1787 e 1790, os Illuminati — juntamente com a Maçonaria e outras sociedades secretas — foram proibidos por éditos do soberano bávaro Carlos Teodoro, com o encorajamento da Igreja Católica [1][2][3]. A ordem foi infiltrada, quebrada e reprimida, deixando de existir como organização funcional ainda no século XVIII [1][3].

## Maçonaria: discrição, simbolismo e suspeita

A Maçonaria é uma fraternidade organizada em lojas, com tradições, símbolos, cerimônias e regras próprias. Sua história moderna está associada à formação de organizações maçônicas na Europa, especialmente a partir do início do século XVIII; a Grande Loja da Inglaterra, criada em Londres em 1717, é um marco frequentemente citado [2]. A origem exata da instituição envolve um processo histórico mais amplo, e não uma única data [2]. Rituais reservados e a participação de pessoas influentes contribuíram para que a Maçonaria fosse associada a diferentes interpretações políticas e religiosas, mas essas características, por si só, não demonstram que a instituição opere como uma estrutura centralizada de controle político ou econômico [2]. Em 1828, um movimento político nos Estados Unidos, o Partido Antimaçônico, foi estabelecido com o único objetivo de combater a ordem [2].

## Skull and Bones: a ordem da morte de Yale

A Skull and Bones (Crânio e Ossos) é uma sociedade secreta estudantil dos Estados Unidos, fundada em 1832 na Universidade de Yale por William Huntington Russell e Alphonso Taft [4][5]. Cada primavera, a sociedade seleciona exatamente quinze novos membros entre estudantes do terceiro ano — um em cada cem [4]. Os nomes dos membros eram publicados anualmente até 1971; não existem rosters oficiais publicados após 1982 [4]. Três presidentes dos EUA foram membros: William Howard Taft, George H.W. Bush e George W. Bush; em 2004, ambos os candidatos presidenciais — George W. Bush e John F. Kerry — eram Bonesmen [4]. Durante a administração de George W. Bush, cinco Bonesmen foram nomeados para cargos governamentais [4].

O que é verificável é uma rede de influência real: pessoas que passaram pela mesma instituição e ascenderam a posições de poder. O que é especulação — e é crucial distinguir — é que exista uma coordenação malévola ou uma agenda oculta controlando os Estados Unidos [4][5]. Teorias de conspiração afirmam que a Skull and Bones controla a CIA, é uma filial do Iluminati ou está por trás de assassinatos, mas nenhuma destas teorias foi comprovada empiricamente [4][5]. É uma organização altamente seletiva, envolvida em segredo absoluto, que reúne consistentemente pessoas que ascendem a posições de poder; se isto representa networking normal de elites ou algo mais sistemático permanece em aberto [4][5].

## Dos fatos às teorias de conspiração

As teorias conspiratórias envolvendo os Illuminati afirmam que a sociedade alemã, historicamente dissolvida em 1785, persistiu na clandestinidade e prossegue com um plano secreto para dominar o mundo [3]. Essas teorias remonta às obras de John Robison e Augustin Barruel, no final do século XVIII, que especulavam que os Illuminati sobreviveram à repressão e tornaram-se os cérebros por trás da Revolução Francesa e do Reino do Terror [3]. No folclore das conspirações, "Illuminati" tornou-se um termo genérico para sintetizar teorias que identificam como conspiradores diversos grupos — maçons, judeus, sionistas, comunistas, sociedades secretas e organizações internacionais — e para designar o sistema resultante, o núcleo dos "senhores do mundo" [3]. Os estudos históricos estimam que os Illuminati não sobreviveram para além do final do século XVIII [3].

## Conclusão

Sociedades secretas existem. São reais, documentadas e, em alguns casos, influentes [1][2][4][5]. Mas a passagem do fato verificável à especulação é curta, e é nela que nascem as teorias de dominação mundial [3]. Não há prova empírica de que Illuminati, maçons ou Bonesmen coordenem um plano secreto para controlar governos, determinar guerras ou definir decisões econômicas globais [2][3][4][5]. O que resta é o segredo — e o fato de que, para muitos, o segredo por si só é prova suficiente [1][2][3][4][5].

## Fontes

[1] Wikipédia (PT) — Illuminati — https://pt.wikipedia.org/wiki/Illuminati
[2] BBC News Brasil — Illuminati: 12 curiosidades sobre uma das sociedades secretas mais fascinantes da história — https://www.bbc.com/portuguese/geral-57460948
[3] Wikipédia (PT) — Illuminati nas teorias de conspiração — https://pt.wikipedia.org/wiki/Illuminati_nas_teorias_de_conspira%C3%A7%C3%A3o
[4] O Cidadão — Skull and Bones: as elites secretas de Yale entre factos e especulação — https://ocidadao.pt/skull-and-bones-as-elites-secretas-de-yale-entre-factos-e-especulacao/
[5] Wikipédia (PT) — Skull and Bones — https://pt.wikipedia.org/wiki/Skull_and_Bones

Artigo gerado automaticamente pelo Pesquisador-Escritor do ZAMBRIA
