---
titulo: "O Fragmento de Ubatuba"
resumo: "Um pedaço de metal branco, supostamente de um disco que explodiu sobre a Praia da Toninha em 1957, repousa esquecido em um arquivo. Quando um estagiário o toca, o fragmento começa a devolver algo que não deveria ter saído da água."
categoria: "ufos"
data: "2026-11-21"
slug: "o-fragmento-de-ubatuba"
tipo: "ficcao"
fonte_pesquisa: "UAP Codex — Caso Ubatuba (fragmentos de metal enviados por carta anonima a Ibrahim Sued, 1957); UFO Evidence — The Ubatuba Fragments"
status: "pendente de curadoria"
---

# O Fragmento de Ubatuba

A caixa chegou lacrada, com o selo do Arquivo Nacional e o nome de Ibrahim Sued riscado a caneta na etiqueta. Eram os papéis doados pelos herdeiros do colunista do O Globo, falecido décadas antes. Daniel Moraes, estagiário de catalogação de doacoes anonimas, abriu-a na manha de um terca-feira de outubro, na sede do arquivo no Centro do Rio. Entre recortes amarelecidos de 1957, cartas de leitores e protocolos internos, havia um envelope manila sem remetente. Dentro, tres pedacos de metal branco, cada um menor que uma moeda, e uma folha datiloscrita sem assinatura.

O autor anonimo relatava que, na noite de quatorze de setembro de 1957, algo explodiu sobre a Praia da Toninha, em Ubatuba, no litoral norte de Sao Paulo. Nao era trovao. Nao era tempestade. Era um disco, segundo a carta, que se despedacou no ar e fez chover metal sobre a areia. Moradores recolheram pedacos. Um deles, nunca identificado, enviou tres deles a Sued, que publicou a historia em sua coluna e entregou o material a um laboratorio mineral do Ministerio da Agricultura. O primeiro laudo falava de magnesio a noventa e nove virgula noventa e nove por cento de pureza — um grau de puridade que, segundo o proprio laboratorio, seria impossivel de alcançar por meios terrestres. Treze anos depois, o projeto Condon, nos Estados Unidos, analisou um dos fragmentos e inverteu a conclusao: nao era magnesio especialmente puro, mas um metal comum, com zinco, estrontio e bario em sua composicao. Dois laudos. Um objeto. Nenhuma explicacao que fechasse.

Daniel colocou o maior fragmento sobre a mesa de luz da sala de consulta. Pesava menos que quatro gramas. Nao tinha arestas de corte, nao parecia fundido, nao apresentava marcas de solda. Era apenas um pedaco opaco e branco, levemente mais pesado que o esperado para o tamanho. Passou a carregá-lo no bolso do casaco. Nao por conviccao de que fosse algo extraordinario, mas porque o objeto exercia sobre ele um silencio que os outros documentos do arquivo nao tinham. Os papeis falavam. O fragmento calava.

Na primeira semana, nada aconteceu. Na segunda, Daniel começou a sonhar com mar.

Não eram sonhos de naves, de luzes no céu ou de seres descendo de cima. Eram sonhos de agua fria, de profundidade escura e de algo abaixo da superfície que conhecia o nome dele. Sonhava que estava na Praia da Toninha na noite de quatorze de setembro de mil novecentos e cinqüenta e sete. Vinha a explosão silenciosa acima do mar, um clarão sem estampido, e os pedacos brancos caindo como chuva sobre as ondas. E via uma figura — ou algo que usava a forma de uma pessoa — recolhendo os fragmentos com as mãos nuas, colocando-os em um envelope de papel manila, lacrando-o. O remetente anonimo da carta nunca foi um cidadão assustado. Era algo que queria garantir que pelo menos um pedaco chegasse ate um arquivo publico. Que alguém, algum dia, tocasse nele novamente.

Daniel passou a levar o fragmento para o banco da universidade onde fazia um trabalho de fim de semana. Pediu ao tecnico do laboratorio de física que o submetesse a testes de dureza e espectroscopia. O resultado irritou o tecnico: o metal nao riscava com lixa de diamante, nao oxidava, nao reagia a acidos diluídos, e o espectro de emissao nao correspondia a nenhum composto conhecido. Pelo menos, nao correspondia a nada que o tecnico estivesse disposto a assinar por escrito. Quando Daniel perguntou se aquilo poderia ser de origem desconhecida, o tecnico respondeu que nao assinava laudos de ficcao cientifica e devolveu o fragmento embrulhado em papel de filtro.

O zumbço começou depois disso. Um som baixo, quase infrassonoro, que Daniel ouvia apenas quando estava sozinho com o objeto e a menos de um metro de distancia. Mediu a frequência com um gravador de campo sensível e um aplicativo de analise de espectro. O aparelho nao captava nada. Nada de aparelho captava. Apenas ele ouvia, ou sentia — uma vibração nos ossos da face, atrás do ouvido esquerdo, como se o som não viesse do ar, mas de dentro do próprio crânio. Os colegas do arquivo falaram em ar-condicionado, encanamento, trens passando sob o Centro. Daniel sabia que não era. O som parava quando ele levava o fragmento para outra sala e voltava ao aproximá-lo da mesa de trabalho.

Fez uma pesquisa nos arquivos do jornal, por conta própria, nas horas vagas. Encontrou a segunda pagina da carta datiloscrita, a que Sued nunca publicou. O autor anonimo descrevia mais do que luzes no céu. Contava que, nas semanas seguintes à explosão, pessoas que tinham tocado nos pedacos de metal começaram a sair de casa à noite, descalças, sem acordar os parentes. Caminhavam até a agua. Não se afogavam. Simplesmente entravam no mar e não voltavam. Os corpos nunca apareceram. A policia de Ubatuba nunca encontrou um sequer. Os parentes diziam que, na ultima vez que viram essas pessoas, elas tinham o olhar distante e a pele levemente mais branca que o normal, como se algo tivesse drenado a cor do sangue sem deixar ferimento.

Daniel começou a anotar os sonhos em um caderno. Na terceira semana, escreveu que o mar não estava mais apenas nos sonhos. Escritava de acordar com a boca cheia de sal, com os dedos enrugados como se tivesse passado horas na agua, com areia debaixo das unhas embora nunca tivesse pisado na praia. O fragmento, quando tocado, parecia mais quente que a pele — não quente de fogo, mas quente de temperatura corporal, como se estivesse vivo de alguma forma lenta e paciente.

Procurou o estagiário que ocupara sua função vinte anos antes, o ultimo funcionário a catalogar a doação de Sued antes dele. O homem já estava aposentado, morava em Niterói, atendeu o telefone com a voz de alguém que não esperava ser procurado. Daniel perguntou sobre os fragmentos de metal. O homem ficou em silencio por tempo demais e então disse apenas: "O magnésio estava vigiando-o." Pediu desculpa, desligou, e não atendeu mais. Daniel descobriu, depois, que o homem pediu baixa do arquivo poucos meses após manusear a doação, apresentando um laudo psicológico no qual afirmava ter a certeza de que algo do lado de fora estava lendo seus pensamentos através dos documentos.

Na sexta-feira seguinte, Daniel pediu demissão. No ultimo dia de trabalho, deixou o fragmento sobre a propria mesa de consulta, dentro do envelope manila, sem fechar o lacre. Saiu do prédio sem olhar para trás. Pegou o metrô até a estação mais próxima da rodoviária, comprou uma passagem de ida para Ubatuba e viajou durante a noite inteira com a cabeça encostada na janela, vendo a paisagem passar em tons de cinza sob a chuva.

Chegou à Praia da Toninha pouco antes do amanhecer. O mar estava calmo, quase plano, uma superfície de chumbo sob o céu cinza. Nao havia ninguem na areia. Daniel nao carregava mais o fragmento — o deixara no arquivo, para o próximo funcionário curioso abrir o envelope e tocar no metal. Mas a agua sabia. A agua sempre soube. Ele tirou os sapatos, deixou a roupa em uma pilha sobre a areia e entrou no mar. Não nadou. Não lutou contra as ondas. Simplesmente andou, de costas para a praia, passo a passo, até que o chão deixasse de existir sob os pés e o frio da agua fosse a unica coisa verdadeira que restou.

Atrás dele, em um arquivo a milhares de quilometros de dali, o envelope permanecia fechado, esperando que alguém colocasse a mão sobre o pedaco branco e ouvisse, bem dentro do crânio, o chamado que não tem eco porque ainda não terminou de viajar.

## Fontes de inspiração

- UAP Codex — "Brazil. Ubatuba: fragments of a disc said to have exploded" (Setembro de 1957; fragmentos de metal branco enviados por carta anonima a Ibrahim Sued; primeiros laudos reportavam magnesio de pureza excepcional; a analise do projeto Condon, em 1968, inverteu a conclusao; a procedencia e a identidade das testemunhas nunca foram comprovadas).
- UFO Evidence — "The Ubatuba, Brazil Fragments" (Carta publicada por Ibrahim Sued em O Globo, em 14 de setembro de 1957, acompanhada de tres pedacos de metal branco; descrita como material recolhido apos a explosão de um disco sobre a Praia da Toninha; testemunhas originais nunca identificadas).

As fontes servem apenas como inspiração para esta obra de ficcao. Personagens, enredo, atmosfera e reviravolta sao criacao original; nenhum trecho foi copiado de fontes externas.
