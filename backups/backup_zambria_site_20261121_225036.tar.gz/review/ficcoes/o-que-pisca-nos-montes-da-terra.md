---
titulo: "O Que Pisca nos Montes da Terra"
resumo: "Uma bióloga viaja ao Parque Nacional das Emas para documentar os pontos verdes dos cupinzeiros luminosos. As luzes, contudo, começam a responder de volta."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-que-pisca-nos-montes-da-terra"
tipo: "ficcao"
fonte_pesquisa: "O Antagonista — bioluminescência nos cupinzeiros do Parque Nacional das Emas"
status: "pendente de curadoria"
---

# O Que Pisca nos Montes da Terra

No Cerrado de Goiás, quando o sol se retira e o Parque Nacional das Emas fica sob a noite, os montes de terra dos cupinzeiros deixam de ser apenas montes de terra. Pontos de luz verde acendem na superfície deles, pequenos faróis que piscam em silêncio. É o trabalho de larvas do vaga-lume Pyrearinus termitilluminans, que constroem túneis rasos e expõem uma lanterna biológica para atrair insetos. Para quem passa por ali, o espetáculo parece inofensivo: um campo pontilhado de estrelas verdes, um fenômeno natural, bonito e distante.

Marina chegou na tarde de quarta-feira. Bióloga de campo, vinha com um equipamento de gravação de áudio de alta sensibilidade e uma câmera modificada para o infravermelho próximo. O objetivo era simples: documentar o padrão de flashes dos cupinzeiros em uma área de chapadão longe da portaria, verificar se a sincronia entre os montes responde a variáveis de umidade, temperatura e fase da lua. Nada mais. Não acreditava em mistério. Acreditava em variáveis, em causa e efeito.

A primeira noite passou sem incidentes. Ela posicionou os equipamentos a vinte metros de um aglomerado de seis montes, ligou o gravador e sentou-se em uma cadeira dobrável a observar. Os pontos verdes piscavam, se apagavam, piscavam novamente. Alguns montes faziam isso em conjunto, outros sozinhos. Era previsível, dentro do que a literatura descrevia. Ela anotou horários, intensidade, intervalos. Quando fechou o equipamento e voltou para a barraca, o silêncio do chapadão a recebeu sem surpresa.

Na segunda noite, algo mudou.

Marina havia se deitado para descansar por volta das vinte e uma horas, com a janela da barraca aberta para ventilar. Acordou não sabe dizer por quê, ou por qual barulho — não havia barulho. O que a despertou foi a vista. Do lado de fora, os pontos verdes dos cupinzeiros não piscavam mais ao acaso. Eles piscavam em um ritmo. Não o ritmo de um inseto, não o ritmo aleatório de um acasalamento. Era uma cadência constante, regular, como um pulso. Três flashes curtos, uma pausa, dois flashes longos. Repetido.

Ela saiu da barraca com a lanterna na mão. Desligou a lanterna. Os pontos verdes continuaram, agora em sincronia perfeita uns com os outros, como se todos os montes daquela área tivessem decidido respirar juntos. Marina aproximou-se devagar, parou a uns dez metros do monte mais próximo. A luz verde brilhava na abertura do túnel, forte e fria, sem calor. Ela ficou imóvel, segurando a respiração.

Então, o monte piscou em resposta à sua respiração.

Não foi imaginação. Marina expirou devagar, e no exato instante em que o ar saiu de seus pulmões, o ponto verde apagou-se e acendeu-se novamente, uma vez, duas vezes, acompanhando o ritmo de sua expiração. Ela prendeu a respiração. As luzes pararam. Soltou o ar devagar, e as luzes voltaram a piscar, marcando cada sopro.

Ela voltou à barraca com o coração acelerado, mas sem medo — só com a atenção aguçada, a atenção de quem ainda acredita que pode medir o que vê. Ligou o gravador, deixou-o apontado para os montes, e passou a noite inteira acordada, observando. Quando revisou o áudio pela manhã, encontrou algo que não deveria estar lá.

Debaixo do coro de insetos noturnos, sob o vento e o crepitar da palha seca, havia um som. Um clique. Ritmado. Sincronizado com os flashes verdes que ela havia visto. E, dentro do clique, uma voz. Não alta, não clara, mas inteligível o suficiente. A voz dizia o próprio nome dela.

Marina.

Ela ouviu o arquivo três vezes. O mesmo resultado. A voz não era de nenhum dos membros de sua equipe — não havia equipe, ela estava sozinha. Não era um animal. Era uma voz que havia aprendido a pronunciar seu nome, e que escolheu o momento em que ela estava sozinha no escuro para pronunciá-lo.

Na terceira noite, Marina decidiu testar até onde ia a resposta. Levou a lanterna até os montes, parou à mesma distância de antes, e acendeu a luz. Um único feixe, dirigido ao monte central. Ela contou até dez e apagou. Os pontos verdes piscaram de volta. Um feixe de resposta, verde, direto para onde ela estava. Ela repetiu o teste. Dois feixes da lanterna, dois feixes verdes de volta. Três feixes, três respostas. Não era eco. Era conversa.

Ela começou a gravar tudo. Vídeo, áudio, anotações de campo. A cada noite, a sincronia ficava mais precisa. Os montes que antes piscavam sozinhos agora esperavam por ela. Quando Marina acendia a lanterna, os pontos verdes se acendiam antes mesmo dela terminar o movimento. Quando ela se afastava, as luzes se apagavam. Não era mais biologia. Era algo que estava observando, e que havia aprendido a falar de volta na língua da luz.

No quarto dia, ela revisou as filmagens com a câmera de infravermelho. No escuro total, os pontos verdes apareciam nítidos, e algo mais também. Nas imagens, ao redor de cada monte iluminado, havia formas alongadas, pálidas, que se moviam entre os túneis da terra. Não eram insetos. Não tinham o tamanho nem a forma de insetos. Eram figuras que se erguiam do monte, se estendiam em direção à câmera, e recuavam quando a luz da câmera as alcançava. Elas estavam na terra, debaixo da grama, e estavam olhando para ela.

Marina fechou o equipamento. Decidiu que ia embora no dia seguinte. Ela arrumou as coisas, guardou os cartões de memória, trancou a barraca. Antes de dormir, fez uma última anotação no caderno de campo: "As luzes não são sinais de acasalamento. São isca. E algo aprendeu a usar a isca."

Na última noite, ela não acendeu a lanterna. Ficou sentada fora da barraca, no escuro, apenas ouvindo. O campo estava silencioso. Sem insetos, sem vento. Então os pontos verdes acenderam. Não no monte a vinte metros. Perto. Perto demais. No chão, a poucos passos da sua bota, um ponto verde piscou. Uma vez. Duas vezes. Três. Um ritmo. Um convite.

Marina não se moveu. Não respirou alto. Ela só observou o ponto verde no chão, tão perto que podia ver o brilho refletido na própria sola do calçado. E então a luz se apagou, e do monte mais próximo veio o som — o clique, o ritmo, a voz — dizendo o nome dela, desta vez não do gravador, mas direto ao ouvido, como se alguém estivesse de pé atrás dela, sussurrando.

Ela se virou. Não havia ninguém. Só a noite, os montes de terra, e os pontos verdes que agora acendiam por todo o campo, em sincronia, formando uma linha que levava da frente dela até o centro do aglomerado. Um caminho de luz. Um convite que ela já havia aceito, sem perceber, no momento em que decidiu responder.

Marina nunca mais saiu do Parque Nacional das Emas. Não houve busca que a encontrasse, nem corpo, nem rastros. O que restou foram os arquivos de áudio e vídeo, guardados em um disco rígido que ninguém ousa abrir inteiro. Quem tenta, relata que os pontos verdes da gravação piscam em direção a quem assiste. E que, se você ficar parado olhando a tela por tempo suficiente, sua própria respiração começa a ser respondida — ponto a ponto, clique a clique — por algo que está do outro lado da imagem, esperando que você acenda a luz de volta.

## Fontes de inspiração

- "Anoitece e os cupinzeiros se enchem de pontos de luz em um parque do Cerrado", O Antagonista. Descreve a bioluminescência de larvas do vaga-lume Pyrearinus termitilluminans nos cupinzeiros do Parque Nacional das Emas, em Chapadão do Céu, Goiás, e o uso da luz verde para atrair insetos.
