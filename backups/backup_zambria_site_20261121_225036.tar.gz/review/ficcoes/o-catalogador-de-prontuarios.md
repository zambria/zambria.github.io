---
titulo: "O Catalogador de Prontuários"
resumo: "Um arquivista contratado para digitalizar os prontuários do antigo Colônia Hospitalar de Barbacena encontra um arquivo que não consta nos livros de entrada — e que acrescenta páginas novas todas as noites, escritas com a sua própria letra."
categoria: "sobrenatural"
data: "2026-11-21"
slug: "o-catalogador-de-prontuarios"
tipo: "ficcao"
fonte_pesquisa: "Folha de S.Paulo e El País — história do Hospital Colônia de Barbacena"
status: "pendente de curadoria"
---

# O Catalogador de Prontuários

O torreão do Museu da Loucura guarda o silêncio de um tipo específico — não o silêncio da ausência de som, mas o silêncio de coisas que foram ditas e ninguém mais ouve. Carlos entrou ali pela primeira vez em uma terça-feira de outubro, contratado por um edital de digitalização de documentos do antigo Hospital Colônia de Barbacena. Quarenta e dois anos, mãos firmes, currículo em arquivo morto de uma gráfica falida. O trabalho era simples: luvas de nitrilo, scanner de mesa, pastas de prontuários dos anos cinquenta aos oitenta, um disco externo para cada cinquenta nomes.

Ele sabia a história do lugar antes de pisar no térreo. O Colônia abriu em 1903 para duzentos leitos e chegou a abrigar cinco mil pessoas. Mais de sessenta mil morreram ali entre frio, fome, diarreia e eletrochoque. Setenta por cento dos internos não tinha qualquer doença mental. Corpos eram vendidos a faculdades de medicina; quando não havia comprador, eram banhados em ácido no pátio, diante dos outros internos. Carlos leu as reportagens. Achava que aquilo o preparava. Não o preparou para o cheiro do papel — mofo, nicotina antiga, umidade de paredes que nunca secam de verdade na região das Vertentes mineiras.

Sua mesa ficava de frente para a escada de caracol do torreão, onde um quadro emoldurado explica ao turista comum que ali ficava a prisão disciplinar do manicômio. Os turistas saem às cinco. Carlos fica até as oito, às vezes mais, sozinho no andar dos arquivos. Apenas o zelador passa pelo corredor a cada hora, com a lanterna fraca e os passos arrastados de quem aprendeu a não esperar resposta quando bate nas portas.

A ruptura começou na segunda semana, com a pasta preta.

Não havia número de registro no lombo. Não constava nos livros de entrada nem no inventário digital que Carlos atualizava a cada fim de dia. Ele a encontrou empurrada para o fundo de uma prateleira de metal, atrás dos prontuários de 1963, como se alguém a tivesse colocado ali de costas, no escuro. Dentro, um único prontuário: Antônia S., internação em 14 de março de 1963, diagnóstico em branco, assinatura do responsável ilegível, carimbo do hospital rasurado. Uma fotografia em branco e preto grudada na primeira página: uma mulher jovem, olhos arregalados, sem sorriso, cabelo preso com um pente que parecia arrancar a pele da testa.

Carlos digitalizou as páginas, nomeou o arquivo com o padrão do edital e moveu-o para a pasta de exceções. Fez anotação no caderno de mão: pasta sem número, possível duplicidade. Terminou o turno e saiu.

Na manhã seguinte, a pasta preta estava sobre a mesa dele. Não na prateleira. Sobre a mesa, exatamente onde ele deixara o scanner na noite anterior. Dentro, duas páginas novas, escritas à mão, tinta preta sobre papel não ofuscado pelo tempo. Um relato da "agitação noturna" da paciente Antônia, datado de cada noite da semana passada, com descrições precisas do corredor, da luz do corredor, do barulho da descarga no banheiro do andar de cima. Carlos não escreveu aquelas páginas. Conferiu o registro de entrada do torreão: ninguém assinou depois dele na véspera. Conferiu com o zelador, que negou ter mexido em arquivos. O zelador não olhou nos olhos dele enquanto falava.

Na terceira noite, as páginas descreviam Carlos.

O scanner ligado às dez e vinte. O copo de café frio deixado sobre o radiador. A forma como ele passa o polegar sobre a folha antes de fechá-la, para afastar a poeira. Detalhes que ninguém notaria, detalhes que ele mesmo não sabia que repete. A caligrafia, inicialmente desigual, foi se tornando familiar. Era a dele. Ou algo copiado com tamanha paciência que a diferença já não importava.

Carlos passou a chegar mais cedo. Passou a trancar a porta do arquivo por dentro com o cinto do casaco, gesto inútil que o acalmava por uns minutos. Na quarta semana encontrou o próprio prontuário.

Carlos M., nascido em data que não conferia com a sua carteira de identidade, internação prevista para o dia seguinte. Diagnóstico: "alucinações sistêmicas; erosão progressiva da fronteira entre o observador e o observado". Fotografias anexadas: ele dormindo em sua casa, a janela do quarto dele, a fachada do prédio onde mora, a mesa do arquivo com o scanner ligado — imagens tiradas de ângulos que nenhum visitante do museu ocupa, em datas que ainda não haviam chegado. A última foto, carimbada com a data de amanhã, mostrava ele próprio sentado nesta mesma mesa, de costas, olhando para a pasta preta.

Ele tentou sair. A porta do torreão estava trancada do lado de fora, chave virada duas vezes, e o zelador não respondeu às batidas. O telefone da mesa não tinha linha desde o dia em que chegou. Carlos pegou a caneta da mesa — a sua caneta, esferográfica azul — e a tinta que saiu ao escrever seu nome no caderno de ponto era preta, quase seca, como se a caneta já tivesse escrito muito mais do que parecia.

Na manhã seguinte, o estagiário que o substitui encontrou o scanner ligado, as pastas organizadas em pilha sobre a mesa, e uma pasta preta nova na caixa de exceções. Dentro, um prontuário quase em branco: apenas o nome dele, a data de internação marcada para a semana que vem, e uma linha assinada em caligrafia que não era a de ninguém que ainda trabalhava ali.

O arquivo do Colônia nunca para de crescer. Alguns internos nunca saíram do torreão. Mudam apenas de função — de paciente para guardião, de guardião para catador de papéis, de catador para prontuário. Carlos ainda está lá, embora o edital de digitalização tenha terminado na sexta-feira. Quem passar pelo museu depois do horário e olhar para a janela do torreão vai ver uma luz acesa, e alguém sentado de costas, escrevendo um nome que ainda não sabe que é o próprio.

## Fontes de inspiração

Folha de S.Paulo, "O que aconteceu no Hospital Colônia de Barbacena?" — histórico da instituição: fundada em 1903, mais de sessenta mil mortos, pacientes internados sem doença mental, corpos vendidos a faculdades de medicina e banhados em ácido no pátio.

El País, "Barbacena, a cidade-manicômio que sobreviveu à morte atroz de 60.000 brasileiros" — contexto do Colônia, do Museu da Loucura e da transformação do torreão em espaço de memória.

Todos os personagens, documentos e eventos desta narrativa são fictícios. As fontes acima serviram apenas como inspiração de atmosfera e contexto histórico; nada delas foi reproduzido.