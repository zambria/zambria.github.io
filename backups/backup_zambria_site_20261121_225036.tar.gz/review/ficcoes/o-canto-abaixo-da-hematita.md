---
titulo: "O Canto Abaixo da Hematita"
resumo: "Um gravador de campo vai a uma mina desativada de Catas Altas registrar o zumbido natural do minério de ferro. Na fita, algo responde — com o nome dele."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-canto-abaixo-da-hematita"
tipo: "ficcao"
fonte_pesquisa: "Estado de Minas; Super/Abril"
status: "pendente de curadoria"
---

O primeiro indício de que algo estava errado não foi um som. Foi a ausência dele.

Elias desceu do carro no entardecer de um sábado de outubro, com o porta-malas cheio de gravadores, microfones de contato e baterias, e notou que o silêncio da estrada de terra não tinha textura. Nem grilo, nem folha arrastada pelo vento, nem o chilrear de algum pássaro inquieto no ipê seco do caminho. Só a poeira subindo nos solas das botas e o cheiro forte de minério úmido vindo do buraco à frente. A mina estava desativada há décadas — um antigo poço de extração de manganês e ferro nas redondezas de Catas Altas, na Serra do Caraça, onde, segundo os moradores mais velhos, a rocha canta sozinha quando a pressão atmosférica muda. Elias não foi lá por crença. Foi por áudio. Queria captar o chamado infrassônico que geólogos associam à concentração de hematita e magnetita no solo mineiro, um zumbido abaixo dos vinte hertz que o ouvido não distingue, mas que o corpo sente no estômago.

O porteiro — um catador aposentado chamado Severo, de mãos enrugada como casca de árvore — não ofereceu boa noite. Entregou a chave do portão e disse apenas: "Não grave depois das três. A pedra não gosta de ser ouvida naquela hora." Não sorriu. Elias agradeceu, guardou a chave e seguiu andando.

Instalou o equipamento na boca do poço número sete, o mais fundo dos registrados na planta caducada que arrancara da prefeitura. Montou os microfones direcionais em tripés de alumínio, ligou o gravador de campo e fez um teste de nível. O fone revelou um ruído grave e contínuo, como um motor distante funcionando a quilômetros de distância, ou como se a própria terra respirasse com dificuldade. Não era vento. O ar estava parado. Elias anotou no caderno de campo: "17h42. Frequência de fundo instável, entre dezenove e vinte e dois hertz. Origem: desconhecida."

Enquanto esperava o crepúsculo fechar, conversou com Severo na varanda de madeira da casebre de apoio. O homem falou de garimpeiros que desciam nos anos cinquenta e nunca subiam, de relatórios que sumiam da prefeitura, de uma inundação subterrânea em Mariana, cidade vizinha, que matara dezessete pessoas em trinta e seis — sinos e correntes que os turistas ainda dizem ouvir nas galerias vazias da Mina da Passagem. Elias ouviu com a educação de quem coleciona histórias, mas acreditava na física. O som vinha da rocha, da água nos filões, da dilatação térmica do minério. Nada mais.

Às duas da madrugada, despertou no banco de trás do carro com os fones ainda nos ouvidos. O gravador estava ligado. O display marcava trinta e dois minutos de gravação contínua que ele não lembrava de ter iniciado. O horário: 03h07. Severo tinha avisado.

Elias rewound a fita. Ouviu o zumbido conhecido, então uma pausa, e então uma voz.

Não era uma gravação limpa. Soava como se alguém falasse dentro de um tubo cheio de água, arrastando as sílabas através de camadas de pedra. Dizia o nome dele. Elias. Com o sotaque arrastado do interior, com a brevidade de quem chama alguém para entrar.

Ele parou o playback, tirou os fones, olhou para o poço negro à sua frente. A noite estava imóvel. Nenhum grilo. Nenhum vento. Só o cheiro de ferro úmido e a sensação, subitamente nítida, de que algo abaixo daqueles seus pés havia parado de cantar para começar a falar.

Fez o que um gravador de campo não deveria fazer: desceu.

Levou um fone, uma lanterna de mão e o gravador ligado no bolso do casaco. A escada de ferro estava enferrujada, os degraus quebrados em pontos alternados, como se alguém tivesse arrancado pedaços dela com força bruta. A cada passo, o eco dos seus próprios passos voltava distorcido, mais lento, como se a rocha mastigasse o som antes de devolvê-lo. A temperatura caiu. As paredes, cobertas de camadas vermelhas de hematita, pareciam pulsar à luz fraca da lanterna — não de luz, mas de som: uma vibração baixa que subia pelos pés e se instalava no peito.

A meio caminho, o gravador no bolso apitou. Algo havia acionado o modo de gravação por voz. Elias parou, encostado à parede úmida, e ouviu através da rocha um ruído que não era de água, nem de pedra se movimentando. Era respiração. Lenta, profunda, de pulmões maiores que os humanos.

Subiu o restante do caminho correndo.

No topo, o céu ainda estava escuro, mas o silêncio havia mudado. Agora ele tinha peso. Elias ligou o carro, colocou o gravador no banco do passageiro e dirigiu de volta para a cidade, ouvindo apenas o motor. Não parou para anotar nada. Não olhou para trás.

Em casa, às seis da manhã, transferiu o áudio para o computador. A onda do arquivo das três da madrugada mostrava um padrão estranho: picos regulares, quase musicais, distribuídos ao longo de toda a fita. Não era ruído de equipamento. Não era vento. Elias colocou os fones de estúdio e apertou play.

O zumbido começava baixo, quase imperceptível, e então a voz vinha — mais clara desta vez, como se a fonte se aproximasse do microfone. Dizia o nome dele. Depois dizia outra coisa, mais difícil de decifrar, uma frase em português com as palavras emboladas: "está embaixo" ou "está voltando". Ele não conseguiu ter certeza. O que o arrepou não foi o conteúdo. Foi o fato de que, nos segundos finais da gravação, por trás da voz, havia um segundo som: o barulho de uma porta de metal pesada sendo aberta, lenta e rangente, muito abaixo dele.

Elias desligou o gravador. Ficou sentado no escuro do quarto, ouvindo o silêncio do apartamento. O zumbido, agora, estava dentro dele. Não nos ouvidos. No peito. Como se a hematita da mina tivesse viajado nas ondas de gravação e se alojado nos ossos dele.

Antes de deitar, fez uma última coisa. Abriu um novo projeto no software de áudio, criou uma faixa vazia e deixou o microfone do computador ligado, apontado para o cômodo, gravando o silêncio. Precisava provar para si mesmo que o som ficara ali embaixo, na serra, nas camadas de minério que não pertenciam ao mundo dos vivos.

Deixou o aparelho rodando e foi tomar água.

Quando voltou, cinco minutos depois, o software mostrava a faixa preenchida. Uma onda grossa e contínua, entre dezenove e vinte e dois hertz. E, no meio dela, uma palavra curta, dita com a própria voz de Elias — uma voz que ele não lembrava de ter gravado:

"Volto já."

Elias não apagou o arquivo. Não ligou para ninguém. Foi para a cama, deitou de frente para o teto, e passou a noite inteira ouvindo o próprio corpo responder, abaixo dos ouvidos, na frequência que o ouvido não distingue: o canto da montanha, agora também o canto dele, e a certeza fria de que algo abaixo do asfalto, abaixo da cidade, abaixo do seu piso de concreto, tinha aprendido o nome dele e estava subindo devagar, escada a escada, para conferir se a porta ainda estava aberta.

## Fontes de inspiração

- Estado de Minas, "O chão que grita e a santa que caminha: os mistérios subterrâneos de Minas" — relato sobre a ressonância ferrosa da Serra do Caraça, em Catas Altas, associada a concentrações de hematita e magnetita, e ao "canto da montanha" ouvido em dias de vento ou mudança de pressão.
- Super/Abril, "Lugares assombrados do Brasil, parte 5: Mina da Passagem" — histórico da mina de ouro de Mariana (MG), inundação subterrânea de 1936 com dezessete vítimas e relatos de sinos e correntes ouvidos em galerias vazias.

Ambas serviram apenas como inspiração de cenário e fenômeno; personagens, enredo e reviravolta são fictícios.
