---
titulo: "O Escuro Entre as Luzes"
resumo: "Uma pesquisadora documenta luzes misteriosas em um vale remoto e descobre que o fenômeno não são as luzes, mas o escuro que as separa."
categoria: "fenomenos-naturais"
data: "2026-11-21"
slug: "o-escuro-entre-as-luzes"
tipo: "ficcao"
fonte_pesquisa: "Fenômeno Hessdalen (Wikipédia e CNN Brasil) — luzes inexplicáveis no vale da Noruega"
status: "pendente de curadoria"
---

O vale não se anuncia. Não há placa na estrada de terra batida, nenhuma seta no asfalto quebrado, nenhuma luz na curva que sobe para o planalto. Cheguei no fim da tarde, o porta-malas carregado de câmeras, gravadores e medidores de luz, e a primeira coisa que me atingiu foi o silêncio — não o silêncio comum de um lugar despovoado, mas o silêncio de um local que parece ter aprendido a reter o som, como se o ar estivesse segurando a respiração.

Não uso meu nome verdadeiro. Chame-me de Clara. Serve para esta noite, e para as que virão.

Fui ao vale para documentar as luzes.

Elas aparecem sem aviso, há décadas, segundo os poucos moradores que ainda falam com forasteiros. Pontos brilhantes, brancos ou amarelos, às vezes avermelhados, que pairam acima do terreno, se dividem, se fundem ou desaparecem de repente. Não fazem barulho. Não queimam o solo. Não deixam rastro. Cientistas já passaram por aqui com aparelhos caros e foram embora com teorias incompletas — correntes elétricas na crosta, gases ionizados, uma espécie de bateria natural formada por rochas e água. Nenhuma explicação fecha. Eu não vim fechar explicações. Vim registrar o que acontece quando o céu deixa de ser cenário e se torna palco.

Montei o acampamento na borda do vale, onde a vista é mais aberta. Primeira noite: nada. Segunda noite: duas luzes, uma branca sobre a crista da colina, outra amarela mais baixa, perto dos troncos de pinheiro. Elas permaneceram imóveis por cerca de quarenta minutos, depois sumiram ao mesmo tempo, como se alguém tivesse desligado um interruptor em dois pontos distintos.

Terceira noite, algo mudou.

Comecei a notar o intervalo. Não entre uma luz e outra no céu, mas entre o fim de uma aparição e o início da seguinte — o escuro que as separa. Pela gravação de áudio, aquele escuro não é vazio. O vale costuma ter grilos, vento nas folhas, o chiado distante de algum animal. Nos segundos que separam as luzes, tudo isso pára. Não é silêncio fraco: é ausência. Áudio sem frequência alguma, um buraco no som.

Levei as gravações para o computador e cruzei os dados. As luzes ocorrem sempre nas bordas de um silêncio que se repete a cada onze minutos e treze segundos, com precisão de despertador. No espectro, esse silêncio tem estrutura: picos regulares, como uma batida demasiado lenta para ser ouvida. As luzes não se movem através da escuridão. Elas são interrupções nela. A escuridão é o contínuo. As luzes são furos.

Passei a observar o escuro em vez das luzes.

Sentei na cadeira de lona com a câmera apontada para o ponto mais escuro do vale, deixando o visor coberto de fita preta para que apenas o contraste entre sombra e sombra fosse registrado. Na quarta noite, as luzes não vieram. O silêncio de onze minutos se estendeu por horas. O ar ficou pesado, e pela primeira vez senti que algo estava me observando do fundo do poço — não um poço físico, mas o próprio vale, profundo, paciente, disposto a esperar que eu piscasse.

Quinta noite. Fiquei do lado de fora da cabine, sem lanterna, deixando os olhos se habituarem. As luzes apareceram: primeiro uma, branca, depois outra, vermelha fraca, depois uma terceira que se dividiu em duas antes de se apagar. Todas nas bordas dos silencios. Contava em voz baixa, gravando a própria voz para não perder a conta: um, dois, três, quatro, cinco... Quando cheguei a dezenove, o padrão se inverteu. As luzes começaram a aparecer no centro do escuro, não nas bordas, e o silêncio entre elas alongou-se até quase um minuto. Nesse minuto, vi o escuro se mover. Não era nuvem, não era neblina. Era um recuo da própria noite, como se algo estivesse se aproximando da linha entre o visto e o não visto.

Na sexta noite, as luzes pararam completamente.

Esperei até o amanhecer. Nada. Desliguei os equipamentos, guardei as fitas, fechei a cabine. Ao passar a mão na porta do carro, percebi que tremia. Não de frio. De reconhecimento.

Sétima noite. Voltei ao mesmo ponto, sem câmera, sem gravador. Apenas eu e o vale. Esperei. Os minutos passaram. Não houve luz nenhuma. Então fechei os olhos.

E continuei vendo-as.

Não era imagem residual. Não era cansaço da retina. Com os olhos fechados, via a sequência exatamente como a tinha registrado: escuro, luz, escuro, luz, o intervalo de onze minutos batendo dentro das próprias pálpebras. As luzes não estavam mais no vale. Ou estavam, e eu havia aprendido a enxergá-las do outro lado daquilo que as separa.

Desliguei o último gravador na manhã seguinte. Deixei o equipamento no banco do passageiro e dirigi de volta pela estrada de terra. No espelho retrovisor, o vale desapareceu atrás de uma curva que não existia na ida. Não sei se as luzes ainda aparecem por ali. Não sei se alguém mais as vê. Sei apenas que agora, quando apago a luz do quarto e deixo o escuro se instalar, entro na contagem. Um. Dois. Três. O escuro entre as luzes está aprendendo a respirar no meu ritmo, e eu ainda não descobri se sou eu quem conta os intervalos, ou se sou o intervalo que alguém está contando.

## Fontes de inspiração

- "Fenômeno Hessdalen", Wikipédia — luzes brancas e amarelas no vale de Hessdalen, Noruega; ausência de som e de marcas no solo; hipótese de bateria natural formada por minerais e água.
- CNN Brasil, "Vale de Hessdalen: o enigma luminoso que intriga cientistas há décadas" — relatos de luzes sem causa aparente, hipóteses em investigação, mistério sem solução confirmada.
