---
titulo: "O Laudo da Frequência 19"
resumo: "Um laudo de insalubridade por ruído em uma estação de bombeamento desativada registra um tom de 19 hertz constante — sem maquinário em funcionamento para explicá-lo."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-laudo-da-frequencia-19"
tipo: "ficcao"
fonte_pesquisa: "Infrasom de 19 Hz (frequência do medo, Vic Tandy); NR-15 — ruído ocupacional (gov.br)"
status: "pendente de curadoria"
---

O medidor de nível de pressão sonora não mentia, mas também não fazia sentido.

Apoiado no tripé de fibra de carbono no centro da sala de máquinas da Estação de Bombeamento São Miguel — desativada desde 1998, sem motor em funcionamento, sem bomba girando, sem ventilador ligado —, o aparelho marcava 52 dB(A) de ruído contínuo, com um pico agudo abaixo dos vinte hertz. Dezessete ponto oito, na primeira medição. Dezenove ponto um, na segunda. Dezenove ponto quatro na terceira. Eu havia sido contratado para assinar um laudo de rotina, NR-15, insalubridade por ruído. Saí dali com a certeza de que havia assinado algo muito mais velho que o formulário.

A estação fica na borda da serra, a uns trinta quilômetros da cidade, construída nos anos 1940 para bombear água de um aquífero profundo até o reservatório da parte alta. Desligaram as máquinas quando o aquífero secou — ou quando o poço colapsou, dependendo de quem conta a história. O prédio permanece em pé: concreto úmido, azulejos descolando, um cheiro permanente de ferro velho e terra saturada. Fui sozinho, como costumo ir. Tinha um colete, um capacete, um medidor de classe 2 e um caderno de campo. Nada disso o preparou para o que o medidor mostrava.

A NR-15 determina que os níveis de ruído contínuo ou intermitente sejam medidos em decibéis, circuito de compensação A, resposta lenta, com as leituras feitas próximas ao ouvido do trabalhador. Também estabelece que não se deve expor ninguém a níveis acima de 115 dB(A) sem proteção adequada. A norma não fala de dezenove hertz. A norma não fala de frequências abaixo do limiar da audição que não vêm de máquina alguma. A norma não fala do que acontece quando o trabalhador mede um som que não existe no papel, mas existe no peito.

Comecei pelo piso térreo. O medidor subiu para cinquenta e dois dB(A) sem que eu encontrasse a fonte. Não havia vento pelas janelas quebradas, não havia gotejamento constante, não havia o zumbido de transformador nas caixas de energia — todas desligadas, cadeados enferrujados. O que havia era um tom grave, contínuo, que eu sentia mais do que ouvia: uma pressão nos tímpanos, um leve zumbido atrás dos olhos, o pêlo do braço eriçado sem motivo. Andei pelos corredores. O tom não diminuía nem aumentava. Era o mesmo na sala de comandos, no escritório do administrador, na escada de serviço. Um tom de dezenove vírgula quatro hertz, estável, como se o prédio inteiro vibrasse numa única nota.

No porão, encontrei o caderno do antecessor. Laerte M., último técnico a assinar um laudo na estação, em junho de 1997. As páginas iniciais são limpas: leituras de trinta e dois, trinta e cinco dB(A), observações padrão sobre vedação de portas e isolamento de tubulações. Então a caligrafia muda. Nas últimas páginas, Laerte escreve que o som não para quando a gente sai da sala. Que ele mediu dezenove hertz em três pontos diferentes e nenhum dos aparelhos da estação consegue produzir aquilo. Que o som vem das paredes. A última frase está interrompida, como se a caneta tivesse sido tirada da mão dele no meio da palavra: "o som está".

Saí do porão com o coração acelerado, sem conseguir dizer se era medo ou apenas a resposta do corpo a uma frequência que ressoa próximo ao globo ocular e à caixa torácica. Pesquisas sobre infrasom documentam que dezenove hertz — o chamado tom do medo — podem produzir suor frio, calafrios, pressão no peito e, em visão periférica, formas cinzentas que somem quando você vira a cabeça para olhar. O próprio corpo, vibrando naquela frequência, engana os olhos. Eu sabia disso intelectualmente. No porão da estação, o intelectual não valeu de nada.

Voltei à sala de máquinas para a medição final. O medidor agora marcava cinquenta e seis dB(A). Dezenove ponto seis hertz. Subira durante as duas horas que passei ali dentro. Coloquei os fones de ouvido protetores, não para bloquear o som — infrasom não se bloqueia com espuma — mas para ter algo entre os ouvidos e o silêncio. Foi então que percebi: o tom não vinha de dentro da estação. Ou melhor, não vinha só de lá. O prédio não estava gerando dezenove hertz. O prédio estava captando. Como uma antena de concreto e ferrugem, a estação estava sintonizada numa frequência que vinha de fora, de baixo, de algum lugar que o laudo não tinha campo para descrever.

Fechei o caderno. Desliguei o medidor. Desci as escadas e entrei no carro com a porta do lado do motorista aberta atrás de mim, como se algo estivesse prestes a entrar junto. Na estrada de volta, o silêncio do habitáculo era apenas um silêncio aparente. O tom continuava, agora mais baixo, mais interno. Naquela noite, em casa, deixei o gravador ligado no quarto enquanto dormia. O arquivo da manhã seguinte mostra picos de dezenove vírgula seis hertz às três e dezessete minutos, exatamente quando acordei com a certeza de que algo estava no pé da cama, vendo eu dormir, algo que não tinha forma porque o globo ocular vibrava na frequência certa para apagar as bordas do escuro.

Assinei o laudo. O laudo, no entanto, não assinou só a estação. Assinou quem o leu. E dezenove hertz não precisa de bomba, de motor ou de ventilador para continuar tocando. Precisa apenas de um ouvido que aprendeu a ouvi-lo.

## Fontes de inspiração

1. "Haunted Circuits: the Sound of Fear" (Perfect Circuit) — relato do engenheiro Vic Tandy sobre a onda estacionária de infrasom próximo a 19 Hz em um laboratório e em porões de Coventry, associada a sensações de presença, calafrios e figuras cinzentas na visão periférica.
2. NR-15 — Atividades e Operações Insalubres (gov.br) — normas sobre medição de ruído ocupacional em dB(A), circuito de compensação A, resposta lenta e limites de exposição diária.
