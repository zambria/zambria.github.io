---
titulo: "Os Quadros que o Ácido Não Apagou"
resumo: "Um restaurador de filmes antigos descobre, nos quadros de rolos de 16 mm gravados dentro do Hospital Colônia de Barbacena, figuras que não existiam no momento da filmagem — e que começam a sair da película."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "os-quadros-que-o-acido-nao-apagou"
tipo: "ficcao"
fonte_pesquisa: "Folha de S.Paulo; Wikipédia – Hospital Colônia de Barbacena"
status: "pendente de curadoria"
---

A noite não chegava ao laboratório de restauração do Museu da Loucura; ela apenas se instalava, como um inquilino que nunca pede licença. Daniel trabalhava sozinho, na sala fria onde os rolos de 16 milímetros do Hospital Colônia de Barbacena esperavam ser salvos da própria decomposição. Fora da janela, a cidade de Minas Gerais respirava o silêncio de quem já viu demais. Dentro, o único som era o zumbido constante do refrigerador de arquivamento e o clique mecânico do escâner de quadro a quadro.

Ele fora contratado para digitalizar o que restou dos filmes institucionais gravados entre os anos 1950 e 1970 dentro do Colônia, o maior hospício do Brasil, conhecido pelos registros como "Cidade dos Loucos" e, nos anos mais sombrios, como o "Holocausto Brasileiro". Documentos oficiais apontam que aproximadamente 24 mil pessoas morreram ali entre 1942 e 2020; a maioria nunca teve diagnóstico de doença mental. Homossexuais, mulheres grávidas fora do casamento, mendigos, epiléticos, presos políticos — todos rejeitados pela sociedade, entregues ao abandono. Os cadáveres, quando o cemitério não tinha mais espaço, eram banhados em ácido no pátio para que a carne se soltasse dos ossos, e os esqueletos vendidos às faculdades de medicina. A prática tinha nome entre os funcionários: "desencarnar" os mortos.

Daniel não acreditava em fantasmas. Acreditava em emulsão, em prata, em gelatina que encolhe com o tempo. Seu trabalho era técnico: limpar, estabilizar, digitalizar quadro por quadro, preservar o que ainda dava para ver. Até que, na terceira semana, notou algo que o escâner não deveria revelar.

No rolo datado de setembro de 1968, filmado no pátio central, apareceu uma figura parada ao lado da cisterna de concreto. Não era um funcionário, nem um interno registrado na lista de figurantes. Era uma silhueta de branco, imóvel, de frente para a câmera, cujos braços pendiam muito além do natural. Daniel passou o quadro novamente no negativo original. Nada. Nada no filme físico. A figura existia apenas na imagem digital, nascida do algoritmo de recuperação de detalhes do escâner, como se a matéria do rolo guardasse algo que o olho humano não podia ver.

Ele atribuiu a um defeito do sensor. Um artefato de compressão. Uma poeira na lente. Passou os dias seguintes ignorando o assunto, mas as figuras voltaram.

No rolo de fevereiro de 1971, duas silhuetas brancas caminhavam no pátio, não em direção à câmera, mas paralelamente à parede, sempre a exatamente vinte e três quadros de distância da borda. No de outubro de 1973, cinco. No último rolo que restou, gravado semanas antes do início da desativação, em 1979, doze figuras se amontoavam no pátio, algumas com a cabeça inclinada em ângulos impossíveis, outras sem traços no rosto — apenas o branco da emulsão onde deveria haver olhos e boca.

Daniel começou a assistir aos filmes inteiros, não apenas os trechos selecionados pelos arquivistas. Percebeu que as figuras não se moviam como pessoas. Elas se moviam como químicos: apareciam onde o solo estava mais úmido, onde o cheiro de ácido ainda poderia estar impregnado no concreto, décadas depois. Elas estavam no lugar exato onde os corpos haviam sido "desencarnados".

Uma noite, depois das duas da manhã, ele encontrou o quadro que mudou tudo. Era de um rolo sem data, rotulado apenas com o número 413. Na imagem, um interno de jaleco rasgado segurava uma câmera de volta para si, apontando a lente para o próprio rosto. Só que o rosto não era dele. Era o rosto de Daniel. Mesmo nariz torto, mesma cicatriz na sobrancelha esquerda, mesma expressão de quem reconhece algo terrível e ainda não entende o que é.

O registro de internação da mãe de Daniel, desaparecida em 1974, estava no arquivo do museu. Ela fora levada ao Colônia por um parente que nunca mais quis falar do assunto. Não havia prontuário completo. Apenas uma ficha, assinada à pressa, e a data de óbito: 12 de março de 1974. Causa: parada cardíaca. Sem necrópsia. Sem entrega do corpo à família.

Daniel passou a noite inteira cruzando as imagens. No quadro seguinte ao seu próprio rosto, uma das figuras brancas — a que faltava o queixo — olhava diretamente para a lente. Não para a câmera do filme, mas para a câmera do escâner, para o lugar onde Daniel estava sentado, naquele instante exato, na sala fria de Barbacena.

Ele fechou o programa. Desligou o computador. A tela permaneceu azul por mais três segundos depois do botão de energia. Quando finalmente escureceu, ele ouviu o som.

Não era um barulho do prédio. Não era o encanamento. Era o clique mecânico do escâner, avançando um quadro, sozinho, no escuro.

Daniel se levantou. O laboratório estava imerso na escuridão total, exceto pela luz vermelha do equipamento de digitalização, que piscava em intervalos regulares. Ele caminhou até o escâner. A mesa de leitura estava vazia. Nenhum rolo carregado. Nenhum filme passando pelos rolamentos. Mas o som continuou: clique. Clique. Clique.

Ele abriu a tampa do escâner. Sobre o vidro de leitura, úmido, havia uma única impressão: a marca de um dedo, ou de algo com a forma de um dedo, pressionado contra a superfície. O cheiro que subiu do vidro não era de produto de limpeza. Era o cheiro de concreto úmido, de ácido velho, de algo que esteve submerso por tempo demais.

Daniel recuou. Na parede oposta, a tela do monitor se acendeu sozinha. Não havia sinal de vídeo. Não havia arquivo aberto. Apenas uma imagem, preta e branca, granulada: o pátio do Colônia, à noite, iluminado por uma única lâmpada pendente. Doze figuras brancas estavam paradas em volta da cisterna, imóveis. E no centro do grupo, agora, estava uma décima terceira figura — menor, de vestido rasgado, cabelos curtos, o rosto virado para a tela, para ele.

Ela não saiu do filme. Ela nunca esteve dentro dele. O filme era apenas a sala de espera, o lugar onde as coisas que não foram enterradas direito esperam que alguém olhe o bastante para notar que estão olhando de volta.

Daniel desligou o monitor. Deixou o laboratório. Não fechou a porta atrás de si, porque não houve tempo. No corredor, o cheiro de ácido era mais forte do que nunca, e as luzes, uma a uma, se apagaram na direção oposta à sua fuga — como se algo estivesse andando atrás dele, acendendo o caminho só para ter certeza de que ele ainda estava sendo seguido.

Ele não voltou ao museu. Os rolos 16 milímetros do Colônia continuam lá, no arquivo frio, aguardando um novo restaurador. E se você pedir para ver o rolo 413, o arquivista vai dizer que não existe. Vai dizer que o número foi riscado do catálogo. Não acredite. O rolo existe. E, se você assistir até o último quadro, vai ver que as figuras já não estão no pátio. Elas estão do lado de fora da imagem, paradas na borda do quadro, olhando para quem assiste, esperando que alguém apague a luz para, finalmente, entrar na sala.

## Fontes de inspiração

Consulta pública limitada a registros jornalísticos e enciclopédicos sobre o Hospital Colônia de Barbacena, usados apenas como referência de atmosfera e contexto histórico. Nenhum trecho foi copiado dessas fontes.

1. Folha de S.Paulo — "Hospital símbolo do 'Holocausto Brasileiro' é fechado de forma definitiva em MG" (dados de internação e óbitos, histórico da instituição).
2. Wikipédia — "Hospital Colônia de Barbacena" (fundação em 1903, apelido "Cidade dos Loucos", estimativa de mortos, tráfico de corpos para faculdades de medicina).
