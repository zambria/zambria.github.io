---
titulo: "O Apito da Estação Fechada"
resumo: "Um ex-sinalheiro registra trens que não constam nos horários, até que um apito, na madrugada, responde de volta."
categoria: "contos-de-terror"
data: "2026-11-21"
slug: "o-apito-da-estacao-fechada"
tipo: "ficcao"
fonte_pesquisa: "Vitruvius — Arquiteturismo, estação ferroviária de Aureliano Mourão (inspiração apenas)"
status: "pendente de curadoria"
---

A estação fechou em dezembro de 1984. Foi o que dizia o documento amarelado que o novo administrador da linha me entregou na última sexta-feira de serviço: "Em dezembro de 1984 apitou e passou por ali o último trem. Não mais passaria por ali as belas locomotivas." Eu assinei o recibo, guardei a chave do gabinete de sinais e, contra todo bom senso, voltei na semana seguinte. Não voltei como funcionário. Voltei como quem não sabe mais onde guardar a própria solidão.

O prédio é triangular, erguido em 1940 sobre os alicerces da estação original de 1887. Fica entre dois municípios pequenos, às margens de um rio que os moradores chamam de Rio das Mortes. Não passo o dia lá. Chego ao entardecer, levo uma lanterna de pilha, um caderno de capa dura e uma caneta. Sento na banqueta de madeira do gabinete, diante do quadro de agulhas que nunca mais moveu um único trilho, e escrevo. Escrevo a hora, o número do trem, a direção, o peso que imagino ter a carga. Escrevo sobre o frio que sobe do assoalho e sobre o cheiro de óleo queimado que ainda gruda nas paredes, quarenta anos depois.

Nos primeiros dias, o caderno ficava em branco. Não havia trens. Não havia razão para haver. A ferrovia foi desativada, os trilhos recolhidos em parte, o restante deixado ao mato alto. Então, numa terça-feira, às três e dezessete da manhã, escrevi sem querer: "Trem 7, leste, passagem sem horário, luzes acesas." Não me lembro de ter movido a mão. A caneta simplesmente parou ali, tinta ainda úmida, letra firme, não a minha.

Não joguei o caderno fora. Guardei. Voltei na noite seguinte. Escrevi novamente, desta vez com intenção: apenas a data e a hora. Deixei a caneta sobre o papel e sentei no escuro, ouvindo o grilo do mato e o barulho da própria respiração. Às três e vinte e um, um apito. Longo, grave, metálico. Não vinha da estrada de ônibus perto da rodovia. Vinha da direção dos trilhos, ou de dentro deles. Saí do gabinete com a lanterna na mão. O feixe iluminou apenas cascalho, dormente quebrado, ervas daninhas. Nenhum farol. Nenhuma fumaça. O apito não se repetiu.

Voltei a sentar. Na página seguinte do caderno, uma nova linha aparecera: "Trem 7, leste, três e vinte e um, resposta ao sinal." Minha letra, novamente. Ou algo que a imitava com perfeição.

Comecei a esperar os apitos. Não mais saía cedo. Levei um cobertor, uma garrafa de água, um relógio de pulso que não atrasava. Nos dias seguintes, os trens passaram a ter frequência. Trem 11, oeste, carga não identificada. Trem 3, leste, sem vagões visíveis. Trem 9, direção indeterminada, passar ao longo da ponte. A ponte — aquela de madeira e pedra sobre o Rio das Mortes, a que a população chama de Ponte do Inferno. Conta-se que, nos anos da operação, um descarrilamento ali levou vagões e passageiros que nunca foram encontrados. Não há registros oficiais do acidente. Há apenas famílias que evitam passar pela ponte à noite e motoristas que dizem sentir o veículo puxar para o lado errado, como se algo, embaixo da madeira podre, quisesse o peso de volta.

No décimo segundo dia, o caderno mudou de tom. Não eram mais apenas registros. Eram instruções. "Apague a lanterna. Deixe a chave na fechadura. Sente-se na banqueta e não olhe para trás." Escrevi de volta, com a caneta trêmula: "Quem está escrevendo?" A resposta demorou minutos, ou talvez horas — no gabinete sem relógio de parede, o tempo se dilata. Então apareceu: "Quem está ouvindo."

Na décima quinta noite, decidi não escrever. Fui apenas para observar. Levei um gravador pequeno, daqueles que guardam vozes em fita fina. Coloquei sobre a mesa, liguei, apaguei a lanterna. Esperei. O silêncio do gabinete é denso: o tique-taque do relógio de pulso, a respiração, o vento nas janelas quebradas. Às três e dezessete — o mesmo horário do primeiro registro — o apito soou. Dessa vez próximo. Tão próximo que vibrou no peito, nos dentes, nos ossos do ouvido. Liguei o gravador novamente no minuto seguinte. Não capturei nada. Apenas o estalo da fita passando pelos cabeçotes e, no final, um sussurro que soou como meu próprio nome dito por uma garganta cheia de cascalho.

Voltei para casa sem abrir o caderno. Deixei-o sobre a banqueta, sob um pedaço de lona plástica. No dia seguinte, não consegui ficar longe. Voltei ao meio da tarde, com luz do sol, pensando que a claridade desfaria qualquer ilusão. O caderno estava aberto. Na última página, uma entrada em letra não minha: "Ex-sinalheiro, turno da noite, comparece ao chamado. Trem 7, oeste, última parada, você." Abaixo, um horário: hoje, à meia-noite. E abaixo disso, uma lista de nomes. O primeiro era o meu. Os seguintes, reconheci: o maquinista Carlos Alberto, o ferroviário Francisco Marques Sobrinho, Luis Henrique — Mamão. Nomes do documento de 1984. Nomes do último trem que nunca mais deveria passar por ali.

Não voltei à noite. Fui de manhã, com o caderno debaixo do braço e a intenção de queimá-lo no quintal de casa. Quando cheguei, o gabinete estava vazio. A banqueta, o quadro de agulhas, a lanterna, o cobertor — tudo sumido. O caderno estava em cima do trilho, exatamente sobre o ponto onde o dormente mais apodrece, aberto na página dos nomes. A tinta ainda estava úmida. O sol caía no horizonte e, pela primeira vez desde que comecei a ir à estação, ouvi o apito vindo da direção oposta à da ponte. Não era um apito de locomotiva. Era o sinal de partida, o mesmo que eu mesmo tocava, anos atrás, quando ainda acreditava que controlar os trilhos significava controlar o que neles viajava.

Não escrevi nada desta vez. Não houve tempo. O som dos passos sobre o cascalho não era o meu. Havia um segundo par, mais pesado, arrastando algo como corrente ou correnteza. Eu saí do gabinete devagar, sem correr — correr atrai, aprendi isso nos registros — e caminhei em direção à estrada, onde deixei o carro. A cada cem metros, o apito soava mais perto, não atrás de mim, mas à frente, como se o trem não viesse pela linha férrea e sim pela própria estrada de terra, pelos campos, pelo mato alto, vindo direto para onde eu estava.

O carro ligou na primeira tentativa. Dei ré, virei, acelerei. No espelho retrovisor, vi uma luz branca no fim do trecho de trilhos que ainda resta. Não se movia. Esperava. Deixei a estação no espelho até que a curva da estrada a escondeu. Nunca mais voltei. Guardei o recibo de 1984, a chave do gabinete e o medo em uma gaveta trancada. Às vezes, no meio da noite, acordo com a sensação de que alguém está anotando minha respiração em um caderno de capa dura. E penso, com a clareza fria de quem já entendeu demais: o último trem não passou pela estação em dezembro de 1984. Ele está passando agora. E eu, ao voltar na semana seguinte, me inscrevi no manifesto.

## Fontes de inspiração

Vitruvius — Arquiteturismo, "Do entroncamento ao esquecimento: a antiga estação ferroviária de Aureliano Mourão". Artigo sobre a estação inaugurada em 1887 pela Estrada de Ferro Oeste de Minas, desativada em 1984, e as narrativas locais em torno do Rio das Mortes e da Ponte do Inferno. Utilizado apenas como referência atmosférica; personagens, enredo e reviravolta são fictícios.
